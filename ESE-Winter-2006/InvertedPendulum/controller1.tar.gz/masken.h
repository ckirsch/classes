#ifndef _MASKEN_H_
#define _MASKEN_H_

#define MAX_ZEICHEN	30

extern void int2string_comfort(int data, unsigned char* pString, unsigned char format, unsigned char kommastellen);
extern void NumericUpDown(unsigned int* pValue, unsigned char mode, unsigned int lowerLimit, unsigned int upperLimit);

extern void maske_Main (void);


#define DIRECTION_LEFT  1
#define DIRECTION_RIGHT	0
#endif //_MASKEN_H_

