#include "main.h"
#include "controller.h"
#include <string.h>

#define DELAY_TIME 150
#define DEFAULT_SPEED 25
#define MAX_EING_FELD_NR_P2	3


unsigned int P_Param = 91;
unsigned int I_Param = 86;
unsigned int D_Param = 7;

// STEPPER Control
unsigned char ucStepperDirection;
unsigned int StepperCLimit = 2;	// 1 = 0,5 msec 	=>100 =^ 5 msec
unsigned char ucStepperEnable = 0;
int StepperKilometer = 1400;

unsigned char ucStepperHalf = 1;//halb
int StepperSpeed;
int direction = 0;	// 0=stopped, 1=positiv, -1=negativ
int lastCount = 0;	// Timer value, when value changed be changed (in 10ms)
int countSpeed = 0;	// Time difference betwee


unsigned char toggle=0;
unsigned char TEXT_STRING[10];
unsigned char colore = NORMAL;	
unsigned char sel_item = 0;


void maske_Main(void)
{
	if (MASKE_INIT != MASKENNUMMER)
	{
		MASKE_INIT = MASKENNUMMER;
		back_light_on(1);	
		Clear_Screen();
		
		Write_Text(X_KO+20,3,NORMAL,2,(unsigned char*)"Inverted Pendulum V1.00");
		Write_Text(X_KO,30,NORMAL,0,(unsigned char*)"Speed:");
		Write_Text(X_KO,45,NORMAL,0,(unsigned char*)"Position:");
		Write_Text(X_KO,60,NORMAL,0,(unsigned char*)"PendelMitte:");
		Write_Text(X_KO,75,NORMAL,0,(unsigned char*)"Step-size:");
		Write_Text(X_KO,90,NORMAL,0,(unsigned char*)"PendulumAngle:");
		Write_Text(X_KO+130,30,NORMAL,0,(unsigned char*)"Control Parameter");

		Write_Text(X_KO+20,120,NORMAL,0,(unsigned char*)"down");
		Write_Text(X_KO+200,120,NORMAL,0,(unsigned char*)"up");
		Write_Text(0,112,NORMAL,0,(unsigned char*)"dec");
		Write_Text(X_KO+218,112,NORMAL,0,(unsigned char*)"inc");
		Write_Text(X_KO+100,120,NORMAL,0,(unsigned char*)"START");
		Write_Text(X_KO+130,44,NORMAL,2,(unsigned char*)"P");
		Write_Text(X_KO+130,64,NORMAL,2,(unsigned char*)"I");
		Write_Text(X_KO+130,84,NORMAL,2,(unsigned char*)"D");
		Draw_Line(  0,109,240,109,1);
	
		UpdateDispFlag = 1;
		
	}
	
	
	UpdateDispFlag = 0;
	
	int2string_comfort(StepperSpeed,TEXT_STRING,5,0);
	Write_Text(X_KO+85,30,NORMAL,0,TEXT_STRING);						

	int2string_comfort(StepperKilometer,TEXT_STRING,5,0);
	Write_Text(X_KO+85,45,NORMAL,0,TEXT_STRING);						

	int2string_comfort(StepSize,TEXT_STRING,5,0);
	Write_Text(X_KO+85,75,NORMAL,0,TEXT_STRING);	
	
	int2string_comfort(PendulumAngle,TEXT_STRING,5,0);
	Write_Text(X_KO+85,90,NORMAL,0,TEXT_STRING);	


	if (Key_Down(TASTE_AB))	
	{
		UpdateDispFlag=1;
		if (EingabeFeldNr >= MAX_EING_FELD_NR_P2)
			EingabeFeldNr = 0;
		else 	
			EingabeFeldNr += 1;
	}
	
	if (Key_Down(TASTE_AUF))	
	{
		UpdateDispFlag=1;
		if (EingabeFeldNr >= 1)
			EingabeFeldNr -= 1;
		else 	
			EingabeFeldNr = MAX_EING_FELD_NR_P2;
	}

	switch (EingabeFeldNr)
	{
		case 0:
			NumericUpDown(&P_Param, 0, 0, 1000);// in 0,5 msec     =>2000 = 1 sec
			int2string_comfort(P_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,44,INVERS,2,TEXT_STRING);						
	
			int2string_comfort(I_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,64,NORMAL,2,TEXT_STRING);						
		
			int2string_comfort(D_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,84,NORMAL,2,TEXT_STRING);						

			int2string_comfort(PendelMitte+Sollverschiebung,TEXT_STRING,5,0);
			Write_Text(X_KO+85,60,NORMAL,0,TEXT_STRING);						
			break;
		case 1:
			NumericUpDown(&I_Param, 0, 0, 1000);// in 0,5 msec     =>2000 = 1 sec
			int2string_comfort(P_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,44,NORMAL,2,TEXT_STRING);						
	
			int2string_comfort(I_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,64,INVERS,2,TEXT_STRING);						
		
			int2string_comfort(D_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,84,NORMAL,2,TEXT_STRING);						

			int2string_comfort(PendelMitte+Sollverschiebung,TEXT_STRING,5,0);
			Write_Text(X_KO+85,60,NORMAL,0,TEXT_STRING);						
			break;
		case 2:
			NumericUpDown(&D_Param, 0, 0, 1000);// in 0,5 msec     =>2000 = 1 sec
			int2string_comfort(P_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,44,NORMAL,2,TEXT_STRING);						
	
			int2string_comfort(I_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,64,NORMAL,2,TEXT_STRING);						
		
			int2string_comfort(D_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,84,INVERS,2,TEXT_STRING);						

			int2string_comfort(PendelMitte+Sollverschiebung,TEXT_STRING,5,0);
			Write_Text(X_KO+85,60,NORMAL,0,TEXT_STRING);						
			break;

		case 3: 	
			int2string_comfort(P_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,44,NORMAL,2,TEXT_STRING);						

			NumericUpDown(&PendelMitte, 0, 1050, 1070);// in 0,5 msec     =>2000 = 1 sec
			int2string_comfort(PendelMitte+Sollverschiebung,TEXT_STRING,5,0);
			Write_Text(X_KO+85,60,INVERS,0,TEXT_STRING);						
	
			int2string_comfort(I_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,64,NORMAL,2,TEXT_STRING);						
		
			int2string_comfort(D_Param,TEXT_STRING,5,0);
			Write_Text(X_KO+170,84,NORMAL,2,TEXT_STRING);						
			break;
		default:
			break;
	
	}


						
	if (Key_Down(TASTE_ON_OFF))		
	{
		if (ucStepperDirection == DIRECTION_LEFT)
			ucStepperDirection = DIRECTION_RIGHT;
		else
			ucStepperDirection = DIRECTION_LEFT;
	}

	if (Key_Down(TASTE_STOP))
	{
		if (ucStepperHalf == 0)
			ucStepperHalf = 1;
		else 
			ucStepperHalf = 0;
	}


	if (Key_Down(TASTE_MENUE))
	{
		if (ucStepperEnable == 0)
		{
			ucStepperEnable = 1;
			Write_Text(X_KO+100,120,NORMAL,0,(unsigned char*)"STOP ");			
		}
		else 
		{
			ucStepperEnable = 0;
			Write_Text(X_KO+100,120,NORMAL,0,(unsigned char*)"START");
		}
	}
		


}


void int2string_comfort(int data, unsigned char* pString, unsigned char format, unsigned char kommastellen)
{
	unsigned char i;
	unsigned char stellen = 0;
	unsigned char buffer[6];
	int negative = 0;
	 
	for(i=0;i<5;i++) 
		buffer[i]=0;
	
	i=0;
	if (data < 0) {
		negative = 1;
		//buffer[i++]=0x2D;
		data = -data;
	}
	
	if (data==0)
	{ 	buffer[i++]=0x30;
		stellen = 1;
	}
	else
	{	for(;i<5;i++)
		{	if (data != 0)					
			{	buffer[i]=data%10;
    	  	  	data-=buffer[i];
				buffer[i]+=0x30;	// ASCII
        		data/=10;
				stellen += 1;
			}
   		}
	}   

	if (kommastellen == 0)
	{
		while(format > stellen)
		{
		 	*pString = 0x20;
			pString++;
			format -= 1;
		}	
		for(i=0;i<stellen;i++)
		{
			*pString = buffer[stellen-i-1];
			pString ++;
		}				
		*pString = '\0'; 
	}
	else
	{	
		while(format > stellen)
		{
		 	*pString = 0x20;
			pString++;
			format -= 1;
		}	
		for(i=0;i<stellen;i++)
		{
			if (i=(stellen-1))	*pString++ = 0x46;	//Komma
			*pString = buffer[stellen-i-1];
			pString ++;
		}				
		*pString = '\0'; 
	}
}

void NumericUpDown(unsigned int* pValue, unsigned char mode, unsigned int lowerLimit, unsigned int upperLimit)
{
	// Z�hlen unterbrechen, wenn die Taste wieder los gelassen wird
	if(direction && (Key_Up(TASTE_PLUS) || Key_Up(TASTE_MINUS)) )
		direction = 0;


	// Wenn noch nicht gez�hlt wird
	if(direction == 0)
	{
		if(Key_Down(TASTE_PLUS))
		{
			direction = 1;
			tw_set(TIMER_BUTTON, DELAY_TIME);
			countSpeed = DEFAULT_SPEED;
			lastCount = DELAY_TIME + DEFAULT_SPEED;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		}
		else if(Key_Down(TASTE_MINUS))
		{
			direction = -1;
			tw_set(TIMER_BUTTON, DELAY_TIME);
			countSpeed = DEFAULT_SPEED;
			lastCount = DELAY_TIME + DEFAULT_SPEED;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		}
	}
		// Ansonsten erh�he die Geschwindigkeit nach der Zeit DELAY_TIME
	else if(!tw_read(TIMER_BUTTON))
	{
		// Geschwindigkeit erh�hen, wenn der Wert in den n�chsten 5 Sekunden nicht zur Grenze kommt
		int tmpValue = (int)*pValue;
		if(	direction == 1 && ((500/countSpeed + tmpValue) <= upperLimit) ||
			direction == -1 && (tmpValue - 500/countSpeed >= lowerLimit))
		{
			// Wenn m�glich, berechnen einer individuellen Geschwindigkeit
			if((upperLimit > lowerLimit) && (upperLimit != lowerLimit))
				countSpeed = 500 / (upperLimit - lowerLimit);
			else
				countSpeed = countSpeed / 3;
		}

		// TODO: Zur ev. besseren Bedienbarkeit: Geschwindigkeit nur einmal erh�hen - Wert unabh�ngig
		//if(countSpeed!=DEFAULT_SPEED)	countSpeed = (DEFAULT_SPEED / 3);

		lastCount = DELAY_TIME + countSpeed;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		tw_set(TIMER_BUTTON, DELAY_TIME);
	}

	if(tw_read(TIMER_BUTTON) <= (lastCount - countSpeed))
	{
		// Wert erh�hen
		if(direction == 1 && (*pValue<upperLimit))
		{
			if ( ((*pValue&0x0F)==9) && (mode==1) )	*pValue += 7;	//(mode==1) => Um die Uhrzeit einstellen zu k�nnen
			else *pValue += 1;
		}
		// Wert vermindern
		else if(direction == -1 && (*pValue>lowerLimit))
		{
			if ( ((*pValue&0x0F)==0) && (mode==1) )	*pValue -= 7;	//(mode==1) => Um die Uhrzeit einstellen zu k�nnen
			else *pValue -= 1;
		}
		lastCount = tw_read(TIMER_BUTTON);
	}
}
