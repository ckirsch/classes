#include <machine.h>
#include "controller.h"
#include "sci.h"

#define PENDEL_MITTE 1056

#define DIRECTION_LEFT  1
#define DIRECTION_RIGHT	0

#define ABW_SUM_GRENZE	30000
long AbweichungSum = 0;
int AbweichungAlt = 0;
int StepSize = 0;
unsigned int PendelMitte = PENDEL_MITTE;
int Sollverschiebung=0;

void PendulumControl (void)
{
	int Abweichung_Mitte;

	//esum = esum + e
	//y = Kp * e + Ki * Ta * esum + Kd * (e - ealt)/Ta
	//ealt = e

	// Versuch, Wagen in der Mitte zu halten:
	if (StepperKilometer > 2500)
		Sollverschiebung = 2;
	else if (StepperKilometer > 2000)
		Sollverschiebung = 1;
	else if (StepperKilometer < 300)
		Sollverschiebung = -2;
	else if (StepperKilometer < 800)
		Sollverschiebung = -1;
	else
		Sollverschiebung = 0;
	
		
	Abweichung_Mitte = PendulumAngle - PendelMitte-Sollverschiebung;
		
	if (ucStepperEnable==1)
		AbweichungSum = AbweichungSum + (long)Abweichung_Mitte;
		
	if (AbweichungSum > ABW_SUM_GRENZE)
		AbweichungSum = ABW_SUM_GRENZE;
	if (AbweichungSum <(- ABW_SUM_GRENZE))
		AbweichungSum = -ABW_SUM_GRENZE;
		
	StepperSpeed = 	P_Param * Abweichung_Mitte +		//P
		(int)((long)I_Param  * (AbweichungSum / 128)) + 	//I
		D_Param*(Abweichung_Mitte - AbweichungAlt); 	//D

	if (StepperSpeed > 0)
		ucStepperDirection = DIRECTION_LEFT;
	else
	{
		ucStepperDirection = DIRECTION_RIGHT;
		StepperSpeed = -StepperSpeed;
	}

	if (StepperSpeed > 400)
	{
		if (ucStepperHalf == 0)
			StepSize = 2;
		else 
			StepSize = 1;
	}
	else
		StepSize = 102 - StepperSpeed/4;
}


void StepperStep (void)
{
	static int StepperPhase = 0;
	static int StepperPhaseH = 0;
	static int deltaTCounter = 0;

	if (ucStepperEnable > 0)
	{
		q_clear(1);	// enable _enable beide spulen
		q_clear(3);
		
		
		deltaTCounter++;
		if (deltaTCounter >= StepSize)
		{
			deltaTCounter = 0;
			
			if (ucStepperHalf == 0)
			{
				switch(StepperPhase)
				{
					case 0:
						q_clear(0);
						q_clear(2); 
						break;
					case 1:
							q_clear(0);
							q_set(2); 
						break;
				
					case 2:
						q_set(0);
						q_set(2);
						break;
				
					case 3:
							q_set(0);
							q_clear(2);
						break;
					default: 
						break;
				}//endswitch
			
				//Kilometer 1410 //mal 2 wegen half
				if (StepperKilometer > 2800)
						ucStepperDirection = DIRECTION_LEFT;
				if (StepperKilometer < 2)
						ucStepperDirection = DIRECTION_RIGHT;
			
				if (ucStepperDirection == DIRECTION_RIGHT)
				{
					StepperKilometer+=2;
					if (StepperPhase == 3)
						StepperPhase = 0;
					else
						StepperPhase++;	// END StepperMotorDrive
				}
				else //DIRECTION_LEFT
				{
					StepperKilometer-=2;
					if (StepperPhase == 0)
						StepperPhase = 3;
					else
						StepperPhase--;	// END StepperMotorDrive
				}
			}
			else	// ucStepperHalf == 1
			{
				// Halbschritt
			
	
				switch(StepperPhaseH)
				{
				case 0:
					q_clear(1);	// not enable 1
					q_clear(3); // not enable 2
					q_set(0);	// Polarity 1
					q_set(2);	// Polarity 2
					break;
				case 1:
					q_clear(1);	
					q_set(3);
					q_set(0);	
					q_clear(2);
					break;
				case 2:
					q_clear(1);	
					q_clear(3);
					q_set(0);	
					q_clear(2);
					break;
				case 3:
					q_set(1);	
					q_clear(3);
					q_clear(0);	
					q_clear(2);
					break;
				case 4:
					q_clear(1);	
					q_clear(3);
					q_clear(0);	
					q_clear(2);
					break;
				case 5:
					q_clear(1);	
					q_set(3);
					q_clear(0);	
					q_set(2);
					break;
			
				case 6:
					q_clear(1);	
					q_clear(3);
					q_clear(0);	
					q_set(2);
					break;
			
				case 7:
					q_set(1);	
					q_clear(3);
					q_set(0);	
					q_set(2);
					break;			
				default: 
					break;
				}// endswitch
			
				if (StepperKilometer > 2800)
					ucStepperDirection = DIRECTION_LEFT;
				if (StepperKilometer < 2)
					ucStepperDirection = DIRECTION_RIGHT;
			
				
			
				if (ucStepperDirection == DIRECTION_RIGHT)
				{
					StepperKilometer++;
					if (StepperPhaseH == 7)
						StepperPhaseH = 0;
					else
						StepperPhaseH++;		
				}
				else //DIRECTION_LEFT
				{
					StepperKilometer--;
					if (StepperPhaseH == 0)
						StepperPhaseH = 7;
					else
						StepperPhaseH--;	
				}

			}			// end ucStepperHalf
		}// endif counter		
			
	}// endif ucStepperEnable
	else 
	{
		q_set(1);	// disable _enable
		q_set(3);

	}
}
