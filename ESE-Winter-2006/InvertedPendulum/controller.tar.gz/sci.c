#include "iodefine.h"
#include "sci.h" 
#include <machine.h>

#define SET_BIT_HIGH				1					
#define SET_BIT_LOW					0					
#define SET_BYTE_HIGH				0xFF				
#define SET_BYTE_LOW				0x00				


volatile int PendulumAngle = 1000;


unsigned char InitSCI( struct SCI_Init_Params SCI_Config )
{
	unsigned char	Wait = INTERVAL, 
					Error = SCI_OK;

	volatile unsigned char	SmrVal = SET_BYTE_LOW;

	/* Clear the SCI1 module stop control bit */
	Serial_Port_Enable_Bit = SET_BIT_LOW;
	
	/* Clear TE & RE bits to 0 in SCR */
	Serial_Port_Control_Register.BYTE = SET_BYTE_LOW;

	/* Clear the error flags */
	Serial_Port_Status_Register.BYTE &= ~ (SSR_PER | SSR_FER | SSR_ORER);

	/* Clear CKS1 and Set CKS0 */
	SmrVal |= 1;
	
	/* Set the Parity setting SMR bits */  
		
	switch ( SCI_Config.Parity )
	{
	case P_EVEN :	SmrVal |= ( SMR_PAR_ENABLE | SMR_PAR_EVEN );
					break;
	case P_ODD :	SmrVal |= ( SMR_PAR_ENABLE | SMR_PAR_ODD );
					break;
	case P_NONE :	SmrVal |= SMR_PAR_DISABLE;
					break;
	default :		Error = SCI_ERR;
					break;
	}
	
  	/* Set the Stop bits setting SMR bits */
	switch ( SCI_Config.Stops )
	{
	case 1 :	SmrVal |= SMR_1_STOP;
				break;
	case 2 :	SmrVal |= SMR_2_STOP;
				break;
	default :	Error = SCI_ERR;
				break;
	}

  	/* Set the Data length setting SMR bits */
	switch ( SCI_Config.Length )
	{
	case 7 :	SmrVal |= SMR_7_CHAR;
				break;
	case 8 :	SmrVal |= SMR_8_CHAR;
				break;
	default :	Error = SCI_ERR;
				break;
	}

	/* Now set the SMR */  
	Serial_Port_Mode_Register.BYTE = SmrVal; 
	
  	/* Set the Baud Rate setting BRR bits */ 
  	Serial_Port_Baud_Rate_Register = SCI_Config.Baud;
  	
  	/* Short delay to let things settle! */ 
	while(Wait--);
 
	/* Enable transmission and reception and timer interrupt*/
	Serial_Port_Control_Register.BYTE |= ( SCR_TE | SCR_RE | SCR_RIE); 
	
	return (Error);
} 

static unsigned char readBuffer[3];
static int readBufferIndex = 0;

__interrupt(vect=93) void INT_RXI1_SCI1(void) 
{
	/*
     * Input from a serial mouse is three bytes long:
     *
     *               D7    D6    D5    D4    D3    D2    D1    D0
     *            -----------------------------------------------
     *  1st byte  |  1     1     LB    RB    Y7    Y6    X7    X6
     *  2nd byte  |  1     0     X5    X4    X3    X2    X1    X0
     *  3rd byte  |  1     0     Y5    Y4    Y3    Y2    Y1    Y0
     */
	int offset;
	unsigned char data;

	set_imask_exr(7);

	if((Serial_Port_Status_Register.BIT.ORER==1) || (Serial_Port_Status_Register.BIT.FER==1));
	{		
		Serial_Port_Status_Register.BIT.ORER=0;
		Serial_Port_Status_Register.BIT.FER=0;
	}	
	

	
	Serial_Port_Status_Register.BIT.RDRF = SET_BIT_LOW;

	data = Serial_Port_Receive_Data_Reg;
	
	if (data >= 0xC0) // Byte1
	{
		readBufferIndex = 0;
		readBuffer[readBufferIndex] = data;
	}
	else	//Byte 2 und 3
	{
		readBufferIndex++;
		readBuffer[readBufferIndex] = data;
		if (readBufferIndex==1)
		{
			if ((readBuffer[0] & 0x03) != 0) //neg.
				PendulumAngle -= (0x40-(readBuffer[readBufferIndex] & 0x3F));
			else
				PendulumAngle += (readBuffer[readBufferIndex] & 0x3F);			
		}	
 		if (readBufferIndex==2)
		{
			readBufferIndex = 0;
		}
	

	}
		
	set_imask_exr(0);
}

