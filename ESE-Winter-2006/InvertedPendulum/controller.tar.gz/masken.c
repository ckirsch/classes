#include "main.h"
#include <string.h>

#define DELAY_TIME 150
#define DEFAULT_SPEED 25

// STEPPER Control
unsigned char ucStepperDirection;
unsigned int StepperCLimit = 2;	// 1 = 0,5 msec 	=>100 =^ 5 msec
unsigned char ucStepperEnable = 0;
unsigned int StepperKilometer = 2;
unsigned char ucStepperHalf = 0;

int direction = 0;	// 0=stopped, 1=positiv, -1=negativ
int lastCount = 0;	// Timer value, when value changed be changed (in 10ms)
int countSpeed = 0;	// Time difference betwee

unsigned char toggle=0;
unsigned char TEXT_STRING[10];
unsigned char colore = NORMAL;	
unsigned char sel_item = 0;









//===============================================================
//===============================================================



void maske_Main(void)
{
	if (MASKE_INIT != MASKENNUMMER)
	{
		MASKE_INIT = MASKENNUMMER;
		back_light_on(1);	
		Clear_Screen();
		
	}
	
	
	Write_Text(X_KO,20,NORMAL,2,(unsigned char*)"SpeedCounter:");
	NumericUpDown(&StepperCLimit, 0, 1, 2000);// in 0,5 msec     =>2000 = 1 sec
	int2string_comfort(StepperCLimit,TEXT_STRING,5,0);
	Write_Text(X_KO+120,20,INVERS,2,TEXT_STRING);						

	Write_Text(X_KO,40,NORMAL,2,(unsigned char*)"Kilometer:");
	int2string_comfort(StepperKilometer,TEXT_STRING,5,0);
	Write_Text(X_KO+120,40,NORMAL,2,TEXT_STRING);						

	Write_Text(X_KO,60,NORMAL,2,(unsigned char*)"Direction:");
	int2string_comfort(ucStepperDirection,TEXT_STRING,1,0);
	Write_Text(X_KO+150,60,NORMAL,2,TEXT_STRING);						

	Write_Text(X_KO,80,NORMAL,2,(unsigned char*)"Enable:");
	int2string_comfort(ucStepperEnable,TEXT_STRING,1,0);
	Write_Text(X_KO+150,80,NORMAL,2,TEXT_STRING);	
	
	Write_Text(X_KO,100,NORMAL,2,(unsigned char*)"PendulumAngle:");
	int2string_comfort(PendulumAngle,TEXT_STRING,5,0);
	Write_Text(X_KO+150,100,NORMAL,2,TEXT_STRING);	
						
	if (Key_Down(TASTE_ON_OFF))		
	{
		if (ucStepperDirection == DIRECTION_LEFT)
			ucStepperDirection = DIRECTION_RIGHT;
		else
			ucStepperDirection = DIRECTION_LEFT;
	}

	if (Key_Down(TASTE_STOP))
	{
		if (ucStepperHalf == 0)
			ucStepperHalf = 1;
		else 
			ucStepperHalf = 0;
	}


	if (Key_Down(TASTE_MENUE))
	{
		if (ucStepperEnable == 0)
			ucStepperEnable = 1;
		else 
			ucStepperEnable = 0;
	}
		


}


void int2string_comfort(int data, unsigned char* pString, unsigned char format, unsigned char kommastellen)
{
	unsigned char i;
	unsigned char stellen = 0;
	unsigned char buffer[6];
	 
	for(i=0;i<5;i++) 
		buffer[i]=0;
	
	i=0;
	if (data < 0) {
		buffer[i++]=0x2D;
		data = -data;
	}
	
	if (data==0)
	{ 	buffer[i++]=0x30;
		stellen = 1;
	}
	else
	{	for(;i<5;i++)
		{	if (data != 0)					
			{	buffer[i]=data%10;
    	  	  	data-=buffer[i];
				buffer[i]+=0x30;	// ASCII
        		data/=10;
				stellen += 1;
			}
   		}
	}                
	if (kommastellen == 0)
	{
		while(format > stellen)
		{
		 	*pString = 0x20;
			pString++;
			format -= 1;
		}	
		for(i=0;i<stellen;i++)
		{
			*pString = buffer[stellen-i-1];
			pString ++;
		}				
		*pString = '\0'; 
	}
	else
	{	
		while(format > stellen)
		{
		 	*pString = 0x20;
			pString++;
			format -= 1;
		}	
		for(i=0;i<stellen;i++)
		{
			if (i=(stellen-1))	*pString++ = 0x46;	//Komma
			*pString = buffer[stellen-i-1];
			pString ++;
		}				
		*pString = '\0'; 
	}
}

/*----------------------------------------------------------------------------
*  Funktion : 	Increases and decreases the given value, depending on specific 
*				up/down buttons
*				The speed depends on the upper resp. lower limit and will be 
*				increased exponential
*  Parameter: 	pValue - Value to be changed
*				mode 	- 0 .. Normal value
						- 1 .. Clock: Simulate HEX value as decimal value (Wert A-F �berspringen)
*				lowerLimit - Minimum value
*				upperLimit - Maximum value
*  Return   : 
------------------------------------------------------------------------------*/
void NumericUpDown(unsigned int* pValue, unsigned char mode, unsigned int lowerLimit, unsigned int upperLimit)
{
	// Z�hlen unterbrechen, wenn die Taste wieder los gelassen wird
	if(direction && (Key_Up(TASTE_PLUS) || Key_Up(TASTE_MINUS)) )
		direction = 0;


	// Wenn noch nicht gez�hlt wird
	if(direction == 0)
	{
		if(Key_Down(TASTE_PLUS))
		{
			direction = 1;
			tw_set(TIMER_BUTTON, DELAY_TIME);
			countSpeed = DEFAULT_SPEED;
			lastCount = DELAY_TIME + DEFAULT_SPEED;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		}
		else if(Key_Down(TASTE_MINUS))
		{
			direction = -1;
			tw_set(TIMER_BUTTON, DELAY_TIME);
			countSpeed = DEFAULT_SPEED;
			lastCount = DELAY_TIME + DEFAULT_SPEED;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		}
	}
		// Ansonsten erh�he die Geschwindigkeit nach der Zeit DELAY_TIME
	else if(!tw_read(TIMER_BUTTON))
	{
		// Geschwindigkeit erh�hen, wenn der Wert in den n�chsten 5 Sekunden nicht zur Grenze kommt
		int tmpValue = (int)*pValue;
		if(	direction == 1 && ((500/countSpeed + tmpValue) <= upperLimit) ||
			direction == -1 && (tmpValue - 500/countSpeed >= lowerLimit))
		{
			// Wenn m�glich, berechnen einer individuellen Geschwindigkeit
			if((upperLimit > lowerLimit) && (upperLimit != lowerLimit))
				countSpeed = 500 / (upperLimit - lowerLimit);
			else
				countSpeed = countSpeed / 3;
		}

		// TODO: Zur ev. besseren Bedienbarkeit: Geschwindigkeit nur einmal erh�hen - Wert unabh�ngig
		//if(countSpeed!=DEFAULT_SPEED)	countSpeed = (DEFAULT_SPEED / 3);

		lastCount = DELAY_TIME + countSpeed;	// Sicherstellen, dass in diesem Zyklus noch gez�hlt wird
		tw_set(TIMER_BUTTON, DELAY_TIME);
	}

	if(tw_read(TIMER_BUTTON) <= (lastCount - countSpeed))
	{
		// Wert erh�hen
		if(direction == 1 && (*pValue<upperLimit))
		{
			if ( ((*pValue&0x0F)==9) && (mode==1) )	*pValue += 7;	//(mode==1) => Um die Uhrzeit einstellen zu k�nnen
			else *pValue += 1;
		}
		// Wert vermindern
		else if(direction == -1 && (*pValue>lowerLimit))
		{
			if ( ((*pValue&0x0F)==0) && (mode==1) )	*pValue -= 7;	//(mode==1) => Um die Uhrzeit einstellen zu k�nnen
			else *pValue -= 1;
		}
		lastCount = tw_read(TIMER_BUTTON);
	}
}

