/* Serial Port Definitions */
#define Serial_Port_Enable_Bit 			MSTPCR.BIT._SCI1
#define Serial_Port_Control_Register	SCI1.SCR
#define Serial_Port_Status_Register		SCI1.SSR
#define Serial_Port_Mode_Register		SCI1.SMR
#define Serial_Port_Baud_Rate_Register	SCI1.BRR
#define Serial_Port_Receive_Data_Reg	SCI1.RDR
#define Serial_Port_Transmit_Data_Reg	SCI1.TDR

/* Bit Rate Register (BRR) settings for 16.000MHz x 2 */
#define B1200   207


/* Serial control register (SCR) bit values/masks */
#define SCR_TIE  	0x80
#define SCR_RIE  	0x40
#define SCR_TE   	0x20
#define SCR_RE   	0x10
#define SCR_MPIE 	0x8
#define SCR_TEIE 	0x4
#define SCR_CKE1 	0x2
#define SCR_CKE0 	0x1


/* Serial mode register (SMR) bit values */
#define SMR_PAR_ENABLE		0x20
#define SMR_PAR_DISABLE		0x00
#define SMR_PAR_ODD			0x10
#define SMR_PAR_EVEN		0x00
#define SMR_1_STOP			0x00
#define	SMR_2_STOP			0x08
#define SMR_7_CHAR			0x40
#define SMR_8_CHAR			0x00


/* Serial status register (SSR) bit values */
#define SSR_TDRE 	0x80
#define SSR_RDRF 	0x40
#define SSR_ORER 	0x20
#define SSR_FER  	0x10
#define SSR_PER  	0x8
#define SSR_TEND 	0x4
#define SSR_MPB  	0x2
#define SSR_MPBT 	0x1


/* Parity values used in port initialisation */
#define P_NONE		0
#define P_EVEN		1
#define P_ODD		2

     
/* Potential error codes from initialisation function */
#define SCI_OK		0x00
#define SCI_ERR		0x01  


#define INTERVAL	10000L
   
    
/* Structure definition used for SCI initialisation */
struct SCI_Init_Params
{        
	unsigned char Baud; 
	unsigned char Parity;
	unsigned char Stops;
	unsigned char Length;
};

   

/* Function Prototypes */
unsigned char 	InitSCI( struct SCI_Init_Params SCI_Config );

extern volatile int PendulumAngle;
