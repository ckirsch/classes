#include "masken.h"

//------------------ M A I N ---------------------------------------------
void main(void)						/* Initialise the serial port and display the menu */
{ 
	// power supply for mouse				
	ANALOG_OUT1 = 225;

	while(1)
	{  		
		maske_Main();		}	
}         


