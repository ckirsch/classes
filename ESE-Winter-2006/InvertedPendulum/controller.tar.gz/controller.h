#ifndef REGLER1_H
#define REGLER1_H
// STEPPER Control

extern unsigned char ucStepperDirection;
extern unsigned int StepperCLimit;
extern unsigned char ucStepperEnable;
extern int StepperKilometer;
extern unsigned char ucStepperHalf;
	

extern volatile int PendulumAngle;
extern unsigned int P_Param;
extern unsigned int I_Param;
extern unsigned int D_Param;
extern int StepperSpeed;
extern int StepSize;
extern unsigned int PendelMitte;
extern int Sollverschiebung;


void PendulumControl (void);
void StepperStep (void);


#endif //REGLER1_H
