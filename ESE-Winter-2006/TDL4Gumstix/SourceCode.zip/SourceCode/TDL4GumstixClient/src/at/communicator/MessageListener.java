package at.communicator;

import java.util.EventListener;


/*
 * JNewsListener
 * Interface for client beans
 */
public interface MessageListener extends EventListener {

  public void messageAction(MessageEvent e);
  
}
