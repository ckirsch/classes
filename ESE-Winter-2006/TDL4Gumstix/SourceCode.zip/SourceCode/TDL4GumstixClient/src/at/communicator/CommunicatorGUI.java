package at.communicator;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.UIManager;

import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import javax.swing.JLabel;

public class CommunicatorGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton btnSendSensor1 = null;
	private Communicator communicator = null;
	private JButton btnReceive = null;
	private Scope scope = null;
	
	private class GUIUpdater implements MessageListener {
		public void messageAction(MessageEvent e) {
			if (e.getAd() == 'd') {
			switch (e.getId()) {
				case 1:
					txtActDi1.setText("" + e.getValue());
					break;
				case 2:
					txtActDi2.setText("" + e.getValue());
					break;
				case 3:
					txtActDi3.setText("" + e.getValue());
					break;
				case 4:
					txtActDi4.setText("" + e.getValue());
					break;
			}
			}
			if (e.getAd() == 'a') {
				switch (e.getId()) {
					case 1:
						txtActAn1.setText("" + e.getValue());
						scope.addSample(System.currentTimeMillis(), e.getValue());
						break;
					case 2:
						txtActAn2.setText("" + e.getValue());
						scope1.addSample(System.currentTimeMillis(), e.getValue());
						break;
					case 3:
						txtActAn3.setText("" + e.getValue());
						scope2.addSample(System.currentTimeMillis(), e.getValue());
						break;
					case 4:
						txtActAn4.setText("" + e.getValue());
						break;
				}
			}
			try {
				Thread.sleep(1);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

	}
	
	/**
	 * This method initializes btnReceive	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnReceive() {
		if (btnReceive == null) {
			btnReceive = new JButton();
			btnReceive.setText("Start receiving");
			btnReceive.addActionListener(
			new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					btnReceive.setEnabled(false);
					new Thread(gui).start();
				}
			});
		}
		return btnReceive;
	}
	
	public static CommunicatorGUI gui = null;
	private JPanel jPanel2 = null;
	private JLabel jLabel = null;
	private JTextField txtSensor1 = null;
	private JLabel jLabel1 = null;
	private JTextField txtSensor2 = null;
	private JLabel jLabel2 = null;
	private JLabel jLabel3 = null;
	private JTextField txtSensor3 = null;
	private JTextField txtSensor4 = null;
	private JPanel jPanel21 = null;
	private JLabel jLabel4 = null;
	private JTextField txtActDi1 = null;
	private JLabel jLabel11 = null;
	private JTextField txtActDi2 = null;
	private JLabel jLabel21 = null;
	private JTextField txtActDi3 = null;
	private JLabel jLabel31 = null;
	private JTextField txtActDi4 = null;
	private JPanel jPanel = null;
	private JButton btnSendSensor2 = null;
	private JButton btnSendSensor3 = null;
	private JButton btnSendSensor4 = null;
	private JPanel jPanel5 = null;
	private JPanel jPanel22 = null;
	private JLabel jLabel5 = null;
	private JTextField txtSensorA1 = null;
	private JButton btnSensorA1 = null;
	private JLabel jLabel12 = null;
	private JTextField txtSensorA2 = null;
	private JButton btnSensorA2 = null;
	private JLabel jLabel22 = null;
	private JTextField txtSensorA3 = null;
	private JButton btnSensorA3 = null;
	private JLabel jLabel32 = null;
	private JTextField txtSensorA4 = null;
	private JButton btnSensorA4 = null;
	private JPanel jPanel211 = null;
	private JLabel jLabel41 = null;
	private JTextField txtActAn1 = null;
	private JLabel jLabel111 = null;
	private JTextField txtActAn2 = null;
	private JLabel jLabel211 = null;
	private JTextField txtActAn3 = null;
	private JLabel jLabel311 = null;
	private JTextField txtActAn4 = null;
	private JLabel jLabel6 = null;
	private JLabel jLabel7 = null;
	private JPanel jPanel1 = null;
	private JLabel jLabel8 = null;
	private JTextField txtIpAddress = null;
	private JPanel jPanel6 = null;
	private JLabel jLabel9 = null;
	private JTextField txtPort = null;
	private JButton jButton = null;
	private JPanel jPanel3 = null;
	private JPanel jPanel4 = null;
	private JPanel jPanel7 = null;
	private JPanel jPanel8 = null;
	private JPanel jPanel9 = null;
	private JPanel jPanel10 = null;
	private JPanel jPanel11 = null;
	private JPanel jPanel12 = null;
	private Scope scope1 = null;
	private Scope scope2 = null;

	/**
	 * This method initializes jPanel2	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			jLabel3 = new JLabel();
			jLabel3.setText("Sensor 4");
			jLabel2 = new JLabel();
			jLabel2.setText("Sensor 3");
			GridLayout gridLayout1 = new GridLayout();
			gridLayout1.setRows(4);
			gridLayout1.setColumns(3);
			jLabel1 = new JLabel();
			jLabel1.setText("Sensor 2");
			jLabel = new JLabel();
			jLabel.setText("Sensor 1");
			jPanel2 = new JPanel();
			jPanel2.setPreferredSize(new Dimension(189, 80));
			jPanel2.setLayout(gridLayout1);
			jPanel2.add(jLabel, null);
			jPanel2.add(getTxtSensor1(), null);
			jPanel2.add(getBtnSendSensor1(), null);
			jPanel2.add(jLabel1, null);
			jPanel2.add(getTxtSensor2(), null);
			jPanel2.add(getBtnSendSensor2(), null);
			jPanel2.add(jLabel2, null);
			jPanel2.add(getTxtSensor3(), null);
			jPanel2.add(getBtnSendSensor3(), null);
			jPanel2.add(jLabel3, null);
			jPanel2.add(getTxtSensor4(), null);
			jPanel2.add(getBtnSendSensor4(), null);
		}
		return jPanel2;
	}

	/**
	 * This method initializes txtSensor1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensor1() {
		if (txtSensor1 == null) {
			txtSensor1 = new JTextField();
			txtSensor1.setPreferredSize(new Dimension(50, 20));
			txtSensor1.setText("5");
		}
		return txtSensor1;
	}

	/**
	 * This method initializes txtSensor2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensor2() {
		if (txtSensor2 == null) {
			txtSensor2 = new JTextField();
			txtSensor2.setText("6");
		}
		return txtSensor2;
	}

	/**
	 * This method initializes txtSensor3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensor3() {
		if (txtSensor3 == null) {
			txtSensor3 = new JTextField();
			txtSensor3.setText("7");
		}
		return txtSensor3;
	}

	/**
	 * This method initializes txtSensor4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensor4() {
		if (txtSensor4 == null) {
			txtSensor4 = new JTextField();
			txtSensor4.setText("8");
		}
		return txtSensor4;
	}

	/**
	 * This method initializes jPanel21	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel21() {
		if (jPanel21 == null) {
			jLabel31 = new JLabel();
			jLabel31.setText("Actuator 4");
			jLabel21 = new JLabel();
			jLabel21.setText("Actuator 3");
			jLabel11 = new JLabel();
			jLabel11.setText("Actuator 2");
			jLabel4 = new JLabel();
			jLabel4.setText("Actuator 1");
			GridLayout gridLayout11 = new GridLayout();
			gridLayout11.setRows(4);
			gridLayout11.setColumns(2);
			jPanel21 = new JPanel();
			jPanel21.setLayout(gridLayout11);
			jPanel21.add(jLabel4, null);
			jPanel21.add(getTxtActDi1(), null);
			jPanel21.add(jLabel11, null);
			jPanel21.add(getTxtActDi2(), null);
			jPanel21.add(jLabel21, null);
			jPanel21.add(getTxtActDi3(), null);
			jPanel21.add(jLabel31, null);
			jPanel21.add(getTxtActDi4(), null);
		}
		return jPanel21;
	}

	/**
	 * This method initializes txtActDi1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActDi1() {
		if (txtActDi1 == null) {
			txtActDi1 = new JTextField();
			txtActDi1.setPreferredSize(new Dimension(50, 20));
		}
		return txtActDi1;
	}

	/**
	 * This method initializes txtActDi2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActDi2() {
		if (txtActDi2 == null) {
			txtActDi2 = new JTextField();
		}
		return txtActDi2;
	}

	/**
	 * This method initializes txtActDi3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActDi3() {
		if (txtActDi3 == null) {
			txtActDi3 = new JTextField();
		}
		return txtActDi3;
	}

	/**
	 * This method initializes txtActDi4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActDi4() {
		if (txtActDi4 == null) {
			txtActDi4 = new JTextField();
		}
		return txtActDi4;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel7 = new JLabel();
			jLabel7.setText("Digital");
			jPanel = new JPanel();
			jPanel.setLayout(new BorderLayout());
			jPanel.add(getJPanel3(), BorderLayout.WEST);
			jPanel.add(getJPanel7(), BorderLayout.CENTER);
		}
		return jPanel;
	}

	/**
	 * This method initializes btnSendSensor2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSendSensor2() {
		if (btnSendSensor2 == null) {
			btnSendSensor2 = new JButton();
			btnSendSensor2.setText("Send");
			btnSendSensor2.setPreferredSize(new Dimension(63, 20));
			btnSendSensor2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('d', 2, Integer.parseInt(txtSensor2.getText()));
				}
			});
		}
		return btnSendSensor2;
	}

	/**
	 * This method initializes btnSendSensor3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSendSensor3() {
		if (btnSendSensor3 == null) {
			btnSendSensor3 = new JButton();
			btnSendSensor3.setText("Send");
			btnSendSensor3.setPreferredSize(new Dimension(63, 20));
			btnSendSensor3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('d', 3, Integer.parseInt(txtSensor3.getText()));
				}
			});
		}
		return btnSendSensor3;
	}

	/**
	 * This method initializes btnSendSensor4	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSendSensor4() {
		if (btnSendSensor4 == null) {
			btnSendSensor4 = new JButton();
			btnSendSensor4.setText("Send");
			btnSendSensor4.setPreferredSize(new Dimension(70, 20));
			btnSendSensor4.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('d', 4, Integer.parseInt(txtSensor3.getText()));
				}
			});
		}
		return btnSendSensor4;
	}

	/**
	 * This method initializes jPanel5	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel5() {
		if (jPanel5 == null) {
			jLabel6 = new JLabel();
			jLabel6.setText("Analog");
			jPanel5 = new JPanel();
			jPanel5.setLayout(new BorderLayout());
			jPanel5.add(getJPanel4(), BorderLayout.WEST);
			jPanel5.add(getJPanel8(), BorderLayout.CENTER);
		}
		return jPanel5;
	}

	/**
	 * This method initializes jPanel22	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel22() {
		if (jPanel22 == null) {
			jLabel32 = new JLabel();
			jLabel32.setText("Sensor 4");
			jLabel22 = new JLabel();
			jLabel22.setText("Sensor 3");
			jLabel12 = new JLabel();
			jLabel12.setText("Sensor 2");
			jLabel5 = new JLabel();
			jLabel5.setText("Sensor 1");
			GridLayout gridLayout12 = new GridLayout();
			gridLayout12.setRows(4);
			gridLayout12.setColumns(3);
			jPanel22 = new JPanel();
			jPanel22.setLayout(gridLayout12);
			jPanel22.add(jLabel5, null);
			jPanel22.add(getTxtSensorA1(), null);
			jPanel22.add(getBtnSensorA1(), null);
			jPanel22.add(jLabel12, null);
			jPanel22.add(getTxtSensorA2(), null);
			jPanel22.add(getBtnSensorA2(), null);
			jPanel22.add(jLabel22, null);
			jPanel22.add(getTxtSensorA3(), null);
			jPanel22.add(getBtnSensorA3(), null);
			jPanel22.add(jLabel32, null);
			jPanel22.add(getTxtSensorA4(), null);
			jPanel22.add(getBtnSensorA4(), null);
		}
		return jPanel22;
	}

	/**
	 * This method initializes txtSensorA1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensorA1() {
		if (txtSensorA1 == null) {
			txtSensorA1 = new JTextField();
			txtSensorA1.setPreferredSize(new Dimension(50, 20));
			txtSensorA1.setText("1");
		}
		return txtSensorA1;
	}

	/**
	 * This method initializes btnSensorA1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSensorA1() {
		if (btnSensorA1 == null) {
			btnSensorA1 = new JButton();
			btnSensorA1.setText("Send");
			btnSensorA1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('a', 1, Integer.parseInt(txtSensorA1.getText()));
				}
			});
		}
		return btnSensorA1;
	}

	/**
	 * This method initializes txtSensorA2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensorA2() {
		if (txtSensorA2 == null) {
			txtSensorA2 = new JTextField();
			txtSensorA2.setText("2");
		}
		return txtSensorA2;
	}

	/**
	 * This method initializes btnSensorA2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSensorA2() {
		if (btnSensorA2 == null) {
			btnSensorA2 = new JButton();
			btnSensorA2.setText("Send");
			btnSensorA2.setPreferredSize(new Dimension(63, 20));
			btnSensorA2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('a', 2, Integer.parseInt(txtSensorA2.getText()));
				}
			});
		}
		return btnSensorA2;
	}

	/**
	 * This method initializes txtSensorA3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensorA3() {
		if (txtSensorA3 == null) {
			txtSensorA3 = new JTextField();
			txtSensorA3.setText("3");
		}
		return txtSensorA3;
	}

	/**
	 * This method initializes btnSensorA3	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSensorA3() {
		if (btnSensorA3 == null) {
			btnSensorA3 = new JButton();
			btnSensorA3.setText("Send");
			btnSensorA3.setPreferredSize(new Dimension(63, 20));
			btnSensorA3.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('a', 3, Integer.parseInt(txtSensorA3.getText()));
				}
			});
		}
		return btnSensorA3;
	}

	/**
	 * This method initializes txtSensorA4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtSensorA4() {
		if (txtSensorA4 == null) {
			txtSensorA4 = new JTextField();
			txtSensorA4.setText("4");
		}
		return txtSensorA4;
	}

	/**
	 * This method initializes btnSensorA4	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSensorA4() {
		if (btnSensorA4 == null) {
			btnSensorA4 = new JButton();
			btnSensorA4.setText("Send");
			btnSensorA4.setPreferredSize(new Dimension(63, 20));
			btnSensorA4.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('a', 4, Integer.parseInt(txtSensorA4.getText()));
				}
			});
		}
		return btnSensorA4;
	}

	/**
	 * This method initializes jPanel211	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel211() {
		if (jPanel211 == null) {
			jLabel311 = new JLabel();
			jLabel311.setText("Actuator 4");
			jLabel211 = new JLabel();
			jLabel211.setText("Actuator 3");
			jLabel111 = new JLabel();
			jLabel111.setText("Actuator 2");
			jLabel41 = new JLabel();
			jLabel41.setText("Actuator 1");
			GridLayout gridLayout111 = new GridLayout();
			gridLayout111.setRows(4);
			gridLayout111.setColumns(2);
			jPanel211 = new JPanel();
			jPanel211.setLayout(gridLayout111);
			jPanel211.add(jLabel41, null);
			jPanel211.add(getTxtActAn1(), null);
			jPanel211.add(jLabel111, null);
			jPanel211.add(getTxtActAn2(), null);
			jPanel211.add(jLabel211, null);
			jPanel211.add(getTxtActAn3(), null);
			jPanel211.add(jLabel311, null);
			jPanel211.add(getTxtActAn4(), null);
		}
		return jPanel211;
	}

	/**
	 * This method initializes txtActAn1	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActAn1() {
		if (txtActAn1 == null) {
			txtActAn1 = new JTextField();
			txtActAn1.setPreferredSize(new Dimension(50, 20));
		}
		return txtActAn1;
	}

	/**
	 * This method initializes txtActAn2	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActAn2() {
		if (txtActAn2 == null) {
			txtActAn2 = new JTextField();
		}
		return txtActAn2;
	}

	/**
	 * This method initializes txtActAn3	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActAn3() {
		if (txtActAn3 == null) {
			txtActAn3 = new JTextField();
		}
		return txtActAn3;
	}

	/**
	 * This method initializes txtActAn4	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtActAn4() {
		if (txtActAn4 == null) {
			txtActAn4 = new JTextField();
		}
		return txtActAn4;
	}

	/**
	 * This method initializes jPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jLabel9 = new JLabel();
			jLabel9.setText("Port");
			jLabel8 = new JLabel();
			jLabel8.setText("IP Adress");
			jPanel1 = new JPanel();
			jPanel1.setLayout(new FlowLayout());
			jPanel1.add(jLabel8, null);
			jPanel1.add(getTxtIpAddress(), null);
			jPanel1.add(jLabel9, null);
			jPanel1.add(getTxtPort(), null);
			jPanel1.add(getJButton(), null);
			jPanel1.add(getBtnReceive(), null);
		}
		return jPanel1;
	}

	/**
	 * This method initializes txtIpAddress	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtIpAddress() {
		if (txtIpAddress == null) {
			txtIpAddress = new JTextField();
			txtIpAddress.setText("141.201.109.36");
		}
		return txtIpAddress;
	}

	/**
	 * This method initializes jPanel6	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel6() {
		if (jPanel6 == null) {
			GridLayout gridLayout = new GridLayout();
			gridLayout.setRows(2);
			gridLayout.setColumns(1);
			jPanel6 = new JPanel();
			jPanel6.setLayout(gridLayout);
			jPanel6.add(getJPanel(), null);
			jPanel6.add(getJPanel5(), null);
		}
		return jPanel6;
	}

	/**
	 * This method initializes txtPort	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getTxtPort() {
		if (txtPort == null) {
			txtPort = new JTextField();
			txtPort.setText("7777");
		}
		return txtPort;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setText("Set");
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.setIpAddress(txtIpAddress.getText());
					communicator.setPort(txtPort.getText());
				}
			});
		}
		return jButton;
	}

	/**
	 * This method initializes jPanel3	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel3() {
		if (jPanel3 == null) {
			jPanel3 = new JPanel();
			jPanel3.setLayout(new GridBagLayout());
			jPanel3.setPreferredSize(new Dimension(50, 16));
			jPanel3.add(jLabel7, new GridBagConstraints());
		}
		return jPanel3;
	}

	/**
	 * This method initializes jPanel4	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel4() {
		if (jPanel4 == null) {
			jPanel4 = new JPanel();
			jPanel4.setLayout(new GridBagLayout());
			jPanel4.setPreferredSize(new Dimension(50, 16));
			jPanel4.add(jLabel6, new GridBagConstraints());
		}
		return jPanel4;
	}

	/**
	 * This method initializes jPanel7	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel7() {
		if (jPanel7 == null) {
			GridLayout gridLayout3 = new GridLayout();
			gridLayout3.setRows(1);
			jPanel7 = new JPanel();
			jPanel7.setLayout(gridLayout3);
			jPanel7.add(getJPanel2(), null);
			jPanel7.add(getJPanel21(), null);
		}
		return jPanel7;
	}

	/**
	 * This method initializes jPanel8	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel8() {
		if (jPanel8 == null) {
			GridLayout gridLayout2 = new GridLayout();
			gridLayout2.setRows(1);
			jPanel8 = new JPanel();
			jPanel8.setLayout(gridLayout2);
			jPanel8.add(getJPanel22(), null);
			jPanel8.add(getJPanel211(), null);
		}
		return jPanel8;
	}

	/**
	 * This method initializes jPanel9	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel9() {
		if (jPanel9 == null) {
			GridLayout gridLayout5 = new GridLayout();
			gridLayout5.setRows(3);
			gridLayout5.setColumns(1);
			jPanel9 = new JPanel();
			jPanel9.setLayout(gridLayout5);
			jPanel9.add(getJPanel10(), null);
			jPanel9.add(getJPanel11(), null);
			jPanel9.add(getJPanel12(), null);
		}
		return jPanel9;
	}

	/**
	 * This method initializes jPanel10	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel10() {
		if (jPanel10 == null) {
			GridLayout gridLayout4 = new GridLayout();
			gridLayout4.setRows(1);
			gridLayout4.setColumns(1);
			jPanel10 = new JPanel();
			jPanel10.setPreferredSize(new Dimension(400, 100));
			jPanel10.setLayout(gridLayout4);
		}
		scope = new Scope();
		scope.setYDivisions(new int[] { 0, 100, 200, 300 });
		jPanel10.add(scope, null);
		return jPanel10;
	}

	/**
	 * This method initializes jPanel11	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel11() {
		if (jPanel11 == null) {
			GridLayout gridLayout6 = new GridLayout();
			gridLayout6.setRows(1);
			jPanel11 = new JPanel();
			jPanel11.setLayout(gridLayout6);
			jPanel11.add(getScope1(), null);
		}
		return jPanel11;
	}

	/**
	 * This method initializes jPanel12	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel12() {
		if (jPanel12 == null) {
			GridLayout gridLayout7 = new GridLayout();
			gridLayout7.setRows(1);
			jPanel12 = new JPanel();
			jPanel12.setLayout(gridLayout7);
			jPanel12.add(getScope2(), null);
		}
		return jPanel12;
	}

	/**
	 * This method initializes scope1	
	 * 	
	 * @return at.communicator.Scope	
	 */
	private Scope getScope1() {
		if (scope1 == null) {
			scope1 = new Scope();
			scope1.setYDivisions(new int[] { 0, 100, 200, 300 });
		}
		return scope1;
	}

	/**
	 * This method initializes scope2	
	 * 	
	 * @return at.communicator.Scope	
	 */
	private Scope getScope2() {
		if (scope2 == null) {
			scope2 = new Scope();
			scope2.setYDivisions(new int[] { 0, 100, 200, 300 });
		}
		return scope2;
	}

	public static void main(String[] args) {
		try {
			  UIManager.setLookAndFeel(
			    UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
			}
		gui = new CommunicatorGUI();
		gui.show();
	}
	
	/**
	 * This is the default constructor
	 */
	public CommunicatorGUI() {
		super();
		Integer.parseInt("2");
		initialize();
		communicator = new Communicator();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(494, 563);
		this.setContentPane(getJContentPane());
		this.setTitle("TDL4Gumstix Client");
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJPanel1(), BorderLayout.NORTH);
			jContentPane.add(getJPanel6(), BorderLayout.CENTER);
			jContentPane.add(getJPanel9(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	/**
	 * This method initializes btnSendSensor1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getBtnSendSensor1() {
		if (btnSendSensor1 == null) {
			btnSendSensor1 = new JButton();
			btnSendSensor1.setText("Send");
			btnSendSensor1.setPreferredSize(new Dimension(70, 20));
			btnSendSensor1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					communicator.sendMessage('d', 1, Integer.parseInt(txtSensor1.getText()));
				}
			});
		}
		return btnSendSensor1;
	}


	public void run() {
		MessageReceiver receiver = new MessageReceiver(communicator.getSocket());
		receiver.addMessageListener(new GUIUpdater());
		receiver.receive();
	}	


}  //  @jve:decl-index=0:visual-constraint="10,10"  
