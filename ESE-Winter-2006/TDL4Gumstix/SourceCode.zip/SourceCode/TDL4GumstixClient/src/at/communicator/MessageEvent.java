package at.communicator;

import java.util.EventObject;

/*
 * JNewsEvent
 * EventObject for JNews
 */
public class MessageEvent extends EventObject {

  private int value;
  private int id;
  private char ad;
  
  public MessageEvent(Object source, int id, int value, char ad) {
    super(source);
    this.value = value;
    this.id = id;
    this.ad = ad;
  }
 
  public char getAd() {
	  return ad;
  }

  public int getValue() {
    return value;
  }
  
  public int getId() {
	  return id;
  }

}
