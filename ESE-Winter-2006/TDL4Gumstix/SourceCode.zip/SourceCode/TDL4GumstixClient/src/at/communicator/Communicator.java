package at.communicator;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.io.*;

public class Communicator {

	public static final int SLEEP_MILLISECS = 1000;
	private MulticastSocket sock;
	private DatagramPacket pack;
	
	/*public static final int UDP_PORT = 7777;
	public static final String UDP_ADDRESS = "141.201.109.36";*/
	private int port = 7777;
	private String ipAddress = "141.201.109.36";

	public Communicator() {
		try {
			sock = new MulticastSocket();
			pack = new DatagramPacket(new byte[0], 0);
			pack.setAddress(InetAddress.getByName(ipAddress));
			pack.setPort(port);
			sock.send(pack);
		} catch (Exception e) {
			System.out.println("Exception in creating socket or packet: "
					+ e.getMessage());
		}
	}
	
	public DatagramSocket getSocket() {
		return sock;
	}


	public void sendMessage(char ad, int sensorID, int value) {
		String s1 = String.valueOf(sensorID);
		String s2 = String.valueOf(value);
		String message = new String("s" + ad + ":" + s1 + ":" + s2);
		byte[] msg = message.getBytes();
		try {
			pack.setData(msg);
			pack.setLength(msg.length);
			sock.send(pack);
			//System.out.println(message + " sent to " + ipAddress);
		} catch (Exception e) {
			System.out
					.println("Exception in sending packet: " + e.getMessage());
		}
	}


	
	public static byte[] doubleToByte(Double value) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		try {
			dos.writeDouble(value.doubleValue());
			dos.flush();
			return bos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] longToByte(Long value) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		try {
			dos.writeLong(value.longValue());
			dos.flush();
			return bos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	/*
	 * public static void main(String[] args) {
	 * 
	 * Communicator sender = new Communicator();
	 * 
	 * while (true) { sender.sendMessage(); try { Thread.sleep(SLEEP_MILLISECS);
	 *  } catch (Exception e) { } } }
	 */
	
	

	public void setIpAddress(String text) {
		this.ipAddress = text; 
	}

	public void setPort(String text) {
		this.port = Integer.parseInt(text);
	}

}
