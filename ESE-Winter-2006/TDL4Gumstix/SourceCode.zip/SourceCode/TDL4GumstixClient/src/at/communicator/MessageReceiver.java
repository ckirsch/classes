package at.communicator;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class MessageReceiver {

	private byte[] receiveBuffer = new byte[100];
	private DatagramPacket pack;
	private DatagramSocket sock = null;
	private ArrayList messageListeners = new ArrayList();

	public MessageReceiver(DatagramSocket socket) {
		this.sock = socket;
	}

	public void receive() {

		// this.sock = new DatagramSocket(null); // no bind will be done with
		// this constructor
		// sock.setReuseAddress(true); // must be done before bind call
		// sock.bind(new InetSocketAddress(7788));
		pack = new DatagramPacket(receiveBuffer, receiveBuffer.length);
		System.out.println("run");
		while (true) {
			try {
				//System.out.println("beforerecv");
				this.sock.receive(pack);
				//System.out.println("afterrecv");
				String msg = new String(receiveBuffer, 0, pack.getLength());
				char ad = msg.charAt(0);
				String id = msg.substring(msg.indexOf(":", 0) + 1, msg.indexOf(
						":", 2));
				String value = msg.substring(msg.indexOf(":", 2) + 1, msg
						.indexOf("."));
				//System.out.println(msg + " id:" + id + ". val:" + value + ".");
				fireEvent(new MessageEvent(this, Integer.parseInt(id), Integer
						.parseInt(value), ad));
				Thread.sleep(1);
			} catch (Exception ex) {
				ex.printStackTrace();
				System.exit(-1);
			}

		}
	}

	public void addMessageListener(MessageListener listener) {
		this.messageListeners.add(listener);
	}

	private void fireEvent(MessageEvent event) {
		for (int i = 0; i < messageListeners.size(); i++) {
			((MessageListener) messageListeners.get(i)).messageAction(event);
		}
	}
}
