package at.communicator;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Scope extends Component {

    private static final int SAMPLE_COUNT = 100;
    private static final int PIXEL_PER_100MS = 1;

    private int[] _yDivisions;
    private long _xOffset;
    private long[] _timestamps;
    private int[] _values;
    private int _head;
    private int _tail;

    public Scope() {
	_timestamps = new long[SAMPLE_COUNT];
	_values = new int[SAMPLE_COUNT];
    }

    // class Component
    //
    public void paint(Graphics g) {
	Rectangle r = getBounds();
	int asc = g.getFontMetrics().getAscent();
	int xOff = 30;
	int yOff = asc / 2;
	int height = r.height - asc;
	g.translate(xOff, yOff);
	paintYLabels(g, height);
	int width = r.width - 30;
	g.setClip(0, 0, width + 1, height + 1);
	paintFrame(g, width, height);
	paintXGrid(g, width, height);
	paintYGrid(g, width, height);
	paintSamples(g, width, height);
	xOff -= 30;
	yOff -= asc / 2;
	g.translate(-xOff, yOff);
    }
    //
    // class Component

    public void setYDivisions(int[] divisions) {
	_yDivisions = divisions;
	repaint(100l);
    }

    public void addSample(long timestamp, int value) {
	_timestamps[_head] = timestamp;
	_values[_head] = value;
	_head = (_head + 1) % SAMPLE_COUNT;
	if (_tail == _head)
	    _tail = (_tail + 1) % SAMPLE_COUNT;
	repaint(100l);
    }

    private void paintYLabels(Graphics g, int height) {
	g.setColor(Color.white);
	int dy = height / (_yDivisions.length - 1);
	FontMetrics m = g.getFontMetrics();
	String l;
	for (int i = 0, y = height + m.getAscent() / 2; i < _yDivisions.length - 1; i++, y -= dy) {
	    l = Integer.toString(_yDivisions[i]);
	    g.drawString(l, -4 - m.stringWidth(l), y);
	}
	l = Integer.toString(_yDivisions[_yDivisions.length - 1]);
	g.drawString(l, -4 - m.stringWidth(l), m.getAscent() / 2);
    }

    private void paintFrame(Graphics g, int width, int height) {
	g.setColor(Color.white);
	g.drawRect(0, 0, width, height);
	g.setColor(Color.black);
	g.fillRect(1, 1, width - 1, height - 1);
    }

    private void paintXGrid(Graphics g, int width, int height) {
	if (_head == _tail)
	    return;
	g.setColor(Color.white);
	long end = _timestamps[_head > 0 ? _head - 1 : SAMPLE_COUNT - 1];
	long start = _timestamps[getStartPosition(width)];
	for (long time = (end + 999l) / 1000l * 1000l; time >= start; time -= 1000l) {
	    int x = width - PIXEL_PER_100MS * (int) (end - time + 1000l) / 10;
	    g.drawLine(x, 0, x, 6);
	    g.drawLine(x, height, x, height - 6);
	    for (int y = 0; y < height; y += 5)
		g.drawLine(x, y, x, y);
	}
    }

    private int getStartPosition(int width) {
	int interval = width * 10 * 1000 / PIXEL_PER_100MS;
	long time = _timestamps[_head > 0 ? _head - 1 : SAMPLE_COUNT - 1];
	for (int p = _head > 0 ? _head - 1 : SAMPLE_COUNT - 1;; p = p > 0 ? p - 1 : SAMPLE_COUNT - 1)
	    if (p == _tail || time - _timestamps[p] > interval)
		return p;
    }

    private void paintYGrid(Graphics g, int width, int height) {
	g.setColor(Color.white);
	int dy = height / (_yDivisions.length - 1);
	for (int i = 1, y = height - dy; i < _yDivisions.length - 1; i++, y -= dy) {
	    g.drawLine(0, y, 6, y);
	    g.drawLine(width - 6, y, width, y);
	    for (int x = 0; x < width; x += 5)
		g.drawLine(x, y, x, y);
	}
    }

    private void paintSamples(Graphics g, int width, int height) {
	if (_head == _tail)
	    return;
	g.setColor(Color.yellow);
	int prevX = -1;
	int prevY = -1;
	int range = _yDivisions[_yDivisions.length - 1] - _yDivisions[0];
	long end = _timestamps[_head > 0 ? _head - 1 : SAMPLE_COUNT - 1];
	long start = _timestamps[getStartPosition(width)];
	for (int p = getStartPosition(width); p != (_head > 0 ? _head - 1 : SAMPLE_COUNT - 1); p = (p + 1) % SAMPLE_COUNT) {
	    int x = width - PIXEL_PER_100MS * (int) (end - _timestamps[p]) / 10;
	    int y = height - (_values[p] - _yDivisions[0]) * height / range;
	    if (prevX == -1)
		g.drawLine(x, y, x, y);
	    else
		g.drawLine(prevX, prevY, x, y);
	    prevX = x;
	    prevY = y;
	}
    }

    public static void main(String[] args) throws Exception {
	Frame f = new Frame("Scope");
	f.setBackground(Color.gray);
	f.setBounds(100, 100, 400, 300);
	f.setLayout(new BorderLayout());
	Scope s = new Scope();
	s.setYDivisions(new int[] {0, 100, 200, 300});
	f.add(s);
	f.show();
//	Random r = new Random();
	for (int i = 0; i < 2000; i++) {
//	    s.addSample(System.currentTimeMillis(), r.nextInt(300));
	    s.addSample(System.currentTimeMillis(), 50 + (i * 20) % 200);
	    Thread.currentThread().sleep(100);
	}
	Thread.currentThread().sleep(100000);
    }
}
