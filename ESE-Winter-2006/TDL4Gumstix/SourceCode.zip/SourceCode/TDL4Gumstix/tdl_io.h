#ifndef IO_H
#define IO_H

void InitIO();
int AnalogIO_get(int channel);
void AnalogIO_set(int channel, int value);
int DigitalIO_get(int channel);
void DigitalIO_set(int channel, int value);

#endif
