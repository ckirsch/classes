#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>
#include <math.h>
#include <pthread.h>

#define MAXSIZE 256
#define MAX_ANALOG 4
#define MAX_DIGITAL 4
#define BUFFER_SIZE 200
#define DEBUG 0

#define CALLOC(n, x) ((x *) calloc(n, sizeof(x)))


int sendSock, recvSock, ret, senderLen, msgCount;
char *recvbuf, *sensor, *value;
struct sockaddr_in anyServer, server;
int analogIO[MAX_ANALOG], digitalIO[MAX_DIGITAL];
char **msgBuffer;
pthread_mutex_t m;

const char *itoa(int n, char *string)
{
	sprintf(string, "%d", n);
	return string;
}


void initSocket(char* host, char* port) {
	struct hostent *h;
	int reuse = 1;
	if (DEBUG)
	fprintf(stderr, "-----------initSocket\n");
	if ((h = gethostbyname(host)) == 0){
		perror("GethostByName failed!\n");
	}
	if ((recvSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
		perror("Error creating socket!\n");
	}
	/*if ((sendSock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
		perror("Error creating socket!\n");
		exit(1);
	}
	

	server.sin_family = AF_INET;
	server.sin_port = htons(atoi("7777"));
	server.sin_addr.s_addr = INADDR_ANY;
	if (bind(sendSock, &server, sizeof(struct sockaddr_in)) < 0) {
		perror("Error binding\n");
		exit(1);
	}*/
	anyServer.sin_family = AF_INET;
	anyServer.sin_port = htons(atoi("7777"));
	anyServer.sin_addr.s_addr = INADDR_ANY;
	if (bind(recvSock, (struct sockaddr *) &anyServer, sizeof(struct sockaddr_in)) < 0) {
		perror("Error binding\n");
	} 
	
	senderLen = sizeof(struct sockaddr_in);
}

void parseMessage(int ret) {
	int i, valstart, intId, intValue;
	char ad;
	//char *id = CALLOC(ret, char);
	char id[ret];
	//char *value = CALLOC(ret, char);
	char value[ret];
	if (DEBUG > 1)
	fprintf(stderr, "-----------parseMessage (%s)\n", recvbuf);
	//if (recvbuf[0] == NULL)
		//return;
	if (recvbuf[0] != 's') { // packet is not a sensor input
		return;
	}
	ad = recvbuf[1];
	for (i = 3; i < ret; i++) {
		if (recvbuf[i] == ':') {
			valstart = i + 1;
			break;
		}
		id[i - 3] = recvbuf[i];
	}
	id[i - 3] = '\0';
	for (i = valstart; i < ret; i++) {
		value[i - valstart] = recvbuf[i];
	}
	intId = atoi(id);
	intValue = atoi(value);
	if (DEBUG) fprintf(stderr, "recv: %c %d %d... \n", ad, intId, intValue);
	if (ad == 'a') {
		analogIO[intId] = intValue;
	} else if (ad == 'd') {
		digitalIO[intId] = intValue;
	}
	//free(id);
	//free(value);
}

void *receive(void *params) {
	if (DEBUG > 1) fprintf(stderr, "-----------receive");
	while (1) {
		if (DEBUG > 1) fprintf(stderr, "recv\n");
		ret = recvfrom(recvSock, recvbuf, 100, 0, (struct sockaddr *)&anyServer, &senderLen);
		if (ret > 0) {
			parseMessage(ret);
		}
	}
	usleep(10);
}

void *sendMessages(void *params) {
	int i;
	int count;
	//char **buffer;
	char *buffer[BUFFER_SIZE];
	
 	if (DEBUG > 1) fprintf(stderr, "-----------sendMessages");
	while (1) {
		if (DEBUG > 1) fprintf(stderr, "-----------send %d messages", msgCount);
		pthread_mutex_lock(&m);
		count = msgCount;
		//buffer = CALLOC(msgCount, char*);
		for (i = 0; i < count; i++) {
			buffer[i] = msgBuffer[i];
			msgBuffer[i] = NULL;
		}
		msgCount = 0;
	  pthread_mutex_unlock(&m);
		for (i = 0; i < count; i++) {
			if (buffer[i] != NULL) {
				if (DEBUG) fprintf(stderr, " =>%s [%d], \n", buffer[i], strlen(buffer[i]));
				sendto (recvSock, buffer[i], strlen(buffer[i]) + 1, 0, (struct sockaddr *)&anyServer, senderLen);
				free(buffer[i]);
			} else //end of messages in buffer reached
				break;
		}
		//free(buffer);
		usleep(100);
	}
}

void IO_set(int channel, int value, char ad) {
	int i, pos = 0;
	//char *ch = CALLOC(BUFFER_SIZE, char);
	//char *v = CALLOC(BUFFER_SIZE, char);
	char ch[BUFFER_SIZE];
	char v[BUFFER_SIZE];
	
	char *msg;
	if (DEBUG > 1) fprintf(stderr, "-----------IO_set %d %d\n", channel, value);
	itoa(channel, ch);
	itoa(value, v); 
	msg = malloc(strlen(ch) + 3*sizeof(char) + strlen(v) + 1); 
	msg[pos++] = ad;
	msg[pos++] = ':';
	for (i = 0; i < strlen(ch); i++) {
		msg[pos++] = ch[i];
	}
	msg[pos++] = ':';
	for (i = 0; i < strlen(v); i++) {
		msg[pos++] = v[i];
	}
	msg[pos++] = '.';
	msg[pos] = '\0';
	if (DEBUG) fprintf(stderr, "%cs: %s %d (%d) \n", ad, msg, strlen(msg), msgCount);
	pthread_mutex_lock(&m);
	msgBuffer[msgCount++] = msg;
  pthread_mutex_unlock(&m);
  //free(ch);
  //free(v);
}

int AnalogIO_get(int channel) {
	if (DEBUG > 1) fprintf(stderr, "-----------AnalogIO_get %d %d\n", channel, analogIO[channel]);
	return analogIO[channel];
}

void AnalogIO_set(int channel, int value) {
	if (DEBUG > 1) fprintf(stderr, "-----------AnalogIO_set %d %d\n", channel, analogIO[channel]);
	IO_set(channel, value, 'a');
}

int DigitalIO_get(int channel) {
	if (DEBUG > 1) fprintf(stderr, "-----------DigitalIO_get %d %d\n", channel, digitalIO[channel]);
	return digitalIO[channel];
}

void DigitalIO_set(int channel, int value) {
	if (DEBUG > 1) fprintf(stderr, "-----------DigitalIO_set\n %d %d\n", channel, digitalIO[channel]);
	IO_set(channel, value, 'd');
}

int InitIO() {
	int sw, i;
	if (DEBUG > 1) fprintf(stderr, "-----------InitIO\n");
		
	recvbuf = CALLOC(BUFFER_SIZE, char);
	
	msgBuffer = malloc(BUFFER_SIZE);
	for (i = 0; i < BUFFER_SIZE; i++) {
		msgBuffer[i] = NULL;
	}
	
	msgCount = 0;
	pthread_mutex_init(&m, NULL);
 
	for (i = 0; i < MAX_ANALOG; i++) {
		analogIO[i] = 0;
		digitalIO[i] = 0;
	}
	initSocket("141.201.109.190", "7777");
	
	pthread_t receiveSensorInput;
	sw = pthread_create(&receiveSensorInput, NULL, receive, NULL);
	if (sw != 0) {
		fprintf(stderr, "Error");
	}
	pthread_t sendActuatorSet;
	sw = pthread_create(&sendActuatorSet, NULL, sendMessages, NULL);
	if (sw != 0) {
		fprintf(stderr, "Error");
	}
}

