package com.preetec.tdl.tools.vdist.platform.gumstix;

import com.preetec.tdl.tools.vdist.model.Node;
import com.preetec.tdl.util.PropertyPage;

public class GumstixNodeProperties extends PropertyPage {

    public static final String PROPKEY_BUILDROOT = "Build Root";
    public static final String PROPKEY_MATLAB    = "MATLAB";
    public static final String PROPKEY_EMACHINE  = "E-Machine";
    private static final String PROPDEF_BUILDROOT = "/gumstix-buildroot";
    private static final String PROPDEF_MATLAB    = "/MATLAB7";
    private static final String PROPDEF_EMACHINE  = "/TDL4Gumstix";

    private Node item;

    public GumstixNodeProperties(Node item) {
	super(item, new Entry[] {
            new PropertyPage.Entry(PROPKEY_BUILDROOT, PROPKEY_BUILDROOT),
            new PropertyPage.Entry(PROPKEY_MATLAB, PROPKEY_MATLAB),
            new PropertyPage.Entry(PROPKEY_EMACHINE, PROPKEY_EMACHINE)
	}, "Gumstix");
	this.item = item;
	String val = (String) getValueAt(0);
	if (val == null || val.equals(""))
	    setValueAt(PROPDEF_BUILDROOT, 0);
	val = (String) getValueAt(1);
	if (val == null || val.equals(""))
	    setValueAt(PROPDEF_MATLAB, 1);
	val = (String) getValueAt(2);
	if (val == null || val.equals(""))
	    setValueAt(PROPDEF_EMACHINE, 2);
    }

    public Object getValueAt(int row) {
	return item.getStringProperty(getKey(row));
    }

    public void setValueAt(Object value, int row) {
	item.model.beginSequence("Change Property");
	item.model.setProperty(item, getKey(row), (String) value);
	item.model.endSequence();
    }
}
