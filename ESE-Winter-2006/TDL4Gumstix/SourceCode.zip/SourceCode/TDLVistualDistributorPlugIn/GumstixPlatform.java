package com.preetec.tdl.tools.vdist.platform.gumstix;

import java.util.Iterator;

import com.preetec.tdl.ast.Element;
import com.preetec.tdl.ast.FunCall;
import com.preetec.tdl.ast.Mode;
import com.preetec.tdl.ast.Module;
import com.preetec.tdl.ast.Port;
import com.preetec.tdl.ast.Task;
import com.preetec.tdl.tools.tdlc.platform.EmbeddedCPlatform;
import com.preetec.tdl.tools.vdist.NodePlatform;
import com.preetec.tdl.tools.vdist.model.DistributorObject;
import com.preetec.tdl.tools.vdist.model.Node;
import com.preetec.tdl.tools.vdist.model.Placement;
import com.preetec.tdl.util.PropertyPage;

public class GumstixPlatform extends EmbeddedCPlatform implements NodePlatform {

    private Node node;

    public GumstixPlatform() {
    }

    // interface NodePlatform
    //
    public PropertyPage[] getPropertyPages(DistributorObject dob, PropertyPage[] base) {
	if (dob instanceof Node)
	    return DistributorObject.addPropertyPage(base, new GumstixBuildProperties((Node) dob));
	if (dob instanceof Placement) {
	    Placement pl = (Placement) dob;
	    return DistributorObject.addPropertyPages(base, new PropertyPage[] {
		new GumstixInputProperties(pl),
		new GumstixOutputProperties(pl)});
	}
	return null;
    }

    public void setNode(Node node) {
	this.node = node;
    }
    //
    // interface NodePlatform

    public String getName() {
	return "Gumstix";
    }

    // class EmbeddedCPlatform
    //
    protected void emitMainCIncludes() {
	out.println("#include <time.h>");
	out.println("#include <sys/timeb.h>");
	super.emitMainCIncludes();
    }

    protected void emitMainCContent() throws Exception {
	super.emitMainCContent();
	out.println();
	out.println("static long nextTimestamp;");
	out.println("static long getCurrentTimestamp() {");
	out.println("  struct timeb time;");
	out.println();
	out.println("  ftime(&time);");
	out.println("  return (long) time.time * 1000l * 1000l + (long) time.millitm * 1000l;");
	out.println("}");
	out.println();
	out.println("static long sleepUntilTimestamp(long timestamp) {");
	out.println("  long duration;");
	out.println("  struct timespec time;");
	out.println();
	out.println("  duration = timestamp - getCurrentTimestamp();");
	out.println("  if (duration <= 0l)");
	out.println("    return duration;");
	out.println("  time.tv_sec = duration / (1000l * 1000l);");
	out.println("  time.tv_nsec = (duration % 1000l) * 1000l;");
	out.println("  nanosleep(&time, NULL);");
	out.println("  return timestamp - getCurrentTimestamp();");
	out.println("}");
	out.println();
	out.println("int main(int argc, char **argv) {");
	out.println("  nextTimestamp = getCurrentTimestamp();");
	out.println("  InitIO();");
	out.println("  initTDLMachine();");
	out.println("  fprintf(stdout, \"[period = %dus]\", " + getPartitionPeriod() + ");");
	out.println("  fflush(stdout);");
	out.println("  for (;;) {");
	out.println("    tdl_machine_step();");
	out.println("    fprintf(stdout, \".\");");
	out.println("    fflush(stdout);");
	out.println("    nextTimestamp += " + getPartitionPeriod() + ";");
	out.println("    while (sleepUntilTimestamp(nextTimestamp) > 0l);");
	out.println("  }");
	out.println("  return 0;");
	out.println("}");
    }

    public void emitCPorts() throws Exception {
	super.emitCPorts();
	emitCGetttersAndSetters();
    }

    public void close(boolean ok) throws Exception {
	super.close(ok);
	if (ok)
	    emitMakefile();
    }
    //
    // class EmbeddedCPlatform

    private void emitCGetttersAndSetters() {
	if (commLayer.isStub(module))
	    return;
	out.println();
	out.println(comment("Getter and setter functions"));
	Placement placement = node.model.getPlacement(node.model.getModule(module.name), node);
	Port[] ports = module.getPorts();
	for (int i = 0; i < ports.length; i++) {
	    Port p = ports[i];
	    if (p.kind == Port.KIND_SENSOR) {
		String device = placement.getSensorDevice(p.name);
		if (device == null || device.equals(""))
		    continue;
		out.println("static " + portType(p) + " " + qualifiedMember(p.moduleID, p.usesDriver) + "(void) {");
		if (device.startsWith("Analog"))
		    out.println("  return AnalogIO_get(" + device.substring(device.lastIndexOf(" ") + 1) + ");");
		else if (device.startsWith("Digital"))
		    out.println("  return DigitalIO_get(" + device.substring(device.lastIndexOf(" ") + 1) + ");");
		out.println("}");
		out.println();
	    } else if (p.kind == Port.KIND_ACTUATOR) {
		String device = placement.getActuatorDevice(p.name);
		if (device == null || device.equals(""))
		    continue;
		out.println("static void " + qualifiedMember(p.moduleID, p.usesDriver) + "(" + portType(p) + " value) {");
		if (device.startsWith("Analog"))
		    out.println("  AnalogIO_set(" + device.substring(device.lastIndexOf(" ") + 1) + ", value);");
		else if (device.startsWith("LED"))
		    out.println("  DigitalIO_set(" + device.substring(device.lastIndexOf(" ") + 1) + ", value);");
		out.println("}");
		out.println();
	    }
	}
    }

    private void emitMakefile() throws Exception {
	this.out = newPrintStream(destDir, "Makefile");
	try {
	    emitMakefileHeader();
	    emitMakefileContent();
	} catch (Exception e) {
	    e.printStackTrace();
	} finally {
	    out.close();
	}
    }

    protected void emitMakefileHeader() {
	String buildroot = node.getStringProperty(GumstixNodeProperties.PROPKEY_BUILDROOT);
	String matlab = node.getStringProperty(GumstixNodeProperties.PROPKEY_MATLAB);
	String emachine = node.getStringProperty(GumstixNodeProperties.PROPKEY_EMACHINE);
	out.println("##   plugin:    " + this.getClass().getName());
	out.println("##   generated: " + new java.util.Date());
	out.println();
	out.println("CC = " + buildroot + "/build_arm_nofpu/staging_dir/bin/arm-linux-gcc");
	out.println("RM = rm");
	out.print("CFLAGS = -O2 -I" + matlab + "/simulink/include -I" + matlab + "/rtw/c/libsrc -I" + matlab + "/stateflow/c/mex/include -I" + emachine);
	for (Iterator m = modules.iterator(); m.hasNext();)
	    out.print(" -I../../Modules/" + ((Module) m.next()).name);
	out.println();
	out.println("LFLAGS = -pthread");
	out.println();
    }

    protected void emitMakefileContent() {
	out.print("all:");
	out.print(" tdl_machine.o tdl_io.o tdl_main_.o");
	for (Iterator m = modules.iterator(); m.hasNext();) {
	    Module mod = (Module) m.next();
	    out.print(" " + mod.name + ".o");
	    out.print(" " + mod.name + "_.o");
	    for (Iterator g = mod.globals.getIndexIterator(); g.hasNext();) {
		Element e = (Element) g.next();
		if (e instanceof Task) {
		    out.print(" " + mod.name + "_" + e.name + ".o");
		    out.print(" " + mod.name + "_" + e.name + "_data.o");
		} else if (e instanceof Mode) {
		    Mode.Activity[] acts = ((Mode) e).activities;
		    for (int j = 0; j < acts.length; j++)
			if (acts[j].guard != null)
			    out.print(" " + mod.name + "_" + acts[j].guard.name + ".o");
		}
	    }
	}
	out.println();
	out.print("\t${CC} ${LFLAGS} -o " + node.getName() + " tdl_machine.o tdl_io.o tdl_main_.o");
	for (Iterator m = modules.iterator(); m.hasNext();) {
	    Module mod = (Module) m.next();
	    out.print(" " + mod.name + ".o");
	    out.print(" " + mod.name + "_.o");
	    for (Iterator g = mod.globals.getIndexIterator(); g.hasNext();) {
		Element e = (Element) g.next();
		if (e instanceof Task) {
		    out.print(" " + mod.name + "_" + e.name + ".o");
		    out.print(" " + mod.name + "_" + e.name + "_data.o");
		} else if (e instanceof Mode) {
		    Mode.Activity[] acts = ((Mode) e).activities;
		    for (int j = 0; j < acts.length; j++)
			if (acts[j].guard != null)
			    out.print(" " + mod.name + "_" + acts[j].guard.name + ".o");
		}
	    }
	}
	out.println();
	out.println();
	String emachine = node.getStringProperty(GumstixNodeProperties.PROPKEY_EMACHINE);
	out.println("tdl_machine.o: " + emachine + "/tdl_machine.c");
	out.println("\t${CC} ${CFLAGS} -c " + emachine + "/tdl_machine.c");
	out.println();
	out.println("tdl_io.o: " + emachine + "/tdl_io.c");
	out.println("\t${CC} ${CFLAGS} -c " + emachine + "/tdl_io.c");
	out.println();
	out.println("tdl_main_.o: tdl_main_.c");
	out.println("\t${CC} ${CFLAGS} -c tdl_main_.c");
	out.println();
	for (Iterator m = modules.iterator(); m.hasNext();) {
	    Module mod = (Module) m.next();
	    out.println(mod.name + ".o: ../../Modules/" + mod.name + "/" + mod.name + ".c");
	    out.println("\t${CC} ${CFLAGS} -c ../../Modules/" + mod.name + "/" + mod.name + ".c");
	    out.println();
	    for (Iterator g = mod.globals.getIndexIterator(); g.hasNext();) {
		Element e = (Element) g.next();
		String nam;
		if (e instanceof Task) {
		    nam = mod.name + "_" + e.name;
		    out.println(nam + ".o: ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + ".c");
		    out.println("\t${CC} ${CFLAGS} -c ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + ".c");
		    out.println();
		    out.println(nam + "_data.o: ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + "_data.c");
		    out.println("\t${CC} ${CFLAGS} -c ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + "_data.c");
		    out.println();
		} else if (e instanceof Mode) {
		    Mode.Activity[] acts = ((Mode) e).activities;
		    for (int j = 0; j < acts.length; j++) {
			if (acts[j].guard == null)
			    continue;
			nam = mod.name + "_" + acts[j].guard.name;
			out.println(nam + ".o: ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + ".c");
			out.println("\t${CC} ${CFLAGS} -c ../../Modules/" + mod.name + "/" + nam + "_ert_rtw/" + nam + ".c");
			out.println();
		    }
		}
	    }
	}
	out.println();
	out.println("clean:");
	out.print("\t${RM} " + node.getName() + " tdl_machine.o tdl_io.o tdl_main_.o");
	for (Iterator m = modules.iterator(); m.hasNext();) {
	    Module mod = (Module) m.next();
	    out.print(" " + mod.name + ".o");
	    out.print(" " + mod.name + "_.o");
	    for (Iterator g = mod.globals.getIndexIterator(); g.hasNext();) {
		Element e = (Element) g.next();
		if (e instanceof Task) {
		    out.print(" " + mod.name + "_" + e.name + ".o");
		    out.print(" " + mod.name + "_" + e.name + "_data.o");
		} else if (e instanceof Mode) {
		    Mode.Activity[] acts = ((Mode) e).activities;
		    for (int j = 0; j < acts.length; j++)
			if (acts[j].guard != null)
			    out.print(" " + mod.name + "_" + acts[j].guard.name + ".o");
		}
	    }
	}
	out.println();
    }
}
