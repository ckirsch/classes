package com.preetec.tdl.tools.vdist.platform.gumstix;

import javax.swing.JComboBox;

import com.preetec.tdl.tools.vdist.model.Placement;
import com.preetec.tdl.util.PropertyPage;

public class GumstixInputProperties extends PropertyPage {

    static final String[] SENSORS = new String[] {
	"",
	"Analog 1", "Analog 2", "Analog 3", "Analog 4",
	"Digital 1", "Digital 2", "Digital 3", "Digital 4"};

    private Placement item;

    public GumstixInputProperties(Placement item) {
	super(item, item.getSensorNames(), "Input");
	this.item = item;
    }

    public Object getValueAt(int row) {
	String val = item.getSensorDevice(getName(row));
	val = val != null ? val : "";
	JComboBox cmb = new JComboBox(SENSORS);
	cmb.getEditor().setItem(val);
	return cmb;
    }

    public void setValueAt(Object value, int row) {
	item.model.beginSequence("Change Sensor");
	item.model.changeSensor(item, getName(row), (String) value);
	item.model.endSequence();
    }

    public String getLeftLabel() {
	return "Sensor Name";
    }

    public String getRightLabel() {
	return "Input Device";
    }
}
