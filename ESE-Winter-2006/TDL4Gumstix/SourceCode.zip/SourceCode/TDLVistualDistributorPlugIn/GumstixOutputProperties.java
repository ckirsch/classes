package com.preetec.tdl.tools.vdist.platform.gumstix;

import javax.swing.JComboBox;

import com.preetec.tdl.util.PropertyPage;
import com.preetec.tdl.tools.vdist.model.Placement;

public class GumstixOutputProperties extends PropertyPage {

  static final String[] ACTUATORS = new String[] {
      "",
      "Analog 1", "Analog 2", "Analog 3", "Analog 4",
      "Digital 1", "Digital 2", "Digital 3", "Digital 4"};

    private Placement item;

    public GumstixOutputProperties(Placement item) {
	super(item, item.getActuatorNames(), "Output");
	this.item = item;
    }

    public Object getValueAt(int row) {
	String val = (String) item.getActuatorDevice(getName(row));
	val = val != null ? val : "";
	JComboBox cmb = new JComboBox(ACTUATORS);
	cmb.getEditor().setItem(val);
	return cmb;
    }

    public void setValueAt(Object value, int row) {
	item.model.beginSequence("Change Actuator");
	item.model.changeActuator(item, getName(row), (String) value);
	item.model.endSequence();
    }

    public String getLeftLabel() {
	return "Actuator Name";
    }

    public String getRightLabel() {
	return "Output Device";
    }
}
