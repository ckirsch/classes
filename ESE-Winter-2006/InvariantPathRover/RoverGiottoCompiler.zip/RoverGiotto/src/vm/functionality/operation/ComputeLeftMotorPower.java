package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class ComputeLeftMotorPower extends Operation{

	public int op(int pc, Vector params){	
		//copy global to actuator port
		//code actuator port fix?
		String portID = "global_valueRotation";
		Port port = portHandler.getPort(portID);
		String leftMotorID = (String)params.elementAt(2);
		Port leftMotor = portHandler.getPort(leftMotorID);
		
		if(port.read()>100){
        	leftMotor.write(rover.SLOWSPEED);
		}
		else{
			leftMotor.write(rover.NORMALSPEED);
		}
		
		portHandler.setPort(leftMotorID, leftMotor);
		
		return pc++;
	}

}
