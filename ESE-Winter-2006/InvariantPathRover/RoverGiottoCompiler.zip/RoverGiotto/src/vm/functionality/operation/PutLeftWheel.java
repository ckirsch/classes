package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;

public class PutLeftWheel extends Operation{

	public int op(int pc, Vector params) {
		rover.putLeftWheel(portHandler.getPort((String)params.elementAt(1)).read());
		return pc++;
	}

}
