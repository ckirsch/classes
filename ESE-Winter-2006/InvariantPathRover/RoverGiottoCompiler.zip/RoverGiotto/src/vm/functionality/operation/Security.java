package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class Security extends Operation{

	public int op(int pc, Vector params) {
		String leftLightID = "local_valueLeftLight";
		Port leftLight = portHandler.getPort(leftLightID);
		leftLight.write(portHandler.getPort("securityTask_valLeftLight").read());
		
		String rightLightID = "local_valueRightLight";
		Port rightLight = portHandler.getPort(rightLightID);
		rightLight.write(portHandler.getPort("securityTask_valRightLight").read());
		
		String rotationID = "local_valueRotation";
		Port rotation = portHandler.getPort(rotationID);
		rotation.write(portHandler.getPort("securityTask_valRotation").read());
		
		portHandler.setPort(leftLightID, leftLight);
		portHandler.setPort(rightLightID, rightLight);
		portHandler.setPort(rotationID, rotation);
		
		return pc++;
	}

}
