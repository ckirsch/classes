package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;

public class dummy extends Operation{

	public int op(int pc, Vector params) {
		// TODO Auto-generated method stub
		return pc++;
	}

}
