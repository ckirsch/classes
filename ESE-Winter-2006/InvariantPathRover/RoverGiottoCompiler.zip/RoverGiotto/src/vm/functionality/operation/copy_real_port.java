package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class copy_real_port extends Operation{

	public int op(int pc, Vector params) {
		//write local port to global
		Port local = portHandler.getPort("local_" + params.elementAt(2));
		String globalPortID = "global_" + params.elementAt(2);
		Port global = portHandler.getPort(globalPortID);
		global.write(local.read());
		portHandler.setPort(globalPortID, global);
		return pc++;
	}

}
