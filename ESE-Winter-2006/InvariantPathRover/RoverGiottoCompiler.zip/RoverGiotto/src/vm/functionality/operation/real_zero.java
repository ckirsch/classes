package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class real_zero extends Operation{

	public int op(int pc, Vector params) {
		//local port set 0
		String portID = "local_"+(String)params.elementAt(1);
		Port port = portHandler.getPort(portID);
		port.write(0);
		portHandler.setPort(portID, port);
		return pc++;
	}
	
	

}
