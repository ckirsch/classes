package vm.functionality.operation;

import java.util.Vector;

import vm.core.VMUtils;
import vm.generic.Operation;

public class GoSecurity extends Operation{

	public int op(int pc, Vector params) {
		//read sensor ports
		String pcUpdate;
		if(rover.goSecurity((int)portHandler.getPort("global_valueLeftLight").read(), (int)portHandler.getPort("global_valueRightLight").read())){
			pcUpdate = (String)params.elementAt(2);
			return VMUtils.stringToInt(pcUpdate);
		}
		
		pcUpdate = (String)params.elementAt(3);
		return VMUtils.stringToInt(pcUpdate);
	}

}
