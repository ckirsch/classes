package vm.functionality.operation;

import java.util.Vector;

import vm.core.VMUtils;
import vm.generic.Operation;

public class constant_true extends Operation{

	public int op(int pc, Vector params) {
		String trueValue = (String)params.elementAt(2);
		return VMUtils.stringToInt(trueValue);
	}

}
