package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class GetRightLight extends Operation{
	
	public int op(int pc, Vector params) {
		String portID = (String)params.elementAt(2);
		Port port = portHandler.getPort(portID);
		port.write(rover.getRightLight());
		portHandler.setPort(portID, port);
		return pc++;
	}
}
