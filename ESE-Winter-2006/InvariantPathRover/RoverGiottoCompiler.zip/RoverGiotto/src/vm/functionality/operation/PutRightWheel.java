package vm.functionality.operation;
import java.util.Vector;

import vm.generic.Operation;


public class PutRightWheel extends Operation{

	public int op(int pc, Vector params){
		rover.putRightWheel(portHandler.getPort((String)params.elementAt(1)).read());
		return pc++;
	}
}
