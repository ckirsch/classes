package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class copy_real_port3 extends Operation{

	public int op(int pc, Vector params) {
	
		String task = (String)params.elementAt(2);
		
		String taskLeftLightID = task + "_valLeftLight";
		Port taskLeftLight = portHandler.getPort(taskLeftLightID);
		taskLeftLight.write(portHandler.getPort("lightLeft").read());
		
		String taskRightLightID = task + "_valRightLight";
		Port taskRightLight = portHandler.getPort(taskRightLightID);
		taskRightLight.write(portHandler.getPort("lightRight").read());
		
		String taskRotationID = task + "_valRotation";
		Port taskRotation = portHandler.getPort(taskRotationID);
		taskRotation.write(portHandler.getPort("rotation").read());
		
		portHandler.setPort(taskLeftLightID, taskLeftLight);
		portHandler.setPort(taskRightLightID, taskRightLight);
		portHandler.setPort(taskRotationID, taskRotation);
		
		return pc++;
	}

}
