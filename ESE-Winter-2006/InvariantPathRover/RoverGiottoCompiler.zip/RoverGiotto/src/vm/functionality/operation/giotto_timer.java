package vm.functionality.operation;

import java.util.Vector;

import vm.core.VMUtils;
import vm.generic.Operation;

public class giotto_timer extends Operation{

	public int op(int pc, Vector params) {
		String pcUpdate = (String)params.elementAt(2);
		return VMUtils.stringToInt(pcUpdate);
	}

}
