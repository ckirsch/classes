package vm.functionality.operation;

import java.util.Vector;

import vm.generic.Operation;
import vm.generic.Port;

public class ComputeRightMotorPower extends Operation{

	public int op(int pc, Vector params) {	
		String portID = "global_valueRotation";
		Port port = portHandler.getPort(portID);
		String rightMotorID = (String)params.elementAt(2);
		Port rightMotor = portHandler.getPort(rightMotorID);
		
		if(port.read()>100){
        	rightMotor.write(rover.SLOWSPEED);
		}
		else{
			rightMotor.write(rover.NORMALSPEED);
		}
		
		portHandler.setPort(rightMotorID, rightMotor);
		
		return pc++;
	}

}
