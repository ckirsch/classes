package vm.functionality;

import josx.platform.rcx.Motor;
import josx.platform.rcx.Sensor;

public class Rover{

	/*
	 * the circular buffers
	 */
    private CBuffer leftCBuffer;
	private CBuffer rightCBuffer;
	
	/*
	 * constants
	 */
	private  final int CBUFFERSIZE = 20;
	public  final int NORMALSPEED = 3;
	public  final int SLOWSPEED = 2;
	public  final int CURVSPEED = 0;
	public  final int BLACKLIMIT = 45;
	public  final int DIRECTION = 100;
	
	/**
	 * initialize the Rover
	 * default constructor
	 */
    public Rover() {      
        Sensor.S1.activate();
		Sensor.S2.activate();
		
		Sensor.S3.setTypeAndMode(4, 0xE0  );
		Sensor.S3.activate();
		Sensor.S3.setPreviousValue(100);
		
		Motor.A.setPower(NORMALSPEED);
		Motor.C.setPower(NORMALSPEED);
		Motor.A.forward();
		Motor.C.forward();
		
		leftCBuffer = new CBuffer(CBUFFERSIZE);
		rightCBuffer = new CBuffer(CBUFFERSIZE);
    }
   
    /**
     * returns the luminance value of the left light
     * @return
     */
    public  float getLeftLight(){
    	return Sensor.S1.readValue();
    }
    
    /**
     * returns the luminance value of the right light
     * @return
     */
    public  float getRightLight(){
    	return Sensor.S2.readValue();
    }
    
    /**
     * returns the value of the rotation sensor
     * @return
     */
    public  float getRotation(){
    	return Sensor.S3.readValue();
    }

    /**
     * sets the speed of the left motor
     * @param speed
     */
    public void putLeftWheel(float speed){
    	Motor.A.setPower((int)speed);
    }
    
    /**
     * sets the speed of the right motor
     * @param speed
     */
    public void putRightWheel(float speed){
    	Motor.C.setPower((int)speed);
    }
    
    /**
     * checks if a task switch to the curve task should be performed
     * @param sensorLeft
     * @param sensorRight
     * @return
     */
    public boolean goCurve(int sensorLeft, int sensorRight){
    	if(sensorLeft > BLACKLIMIT ){
    		return true;
    	}
    	else if(sensorRight > BLACKLIMIT){
    		return true;
    	}
    	return false;
    }
    
    /**
     * checks if a task switch to the security task should be performed
     * @param sensorLeft
     * @param sensorRight
     * @return
     */
    public boolean goSecurity(int sensorLeft, int sensorRight){
    	if(sensorLeft > BLACKLIMIT && sensorRight > BLACKLIMIT){
    		return true;
    	}
    	return false;
    }
    
    /**
     * checks if a task switch to the straight forward task should be performed
     * @param sensorLeft
     * @param sensorRight
     * @return
     */
    public boolean goStraight(int sensorLeft, int sensorRight){
    	if(sensorLeft <= BLACKLIMIT && sensorRight <= BLACKLIMIT){
    		return true;
    	}
    	return false;
    }
    
    /**
     * executes the straigt forward task
     * @param motorLeft
     * @param motorRight
     */
    public void straightForward(int motorLeft, int motorRight){
    	Motor.A.setPower((int)motorLeft);
    	Motor.C.setPower((int)motorRight);
    }
    
    /**
     * executes the curve task
     * @param motorLeft
     * @param motorRight
     */
    public void curve(int motorLeft, int motorRight){
    	Motor.A.setPower((int)motorLeft);
    	Motor.C.setPower((int)motorRight);
    }
    
    /**
     * executes the security task
     */
    public void security(){
    	int leftVal;
    	int rightVal;
    	
    	do{
			leftVal = leftCBuffer.getData();
			rightVal = rightCBuffer.getData();
		}while(leftVal>BLACKLIMIT || rightVal>BLACKLIMIT);
		
		if(leftVal <= BLACKLIMIT){
			Motor.A.setPower(CURVSPEED);
			Motor.C.setPower(NORMALSPEED);
		}
		else{
			Motor.A.setPower(NORMALSPEED);
			Motor.C.setPower(CURVSPEED);
		}
    }
    
}
