package vm.functionality;
public class CBuffer {
	
	private int[] cbuffer;
	private int read;
	private int write;
	private int size;
	
	/**
	 * constructor
	 */
	public CBuffer(int size){
		cbuffer = new int[size];
		this.size = size;
		read = 0;
		write = 0;
	}
	
	/**
	 * not performat write implemetation
	 * @param val
	 */
	public void write(int val){
		if(write>=size){
			//the performat solution does not work on the rcx, therefore a
			//iteration of the hole buffer is needed
			for(int i=1; i<size; i++){
				cbuffer[i-1] = cbuffer[i];
			}
			cbuffer[size-1] = val;
		}
		else{
			cbuffer[write] = val;
			write++;
		}
		if(read<size-1){
			read++;
		}
	}
	
	/**
	 * returns a entry
	 * @return
	 */
	public int getData(){
		if(read>0){
			read--;
			return cbuffer[read+1];
		}
		else{
			return cbuffer[0];
		}
	}
	
	/**
	 * returns the read position
	 * @return
	 */
	public int readPosition(){
		return read;
	}
	
	
	/**
	 * returns the circular buffer size
	 * @return
	 */
	public int getSize(){
		return size;
	}
}