package vm.core;

public class VMUtils {
	
	/**
	 * a simple string to integer cast
	 * @param integer
	 * @return
	 */
	public static int stringToInt(String integer){
		int val = 0;
		for(int i=0; i<integer.length(); i++){
			if(i>0){
				val *= 10;
			}
			val += (integer.charAt(i) - 48);
		}
		
		return val;
	}
}
