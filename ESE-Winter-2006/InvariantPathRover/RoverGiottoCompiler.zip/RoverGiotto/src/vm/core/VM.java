package vm.core;
import java.util.Vector;

import vm.generic.ECode;
import vm.generic.Operation;
import vm.generic.OperationHandler;


public class VM {

	private static ECode eCode;
	private static OperationHandler oHandler;
	private int pc;
	
	/**
	 * initializes the virtual machine
	 */
	public VM(){
		eCode = new ECode();
		oHandler = new OperationHandler(); 
		pc = 0;
	}
	
	/**
	 * start the vm
	 */
	public void start(){
		int limit = eCode.getECodeSize();
		
		Vector instruction;
		Operation operation;
		
		int op;
		
		//execute the ecode
		while(pc < limit){
			instruction = eCode.getInstruction(pc);
			op = VMUtils.stringToInt((String)instruction.elementAt(0));
			
			if(op==0){ //nop
				pc++;
			}
			else if(op==1 || op==2 || op==3 || op==4){
				//future
				operation = (Operation)oHandler.getOperation((String)instruction.elementAt(1));
				pc = operation.op(pc, instruction);
			}
			else if(op==5){
				pc = VMUtils.stringToInt((String)instruction.elementAt(1));
			}
			else if (op==6){
				//return
			}
		}
	}
	
	/**
	 * the main method
	 * @param args
	 */
	public static void main(String[] args) {
		VM vm = new VM();
		vm.start();
	}

}
