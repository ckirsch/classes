package vm.generic;

import java.util.Vector;

import vm.functionality.Rover;

public abstract class Operation {
	protected static Rover rover;
	protected static PortHandler portHandler;
	
	/**
	 * the abastract operation class constructor
	 *
	 */
	public Operation(){
		rover = new Rover();
		portHandler = new PortHandler();
	}
	
	/**
	 * every operation has to implement op
	 * @param pc
	 * @param params
	 * @return
	 */
	public abstract int op(int pc, Vector params);
}
