package vm.generic;
import java.util.Vector;

public class ECode {
	
	private static Vector code;
	
	public ECode(){
		code = new Vector();
		initECode();
	}
	
	private static void initECode(){
		Vector tmp;
		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.real_zero");
		tmp.addElement("valueLeftLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.real_zero");
		tmp.addElement("valueRightLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.real_zero");
		tmp.addElement("valueRotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("4");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueLeftLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRightLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("8");
		tmp.addElement("9");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeLeftMotorPower");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("10");
		tmp.addElement("11");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeRightMotorPower");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutLeftWheel");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutRightWheel");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoCurve");
		tmp.addElement("16");
		tmp.addElement("18");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("curve");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("46");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoSecurity");
		tmp.addElement("19");
		tmp.addElement("21");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("security");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("71");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRotation");
		tmp.addElement("rotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("25");
		tmp.addElement("27");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port3");
		tmp.addElement("straightForwardTask");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("3");
		tmp.addElement("vm.functionality.operation.StraightForward");
		tmp.addElement("0");
		tmp.addElement("0");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("1");
		tmp.addElement("vm.functionality.operation.giotto_timer");
		tmp.addElement("4");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("6");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueLeftLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRightLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("33");
		tmp.addElement("34");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeLeftMotorPower");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("35");
		tmp.addElement("36");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeRightMotorPower");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutLeftWheel");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutRightWheel");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoStraight");
		tmp.addElement("41");
		tmp.addElement("43");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("straightForward");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("21");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoSecurity");
		tmp.addElement("44");
		tmp.addElement("46");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("security");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("71");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRotation");
		tmp.addElement("rotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("50");
		tmp.addElement("52");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port3");
		tmp.addElement("curveTask");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("3");
		tmp.addElement("vm.functionality.operation.Curve");
		tmp.addElement("0");
		tmp.addElement("0");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("1");
		tmp.addElement("vm.functionality.operation.giotto_timer");
		tmp.addElement("29");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("6");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueLeftLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRightLight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port");
		tmp.addElement("valueRotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("58");
		tmp.addElement("59");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeLeftMotorPower");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("60");
		tmp.addElement("61");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.ComputeRightMotorPower");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutLeftWheel");
		tmp.addElement("leftWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.PutRightWheel");
		tmp.addElement("rightWheel");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoStraight");
		tmp.addElement("66");
		tmp.addElement("68");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("straightForward");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("21");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.GoCurve");
		tmp.addElement("69");
		tmp.addElement("71");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.dummy");
		tmp.addElement("curve");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("5");
		tmp.addElement("46");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRotation");
		tmp.addElement("rotation");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetLeftLight");
		tmp.addElement("lightLeft");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.GetRightLight");
		tmp.addElement("lightRight");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("4");
		tmp.addElement("vm.functionality.operation.constant_true");
		tmp.addElement("75");
		tmp.addElement("77");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("2");
		tmp.addElement("vm.functionality.operation.copy_real_port3");
		tmp.addElement("securityTask");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("3");
		tmp.addElement("vm.functionality.operation.Security");
		tmp.addElement("0");
		tmp.addElement("0");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("1");
		tmp.addElement("vm.functionality.operation.giotto_timer");
		tmp.addElement("54");
		tmp.addElement("200");
		code.addElement(tmp);

		tmp = new Vector();
		tmp.addElement("6");
		code.addElement(tmp);

	}
	
	public Vector getInstruction(int pc){
		return (Vector)code.elementAt(pc);
	}
	
	public int getECodeSize(){
		return code.size();
	}
	
}
