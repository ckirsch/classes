package vm.generic;

public class Port {
	
	protected float value = 0;
	
	public float read(){
		return value;
	}
	public void write(float value){
		this.value = value;
	}
}
