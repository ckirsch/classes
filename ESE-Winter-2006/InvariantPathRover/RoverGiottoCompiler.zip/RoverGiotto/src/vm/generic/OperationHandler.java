package vm.generic;
import java.util.Hashtable;

public class OperationHandler {

	private static Hashtable operations;
	
	public OperationHandler(){
		operations = new Hashtable();
		initOperationHandler();
	}
	
	private static void initOperationHandler(){
		
		operations.put("vm.functionality.operation.GetLeftLight", new vm.functionality.operation.GetLeftLight());
		operations.put("vm.functionality.operation.GetRightLight", new vm.functionality.operation.GetRightLight());
		operations.put("vm.functionality.operation.GetRotation", new vm.functionality.operation.GetRotation());
		operations.put("vm.functionality.operation.PutRightWheel", new vm.functionality.operation.PutRightWheel());
		operations.put("vm.functionality.operation.PutLeftWheel", new vm.functionality.operation.PutLeftWheel());
		operations.put("vm.functionality.operation.real_zero", new vm.functionality.operation.real_zero());
		operations.put("vm.functionality.operation.copy_real_port", new vm.functionality.operation.copy_real_port());//2 parameter?
		operations.put("vm.functionality.operation.ComputeLeftMotorPower", new vm.functionality.operation.ComputeLeftMotorPower());
		operations.put("vm.functionality.operation.ComputeRightMotorPower", new vm.functionality.operation.ComputeRightMotorPower());
		operations.put("vm.functionality.operation.dummy", new vm.functionality.operation.dummy());
		operations.put("vm.functionality.operation.copy_real_port3", new vm.functionality.operation.copy_real_port3());
		operations.put("vm.functionality.operation.giotto_timer", new vm.functionality.operation.giotto_timer());
		operations.put("vm.functionality.operation.StraightForward", new vm.functionality.operation.StraightForward());
		operations.put("vm.functionality.operation.Curve", new vm.functionality.operation.Curve());
		operations.put("vm.functionality.operation.Security", new vm.functionality.operation.Security());
		operations.put("vm.functionality.operation.constant_true", new vm.functionality.operation.constant_true());
		operations.put("vm.functionality.operation.GoCurve", new vm.functionality.operation.GoCurve());
		operations.put("vm.functionality.operation.GoSecurity", new vm.functionality.operation.GoSecurity());
		operations.put("vm.functionality.operation.GoStraight", new vm.functionality.operation.GoStraight());

	}
	
	public Operation getOperation(String name){
		return (Operation)operations.get(name);
	}
	
}
