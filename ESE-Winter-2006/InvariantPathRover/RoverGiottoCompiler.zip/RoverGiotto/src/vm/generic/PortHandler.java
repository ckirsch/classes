package vm.generic;
import java.util.Hashtable;


public class PortHandler {

	private static Hashtable ports;
	
	public PortHandler(){
		ports = new Hashtable();
		initPortHandler();
	}
	
	private void initPortHandler(){
		
		ports.put("lightLeft", new Port());
		ports.put("lightRight", new Port());
		ports.put("rotation", new Port());
		ports.put("rightWheel", new Port());
		ports.put("leftWheel", new Port());
		ports.put("global_valueLeftLight", new Port());
		ports.put("local_valueLeftLight", new Port());
		ports.put("global_valueRightLight", new Port());
		ports.put("local_valueRightLight", new Port());
		ports.put("global_valueRotation", new Port());
		ports.put("local_valueRotation", new Port());
		ports.put("straightForwardTask_valLeftLight", new Port());
		ports.put("straightForwardTask_valRightLight", new Port());
		ports.put("straightForwardTask_valRotation", new Port());
		ports.put("curveTask_valLeftLight", new Port());
		ports.put("curveTask_valRightLight", new Port());
		ports.put("curveTask_valRotation", new Port());
		ports.put("securityTask_valLeftLight", new Port());
		ports.put("securityTask_valRightLight", new Port());
		ports.put("securityTask_valRotation", new Port());
	}
	
	public Port getPort(String name){
		return (Port)ports.get(name);
	}
	
	public void setPort(String name, Port port){
		ports.put(name, port);
	}
	
}
