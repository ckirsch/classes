#ifndef __emachine_h__
#define __emachine_h__

#include <semaphore.h>

#define MAXTRIGGER 10

#define OPCODE_IF        0
#define OPCODE_CALL      1
#define OPCODE_SCHEDULE  2
#define OPCODE_FUTURE    3
#define OPCODE_RETURN    4

#define IF(condition,then_address)      {OPCODE_IF,        condition,   then_address}
#define CALL(driver)                    {OPCODE_CALL,      driver,      -1}
#define SCHEDULE(task)                  {OPCODE_SCHEDULE,  task,        -1}
#define FUTURE(rel_time,address)        {OPCODE_FUTURE,    rel_time,    address}
#define RETURN()                        {OPCODE_RETURN,    -1,          -1}

typedef struct {
  unsigned opcode;
  unsigned arg1;
  unsigned arg2;
} instruction_t;

typedef struct {
  long int trigger_time;
  unsigned address;
} time_trigger_t;

typedef void (*driver_code_type) (void);
typedef unsigned (*condition_code_type) (void);

void e_machine();

void e_machine_init(sem_t *, instruction_t *, driver_code_type *, condition_code_type *);

#endif














