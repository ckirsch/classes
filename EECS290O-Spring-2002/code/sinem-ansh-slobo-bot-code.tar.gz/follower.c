
#include <tm.h>
#include <unistd.h>
#include <semaphore.h>    
#include <emachine.h>
#include <conio.h>
#include <dsound.h>
#include <dsensor.h>
#include <dmotor.h>

#include <lnp.h>
#include <sys/irq.h>
#include <sys/h8.h>
#include <dkey.h>
#include <lnp-logical.h>
#include <sys/lnp-logical.h>
#include <cni.h>

#define MAXTASK       5
#define MAXINSTR      28
#define MAXDRIVER     7
#define MAXCONDITION  5

#define MAX_STEP 6

#define T -150 /*100*/
#define R -150 /* -150 *//*112*/
#define D -10

#define RIGHT 0
#define STRAIGHT 1
#define LEFT 2
#define BACK 3
#define NO 0
#define YES 1
#define LIGHT_THRESHOLD 95
#define LOW_THRESHOLD 42
#define FREQ_DIV 6 /*10*/
#define DIV_COMM 12

#define LEN 2
#define MY_PORT 2
#define DEST_HOST 0
#define DEST_PORT 2
#define DEST_ADDR ( DEST_HOST << 4 | DEST_PORT )

#define INTERVAL 3

unsigned task_ids[MAXTASK];
char* p_task_ids[MAXTASK];
sem_t task_semaphores[MAXTASK];

nonBlockingType found = {0,0};
circularBuffer directions;

void control_task();
void ref_orient_task();
void ref_search_task();
void ref_finish_task();
void send_task();
void T_motor_device_drv();
void R_motor_device_drv(); 
void reference_out_drv();
void reference_drv();
void control_drv();
void sound_drv();
void stop_drv();
unsigned start_over_cond();
unsigned freq_div_cond();
unsigned found_cond();
unsigned send_cond();
unsigned move_cond();

typedef void (*task_code_type) (void);
task_code_type schedule[MAXTASK] = { ref_orient_task, ref_search_task, control_task, ref_finish_task, send_task };
driver_code_type driver[MAXDRIVER] = { T_motor_device_drv, R_motor_device_drv, reference_out_drv, reference_drv, control_drv, sound_drv, stop_drv };
condition_code_type condition[MAXCONDITION] = { freq_div_cond, start_over_cond, found_cond, send_cond, move_cond };

instruction_t program[MAXINSTR] = {
  /* 0 */   CALL(0),
  /* 1 */   CALL(1),
  /* 2 */   IF(0,8),
  /* 3 */   CALL(2),
  /* 4 */   IF(2,12),
  /* 5 */   IF(4,8),
  /* 6 */   CALL(3),
  /* 7 */   SCHEDULE(1),
  /* 8 */   CALL(4),
  /* 9 */   SCHEDULE(2),
  /* 10 */  FUTURE(500,0),
  /* 11 */  RETURN(),
  /* 12 */  FUTURE(5000,19),
  /* 13 */  CALL(0),
  /* 14 */  CALL(1),
  /* 15 */  CALL(4),
  /* 16 */  SCHEDULE(2),
  /* 17 */  FUTURE(500,13),
  /* 18 */  RETURN(),
  /* 19 */  CALL(5),
  /* 20 */  FUTURE(500,19),
  /* 21 */  RETURN()
};

int T_increment, R_increment;
int T_g_ref, R_g_ref;
int T_speed, R_speed, T_dir, R_dir;

unsigned light;
int T_l_ref, R_l_ref;
unsigned light_max, search_state; 
signed dir, dirNew;

unsigned step, look_state, right_dir;

void send_task() {
    unsigned char data[LEN];
    unsigned char len = LEN;
    signed char result;
    char direction;
    
    dsound_system(DSOUND_BEEP);
    dsound_system(DSOUND_BEEP);
    dsound_system(DSOUND_BEEP);
    dsound_system(DSOUND_BEEP);
    
    direction = read_circBuffer(&directions);

    data[0]=direction;
    result = lnp_addressing_write(data,len ,DEST_ADDR,MY_PORT);

}

void control_task() {
  T_speed = 0.5*(T_g_ref - T_increment);
  T_dir = (T_speed < 0) ? fwd : rev;
  T_speed = (T_speed < 0) ? -T_speed : T_speed;

  R_speed = 0.5*(R_g_ref - R_increment);
  R_dir = (R_speed < 0) ? fwd : rev;
  R_speed = (R_speed < 0) ? -R_speed : R_speed;
}


void ref_orient_task() {
  R_l_ref = 0;
  T_l_ref = 0;
  switch(++look_state) {
  case 1:
    R_l_ref = -R;
    break;
  case 2:
    T_l_ref = T;
    break;
  case 3:
    R_l_ref = R;
    break;
  case 4:
  
    if (step < MAX_STEP){
      if(light >light_max){
	light_max = light;
	right_dir = step % (MAX_STEP - 1);
      }
      
      step++;
      T_l_ref = -T;
    }
    else if (right_dir > 0){
      right_dir --;
      if (right_dir != 0)
	T_l_ref = -T;
    }

    if(right_dir == 0)
      R_l_ref = R;
 
    look_state = 0;
    break;  
  }
}

void ref_search_task() {
  switch(++search_state) {
    case 1:
      dirNew = read_circBuffer(&directions);
  lcd_int(dirNew*100+dir*10+search_state);
      if(dirNew > dir)
	R_l_ref = -R;
      if(dirNew < dir)
	R_l_ref = R;
      break;
    case 2:
      if((dirNew-dir) > 1) 
	R_l_ref = -R;
      if((dirNew-dir) < -1) 
	R_l_ref = R;
      break;
    case 3:
      T_l_ref = T;
      dir = dirNew;
      search_state = 0;
      break;
  }
}

void ref_finish_task() {
}

unsigned start_over_cond() {
   return 1;
}
 
unsigned freq_div_cond() {
  static unsigned i = FREQ_DIV;

  if(i++ == FREQ_DIV) {
    i = 0;
    return 0;
  }
  return 1;
}

unsigned send_cond() {
  static unsigned i = 2;

  if(i++ == DIV_COMM) {
    i = 0;
    return 0;
  }
  return 1;
}

unsigned found_cond() {
  unsigned fou;

  fou = nonblocking_read(&found);
  if(fou==YES && search_state == 0 &&((directions.tail - directions.head) %  SIZE_CIRCULAR) == 2 ) {

    return 1;
  }  
  return 0;
}

unsigned move_cond() {
   
  if (((search_state > 0) || (((directions.tail) - (directions.head)) %  SIZE_CIRCULAR) >= INTERVAL)){
      return 0;
    }

    return 1;

}

void sound_drv(){
  dsound_system(DSOUND_BEEP);

}

void control_drv() {
  light = LIGHT_2;  
  T_increment = ROTATION_3;
  R_increment = ROTATION_1;
}

void reference_out_drv() {
  ds_rotation_set(&SENSOR_3,0);
  ds_rotation_set(&SENSOR_1,0);
  T_g_ref = T_l_ref;
  R_g_ref = R_l_ref;
  R_l_ref = 0;
  T_l_ref = 0;
}

void reference_drv() {
  /*
  light = LIGHT_2;  
  */
}

void T_motor_device_drv() {
  motor_b_dir(T_dir);
  motor_b_speed(T_speed);
}

void R_motor_device_drv() {
  motor_a_dir(R_dir);
  motor_a_speed(R_speed);
}

void stop_drv() {
  motor_a_dir(brake);
  motor_b_dir(brake);
}

int task_code(int argc, char **argv) {
   while(1) {
     sem_wait(&(task_semaphores[*((unsigned *) argv[0])]));

     schedule[*((unsigned *) argv[0])]();
  }
  return 0;
}


void packet_handler(const unsigned char* data,unsigned char length, unsigned char src)
{
  signed char direction,
    fou;

  direction = data[0];
  fou=data[1];

  nonblocking_write(&found,fou);
  write_circBuffer(&directions,direction);
}


void sens_act_init() {
  T_speed = R_speed = T_dir = R_dir = 0;

  step = 1;
  look_state = 0;
  right_dir = 1;
  light_max = 0;

  search_state = 0; /* 1 */
  dir = STRAIGHT;


  write_circBuffer(&directions, STRAIGHT);
  write_circBuffer(&directions, STRAIGHT);

  ds_active(&SENSOR_2);

  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);
  ds_rotation_set(&SENSOR_3,0);
  T_l_ref = 0;

  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);
  ds_rotation_set(&SENSOR_1,0);
  R_l_ref = 0;
}
 
int main() {
  unsigned i;

  lnp_logical_range(1);
  lcd_clear();
  cputs("wait");

  lnp_addressing_set_handler(MY_PORT, packet_handler);
   
  init_circBuffer(&directions);
       
  for (i = 0; i < MAXTASK; i++) {
    task_ids[i] = i;
    p_task_ids[i] = (char *)&(task_ids[i]);
     
    sem_init(&(task_semaphores[i]),0,0);

    execi(&task_code,1,&p_task_ids[i],PRIO_NORMAL,DEFAULT_STACK_SIZE);
  }  
  e_machine_init(task_semaphores, program, driver, condition);
  sens_act_init();

  return(0);
}















