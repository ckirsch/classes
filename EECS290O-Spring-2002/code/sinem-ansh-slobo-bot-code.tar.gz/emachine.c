#include <time.h>
#include <emachine.h>

sem_t *task_semaphore;
instruction_t *e_code;
driver_code_type *driver_code;
condition_code_type *condition_code;

unsigned n_enabled_triggers = 0;
time_trigger_t e_schedule[MAXTRIGGER];

void e_machine() {
  unsigned i = 0, j, end, pc, arg1, arg2;
  long int sys_time_aux = sys_time;

  while (i < n_enabled_triggers) {
    if (e_schedule[i].trigger_time <= sys_time_aux) {
     
      pc = e_schedule[i].address;

      for(j = i; j < n_enabled_triggers-1; j++) {
	e_schedule[j].trigger_time = e_schedule[j+1].trigger_time;
	e_schedule[j].address = e_schedule[j+1].address;
      }
      n_enabled_triggers--;     
      
      end = 0;
      while (!end) {
	arg1 = e_code[pc].arg1;
	arg2 = e_code[pc].arg2;

	switch(e_code[pc].opcode) {
 	  case OPCODE_IF:
	    if(condition_code[arg1]())
	      pc = arg2;
	    else
	      pc++;
	    break;
	  case OPCODE_FUTURE:
	    j = n_enabled_triggers;
	    e_schedule[j].trigger_time = sys_time_aux + arg1;
	    e_schedule[j].address = arg2;
	    n_enabled_triggers++;
	    pc++;
	    break;
 	  case OPCODE_CALL:
	    driver_code[arg1]();
	    pc++;
	    break;
	  case OPCODE_SCHEDULE:
	    sem_post(task_semaphore + arg1);
	    pc++;
	    break;
	  case OPCODE_RETURN:
	    end = 1;
	    pc++;
	    break;
        } /* switch */
      } /* while */  
    } /* if */
    else 
      i++;
  } /* while */
}

void e_machine_init(sem_t *sem, instruction_t *program, driver_code_type *driver, condition_code_type *condition) {
  task_semaphore = sem;
  e_code = program;
  driver_code = driver;
  condition_code = condition;
       
  e_schedule[0].trigger_time = sys_time + 1000;
  e_schedule[0].address = 0;
  n_enabled_triggers = 1;  
}
























