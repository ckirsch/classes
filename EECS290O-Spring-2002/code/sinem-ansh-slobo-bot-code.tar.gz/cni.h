#ifndef __cni_h__
#define __cni_h__

#define SIZE_CIRCULAR  50

typedef struct cBuffer{
  char buffer[SIZE_CIRCULAR];
  int head;
  int tail;
}circularBuffer;

typedef struct nBlockingType{
  char value;
  int CCF;
}nonBlockingType; 

void nonblocking_write(nonBlockingType *, char);

char nonblocking_read(nonBlockingType *);

void init_circBuffer(circularBuffer *);

void write_circBuffer(circularBuffer *, char );

char read_circBuffer(circularBuffer *);


#endif














