
#include <tm.h>
#include <unistd.h>
#include <semaphore.h>    
#include <emachine.h>
#include <conio.h>
#include <dsound.h>
#include <dsensor.h>
#include <dmotor.h>

#include <lnp.h>
#include <sys/irq.h>
#include <sys/h8.h>
#include <dkey.h>
#include <lnp-logical.h>
#include <sys/lnp-logical.h>
#include <cni.h>

#define MAXTASK       5
#define MAXINSTR      29
#define MAXDRIVER     7
#define MAXCONDITION  4

#define MAX_STEP 6

#define T -150 /*100*/
#define R -150 /*112*/
#define D 20

#define RIGHT 0
#define STRAIGHT 1
#define LEFT 2
#define BACK 3
#define NO 0
#define YES 1
#define LIGHT_THRESHOLD 50
#define LOW_THRESHOLD 1
#define FREQ_DIV 6 /*10*/
#define DIV_COMM 12

#define LEN 2
#define MY_PORT 2
#define DEST_HOST 0
#define DEST_PORT 2
#define DEST_ADDR ( DEST_HOST << 4 | DEST_PORT )

unsigned task_ids[MAXTASK];
char* p_task_ids[MAXTASK];
sem_t task_semaphores[MAXTASK];

circularBuffer directions;

void control_task();
void ref_orient_task();
void ref_search_task();
void ref_finish_task();
void send_task();
void T_motor_device_drv();
void R_motor_device_drv(); 
void reference_out_drv();
void reference_drv();
void control_drv();
void sound_drv();
void stop_drv();
unsigned start_over_cond();
unsigned freq_div_cond();
unsigned found_cond();
unsigned send_cond();

typedef void (*task_code_type) (void);
task_code_type schedule[MAXTASK] = { ref_orient_task, ref_search_task, control_task, ref_finish_task, send_task };
driver_code_type driver[MAXDRIVER] = { T_motor_device_drv, R_motor_device_drv, reference_out_drv, reference_drv, control_drv, sound_drv, stop_drv };
condition_code_type condition[MAXCONDITION] = { freq_div_cond, start_over_cond, found_cond, send_cond };

instruction_t program[MAXINSTR] = {
  /* 0 */   IF(1,11),
  /* 1 */   CALL(0),
  /* 2 */   CALL(1),
  /* 3 */   IF(0,7),
  /* 4 */   CALL(2),
  /* 5 */   CALL(3),
  /* 6 */   SCHEDULE(0),
  /* 7 */   CALL(4),
  /* 8 */   SCHEDULE(2),
  /* 9 */   FUTURE(500,0),
  /* 10 */  RETURN(),
  /* 11 */  CALL(0),
  /* 12 */  CALL(1),
  /* 13 */  IF(0,19),
  /* 14 */  IF(3,16),
  /* 15 */  SCHEDULE(4),
  /* 16 */  CALL(2),
  /* 17 */  CALL(3),
  /* 18 */  SCHEDULE(1),
  /* 19 */  CALL(4),
  /* 20 */  IF(2,24),
  /* 21 */  SCHEDULE(2),
  /* 22 */  FUTURE(500,11),
  /* 23 */  RETURN(),
  /* 24 */  CALL(6),
  /* 25 */  SCHEDULE(4),
  /* 26 */  CALL(5),
  /* 27 */  FUTURE(500,26),
  /* 28 */  RETURN()
};

int T_increment, R_increment;
int T_g_ref, R_g_ref;
int T_speed, R_speed, T_dir, R_dir;

unsigned light;
int T_l_ref, R_l_ref;
unsigned light_max, search_state, dir, found, lost;

unsigned step, look_state, right_dir;

void send_task() {
    unsigned char data[LEN];
    unsigned char len = LEN;
    signed char result;
    signed char direction, fou;

    direction = read_circBuffer(&directions);

    if (lost == YES)
      fou = lost;
    else
      fou = found;
    
    if (direction == -1)
      direction=0;
    data[0]=direction;
    data[1]=fou;
    result = lnp_addressing_write(data,len ,DEST_ADDR,MY_PORT);

}

void control_task() {

  T_speed = 0.5*(T_g_ref - T_increment);
  T_dir = (T_speed < 0) ? fwd : rev;
  T_speed = (T_speed < 0) ? -T_speed : T_speed;

  R_speed = 0.5*(R_g_ref - R_increment);
  R_dir = (R_speed < 0) ? fwd : rev;
  R_speed = (R_speed < 0) ? -R_speed : R_speed;
}


void ref_orient_task() {
  R_l_ref = 0;
  T_l_ref = 0;
  switch(++look_state) {
  case 1:
    R_l_ref = -R;
    break;
  case 2:
    T_l_ref = T;
    break;
  case 3:
    R_l_ref = R;
    break;
  case 4:
  
    if (step < MAX_STEP){
      lcd_int(light);
      if(light >light_max){
	light_max = light;
	right_dir = step % (MAX_STEP - 1);
      }
      
      step++;
      T_l_ref = -T;
    }
    else if (right_dir > 0){
      right_dir --;
      if (right_dir != 0)
	T_l_ref = -T;
    }

    if(right_dir == 0)
      R_l_ref = R;
 
    look_state = 0;
    break;  
  }
}

void ref_search_task() {
  R_l_ref = 0;
  T_l_ref = 0;
  switch(++search_state) {
    case 1:
      if(dir == LEFT)
	R_l_ref = R;
      break;
    case 2:
      light_max = 0;
      if(dir != RIGHT) 
	R_l_ref = R - D;
      break;
    case 3:
      T_l_ref = T;
      break;
    case 4:
      T_l_ref = -T; 
      break;
    case 5:
      if(light > light_max) {
	light_max = light;
	dir = RIGHT;
      }
      R_l_ref = -R /*- D*/;
      break;
    case 6:
      T_l_ref = T;
      break;
    case 7:
      T_l_ref = -T;
      break;
    case 8:
      if(light > light_max) {
	/*	dsound_system(DSOUND_BEEP);
	 */	light_max = light;
	dir = STRAIGHT;
      }   
      R_l_ref = -R /*- D*/;
      break;
    case 9:
      T_l_ref = T;
      break;
    case 10:
      T_l_ref = -T;
      break;
    case 11:
      if(light > light_max) {
	light_max = light;
	dir = LEFT;
      }
      if (light_max <= LOW_THRESHOLD)
        lost = YES;
      write_circBuffer(&directions, dir);
      if(dir != LEFT ) 
	R_l_ref = R - D;
      break;
    case 12:
      if(dir == RIGHT ) 
	R_l_ref = R ;
      break;

    case 13:
      T_l_ref = T;
      if(light_max > LIGHT_THRESHOLD) 
	found = YES;
      
      search_state = 0;
      break;
  }
}

void ref_finish_task() {
}

unsigned start_over_cond() {
  /*
  if(right_dir == 0) 
    return 1;

  return 0;
  */
   return 1;
}

  
unsigned freq_div_cond() {
  static unsigned i = FREQ_DIV;

  if(i++ == FREQ_DIV) {
    i = 0;
    return 0;
  }
  return 1;
}

unsigned send_cond() {
  static unsigned i = 2;

  if(i++ == DIV_COMM) {
    i = 0;
    return 0;
  }
  return 1;
}

unsigned found_cond() {
  if(light > LIGHT_THRESHOLD) {
    found = YES;
    return 1;
  }
  if (lost == YES)
    return 1;
  return 0;
}

void sound_drv(){
  //  dsound_system(DSOUND_BEEP);
}

void control_drv() {
  light = LIGHT_2;  
  lcd_int(light);
  T_increment = ROTATION_3;
  R_increment = ROTATION_1;
}

void reference_out_drv() {
  ds_rotation_set(&SENSOR_3,0);
  ds_rotation_set(&SENSOR_1,0);
  T_g_ref = T_l_ref;
  R_g_ref = R_l_ref;
}

void reference_drv() {
  /*
  light = LIGHT_2;  
  */
}

void T_motor_device_drv() {
  motor_b_dir(T_dir);
  motor_b_speed(T_speed);
}

void R_motor_device_drv() {
  motor_a_dir(R_dir);
  motor_a_speed(R_speed);
}

void stop_drv() {
  motor_a_dir(brake);
  motor_b_dir(brake);
}

int task_code(int argc, char **argv) {
   while(1) {
     sem_wait(&(task_semaphores[*((unsigned *) argv[0])]));

     schedule[*((unsigned *) argv[0])]();
  }
  return 0;
}

void sens_act_init() {
  T_speed = R_speed = T_dir = R_dir = 0;

  step = 1;
  look_state = 0;
  right_dir = 1;
  light_max = 0;

  search_state = 1;
  dir = STRAIGHT;
  found = NO;

  ds_active(&SENSOR_2);

  ds_active(&SENSOR_3);
  ds_rotation_on(&SENSOR_3);
  ds_rotation_set(&SENSOR_3,0);
  T_l_ref = 0;

  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);
  ds_rotation_set(&SENSOR_1,0);
  R_l_ref = 0;
}
 
int main() {
  unsigned i;

  lnp_logical_range(1);
  lcd_clear();
  cputs("wait");

  init_circBuffer(&directions);
       
  for (i = 0; i < MAXTASK; i++) {
    task_ids[i] = i;
    p_task_ids[i] = (char *)&(task_ids[i]);
     
    sem_init(&(task_semaphores[i]),0,0);

    execi(&task_code,1,&p_task_ids[i],PRIO_NORMAL,DEFAULT_STACK_SIZE);
  }  
  e_machine_init(task_semaphores, program, driver, condition);
  sens_act_init();

  return(0);
}















