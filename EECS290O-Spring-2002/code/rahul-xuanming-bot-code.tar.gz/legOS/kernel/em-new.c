// #ifdef CONF_EM

#include <em.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <dsound.h>
#include <time.h>
// #include <dbutton.h>
// #include <dkey.h>
#include <dmotor.h>

#include <sys/lcd.h>
#include <conio.h>

const int stack_max_size = 10;
const int eco_max_size = 35;
const int int_max_size = 10;

emachine_t* em;
// stack_t* stack;
trigger_node *head;

unsigned long clock_time;
int ticks = 0;
int pc = 0;

void em_init() {
        trigger_node *t0;
        trigger_node *t1;
       
cputs("Init");
msleep(200);
 
        if (em!= 0) {
                free(em->eco);
                free(em->i);
                free(em);
        }
        em 	= (emachine_t*) malloc (sizeof(emachine_t));
        em->eco = (inst_t*) malloc (eco_max_size*sizeof(inst_t));
        em->i 	= (int *) malloc (int_max_size*sizeof(int));
        
/*
        if (stack!=0) {
                free(stack->stack);
                free(stack);
        }
        stack 		= (stack_t*) malloc (sizeof(stack_t));
        stack->stack 	= (int*) malloc (stack_max_size*sizeof(int));
        stack->sp 	= -1;        
*/

        if (head!=0) {
                t0 = head;
                while(t0!=0) {
                        t1 = t0;
                        t0 = t0->next;
                        free(t1);
                }                        
        }
	head = (trigger_node *) 0;
//        head = (trigger_node *) NULL;
}        


void handle_triggers() {
	trigger_node* tn;
 
	ticks++;
	if ((ticks%50)==0)  {
//		if (PRESSED(dbutton(), BUTTON_RUN)) {
//			msleep(200);
//			if (RELEASED(dbutton(), BUTTON_RUN)) {
//				motor_a_dir(off);
//				motor_b_dir(off);
//				motor_c_dir(off);
//				em_init();
//				pc = 0;
//				ticks = 0;
//				return;
//			}
//		}
//		lcd_int(pc);
		if (head != 0) {  //triggers to be processed
		lcd_int(pc);
			clock_time = (unsigned long) sys_time;
			tn = removeTriggerNode();
			while (tn != 0) {
				pc = tn->trigger_object->next;
		                free(tn->trigger_object);
        		        free(tn);
				Einterpreter();
				tn = removeTriggerNode();
			}
		}  else {
//			em_init();
			Einterpreter();
		}
		ticks = 0;
	}
}


void Emachine(emachine_t* em_user) {
	configure_em(em_user);
//	head = create_trigger_node(create_trigger(NULL_INPUT,0,0));
	insert( create_trigger_node(create_trigger(NULL_INPUT,0,0)) );
}

void Einterpreter() {
        
	inst_t* inst;
  
// 	dsound_system(DSOUND_BEEP);
//	cputs("interpreter");
	while(pc < em->eco_size) {
dsound_system(DSOUND_BEEP);
lcd_int(em->eco_size);
		if (!fetch(&inst, &pc)) {
	 		dsound_system(DSOUND_BEEP);
			return;
		} 

		switch(inst->opcode) { 
			case NOP:
				break;
/*
			case PSH:
				push(inst->arg1);
				break;
			case POP:
				pop(); 
				break;
*/

//			case JMP:
//				pc = inst->arg1;
//				break;
			case FUTURE: {
				trigger *trig_obj = create_trigger(inst->arg1, inst->arg2, 0);
				insert (create_trigger_node(trig_obj));
//				pc = inst->arg2;
				return;
				}
			case RETURN:
//				cputs("return");
				return;
			case CALL:
				execute((int (*)()) inst->arg1);
				break;
			case SCHEDULE: {
				int k = execi(((int (*)()) inst->arg1), 0, NULL, 1, DEFAULT_STACK_SIZE);
				if (k==-1) 	{ cputs("err"); }
				break;
				}
			case SLEEP:
				head = create_trigger_node(create_trigger(TIMER_TRIGGER,inst->arg1,sys_time+inst->arg2));
				return;
    				break;
			default:
				return;
		}
	}

	return;
}


void configure_em(emachine_t* em_user) {
	int i;
  
	em_init();
	
	em->eco_size = em_user->eco_size;
	em->i_size   = em_user->i_size;
dsound_system(DSOUND_BEEP);
lcd_int(em->eco_size);
msleep(200);

	for(i=0; i<em->eco_size; i++) {
		em->eco[i].opcode = em_user->eco[i].opcode;
		em->eco[i].arg1   = em_user->eco[i].arg1;
		em->eco[i].arg2   = em_user->eco[i].arg2;
		em->eco[i].arg3   = em_user->eco[i].arg3;
	}

	for(i=0; i<em->i_size; i++) {
		em->i[i] = 0;
	}
}


int fetch(inst_t** inst, int* pcount) {
	if (*pcount >= em->eco_size) {
		return 0;
	}

	*inst = &(em->eco[*pcount]);
	*pcount = *pcount + 1;
	return 1;
}

int execute(int (*pf) ()) {
	return pf();
}

/*
int push(int i) {
	stack->sp += 1;
	if (stack->sp >= stack_max_size) {
		return -1;
	}
	stack->stack[stack->sp] = i;
	return 1;
}

int pop() {
	int tmp;
	if (stack->sp <= -1) {
		return -1;
	} 
	tmp = stack->sp;
	stack->sp = stack->sp - 1;
	return stack->stack[tmp];
}

int top() {
	if (stack->sp <= -1) {
		return -1;
	}
	return stack->stack[stack->sp];
}
*/


trigger* create_trigger(int signal, int next, unsigned long timer) {
	trigger* new_trigger = (trigger*) malloc (sizeof(trigger));

//	if ( (signal==0) && (next==0) )
//		return (trigger*) 0;

	if (new_trigger == 0) {
                cputs("trigger err");
                lcd_refresh();
		return (trigger*) 0;
        }        
	new_trigger->signal = signal;
	new_trigger->next = next;
	new_trigger->timer = timer;
	return new_trigger;
}

trigger_node* create_trigger_node(trigger* trigger_object) {
	trigger_node* new_node = (trigger_node*) malloc(sizeof(trigger_node));

	if (trigger_object == 0)
		return (trigger_node*) 0;

	if (new_node == 0)
		return (trigger_node*) 0;
	new_node->trigger_object = trigger_object;
	new_node->next = 0;
	return new_node;
}

void insert(trigger_node *new_node )  {
	trigger_node *current = head;
//	trigger_node *prev = head;

	dsound_system(DSOUND_BEEP);

  	/* empty list */
	if( current == 0 )
		head = new_node;         
	/* insert in front (need special case because of head ptr)*/
//	else if (current->trigger_object->m > m) {
	else {
		head = new_node;
		new_node->next = current;
	}
	/* other cases */
/*
	else {
		current = current->next;	
   		while ((current != 0) && (current->trigger_object->m < m)) {
   			current = current->next;
   			prev = prev->next;
   		}	
   		new_node->next = current;
   		prev->next = new_node;
	}
*/
}


trigger_node* removeTriggerNode()
{
	trigger_node *current, *prev, *temp;
	current = head;  
	prev = head;  
	temp = head;

	if (current == 0)
		return (trigger_node*) 0;

	if(check_signal(current->trigger_object->signal, current->trigger_object->timer)==1) {
		temp = current;
		head = current->next;
		return temp;
	}
 
	current = current->next;
	while(current != 0) {
		if (check_signal(current->trigger_object->signal, 0)==1) {
			temp = current;
			prev->next = current->next;
        	        return temp;
	        }
		current = current->next;
		prev = prev->next;
	}

	//no such node found	
	return (trigger_node*) 0;
}


trigger_node* descheduleTriggerNode(int signal, int next)
{
	trigger_node *current, *prev, *temp;
	current = head;  
	prev = head;  
	temp = head;

	if (current == 0)
		return (trigger_node*) 0;

	if ((current->trigger_object->signal == signal)&&(current->trigger_object->next == next)) {
		temp = current;
		head = current->next;	
		return temp;
	}

	current = current->next;
	while(current != 0) {
		if ((current->trigger_object->signal == signal)&&(current->trigger_object->next == next)) {
			temp = current;
			prev->next = current->next;
			return temp;
		}
		current = current->next;
		prev = prev->next;
	}

	//no such node found	
   	return (trigger_node*) 0;
}


int check_signal(int signal, unsigned long timer)
{
	dsound_system(DSOUND_BEEP);
	switch(signal) 	{ 
		case NULL_INPUT:
			return 1;
		case TOUCH_INPUT_1:
			if (TOUCH(SENSOR_1))
				return 1;
			else
				return 0;
		case TOUCH_INPUT_2:
			if (TOUCH(SENSOR_2))
				return 1;
			else
				return 0;
		case TOUCH_INPUT_3:
			if (TOUCH(SENSOR_3))
				return 1;
			else
				return 0;
		case LIGHT_LOW_1:
			if (LIGHT(SENSOR_1) < 34)
				return 1;
			else
				return 0;
		case LIGHT_HIGH_1:
			if (LIGHT(SENSOR_1) > 38)
				return 1;
			else
				return 0;
		case LIGHT_1_VALUE:
			break;
		case LIGHT_LOW_2:
			if (LIGHT(SENSOR_2) < 34)
				return 1;
			else
				return 0;
		case LIGHT_HIGH_2:
			if (LIGHT(SENSOR_2) > 38)
				return 1;
			else
				return 0;
		case LIGHT_2_VALUE:
			break;
		case LIGHT_LOW_3:
			if (LIGHT(SENSOR_3) < 34)
				return 1;
			else
				return 0;
		case LIGHT_HIGH_3:
			if (LIGHT(SENSOR_3) > 38)
				return 1;
			else
				return 0;
		case LIGHT_3_VALUE: 
			break;

		case TIMER_TRIGGER:
			if ( sys_time > timer )
				return 1;
			else 
				return 0;

		default:
			return 0;
	};
	return 0;
}

// #endif
