// #ifdef CONF_EM

#include <em.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <time.h>
#include <semaphore.h>

// #ifdef CONF_VIS
#include <sys/lcd.h>
#include <conio.h>
// #endif 


const int eco_max_size = 55;
const int int_max_size = 20;
int ticks = 0;
int pc = 0;

emachine_t* em;

void handle_triggers() {
  ticks++;
  if ((ticks%50)==0)  {
  	Einterpreter();
	ticks = 0;
  }
}


void Emachine(emachine_t* em_user) {
  configure_em(em_user);
}

void Einterpreter() {
        
  inst_t* inst;
  
  while(pc < em->eco_size) {
    if (!fetch(&inst, &pc)) {
      return;
    } 
    switch(inst->opcode) { 
    case NOP:
      break;
    case FUTURE: 
      pc = inst->arg1;
      return;
      break;
    case CALL:
      execute((int (*)()) inst->arg1);
      break;
    case SCHEDULE: {
      int k = execi(((int (*)()) inst->arg1), 0, NULL, 1, DEFAULT_STACK_SIZE);
      if (k==-1) { cputs("err"); }
      break;
    }
    
    default:
      return;
    }
  }
    
  return;
}

void configure_em(emachine_t* em_user) {
  int i;
  
  if (em!= 0) {
        free(em->eco);
        free(em);
  }
  em = (emachine_t*) malloc (sizeof(emachine_t));
  em->eco = (inst_t*) malloc (eco_max_size*sizeof(inst_t));
 
  em->eco_size = em_user->eco_size;

  for(i=0; i<em->eco_size; i++) {
      em->eco[i].opcode = em_user->eco[i].opcode;
      em->eco[i].arg1   = em_user->eco[i].arg1;
  }
}

int fetch(inst_t** inst, int* pc) {
  if (*pc >= em->eco_size) {
    return 0;
  }
  *inst = &(em->eco[*pc]);
  *pc = *pc + 1;
  return 1;
}

int execute(int (*pf) ()) {
  return pf();
}

