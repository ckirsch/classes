#include <stdio.h>
#include <string.h>

/**************************************************
	Some assumptions:
	----------------
	1. Max size of stack = 50
	2. If statements are to be written as:
		if - then - else - end
**************************************************/

/* Structure declarations */

struct node {
	int command;
	int arguments;
	char *arg1;
	int arg2;
	int position;
	int line_num;
	int traversed;
};

struct iofunction {
	int position;
	struct iofunction *next;
};

struct signal {
	int name;
	struct iofunction *input_function;
	struct iofunction *output_function;
	struct signal *next;
};

struct scfg_node {
	int command;
	int arguments;
	struct node *command_node;
	struct scfg_node *left;		/* For "true" evaluation */
	struct scfg_node *right;	/* For "false" evaluation */
};

struct state_var {
	int value;
	int position;
	struct state_var *next;
};

struct ecode_format {
	char *command;
	char *arg1;
	char *arg2;
	int position;
};


/* Global Variables */
int stack[100];
int stack_size=0;
int node_array[200][200];
struct node *ptr_array[200];
struct signal *signal_ptrs;
int left_fork=0;
int right_fork=0;
int within_fork=0;
int await_in_left_fork=0;
int await_in_right_fork=0;
int array_size;
int current_state_value=0;
int context_value=1;

/* Function Declarations */
struct node* add_node(int command, int arguments, int arg2, char *arg1, int position);
void push(int *stack, int position);
int pop(int *stack);
void add_input_function(int name, int position);
void add_output_function(int name, int position);
int all_parents_traversed(int position);
int state_size(struct state_var *sv);
int one_child_command(int command);
int first_child(int command);
int second_child(int command);
struct state_var* add_state(struct state_var *sv, struct state_var *new_state);
struct scfg_node* context_switch(struct state_var **ptr_to_saved_states, struct scfg_node *last_node);
struct scfg_node* program_list(int position, struct scfg_node *last_node, int *new_position, int *state_value);
void print_program(struct scfg_node *program_nodes);
int unroll_awaits(int fork_start, int array_pos);
void print_embedded_code(struct scfg_node *program_nodes, char *fname);
void itoa(int n, char s[]);
void reverse(char s[]);


main(int argc, char **argv)
{
FILE *fp;
int command,array_pos;
int parent, prev, prev_token;
int i,j;
int arguments;
int val1,pos1;
struct node *new, *new1;
struct signal *ptr;
struct iofunction *fptr1,*fptr2;
struct state_var *sv;
struct scfg_node *program_nodes,*last_program_node;
char arg1[50];


/********************************************
1 - if
2 - then
3 - else
4 - end
5 - emit
6 - merge
7 - present
8 - || (parallel operator)
9 - [ (starting of a set of statements)
10 - ] (ending of a set of statements)
11 - fork
12 - nop
13 - save state
14 - end program
15 - merge fork
16 - await without return
17 - await with return
18 - loop
19 - end loop
20 - jump
********************************************/

fp = fopen(argv[1],"r");
array_pos = 1;
prev = 0;
signal_ptrs = NULL;
stack_size = 0;

while (!feof(fp)) {
	fscanf(fp,"%d %d %s\n",&command,&arguments,arg1);

	if (!strcmp(arg1,"0")) {
		arg1[0] = '\0';
	}

	if (command == 1) {
		/* "If" */
		/* If node */
		node_array[prev][array_pos] = 1;
		new = add_node(1, arguments, 0, arg1, array_pos);
		ptr_array[array_pos] = new;
		push(stack, array_pos);
		prev = array_pos;
		/* Add to the signal input functions */
		if (within_fork)
			add_input_function(arguments,array_pos);
		array_pos++;
		/* "Merge" node */
		/*node_array[prev][array_pos] = 1;*/
		new1 = add_node(6, /* (char *) NULL*/ 0, 0, "", array_pos);
		ptr_array[array_pos] = new1;
		array_pos++;
	}

	if (command == 2) {
		/* "Then" */
		prev = prev;
	}

	if (command == 3) {
		/* "Else" */
		prev_token = pop(stack);
		node_array[prev][prev_token+1] = 1;
		prev = prev_token;
		push(stack,prev_token);
	}

	if (command == 4) {
		/* "End" */
		prev_token = pop(stack);
		node_array[prev][prev_token+1] = 1;
		prev = prev_token + 1;
	}

	if (command == 5) {
		/* "Emit" */
		node_array[prev][array_pos] = 1;
		new = add_node(5, arguments, 0, arg1, array_pos);
		ptr_array[array_pos] = new;
		prev = array_pos;
		/* Add to the signal output functions */
		if (within_fork)
			add_output_function(arguments, array_pos);
		array_pos++;
	}

	if (command == 7) {
		/* Present node */
		node_array[prev][array_pos] = 1;
		new = add_node(7, arguments, 0, arg1, array_pos);
		ptr_array[array_pos] = new;
		push(stack, array_pos);
		prev = array_pos;
		/* Add to the signal input functions */
		if (within_fork)
			add_input_function(arguments, array_pos);
		array_pos++;
		/* Merge node */
		/*node_array[prev][array_pos] = 1;*/
		new1 = add_node(6, /*(char *) NULL*/ 0, 0, "", array_pos);
		ptr_array[array_pos] = new1;
		array_pos++;
	}

	if (command == 8) {
		/* || - Parallel operator */
		prev_token = pop(stack);
		node_array[prev][prev_token+1] = 1;
		prev = prev_token;
		push(stack,prev_token);
		left_fork = 0;
		right_fork = 1;
		await_in_right_fork = 0;
	}

	if (command == 9) {
		/* [ - Opening operator */
		node_array[prev][array_pos] = 1;
		new = add_node(11, /*(char *) NULL*/ 0, 0, arg1, array_pos);
		ptr_array[array_pos] = new;
		push(stack, array_pos);
		prev = array_pos;
		array_pos++;
		within_fork = 1;
		await_in_left_fork = 0;
		left_fork = 1;
		right_fork = 0;
		/* Merge node */
		/*node_array[prev][array_pos] = 1;*/
		new1 = add_node(15, /*(char *) NULL*/ 0, 0, "", array_pos);
		ptr_array[array_pos] = new1;
		array_pos++;
	}

	if (command == 10) {
		/* ] - Closing operator */
		prev_token = pop(stack);
		node_array[prev][prev_token+1] = 1;
		prev = prev_token + 1;
		if (await_in_left_fork && await_in_right_fork) {
			array_pos = unroll_awaits(prev_token, array_pos);
		}
		within_fork = 0;
		left_fork = right_fork = 0;
		await_in_left_fork = await_in_right_fork = 0;
	}

	if (command == 16) {
		/* Await without return */
		if (!within_fork) {
			node_array[prev][array_pos] = 1;
			new = add_node(17, arguments, 0, arg1, array_pos);
			ptr_array[array_pos] = new;
			prev = array_pos;
			array_pos++;
		} else {
			/* An await within a fork */
			node_array[prev][array_pos] = 1;
			new = add_node(17, arguments, 0, arg1, array_pos);
			ptr_array[array_pos] = new;
			prev = array_pos;
			array_pos++;
			if (left_fork) {
				await_in_left_fork = 1;
			} else if (right_fork) {
				await_in_right_fork = 1;
			}
		}
	}

	if (command == 18) {
		/* Loop */
		push(stack, array_pos);
	}

	if (command == 19) {
		/* End loop */
		prev_token = pop(stack);
		node_array[prev][array_pos] = 1;
		new = add_node(20, prev_token, 0, arg1, array_pos);
		ptr_array[array_pos] = new;
		prev = array_pos;
		array_pos++;
	}
	array_size = array_pos;
}
/* Add the end program node */
node_array[prev][array_pos] = 1;
new = add_node(14, 0, 0, "", array_pos);
ptr_array[array_pos] = new;
prev = array_pos;
array_pos++;
/* Close the file and set the program size */
array_size = array_pos;
fclose(fp);

/* Add all the secondary dependencies due to signals */
for (ptr=signal_ptrs;ptr!=NULL;ptr=ptr->next)
	for (fptr1=ptr->output_function;fptr1!=NULL;fptr1=fptr1->next)
		for (fptr2=ptr->input_function;fptr2!=NULL;fptr2=fptr2->next)
			node_array[fptr1->position][fptr2->position] =2;


/* Print the array of potentials */
/* for (i=1;i<array_size;i++) {
	printf("%2d | %2d %2d | ",i,ptr_array[i]->command,ptr_array[i]->arguments);
	for (j=1;j<array_size;j++) 
		printf("%d ",node_array[i][j]);
	printf("\n");
} */

/* Sequentialize the parallelism */
last_program_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
last_program_node->command = 6;
last_program_node->arguments = 0;
sv = NULL;
program_nodes = program_list(1, last_program_node, &pos1, &val1);

/* Print the sequential program */
/* print_program(program_nodes); */

/* Print LEGOS embedded code! */
print_embedded_code(program_nodes,argv[2]);
}


int unroll_awaits(int fork_start, int array_pos) {
	int position, prev, before_fork, pos_left, pos_right;
	struct node *new;

	prev = before_fork = fork_start - 1;	
	node_array[before_fork][fork_start] = 0;
	position = first_child(fork_start);
	while ((ptr_array[position]->command!=16) && (ptr_array[position]->command!=17)) {
		node_array[prev][array_pos] = 1;
		new = add_node(ptr_array[position]->command, ptr_array[position]->arguments, 0, ptr_array[position]->arg1, array_pos);
		ptr_array[array_pos] = new;
		prev = array_pos;
		array_pos++;
		position++;
	}
	pos_left = position;
	position = second_child(fork_start);
	while ((ptr_array[position]->command!=16) && (ptr_array[position]->command!=17)) {
		node_array[prev][array_pos] = 1;
		new = add_node(ptr_array[position]->command, ptr_array[position]->arguments, 0, ptr_array[position]->arg1, array_pos);
		ptr_array[array_pos] = new;
		prev = array_pos;
		array_pos++;
		position++;
	}
	pos_right = position;
	/* Add the left side await */
	node_array[prev][array_pos] = 1;
	new = add_node(16, ptr_array[pos_left]->arguments, first_child(pos_left), "", array_pos);
	ptr_array[array_pos] = new;
	prev = array_pos;
	array_pos++;
	/* Add the right side await */
	node_array[prev][array_pos] = 1;
	new = add_node(17, ptr_array[pos_right]->arguments, first_child(pos_right), "", array_pos);
	ptr_array[array_pos] = new;
	prev = array_pos;
	array_pos++;
	/* Connect back to the start of fork */
	node_array[prev][fork_start] = 1;
	return(array_pos);
}


void print_program(struct scfg_node *program_nodes) {
	struct scfg_node *pc;
	char c;

	pc = program_nodes;
	printf("\n\nProgram\n");
	for (pc=pc;pc!=NULL;pc=pc->left) {
		printf("%d %d %d %d %d\n",pc,pc->command,pc->arguments,pc->left,pc->right);
	}		
}


struct node* add_node(int command, int arguments, int arg2, char *arg1, int position) {
	struct node *new;

	new = (struct node *) malloc(sizeof(struct node));
	new->command = command;
	new->arguments = arguments;
	new->arg2 = arg2;
	new->arg1 = strdup(arg1);
	new->position = position;
	return(new);
}


void push(int *stack, int position) {
	stack[stack_size++] = position;
}


int pop(int *stack) {
	if (stack_size > 0) {
		return(stack[--stack_size]);
	} else {
		return(-1);
	}
}


void add_input_function(int name, int position) {
	struct signal *ptr,*new_signal;
	struct iofunction *new_function;

	for (ptr=signal_ptrs;ptr!=NULL;ptr=ptr->next) {
		if (ptr->name == name) {
			/* Found signal, add the input function */
			new_function = (struct iofunction *) malloc(sizeof(struct iofunction));
			new_function->position = position;
			new_function->next = ptr->input_function;
			ptr->input_function = new_function;
			return;
	}
	}
	/* Did not find the signal, add it and the input function */
	new_signal = (struct signal *) malloc(sizeof(struct signal));
	new_signal->name = name;
	new_function = (struct iofunction *) malloc(sizeof(struct iofunction));
	new_function->position = position;
	new_function->next = NULL;
	new_signal->input_function = new_function;
	new_signal->output_function = NULL;
	new_signal->next = signal_ptrs;
	signal_ptrs = new_signal;
	return;
}


void add_output_function(int name, int position) {
	struct signal *ptr,*new_signal;
	struct iofunction *new_function;

	for (ptr=signal_ptrs;ptr!=NULL;ptr=ptr->next) {
		if (ptr->name == name) {
			/* Found signal, add the output function */
			new_function = (struct iofunction *) malloc(sizeof(struct iofunction));
			new_function->position = position;
			new_function->next = ptr->output_function;
			ptr->output_function = new_function;
			return;
		}
	}
	/* Did not find the signal, add it and the output function */
	new_signal = (struct signal *) malloc(sizeof(struct signal));
	new_signal->name = name;
	new_function = (struct iofunction *) malloc(sizeof(struct iofunction));
	new_function->position = position;
	new_function->next = NULL;
	new_signal->output_function = new_function;
	new_signal->input_function = NULL;
	new_signal->next = signal_ptrs;
	signal_ptrs = new_signal;
	return;
}


int all_parents_traversed(int position) {
	int i;

	for (i=1;i<array_size;i++) {
		if (node_array[i][position] != 0) {
			if (ptr_array[i]->traversed != 1) {
				return(0);
			}
		}
	}
	return(1);
}


struct scfg_node* context_switch(struct state_var **ptr_to_saved_states, struct scfg_node *last_node) {
	struct state_var *ptr,*new_states,*saved_states;
	struct scfg_node *new_node,*first_node;
	int pos1,val1;

	saved_states = *(ptr_to_saved_states);
	first_node = NULL;
	new_states = NULL;
	/* Create a new NOP node 
	nop_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
	nop_node->command = 12;		 NOP command 
	nop_node->arguments = 0;*/

	/* Cycle through all the state values recursively*/
	if (saved_states != NULL) {
		if (all_parents_traversed(saved_states->position)) {
			/* This command has no dependencies, add node for it*/
			/* First add the node to check the state value */
			new_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
			new_node->command = 1;		/* If command */
			new_node->arguments = saved_states->value;	/* State value */
			new_node->command_node = NULL;
			/* Explore the tree */
			new_states = NULL;
			pos1 = val1 = 0;
			new_node->left = program_list(saved_states->position,last_node,&pos1,&val1);
			if (pos1 != 0) {
				new_states = (struct state_var *) malloc(sizeof(struct state_var));
				new_states->position = pos1;
				new_states->value = val1;
				new_states->next = NULL;
			}
			first_node = new_node;

			/* Move to the next state, delete this state entry */
			ptr = saved_states;
			saved_states = saved_states->next;
			free(ptr);
			if (saved_states != NULL) {
				new_node->right = context_switch(&saved_states,last_node);
			} else {
				new_node->right = last_node;
			}
			saved_states = add_state(saved_states,new_states);
		} else {
			/* The command still has some dependencies, cannot traverse it, try the other states */
			ptr = saved_states;
			saved_states = saved_states->next;
			ptr->next = NULL;
			if (saved_states != NULL) {
				first_node = context_switch(&saved_states,last_node);
			}
			saved_states = add_state(saved_states,ptr);
		}
	}
	*(ptr_to_saved_states) = saved_states;
	return(first_node);
}


int state_size(struct state_var *sv) {
	int size = 0;
	struct state_var *ptr;

	if (sv == NULL) {
		return(0);
	} else {
		for (ptr=sv;ptr!=NULL;ptr=ptr->next) {
			size++;
		}
		return(size);
	}
}


int one_child_command(int command) {
	if ((command == 1) || (command == 7) || (command == 11)) 
		return(0);
	else
		return(1);
}


int first_child(int command_position) {
	int i;

	for (i=0;i<array_size;i++) {
		if (node_array[command_position][i] == 1) {
			return(i);
		}
	}
	return(-1);
}


int second_child(int command_position) {
	int i,found_first_child;

	found_first_child = 0;
	for (i=0;i<array_size;i++) {
		if (node_array[command_position][i] == 1) {
			if (found_first_child) {
				return(i);
			} else {
				found_first_child = 1;
			}
		}
	}
	return(-1);
}


struct state_var* add_state(struct state_var *sv, struct state_var *new_state) {
	struct state_var *ptr;

	if (new_state == NULL) {
		return(sv);
	}
	if (sv == NULL) {
		return(new_state);
	}
	for (ptr=sv;ptr->next!=NULL;ptr=ptr->next);
	ptr->next = new_state;
	return(sv);
}

/*
void sequentialize(int position) {
	struct state_var *left_state,*right_state;
	struct scfg_node *new_node,*prev_node;

	while (ptr_array[position]->command) {
		if (one_child_command(ptr_array[position]->command)) {
			new_node = (struct scfg_node*) malloc(sizeof(struct scfg_node));
			new_node->command = ptr_array[position]->command;
			new_node->arguments = ptr_array[position]->arguments;
			ptr_array[position]->traversed = 1;
			prev_node = new_node;
			position = first_child(position);
		} else {
			 Two child command 
			if (ptr_array[position]->command == 11) {
				 Its a fork command 
				left_state = (struct state_var *) malloc(sizeof(struct state_var));
				left_state->position = first_child(position);
				left_state->next = NULL;
				right_state = (struct state_var *) malloc(sizeof(struct state_var));
				right_state->position = second_child(position);
				right_state->next = NULL;
				while ((state_size(left_state)!=0) || (state_size(right_state)!=0)) {
					context_switch(left_state, prev_node);
					context_switch(right_state, prev_node);
				}
			}
		}
	}
}*/


struct scfg_node* program_list(int position, struct scfg_node *last_node, int *new_position, int *state_value) {
	struct scfg_node *first_node,*new_node,*prev_node,*merge_node;
	int new_pos1,new_pos2;
	struct state_var *left_state,*right_state,*saved_states,*state1,*state2,*new_state;
	int pos1,pos2,val1,val2;

	prev_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
	first_node = prev_node;
	*(new_position) = 0;
	*(state_value) = 0;
	while ((ptr_array[position]->command == 6) || ((ptr_array[position]->command != 14) && (all_parents_traversed(position)))) {
		if (ptr_array[position]->command == 6) {
			ptr_array[position]->traversed = 1;
			prev_node->left = last_node;
			return(first_node->left);
		}
		if ((ptr_array[position]->command == 15) && (all_parents_traversed(position))) {
			ptr_array[position]->traversed = 1;
			prev_node->left = last_node;
			return(first_node->left);
		}
		if (one_child_command(ptr_array[position]->command)) {
			new_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
			new_node->command = ptr_array[position]->command;
			new_node->arguments = ptr_array[position]->arguments;
			new_node->command_node = ptr_array[position];
			ptr_array[position]->traversed = 1;
			prev_node->left = new_node;
			prev_node = new_node;
			position = first_child(position);
		} else {
			/* Two child command */
			if (ptr_array[position]->command != 11) {
				/* Its not a fork command */
				new_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
				new_node->command = ptr_array[position]->command;
				new_node->arguments = ptr_array[position]->arguments;
				new_node->command_node = ptr_array[position];
				ptr_array[position]->traversed = 1;
				merge_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
				merge_node->command = 6;
				merge_node->arguments = 0;
				new_node->command_node = NULL;
				pos1 = pos2 = val1 = val2 = 0;
				new_node->left = program_list(first_child(position),merge_node,&pos1,&val1);
				new_node->right = program_list(second_child(position),merge_node,&pos2,&val2);
				prev_node->left = new_node;
				prev_node = merge_node;
				position = first_child(position+1);
			} else if (ptr_array[position]->command == 11) {
				/* Its a fork command */
				ptr_array[position]->traversed = 1;
				/*left_state = (struct state_var *) malloc(sizeof(struct state_var));
				left_state->position = first_child(position);
				left_state->value = context_value++;
				left_state->next = NULL;
				right_state = (struct state_var *) malloc(sizeof(struct state_var));
				right_state->position = second_child(position);
				right_state->value = context_value++;
				right_state->next = NULL;*/
				left_state = NULL;
				right_state = NULL;
				merge_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
				merge_node->command = 6;
				merge_node->arguments = 0;
				merge_node->command_node = NULL;
				pos1 = pos2 = val1 = val2 = 0;
				prev_node->left = program_list(first_child(position),merge_node,&pos1,&val1);
				if (pos1 != 0) {
					left_state = (struct state_var *) malloc(sizeof(struct state_var));
					left_state->position = pos1;
					left_state->value = val1;
					left_state->next = NULL;
				}
				prev_node = merge_node;
				merge_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
				merge_node->command = 6;
				merge_node->arguments = 0;
				merge_node->command_node = NULL;
				prev_node->left = program_list(second_child(position),merge_node,&pos2,&val2);
				if (pos2 != 0) {
					right_state = (struct state_var *) malloc(sizeof(struct state_var));
					right_state->position = pos2;
					right_state->value = val2;
					right_state->next = NULL;
				}
				prev_node = merge_node;
				while ((state_size(left_state)!=0) || (state_size(right_state)!=0)) {
					if (state_size(left_state) != 0) {
						merge_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
						merge_node->command = 6;
						merge_node->arguments = 0;
						merge_node->command_node = NULL;
						new_node = context_switch(&left_state, merge_node);
						if (new_node != NULL) {
							prev_node->left = new_node;
							prev_node = merge_node;
						}
					}
					if (state_size(right_state) != 0) {
						merge_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
						merge_node->command = 6;
						merge_node->arguments = 0;
						merge_node->command_node = NULL;
						new_node = context_switch(&right_state, merge_node);
						if (new_node != NULL) {
							prev_node->left = new_node;
							prev_node = merge_node;
						}
					}
				}
				position = first_child(++position);
			}
		}
	}
	if (ptr_array[position]->command == 14) {
		/* End of program node */
		new_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
		new_node->command = ptr_array[position]->command;
		new_node->arguments = ptr_array[position]->arguments;
		new_node->command_node = ptr_array[position];
		prev_node->left = new_node;
		new_node->left = last_node;
	}
	if (!all_parents_traversed(position)) {
		/* Add node saving the state */
		new_node = (struct scfg_node *) malloc(sizeof(struct scfg_node));
		new_node->command = 13;		/* Save state */
		new_node->arguments = context_value;
		new_node->command_node = NULL;
		prev_node->left = new_node;
		prev_node = new_node;
		/* new_state = (struct state_var *) malloc(sizeof(struct state_var));
		new_state->position = position;
		new_state->next = NULL;
		saved_states = add_state(saved_states,new_state); */
		*new_position = position;
		*state_value = context_value++;
	}
	prev_node->left = last_node;
	/* print_program(first_node->left); */
	return(first_node->left);
}


void print_embedded_code(struct scfg_node *program_nodes, char *fname) {
	struct scfg_node *pc;
	int ecode_line_num,command,i;
	struct ecode_format ecode[100];
	char *input_signals[50];
	char temp[50];
	FILE *fp;

	input_signals[1] = strdup("TOUCH_INPUT_1");
	input_signals[2] = strdup("TOUCH_INPUT_2");
	input_signals[3] = strdup("TOUCH_INPUT_3");
	input_signals[4] = strdup("LIGHT_LOW_1");
	input_signals[5] = strdup("LIGHT_HIGH_1");
	input_signals[6] = strdup("LIGHT_1_VALUE");
	input_signals[7] = strdup("LIGHT_LOW_2");
	input_signals[8] = strdup("LIGHT_HIGH_2");
	input_signals[9] = strdup("LIGHT_2_VALUE");
	input_signals[10] = strdup("LIGHT_LOW_3");
	input_signals[11] = strdup("LIGHT_HIGH_3");
	input_signals[12] = strdup("LIGHT_3_VALUE");
	input_signals[13] = strdup("MOTOR_A_DIR");
	input_signals[14] = strdup("MOTOR_A_SPEED");
	input_signals[15] = strdup("MOTOR_B_DIR");
	input_signals[16] = strdup("MOTOR_B_SPEED");
	input_signals[17] = strdup("MOTOR_C_DIR");
	input_signals[18] = strdup("MOTOR_C_SPEED");
	input_signals[19] = strdup("CPUTS");
	input_signals[20] = strdup("SET_LIGHT_1_THRESHOLD");
	input_signals[21] = strdup("SET_LIGHT_2_THRESHOLD");
	input_signals[22] = strdup("SET_LIGHT_3_THRESHOLD");

	pc = program_nodes;
	ecode_line_num = 0;
	while (pc != NULL) {
		command = pc->command;
		if (command == 1) {
			/* If command */
			ecode[ecode_line_num].command = strdup("CALL");
			ecode[ecode_line_num].arg1 = strdup(pc->command_node->arg1);
			ecode[ecode_line_num].arg2 = strdup("");
			pc->command_node->line_num = ecode_line_num;
			ecode_line_num++;
			pc = pc->left;
			push(stack,(int) pc->right);
			pc = pc->left;
		}
		if (command == 5) {
			/* Emit command */
			ecode[ecode_line_num].command = strdup("CALL");
			ecode[ecode_line_num].arg1 = strdup(pc->command_node->arg1);
			ecode[ecode_line_num].arg2 = strdup("");
			pc->command_node->line_num = ecode_line_num;
			ecode_line_num++;
			pc = pc->left;
		}
		if (command == 16) {
			/* Await without return command */
			ecode[ecode_line_num].command = strdup("FUTURE");
			ecode[ecode_line_num].arg1 = strdup(input_signals[pc->command_node->arguments]);
			ecode[ecode_line_num].position = pc->left->command_node->position;
			pc->command_node->line_num = ecode_line_num;
			ecode_line_num++;
			pc = pc->left;
		}
		if (command == 17) {
			/* Await with return command */
			ecode[ecode_line_num].command = strdup("FUTURE");
			ecode[ecode_line_num].arg1 = strdup(input_signals[pc->command_node->arguments]);
			ecode[ecode_line_num].position = pc->left->command_node->position;
			pc->command_node->line_num = ecode_line_num;
			ecode_line_num++;
			ecode[ecode_line_num].command = strdup("RETURN");
			ecode[ecode_line_num].arg1 = strdup("");
			ecode[ecode_line_num].arg2 = strdup("");
			ecode_line_num++;
			pc = pc->left;
		}
		if (command == 20) {
			/* End loop command */
			ecode[ecode_line_num].command = strdup("JMP");
			ecode[ecode_line_num].arg1 = strdup("");
			ecode[ecode_line_num].arg2 = strdup("");
			ecode[ecode_line_num].position = pc->command_node->arguments;
			pc->command_node->line_num = ecode_line_num;
			ecode_line_num++;
			pc = pc->left;
		}
		if (command == 13) {
			/* Save state command */
			ecode[ecode_line_num].command = strdup("PUSH");
			ecode[ecode_line_num].arg1 = strdup("");
			ecode[ecode_line_num].arg2 = strdup("");
			ecode[ecode_line_num].position = pc->command_node->arguments;
			ecode_line_num++;
			pc = pc->left;
		}
		if (command == 6) {
			/* Merge command */
			ecode[ecode_line_num].command = strdup("NOP");
			ecode[ecode_line_num].arg1 = strdup("");
			ecode[ecode_line_num].arg2 = strdup("");
			ecode_line_num++;
			pc = pc->left;
		}
	}

	/* Now resolve the line number references in the code */
	for (i=0;i<ecode_line_num;i++) {
		if (!strcmp(ecode[i].command,"FUTURE")) {
			/* Future command */
			itoa(ptr_array[ecode[i].position]->line_num, temp);
			ecode[i].arg2 = strdup(temp);
		}
		if (!strcmp(ecode[i].command,"JMP")) {
			/* Jump command */
			itoa(ptr_array[ecode[i].position]->line_num, temp);
			ecode[i].arg1 = strdup(temp);
		}
	}

	/* Now print out the program */
	fp = fopen(fname,"a");
	fprintf(fp,"\n\nint main() {\n");
	fprintf(fp,"\tinst_t eco[%d];\n",ecode_line_num);
	fprintf(fp,"\temachine_t *em;\n\n");
	fprintf(fp,"\tds_active(&SENSOR_1);\n");
	fprintf(fp,"\tds_active(&SENSOR_2);\n");
	fprintf(fp,"\tds_active(&SENSOR_3);\n\n");
	for (i=0;i<ecode_line_num;i++) {
		fprintf(fp,"\teco[%d].opcode = %s;\n",i,ecode[i].command);
		if (strlen(ecode[i].arg1) > 0) {
			fprintf(fp,"\teco[%d].arg1 = (int) %s;\n",i,ecode[i].arg1);
		}
		if (strlen(ecode[i].arg2) > 0) {
			fprintf(fp,"\teco[%d].arg2 = (int) %s;\n",i,ecode[i].arg2);
		}
		fprintf(fp,"\n");
	}
	fprintf(fp,"\tem = (emachine_t *) malloc(sizeof(emachine_t));\n");
	fprintf(fp,"\tem->eco = eco;\n");
	fprintf(fp,"\tem->eco_size = %d;\n\n",ecode_line_num);
	fprintf(fp,"\tEmachine(em);\n\n");
	fprintf(fp,"\treturn 0;\n");
	fprintf(fp,"}\n\n");
}


void itoa(int n, char s[]) {
	int i;

	i = 0;
	do {
		s[i++] = n%10 + '0';
	} while ((n /= 10) > 0);
	s[i] = '\0';
	reverse(s);
}


void reverse(char s[]) {
	int c,i,j;

	for (i=0,j=strlen(s)-1;i<j;i++,j--) {
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}

