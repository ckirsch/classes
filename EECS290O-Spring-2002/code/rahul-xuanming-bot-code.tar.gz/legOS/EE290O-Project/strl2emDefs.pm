# strl2emDefs.pm

# package strl2emDefs;

# require Exporter;
# @ISA = (Exporter);
# @EXPORT = qw($EMIT $AWAIT);

$IF = 1;
$THEN = 2;
$ELSE = 3;
$END = 4;
$EMIT = 5;
$MERGE = 6;
$PRESENT = 7;
$PARALLEL = 8;
$START_BLOCK = 9;
$END_BLOCK = 10;
$FORK = 11;
$NOP = 12;
$SAVE_STATE = 13;
$END = 14;
$MERGE_FORK = 15;
$AWAIT = 16;
$AWAIT_WITH_RETURN = 17;
$LOOP = 18;
$END_LOOP = 19;

