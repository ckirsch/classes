#include <stdlib.h>
#include <sys/em.h>
#include <conio.h>
#include <unistd.h>
#include <time.h>
#include <dsound.h>
#include <dmotor.h>
#include <dsensor.h>


#define NORMAL_SPEED	(MAX_SPEED/10)
#define TURN_SPEED	(MAX_SPEED)

void e_motor_a_speed_0( )
{
	motor_a_speed (0);
}

void e_motor_a_speed_1( )
{
	motor_a_speed (NORMAL_SPEED);
}

void e_motor_c_speed_0( )
{
	motor_c_speed (0);
}

void e_motor_c_speed_1( )
{
	motor_c_speed (TURN_SPEED);
}

void e_motor_a_dir_f( )
{
	motor_a_dir (fwd);
}

void e_motor_a_dir_r( )
{
	motor_a_dir (rev);
}

void e_motor_c_dir_f( )
{
	motor_c_dir (fwd);
}

void e_motor_c_dir_r( )
{
	motor_c_dir (rev);
}

void main() {
	inst_t eco[11];
	emachine_t *em;

	ds_active(&SENSOR_1);
	ds_active(&SENSOR_2);

	eco[0].opcode = NOP;

	eco[1].opcode = CALL;
	eco[1].arg1 = (int) (&e_motor_a_dir_f);

	eco[2].opcode = CALL;
	eco[2].arg1 = (int) (&e_motor_a_speed_1);

	eco[3].opcode = FUTURE;
	eco[3].arg1 = (int) TOUCH_INPUT_1;
	eco[3].arg2 = (int) 5;

	eco[4].opcode = RETURN;

	eco[5].opcode = CALL;
	eco[5].arg1 = (int) (&e_motor_a_dir_r);

	eco[6].opcode = CALL;
	eco[6].arg1 = (int) (&e_motor_a_speed_1);

	eco[7].opcode = FUTURE;
	eco[7].arg1 = (int) LIGHT_LOW_2;
	eco[7].arg2 = (int) 9;

	eco[8].opcode = RETURN;

	eco[9].opcode = JMP;
	eco[9].arg1 = (int) 1;

	eco[10].opcode = NOP;

	em = (emachine_t *) malloc(sizeof(emachine_t));
	em->eco = eco;
	em->eco_size = 11;

	Emachine(em);

	return 0;
}

