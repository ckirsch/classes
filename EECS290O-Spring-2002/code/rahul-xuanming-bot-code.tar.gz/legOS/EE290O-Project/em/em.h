// #ifndef __em_h__
#define __em_h__

#include <config.h>
// #ifdef CONF_EM

typedef enum { NOP, JMP, CALL, FUTURE, RETURN, SCHEDULE, SLEEP } op_t;

typedef enum { NULL_INPUT, TOUCH_INPUT_1, TOUCH_INPUT_2, TOUCH_INPUT_3,
		LIGHT_LOW_1, LIGHT_HIGH_1, LIGHT_1_VALUE,
		LIGHT_LOW_2, LIGHT_HIGH_2, LIGHT_2_VALUE,
		LIGHT_LOW_3, LIGHT_HIGH_3, LIGHT_3_VALUE, TIMER_TRIGGER }
valid_input;

 
typedef struct {
	op_t	opcode;
	int	arg1;
	int	arg2;
	int	arg3;
} inst_t;

typedef struct {
	inst_t*	eco;  
	int*	i;
	int	eco_size;
	int	i_size;
} emachine_t;

typedef struct {
	int		signal;
	int		next;
	unsigned long	timer;
} trigger;

struct node {
	trigger* 	trigger_object;
	struct node 	*next;
};

typedef struct node trigger_node;

void 	Emachine(emachine_t*);
void 	Einterpreter();
void 	configure_em(emachine_t*);

int 	fetch(inst_t**, int*);
int 	execute(int (*f) ());


// TRIGGER FUNCTIONS
trigger* 	create_trigger(int, int, unsigned long);
trigger_node* 	create_trigger_node(trigger*);
void 		insert(trigger_node*);
trigger_node* 	removeTriggerNode();
trigger_node* 	descheduleTriggerNode(int, int);
int		check_signal(int, unsigned long);

// #endif

// #endif
