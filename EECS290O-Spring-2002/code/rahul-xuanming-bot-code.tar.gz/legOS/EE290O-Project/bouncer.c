#include <stdlib.h>
#include <sys/em.h>
#include <conio.h>
#include <unistd.h>
#include <time.h>
#include <dsound.h>
#include <dmotor.h>
#include <dsensor.h>


void function1() {
	motor_a_dir(1);
}

void function2() {
	motor_a_speed(100);
}

void function3() {
	motor_a_dir(2);
}

void function4() {
	motor_a_speed(100);
}



int main() {
	inst_t eco[10];
	emachine_t *em;

	ds_active(&SENSOR_1);
	ds_active(&SENSOR_2);
	ds_active(&SENSOR_3);

	eco[0].opcode = CALL;
	eco[0].arg1 = (int) &function1;

	eco[1].opcode = CALL;
	eco[1].arg1 = (int) &function2;

	eco[2].opcode = FUTURE;
	eco[2].arg1 = (int) TOUCH_INPUT_1;
	eco[2].arg2 = (int) 4;

	eco[3].opcode = RETURN;

	eco[4].opcode = CALL;
	eco[4].arg1 = (int) &function3;

	eco[5].opcode = CALL;
	eco[5].arg1 = (int) &function4;

	eco[6].opcode = FUTURE;
	eco[6].arg1 = (int) LIGHT_LOW_2;
	eco[6].arg2 = (int) 8;

	eco[7].opcode = RETURN;

	eco[8].opcode = JMP;
	eco[8].arg1 = (int) 0;

	eco[9].opcode = NOP;

	em = (emachine_t *) malloc(sizeof(emachine_t));
	em->eco = eco;
	em->eco_size = 10;

	Emachine(em);

	return 0;
}

