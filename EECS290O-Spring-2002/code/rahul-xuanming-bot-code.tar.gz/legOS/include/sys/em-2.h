#ifndef __em_h__
#define __em_h__

#include <config.h>
#ifdef CONF_EM

typedef enum { NOP, CALL, FUTURE, SCHEDULE } op_t;

typedef struct {
  op_t opcode;
  int operand;
} inst_t;

typedef struct {
  inst_t* eco;  
  int* i;

  int eco_size;
  int i_size;
} emachine_t;

typedef struct {
  int s;
  unsigned long m;
  int l;
} trigger;

struct node{
  trigger* trigger_object;
  struct node *next;
};

typedef struct node trigger_node;


// EM SYSCALL (called by user program)
void Emachine(emachine_t*);
void Einterpreter(int);
void configure_em(emachine_t*);
void write_int(int, int);
int read_int(int);


int fetch(inst_t**, int*);
int execute(int (*f) ());

#endif

#endif
