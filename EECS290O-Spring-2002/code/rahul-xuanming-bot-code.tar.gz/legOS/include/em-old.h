#define __em_h__

#include <config.h>
// #ifdef CONF_EM

typedef enum { NOP, CALL, FUTURE, SCHEDULE } op_t;

typedef struct {
  op_t opcode;
  int arg1;
} inst_t;

typedef struct {
  inst_t* eco;  
  int eco_size;
} emachine_t;

// EM SYSCALL (called by user program)
void Emachine(emachine_t*);
void Einterpreter();
void configure_em(emachine_t*);
void write_int(int, int);
int read_int(int);
void handle_triggers();

int fetch(inst_t**, int*);
int execute(int (*f) ());

// #endif

// #endif
