/* occ : C CODE OF AUTOMATON extnode */

/* AUXILIARY DECLARATIONS */

#ifndef STRLEN
#define STRLEN 81
#endif
#define _COND(A,B,C) ((A)?(B):(C))
#ifdef TRACE_ACTION
#include <stdio.h>
#endif
#ifndef NULL
#define NULL ((char*)0)
#endif

#ifndef __EXEC_STATUS_H_LOADED
#define __EXEC_STATUS_H_LOADED

typedef struct {
unsigned int start:1;
unsigned int kill:1;
unsigned int active:1;
unsigned int suspended:1;
unsigned int prev_active:1;
unsigned int prev_suspended:1;
unsigned int exec_index;
unsigned int task_exec_index;
void (*pStart)();
void (*pRet)();
} __ExecStatus;

#endif
#define __ResetExecStatus(status) {\
   status.prev_active = status.active; \
   status.prev_suspended = status.suspended; \
   status.start = status.kill = status.active = status.suspended = 0; }
#define __DSZ(V) (--(V)<=0)
static int __extnode_engine();
#define __BASIC_ACT(i) (*__extnode_PActionArray[i])()
#ifdef TRACE_ACTION
#define __ACT(i) fprintf(stderr, "__extnode_A%d\n", i);__BASIC_ACT(i)
#else
#define __ACT(i) __BASIC_ACT(i)
#endif
#define BASIC_TYPES_DEFINED
typedef int boolean;
typedef int integer;
typedef char* string;
#define _true 1
#define _false 0
#define __extnode_GENERIC_TEST(TEST) {if (TEST) __extnode_cp++; else __extnode_cp += *__extnode_cp;}
typedef unsigned char  __extnode_indextype;
typedef void (*__extnode_APF)();
static __extnode_APF *__extnode_PActionArray;

                       
/* EXTERN DECLARATIONS */

#ifndef _NO_EXTERN_DEFINITIONS
#endif

/* INITIALIZED CONSTANTS */

/* MEMORY ALLOCATION */

static boolean __extnode_V0;

/*OUTPUT FUNCTIONS*/
void extnode_O_TO_N () {
  sendMessage(NODE_ID, 0);
}


/* INPUT FUNCTIONS */

void extnode_I_CAR () {
__extnode_V0 = _true;
}

/* FUNCTIONS RETURNING NUMBER OF EXEC */

int extnode_number_of_execs () {
return (0);
}


/* AUTOMATON (STATE ACTION-TREES) */

static __extnode_indextype __extnode_sct0 [] = {
0,0
};
static __extnode_indextype __extnode_sct1 [] = {
0,2
};
static __extnode_indextype __extnode_sct2 [] = {
4,2,5,0,2
};
static __extnode_indextype* __extnode_dct [] = {
(__extnode_indextype*)0 /* no-sub-dags */
};
static __extnode_indextype* __extnode_sct [] = {
__extnode_sct0,
 __extnode_sct1,
 __extnode_sct2
};

static __extnode_indextype* __extnode_cp = __extnode_sct1;

/* ACTIONS */

/* PREDEFINED ACTIONS */

static void __extnode_A1 () {
extern __extnode_indextype* __extnode_dct[];
__extnode_indextype* old_cp = __extnode_cp + 1;
__extnode_cp = __extnode_dct[*__extnode_cp];
__extnode_engine();
__extnode_cp = old_cp;
}
static void __extnode_A2 () {
extern __extnode_indextype* __extnode_dct[];
__extnode_cp = __extnode_dct[*__extnode_cp];
}
static void __extnode_A3 () {
__extnode_GENERIC_TEST(_false);
}

/* PRESENT SIGNAL TESTS */

static void __extnode_A4 () {
__extnode_GENERIC_TEST(__extnode_V0);
}

/* OUTPUT ACTIONS */

static void __extnode_A5 () {
extnode_O_TO_N();
}

/* ASSIGNMENTS */

static void __extnode_A6 () {
__extnode_V0 = _false;
}

/* PROCEDURE CALLS */

/* CONDITIONS */

/* DECREMENTS */

/* START ACTIONS */

/* KILL ACTIONS */

/* SUSPEND ACTIONS */

/* ACTIVATE ACTIONS */

/* WRITE ARGS ACTIONS */

/* RESET ACTIONS */

/* ACTION SEQUENCES */

/* THE ACTION ARRAY */

static __extnode_APF __extnode_ActionArray[] = {
0,
(__extnode_APF)__extnode_A1,
(__extnode_APF)__extnode_A2,
(__extnode_APF)__extnode_A3,
(__extnode_APF)__extnode_A4,
(__extnode_APF)__extnode_A5,
(__extnode_APF)__extnode_A6
};
static __extnode_APF *__extnode_PActionArray  = __extnode_ActionArray;


static void __extnode__reset_input () {
__extnode_V0 = _false;
}

/* AUTOMATON ENGINE */

static int __extnode_engine () {
register __extnode_indextype x;
while (x = *(__extnode_cp++)) {
__ACT(x);
}
return *__extnode_cp;
}

int extnode () {
int x;
x = __extnode_engine();
__extnode_cp = __extnode_sct[x];
__extnode__reset_input();
return x!=0;
}

/* AUTOMATON RESET */

int extnode_reset () {
__extnode_cp = __extnode_sct1;
__extnode__reset_input();
return 0;
}
