/* occ : C CODE OF AUTOMATON internal */

/* AUXILIARY DECLARATIONS */

#ifndef STRLEN
#define STRLEN 81
#endif
#define _COND(A,B,C) ((A)?(B):(C))
#ifdef TRACE_ACTION
#include <stdio.h>
#endif
#ifndef NULL
#define NULL ((char*)0)
#endif

#ifndef __EXEC_STATUS_H_LOADED
#define __EXEC_STATUS_H_LOADED

typedef struct {
unsigned int start:1;
unsigned int kill:1;
unsigned int active:1;
unsigned int suspended:1;
unsigned int prev_active:1;
unsigned int prev_suspended:1;
unsigned int exec_index;
unsigned int task_exec_index;
void (*pStart)();
void (*pRet)();
} __ExecStatus;

#endif
#define __ResetExecStatus(status) {\
   status.prev_active = status.active; \
   status.prev_suspended = status.suspended; \
   status.start = status.kill = status.active = status.suspended = 0; }
#define __DSZ(V) (--(V)<=0)
static int __internal_engine();
#define __BASIC_ACT(i) (*__internal_PActionArray[i])()
#ifdef TRACE_ACTION
#define __ACT(i) fprintf(stderr, "__internal_A%d\n", i);__BASIC_ACT(i)
#else
#define __ACT(i) __BASIC_ACT(i)
#endif
#define BASIC_TYPES_DEFINED
typedef int boolean;
typedef int integer;
typedef char* string;
#define _true 1
#define _false 0
#define __internal_GENERIC_TEST(TEST) {if (TEST) __internal_cp++; else __internal_cp += *__internal_cp;}
typedef unsigned char  __internal_indextype;
typedef void (*__internal_APF)();
static __internal_APF *__internal_PActionArray;

                       
/* EXTERN DECLARATIONS */

#ifndef _NO_EXTERN_DEFINITIONS
#endif

/* INITIALIZED CONSTANTS */

/* MEMORY ALLOCATION */

static boolean __internal_V0;
static boolean __internal_V1;
static boolean __internal_V2;

/* OUTPUT FUNCTIONS */

void internal_O_TO_NC (){
  sendMessage(NODE_ID, 1);
}

void internal_O_CAR_TURN (){
  sendMessage(NODE_ID, 3);
}


/* INPUT FUNCTIONS */

void internal_I_CAR () {
__internal_V0 = _true;
}
void internal_I_FROM_N () {
__internal_V1 = _true;
}
void internal_I_FROM_NC () {
__internal_V2 = _true;
}

/* FUNCTIONS RETURNING NUMBER OF EXEC */

int internal_number_of_execs () {
return (0);
}


/* AUTOMATON (STATE ACTION-TREES) */

static __internal_indextype __internal_sct0 [] = {
0,0
};
static __internal_indextype __internal_sct1 [] = {
0,2
};
static __internal_indextype __internal_sct2 [] = {
4,17,5,9,7,8,6,3,0,3,0,4,6,3,0,5,0,6,
5,7,6,3,0,7,0,8,6,3,0,9,0,2
};
static __internal_indextype __internal_sct3 [] = {
5,7,4,3,0,3,0,10,4,3,0,11,0,3
};
static __internal_indextype __internal_sct4 [] = {
4,15,5,7,6,3,0,3,0,4,6,3,0,11,0,12,5,7,
6,3,0,10,0,13,6,3,0,3,0,4
};
static __internal_indextype __internal_sct5 [] = {
5,3,0,2,0,5
};
static __internal_indextype __internal_sct6 [] = {
5,3,0,2,6,3,0,5,0,6
};
static __internal_indextype __internal_sct7 [] = {
4,5,8,7,0,14,0,7
};
static __internal_indextype __internal_sct8 [] = {
4,8,7,6,3,0,15,0,16,6,3,0,7,0,8
};
static __internal_indextype __internal_sct9 [] = {
5,9,4,5,7,8,0,3,0,7,4,3,0,5,0,9
};
static __internal_indextype __internal_sct10 [] = {
4,5,8,7,0,17,0,10
};
static __internal_indextype __internal_sct11 [] = {
5,3,0,2,0,11
};
static __internal_indextype __internal_sct12 [] = {
5,3,0,2,6,3,0,11,0,12
};
static __internal_indextype __internal_sct13 [] = {
4,8,7,6,3,0,18,0,19,6,3,0,10,0,13
};
static __internal_indextype __internal_sct14 [] = {
5,9,4,5,7,8,0,17,0,20,4,3,0,21,0,14
};
static __internal_indextype __internal_sct15 [] = {
4,9,5,5,7,8,0,18,0,22,5,3,0,23,0,15
};
static __internal_indextype __internal_sct16 [] = {
5,17,4,9,7,8,6,3,0,18,0,19,6,3,0,23,0,24,
4,7,6,3,0,22,0,25,6,3,0,15,0,16
};
static __internal_indextype __internal_sct17 [] = {
4,7,5,3,0,17,0,26,5,3,0,27,0,17
};
static __internal_indextype __internal_sct18 [] = {
5,7,4,3,0,18,0,28,4,3,0,29,0,18
};
static __internal_indextype __internal_sct19 [] = {
4,15,5,7,6,3,0,18,0,19,6,3,0,29,0,30,5,7,
6,3,0,28,0,31,6,3,0,18,0,19
};
static __internal_indextype __internal_sct20 [] = {
4,3,0,14,0,20
};
static __internal_indextype __internal_sct21 [] = {
5,3,0,2,0,21
};
static __internal_indextype __internal_sct22 [] = {
5,3,0,2,0,22
};
static __internal_indextype __internal_sct23 [] = {
4,4,8,0,14,0,23
};
static __internal_indextype __internal_sct24 [] = {
6,7,4,3,0,15,0,23,4,3,0,16,0,24
};
static __internal_indextype __internal_sct25 [] = {
5,3,0,2,6,3,0,22,0,25
};
static __internal_indextype __internal_sct26 [] = {
5,3,0,2,0,26
};
static __internal_indextype __internal_sct27 [] = {
4,3,0,17,0,27
};
static __internal_indextype __internal_sct28 [] = {
4,4,8,0,17,0,28
};
static __internal_indextype __internal_sct29 [] = {
5,3,0,2,0,29
};
static __internal_indextype __internal_sct30 [] = {
5,3,0,2,6,3,0,29,0,30
};
static __internal_indextype __internal_sct31 [] = {
6,7,4,3,0,18,0,28,4,3,0,19,0,31
};
static __internal_indextype* __internal_dct [] = {
(__internal_indextype*)0 /* no-sub-dags */
};
static __internal_indextype* __internal_sct [] = {
__internal_sct0,
 __internal_sct1,
 __internal_sct2,
 __internal_sct3,
 __internal_sct4,
 __internal_sct5,
 __internal_sct6,
 __internal_sct7,
 __internal_sct8,
 __internal_sct9,
 __internal_sct10,
 __internal_sct11,
 __internal_sct12,
 __internal_sct13,
 __internal_sct14,
 __internal_sct15,
 __internal_sct16,
 __internal_sct17,
 __internal_sct18,
 __internal_sct19,
 __internal_sct20,
 __internal_sct21,
 __internal_sct22,
 __internal_sct23,
 __internal_sct24,
 __internal_sct25,
 __internal_sct26,
 __internal_sct27,
 __internal_sct28,
 __internal_sct29,
 __internal_sct30,
 __internal_sct31
};

static __internal_indextype* __internal_cp = __internal_sct1;

/* ACTIONS */

/* PREDEFINED ACTIONS */

static void __internal_A1 () {
extern __internal_indextype* __internal_dct[];
__internal_indextype* old_cp = __internal_cp + 1;
__internal_cp = __internal_dct[*__internal_cp];
__internal_engine();
__internal_cp = old_cp;
}
static void __internal_A2 () {
extern __internal_indextype* __internal_dct[];
__internal_cp = __internal_dct[*__internal_cp];
}
static void __internal_A3 () {
__internal_GENERIC_TEST(_false);
}

/* PRESENT SIGNAL TESTS */

static void __internal_A4 () {
__internal_GENERIC_TEST(__internal_V0);
}
static void __internal_A5 () {
__internal_GENERIC_TEST(__internal_V1);
}
static void __internal_A6 () {
__internal_GENERIC_TEST(__internal_V2);
}

/* OUTPUT ACTIONS */

static void __internal_A7 () {
internal_O_TO_NC();
}
static void __internal_A8 () {
internal_O_CAR_TURN();
}

/* ASSIGNMENTS */

static void __internal_A9 () {
__internal_V0 = _false;
}
static void __internal_A10 () {
__internal_V1 = _false;
}
static void __internal_A11 () {
__internal_V2 = _false;
}

/* PROCEDURE CALLS */

/* CONDITIONS */

/* DECREMENTS */

/* START ACTIONS */

/* KILL ACTIONS */

/* SUSPEND ACTIONS */

/* ACTIVATE ACTIONS */

/* WRITE ARGS ACTIONS */

/* RESET ACTIONS */

/* ACTION SEQUENCES */

/* THE ACTION ARRAY */

static __internal_APF __internal_ActionArray[] = {
0,
(__internal_APF)__internal_A1,
(__internal_APF)__internal_A2,
(__internal_APF)__internal_A3,
(__internal_APF)__internal_A4,
(__internal_APF)__internal_A5,
(__internal_APF)__internal_A6,
(__internal_APF)__internal_A7,
(__internal_APF)__internal_A8,
(__internal_APF)__internal_A9,
(__internal_APF)__internal_A10,
(__internal_APF)__internal_A11
};
static __internal_APF *__internal_PActionArray  = __internal_ActionArray;


static void __internal__reset_input () {
__internal_V0 = _false;
__internal_V1 = _false;
__internal_V2 = _false;
}

/* AUTOMATON ENGINE */

static int __internal_engine () {
register __internal_indextype x;
while (x = *(__internal_cp++)) {
__ACT(x);
}
return *__internal_cp;
}

int internal () {
int x;
x = __internal_engine();
__internal_cp = __internal_sct[x];
__internal__reset_input();
return x!=0;
}

/* AUTOMATON RESET */

int internal_reset () {
__internal_cp = __internal_sct1;
__internal__reset_input();
return 0;
}
