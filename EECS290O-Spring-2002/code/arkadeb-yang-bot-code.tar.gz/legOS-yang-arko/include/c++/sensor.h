/*! \file   include/c++/sensor.h
   \brief  Direct sensor access in C++
   \author Markus L. Noga <markus@noga.de>
 */

/*
 *  The contents of this file are subject to the Mozilla Public License
 *  Version 1.0 (the "License"); you may not use this file except in
 *  compliance with the License. You may obtain a copy of the License at
 *  http://www.mozilla.org/MPL/
 *
 *  Software distributed under the License is distributed on an "AS IS"
 *  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 *  License for the specific language governing rights and limitations
 *  under the License.
 *
 *  The Original Code is legOS code, released October 17, 1999.
 *
 *  The Initial Developer of the Original Code is Markus L. Noga.
 *  Portions created by Markus L. Noga are Copyright (C) 1999
 *  Markus L. Noga. All Rights Reserved.
 *
 *  Contributor(s): Markus L. Noga <markus@noga.de>
 */

#ifndef __cxx_sensor__
#define __cxx_sensor__

extern "C" {
#include <dsensor.h>
}				//! Raw Sensor class

 class Sensor {
  public:
  //! Creates a sensor at the specified address.
  /*! \param addr   One of Sensor::s1, Sensor::s2, Sensor::s3 or 
     Sensor::battery.
     \param active Flag to activate alimentation for active
     Sensors.
   */
  Sensor(unsigned *addr = s1, int active = 0) {
    ptr = addr;
    if (active)
      ds_active(ptr);
    else
      ds_passive(ptr);
  }				//! Destructor
  /*! Turns off alimentation.
   */ ~Sensor() {
    ds_passive(ptr);
  }

  //! Read raw sensor value
  unsigned value() {
    return *ptr;
  } public:
  static unsigned *const Sensor::s1;	//!< RCX sensor 1 address

  static unsigned *const Sensor::s2;	//!< RCX sensor 2 address

  static unsigned *const Sensor::s3;	//!< RCX sensor 3 address

  static unsigned *const Sensor::battery;	//!< RCX battery sensor address

protected:
  unsigned *ptr;		//!< Pointer to raw sensor value

};

//! LEGO light sensor class
class LightSensor:public Sensor {
  public:
  //! Creates a light sensor at the specified address.
  /*! \param addr   One of Sensor::s1, Sensor::s2, Sensor::s3 or 
     Sensor::battery.
     \param active Flag to activate sensor alimentation. With 
     alimentation, the sensor measures reflectivity, 
     without alimentation it samples ambient light level.
   */
  LightSensor(unsigned *addr = s1, int active = 1):Sensor(addr, active) {
  }				//! Read light sensor value (0..100)
   unsigned value() {
    return LIGHT(Sensor::value());
  }
};

//! LEGO rotation sensor class
class RotationSensor:public Sensor {
  public:
  //! Creates a rotation sensor at the specified address.
  /*! \param addr    One of Sensor::s1, Sensor::s2 or Sensor::s3.
     \param initial Initial rotational position.

     Rotation sensors are always active.
   */
  RotationSensor(unsigned *addr = s1, int initial = 0);

  //! Decactivates rotation tracking.
  ~RotationSensor() {
    ds_rotation_off(ptr);
  }				//! Read current rotational position.
   inline int position() {
    return *posPtr;
  } protected:
  int *volatile posPtr;		//!< Pointer to position value

};

#endif // __cxx_sensor__
