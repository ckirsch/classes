#define __em2_h__

#include <config.h>
#include <tm.h>

typedef enum { NOP, COND, FUTURE, CALL, SCHEDULE}
op_t;
 
typedef struct {
  op_t opcode;
  int arg1;
  int (*fn)(int, void *);
  int arg2;
  int arg3;
} inst_t;

typedef struct {
  inst_t* eco;  
  int* i;

  int eco_size;
  int i_size;
} emachine_t;

typedef struct {
  int (*fn)(int, void *);
  int data;
  int addr;
  long int current_time;
} trigger;

typedef struct{
  trigger* node;
  int queue_size;
} trigger_queue;


void Emachine(emachine_t*, int);
int trigger_queue_init(int, trigger_queue*);
void write_int(emachine_t*, int, int);
int read_int(emachine_t*, int);
wakeup_t button_pressed(wakeup_t);

int button_event_trigger(int, trigger_queue*);

int time_trigger(int, trigger_queue*);

void itoa(int, char *);

void insertChar(char, char *); 














