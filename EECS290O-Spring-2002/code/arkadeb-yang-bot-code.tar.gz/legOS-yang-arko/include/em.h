#define __em_h__

#include <config.h>
#include <tm.h>

typedef enum { NOP, COND, FUTURE, CALL, SCHEDULE}
op_t;

typedef enum { CLK, TS_1, TS_2, TS_3, LS_1, LS_2, LS_3,  
               MDIR_1, MSPD_1, MDIR_2, MSPD_2, MDIR_3, MSPD_3 }
int_t;
 
typedef struct {
  op_t opcode;
  int arg1;
  int (*fn)(int, void *);
  int arg2;
  int arg3;
} inst_t;

typedef struct {
  inst_t* eco;  
  int* i;

  int eco_size;
  int i_size;
} emachine_t;

typedef struct {
  int* stack;
  int sp;
} stack_t;


typedef struct {
  int s;
  unsigned long m;
  int l;
} trigger;

struct node{
  trigger* trigger_object;
  struct node *next;
};

typedef struct node trigger_node;


// EM SYSCALL (called by user program)
void Emachine(emachine_t*);
void write_int(emachine_t*, int, int);
int read_int(emachine_t*, int);

wakeup_t time_wakeup(wakeup_t);

wakeup_t button_pressed(wakeup_t);

int wait_button_pressed(int, void*);

int is_pressed(wakeup_t, void*);

int wait_time(int, void*);

void itoa(int, char *);

void insertChar(char, char *); 














