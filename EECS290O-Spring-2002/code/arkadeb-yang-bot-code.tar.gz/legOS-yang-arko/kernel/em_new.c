//#include <sys/em.h>




#include <em_new.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <tm.h>
#include <semaphore.h>
#include <dbutton.h>
#include <sys/lcd.h>
#include <conio.h>
 
void Emachine(emachine_t* em) {
  
  int i, k, m;

  for(i=0; i<em->eco_size; i++) {
    switch(em->eco[i].opcode) { 
    case NOP:
      break;


	case COND:
	  if ((*(em->eco[i].fn))(0, em)) {
		i = em->eco[i].arg2 - 1;	
	  }

	  else { 
	    i = em->eco[i].arg1 - 1;
	  }
	  break;

    case FUTURE:
	  m = em->eco[i].arg1;
	  (*(em->eco[i].fn))(m, 0);
	  i = em->eco[i].arg2 - 1;
      break;

    case CALL:
      (*(em->eco[i].fn))(0, em);
      break;
	
    case SCHEDULE:
      k = execi( em->eco[i].fn, 0, em, 1, DEFAULT_STACK_SIZE);
      if (k==-1) { cputs("err"); }
      break;

    default:
		break;
	}
  }

  return;
}

void write_int(emachine_t* em, int k, int val) { 
        em->i[k] = val; 
}

int read_int(emachine_t* em, int k) { 
        return em->i[k]; 
}

wakeup_t time_wakeup(wakeup_t data) {
	return ((time_t)data)<=sys_time;
}


wakeup_t button_pressed(wakeup_t data){
	return PRESSED(dbutton(), data);
}

int is_pressed(wakeup_t data, void* p) {
	if(button_pressed(data) == 1){
		return 1;
	}
	else {
		return 0;  
	}
}

int wait_button_pressed(int m, void* p) {
	wait_event(&button_pressed, m);
	return 0;
}

int wait_time(int msec, void* p)
{
 wait_event(&time_wakeup, sys_time + MSECS_TO_TICKS(msec));
 return 0;
}

void itoa(int n, char * s) {
	int k = n;
	int sgn;

	if (k == 0) {
		*s = '0';
		*(s + 1) = 0;
		return;
	}

	if (k < 0) {
		k = -k;
		sgn = 1;
	} else {
		sgn = 0;
	}

	*s = 0;
	while (k > 0) {
		int d = k % 10;
		k = k / 10;
		insertChar((char)('0' + d), s);
	}
	if (sgn) {
		insertChar('-', s);
	}
}

void insertChar(char c, char *s) {
	char *q = s;
	char b = c;

	while (*q) {
		char a = *q;
		*q = b;
		b = a;
		q += 1;
	}

	*q++ = b;
	*q = 0;
}




















