//#include <sys/em.h>




#include <em2.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <tm.h>
#include <semaphore.h>
#include <dbutton.h>
#include <sys/lcd.h>
#include <conio.h>
 

trigger_queue* que;

int trg;

void interpreter(emachine_t* em, int max_que_size) {
      int i, k, j;
	  long int current_time = sys_time;
	  j = 0;
	  while (j < trg) {
		  if ((*(que->node[j].fn))(j, que)) {
			  
			  i = que->node[j].addr;
			  flag = 1;
			  trg--;
			  
			  for (m=j; m <trg; m++) {
					que->node[m].fn = que->node[m+1].fn;
					que->node[m].data = que->node[m+1].data;
					que->node[m].addr = que->node[m+1].addr;
					que->node[m].current_time = que->node[m+1].current_time;
			  }  //for


			  while(flag) {
				switch(em->eco[i].opcode) { 

				case NOP:
				  flag = 0;
				  break;

				case COND:
				  if ((*(em->eco[i].fn))(0, em)) {
					i = em->eco[i].arg2 - 1;	
				  }

				  else { 
					i = em->eco[i].arg1 - 1;
				  }
				  break;

				case FUTURE:
				  que->node[trg].fn = em->eco[i].fn;
				  que->node[trg].data = em->eco[i].arg1;
				  que->node[trg].addr = em->eco[i].arg2;
				  que->node[trg].current_time = current_time;
				  trg++;
				  break;

				case CALL:
				  (*(em->eco[i].fn))(0, em);
				  break;
				
				case SCHEDULE:
				  k = execi( em->eco[i].fn, 0, em, 1, DEFAULT_STACK_SIZE);
				  if (k==-1) { cputs("err"); }
				  break;

				default:
					break;
				}  //switch

				i++;
			  } //while
		  } //if
		  else { 
			j++; 
		  }
	  } //while
    return;
}

void Emachine(emachine_t* em, int max_que_size) {
  
  int k;
  
  que = (trigger_queue*) malloc(sizeof(trigger_queue));
  que->queue_size = max_que_size;
  que->node = (trigger*) malloc(que->queue_size * sizeof(trigger));
  
  que->node[0].fn = (void *)&trigger_queue_init;
  que->node[0].data = 0;
  que->node[0].addr = 0;
  
  
  trg = 1;

  while (trg > 0) {
	  k = execi( &interpreter, 0, em, PRIO_HIGHEST, DEFAULT_STACK_SIZE);
	  msleep(100);
  }

  return;
}


int trigger_queue_init(int data, trigger_queue* p) {
	return 1;
}

void write_int(emachine_t* em, int k, int val) { 
        em->i[k] = val; 
}

int read_int(emachine_t* em, int k) { 
        return em->i[k]; 
}

wakeup_t button_pressed(wakeup_t data){
	return PRESSED(dbutton(), data);
}


int button_event_trigger(int m, trigger_queue* p) {
  unsigned long data = p->node[m].data;
  return PRESSED(dbutton(), data);
}


int time_trigger(int m, trigger_queue* p) {
 long int t = p->node[m].current_time + p->node[m].data;
 if (((time_t) t) <= sys_time) {
    return 1;
 }
 else {
    return 0;
 }
}

void itoa(int n, char * s) {
	int k = n;
	int sgn;

	if (k == 0) {
		*s = '0';
		*(s + 1) = 0;
		return;
	}

	if (k < 0) {
		k = -k;
		sgn = 1;
	} else {
		sgn = 0;
	}

	*s = 0;
	while (k > 0) {
		int d = k % 10;
		k = k / 10;
		insertChar((char)('0' + d), s);
	}
	if (sgn) {
		insertChar('-', s);
	}
}

void insertChar(char c, char *s) {
	char *q = s;
	char b = c;

	while (*q) {
		char a = *q;
		*q = b;
		b = a;
		q += 1;
	}

	*q++ = b;
	*q = 0;
}




















