//#include <sys/em.h>




#include <em.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <tm.h>
#include <semaphore.h>

#include <sys/lcd.h>
#include <conio.h>
 
/*
static const note_t devil_1[] = {
	{PITCH_B4, QUARTER}
};
*/

const int stack_max_size = 10;
const int eco_max_size = 55;
const int int_max_size = 20;

emachine_t* em;
stack_t* stack;
trigger_node *head;
//sem_t trig_sem;
/*

void em_init() {
        trigger_node *t0;
        trigger_node *t1;
        
        if (em!= 0) {
                free(em->eco);
                free(em->i);
                free(em);
        }
        em = (emachine_t*) malloc (sizeof(emachine_t));
        em->eco = (inst_t*) malloc (eco_max_size*sizeof(inst_t));
        em->i = (int *) malloc (int_max_size*sizeof(int));
        
        if (stack!=0) {
                free(stack->stack);
                free(stack);
        }
        stack = (stack_t*) malloc (sizeof(stack_t));
        stack->stack = (int*) malloc (stack_max_size*sizeof(int));
        stack->sp = -1;        

        if (head!=0) {
                t0 = head;
                while(t0!=0) {
                        t1 = t0;
                        t0 = t0->next;
                        free(t1);
                }                        
        }
        head = (trigger_node *) 0;
}        
*/
/*
void handle_triggers() {
 unsigned long clock_time;
 trigger_node* tn;
 
 //if (sem_trywait(&trig_sem)) { return; }
 
 if (head != 0) {  //triggers to be processed
        clock_time = (unsigned long) sys_time;
        tn = removeTriggerNode(clock_time);
	while (tn != 0) {
		int l = tn->trigger_object->l;
                free(tn->trigger_object);
                free(tn);
		Einterpreter(l);
		tn = removeTriggerNode(clock_time);
	}
  }
  
  //sem_post(&trig_sem);
}
*/

void Emachine(emachine_t* em_user) {
  //dsound_play(devil_1);
  cputs ("hello");
  msleep (1000);
  cputs ("wolrd");
  configure_em(em_user);
  //head = create_trigger_node(create_trigger(CLK,0,0));
}

void Einterpreter(int pc_init) {
        
  inst_t* inst;
  int pc = pc_init;
  unsigned long t = sys_time;  //everything happens at t instant in time
 
  //dsound_play(devil_1);

  //while(pc < em->eco_size) {
    //if (!fetch(&inst, &pc)) {
    //  return;
    //} 
    switch(em->eco[pc].opcode) { 
    case NOP:
      break;
    case FUTURE: /*{
    	int topStack = top();
    	int s = inst->arg1;
    	unsigned long m = t + (unsigned long) topStack; 
    	int l = inst->arg2;
        if (topStack == -1) {
    		return;
        }
    	if (topStack == 0) {
    		push(pc); 
    		pc = l;
    	} else {
    		trigger* trig_obj = create_trigger(s, m, l);
	        insert(create_trigger_node(trig_obj));
        }
    }*/
    break;
    case CALL:
      cputs("Hello");
      execute((int (*)()) em->eco[pc].arg1);
	  cputs ("World");
      break;
    case SCHEDULE: {
      //unsigned long deadline = t + (unsigned long) top();
      //unsigned long priority = PRIO_HIGHEST - deadline;
      int k = execi( em->eco[pc].arg1, 0, 0, 1, DEFAULT_STACK_SIZE);
      if (k==-1) { cputs("err"); }
      break;
    }
    default:
      return;
    }
  //}
    
  return;
}


// Internal Port IO
void write_int(int k, int val) { 
        //cputw(k);
        em->i[k] = val; 
}

int read_int(int k) { 
        return em->i[k]; 
}

void configure_em(emachine_t* em_user) {
  int i;
  
  em->eco_size = em_user->eco_size;
  em->i_size   = em_user->i_size;

  cputs("hello");
  msleep (1000);

  for(i=0; i<em->eco_size; i++) {
      em->eco[i].opcode = em_user->eco[i].opcode;
      em->eco[i].arg1   = em_user->eco[i].arg1;
      em->eco[i].arg2   = em_user->eco[i].arg2;
	  //Einterpreter(i);
  }

  cputs("world"); 
  for(i=0; i<em->i_size; i++) {
      em->i[i] = 0;
  }

  for(i=0; i<em->eco_size; i++) {
      
	  Einterpreter(i);
	  //lcd_refresh();
  }
 


}

int fetch(inst_t** inst, int* pc) {
  if (*pc >= em->eco_size) {
    return 0;
  }
  *inst = &(em->eco[*pc]);
  *pc = *pc + 1;
  return 1;
}

int execute(int (*pf) ()) {
  return pf();
}

int push(int i) {
 
  //cputw(i);
  stack->sp += 1;
  if (stack->sp >= stack_max_size) {
    return -1;
  }
  stack->stack[stack->sp] = i;
  return 1;
}

int pop() {
  int tmp;
  if (stack->sp <= -1) {
    return -1;
  } 
  tmp = stack->sp;
  stack->sp = stack->sp - 1;
  return stack->stack[tmp];
}

int top() {
   if (stack->sp <= -1) {
    return -1;
   }
   return stack->stack[stack->sp];
}

/*
trigger* create_trigger(int s, unsigned long m, int l) {
	trigger* new_trigger = (trigger*) malloc (sizeof(trigger));
	if (new_trigger == 0) {
                cputs("err");
                lcd_refresh();
		return (trigger*) 0;
        }        
	new_trigger->s = s;
	new_trigger->m = (unsigned long) m;
	new_trigger->l = l;
	return new_trigger;
}

trigger_node* create_trigger_node(trigger* trigger_object) {
	trigger_node* new_node = (trigger_node*) malloc(sizeof(trigger_node));
	if (new_node == 0)
		return (trigger_node*) 0;
	new_node->trigger_object = trigger_object;
	new_node->next = 0;
	return new_node;
}

void insert(trigger_node *new_node )  {

   unsigned m = new_node->trigger_object->m;
   trigger_node *current = head;
   trigger_node *prev = head;

	// empty list 
   if( current == 0 )
   		head = new_node;         
   
	// insert in front (need special case because of head ptr)
   else if (current->trigger_object->m > m) {
		head = new_node;
		new_node->next = current;
	}
   
    // other cases 
   else {
    current = current->next;	
   		while ((current != 0) && (current->trigger_object->m < m)) {
   			current = current->next;
   			prev = prev->next;
   		}	
   		new_node->next = current;
   		prev->next = new_node;
   }
   
}

trigger_node* removeTriggerNode(unsigned long m)
{
   trigger_node *current, *prev, *temp;
   current = head;  
   prev = head;  
   temp = head;

	if (current == 0)
	  return (trigger_node*) 0;

    if(current->trigger_object->m <= m) {
       temp = current;
       head = current->next;
       return temp;
   }
 
	current = current->next;
   while(current != 0) {
	if (current->trigger_object->m <= m) {
		temp = current;
		prev->next = current->next;
                return temp;
        }
        current = current->next;
        prev = prev->next;
   }
	//no such node found	
   	return (trigger_node*) 0;
   
}

trigger_node* descheduleTriggerNode(int s, int l)
{
   trigger_node *current, *prev, *temp;
   current = head;  
   prev = head;  
   temp = head;

	if (current == 0)
	  return (trigger_node*) 0;

    if ((current->trigger_object->s == s)&&(current->trigger_object->l == l)) {
       temp = current;
       head = current->next;	
		return temp;
   }

	current = current->next;
   while(current != 0) {
	if ((current->trigger_object->s == s)&&(current->trigger_object->l == l)) {
		temp = current;
		prev->next = current->next;
		return temp;
    }
    current = current->next;
    prev = prev->next;
  }
	//no such node found	
   	return (trigger_node*) 0;
  
}

*/





















