//#include <sys/em.h>




#include <em.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <dsensor.h>
#include <tm.h>
#include <semaphore.h>
#include <dbutton.h>

#include <sys/lcd.h>
#include <conio.h>
 

static int __debugging = 1;

void debug(char *s) {
	if (__debugging) {
		 msleep(1000);
		 cputs(s);
		 msleep(1000);
	}
}


void Emachine(emachine_t* em) {
  
  int i, k, m;

  //debug("x1");

  for(i=0; i<em->eco_size; i++) {
    switch(em->eco[i].opcode) { 
    case NOP:
      break;

    case FUTURE:
	  m = em->eco[i].arg1;
	  (*(em->eco[i].fn))(m, 0);
      
	  i = em->eco[i].arg2 - 1;
    break;

    case CALL:
	  //debug("x2");
      (*(em->eco[i].fn))(0, em);
	  //debug("x3");
      break;
	
    case SCHEDULE:
	  //debug("x4"); 
      k = execi( em->eco[i].fn, 0, em, 1, DEFAULT_STACK_SIZE);
      if (k==-1) { cputs("err"); }
      break;

    default:
		break;
	}
  }

  //debug("x5");
  return;
}


// Internal Port IO
void write_int(emachine_t* em, int k, int val) { 
        //cputw(k);
        em->i[k] = val; 
}

int read_int(emachine_t* em, int k) { 
        return em->i[k]; 
}

/*
int execute(int (*pf) ()) {
  return *pf();
} */





















