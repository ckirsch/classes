#include <conio.h>
#include <unistd.h>
#include <em2.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dsound.h>
#include <dmotor.h>
#include <stdlib.h>

//#define LIGHTSENS       SENSOR_2

#define LS 1
#define BT 2
#define RS_1 3
#define RS_2 4
#define CT 5
#define T 6 //for timed
#define PS 7 //for blocked position

#define DARK   14
#define FWD 1200
#define FWD_T 96
#define TURN_LEFT_180 348
#define TURN_RIGHT_180 324
#define TURN_90 160
#define TURN_45 76
#define ROT_LEFT_1 248
#define ROT_LEFT_2 248
#define ROT_RIGHT 280
//#define GAP 168

//drivers
void read_light_sensor(int arg, emachine_t* em) {
	write_int(em, LS, LIGHT_3);
}

void read_button(int arg, emachine_t* em) {
	int i;
	i = PRESSED(dbutton(), BUTTON_VIEW);
	write_int(em, BT, i);
}

void read_rot1_sensor(int arg, emachine_t* em) {
	write_int(em, RS_1, ROTATION_1);
}

void read_rot2_sensor(int arg, emachine_t* em) {
	write_int(em, RS_2, ROTATION_2);
}

void increase_count(int arg, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	write_int(em, CT, k+1);
}

void reduce_count(int arg, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	write_int(em, CT, k-1);
}

void set_rot1_sensor(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_1, 0);
}

void set_rot2_sensor(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_2, 0);
}

void set_time(int arg, emachine_t* em) {
	write_int(em, T, 0);
}

void set_blocked_position(int arg, emachine_t* em) {
	int k;
	k = read_int(em, RS_1);
	write_int(em,PS, k);
}

void stop_a(int arg, emachine_t* em) {
	motor_a_speed(0);
	motor_a_dir(brake);

}

void stop_b(int arg, emachine_t* em) {
	motor_b_speed(0);
	motor_b_dir(brake);

}

void stop_c(int arg, emachine_t* em) {
	motor_c_speed(0);
	motor_c_dir(off);
}

//tasks
void forward(int arg, emachine_t* em) {
  motor_a_speed(MAX_SPEED);
  motor_a_dir(fwd);
}

void pick(int arg, emachine_t* em) {
  	  motor_c_speed(MAX_SPEED/5);
	  motor_c_dir(fwd);
}

void drop (int arg, emachine_t* em) {
	  motor_c_speed(MAX_SPEED/5);
	  motor_c_dir(rev);
}

int turn(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
		motor_b_dir(fwd);
		motor_b_speed(MAX_SPEED/2);  //adjust the angle
	}
	stop_b(0,0);
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -TURN_LEFT_180) && (ROTATION_1 <= TURN_LEFT_180)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED/5);   //turn 180 degree
	}
	stop_a(0,0);
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_2 ) && (ROTATION_2 <= ROT_LEFT_2)) {
			motor_b_dir(rev);
			motor_b_speed(MAX_SPEED/2);  //allign itself
	}
	stop_b(0,0);
	return 0;
}

void beep(int arg, emachine_t* em) {
	note_t* beep = (note_t *)malloc(sizeof(note_t));
    beep->pitch = (char) (PITCH_A4);
	beep->length = (char) (1); 

	dsound_set_duration(20);
	dsound_play(beep);
}


//triggers
int arrived(int m, trigger_queue* p) {
	if ((ROTATION_1 <= - FWD) || (ROTATION_1 >= FWD)) {
		return 1; }
	else {
		return 0; }
}

int arrived_bl(int arg, emachine_t* em) {
	int k, r;
	k = read_int(em, RS_1);
	if (k<0) k = -k;
	lcd_int(k);
    r = FWD - k - 32;

    if ((ROTATION_1 <= - r) || (ROTATION_1 >= r)) {
		return 1; }
	else {
		return 0; }
}

int dark(int arg, emachine_t* em) {
	if (read_int(em, LS) <= DARK)
       return 1;
    else 
	   return 0;
}

int pressed(int arg, emachine_t* em) {
	return read_int(em, BT);
}

int timed(int arg, emachine_t* em) {
	int i;
	i = read_int(em, T);
	write_int(em, T, i+1);
	if (i >= 29)
		return 1;
	else 
		return 0;
}

int get_object(int arg, emachine_t* em) {
	int i;
	i = read_int(em, CT);
	if (i >= 1)
		return 1;
	else 
		return 0;
}

int main(int argc, char **argv) {

  emachine_t* em;
  inst_t *eco;
  int k;
  

  em = (emachine_t*) malloc(sizeof(emachine_t));
  em->eco_size = 37;
  em->i_size = 37;
  em->eco = eco = (inst_t*) malloc(em->eco_size * sizeof(inst_t));
  em->i = (int*) malloc(em->i_size * sizeof(int));

  for(k=0;k<em->i_size;k++) {
	  em->i[k] = 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
  }


  // the forward mode
  eco[0].opcode = CALL;
  eco[0].fn = &set_rot1_sensor;

  eco[1].opcode = CALL;
  eco[1].fn = &read_light_sensor;

  eco[2].opcode = CALL;
  eco[2].fn = &read_rot1_sensor;

  eco[3].opcode = COND;
  eco[3].fn = &dark;
  eco[3].arg1 = 4;
  eco[3].arg2 = 31;

  eco[4].opcode = COND;
  eco[4].fn = &arrived;
  eco[4].arg1 = 5; //if not arrived
  eco[4].arg2 = 8; //if arrived, go to wait

  eco[5].opcode = SCHEDULE;
  eco[5].fn = &forward;

  eco[6].opcode =FUTURE;
  eco[6].fn = &time_trigger;
  eco[6].arg1 = 200;
  eco[6].arg2 = 1; 

  eco[7].opcode = NOP;

  //wait
  eco[8].opcode = CALL;
  eco[8].fn = &stop_a;

  eco[9].opcode = CALL;
  eco[9].fn = &set_time;
  
  eco[10].opcode = COND;
  eco[10].fn = &get_object;
  eco[10].arg1 = 12; //if not
  eco[10].arg2 = 18; //if already has sth, then drop off first

  eco[11].opcode = CALL;
  eco[11].fn = &stop_c;

  eco[12].opcode = CALL;
  eco[12].fn = &read_button;

  eco[13].opcode = COND;
  eco[13].fn = &timed;
  eco[13].arg1 = 14; //if not
  eco[13].arg2 = 26; //if timed, make a turn.

  eco[14].opcode =FUTURE;
  eco[14].fn = &time_trigger;
  eco[14].arg1 = 200;
  eco[14].arg2 = 16; 

  eco[15].opcode = NOP;

  //check touch sensor
  eco[16].opcode = COND;
  eco[16].fn = &pressed;
  eco[16].arg1 = 12;
  eco[16].arg2 = 22;

  eco[17].opcode = NOP;

  // drop_off then wait
  eco[18].opcode = CALL;
  eco[18].fn = &reduce_count;

  eco[19].opcode =FUTURE;
  eco[19].fn = &time_trigger;
  eco[19].arg1 = 2000;
  eco[19].arg2 = 11; 

  eco[20].opcode = SCHEDULE;
  eco[20].fn = &drop;

  eco[21].opcode = NOP;

  //pick up
  eco[22].opcode = CALL;
  eco[22].fn = &increase_count;
    
  eco[23].opcode = FUTURE;
  eco[23].fn = &time_trigger;
  eco[23].arg1 = 2500;
  eco[23].arg2 = 26;  //turn

  eco[24].opcode = SCHEDULE;
  eco[24].fn = &pick;

  eco[25].opcode = NOP;

  //regular turn mode
  eco[26].opcode = CALL;
  eco[26].fn = &stop_c;

  eco[27].opcode = FUTURE;
  eco[27].fn = &time_trigger;
  eco[27].arg1 = 16000;
  eco[27].arg2 = 0;

  eco[28].opcode = SCHEDULE;
  eco[28].fn = &turn;
 
  eco[29].opcode = NOP;

  //blocked turn after blocked
  eco[31].opcode = CALL;
  eco[31].fn = &stop_a;

  eco[32].opcode = CALL;
  eco[32].fn = &read_light_sensor;

  eco[33].opcode = COND;
  eco[33].fn = &dark;
  eco[33].arg1 = 2;
  eco[33].arg2 = 34;

  eco[34].opcode = SCHEDULE;
  eco[34].fn = &beep;

  eco[35].opcode = FUTURE;
  eco[35].fn = &time_trigger;
  eco[35].arg1 = 1000;
  eco[35].arg2 = 32;

  eco[36].opcode = NOP;

//check the size of the code

  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  ds_active(&SENSOR_2);
  ds_rotation_on(&SENSOR_2);

  ds_active(&SENSOR_3);


  
  Emachine(em, 10);
  //cputs("done");
  return 0;
}






