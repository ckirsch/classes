#include <conio.h>
#include <unistd.h>
#include <em2.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dsound.h>
#include <dmotor.h>
#include <stdlib.h>

//#define LIGHTSENS       SENSOR_2

#define LS 1
#define TS 2
#define RS_1 3
#define RS_2 4
#define CT 5

#define DARK   16
#define FWD 600
#define TURN_LEFT_180 316
#define TURN_RIGHT_180 340
#define TURN_90_ODD 158
#define TURN_45 90
#define ROT_LEFT_1 256
#define ROT_LEFT_2 256
#define ROT_RIGHT 280
#define GAP_ODD 180
#define GAP_EVEN 198
#define TURN_90_EVEN 172

//drivers
void read_light_sensor(int arg, emachine_t* em) {
	write_int(em, LS, LIGHT_3);
}

void read_touch_sensor(int arg, emachine_t* em) {
	write_int(em, TS, TOUCH_3);
}

void read_rot1_sensor(int arg, emachine_t* em) {
	write_int(em, RS_1, ROTATION_1);
}

void read_rot2_sensor(int arg, emachine_t* em) {
	write_int(em, RS_2, ROTATION_2);
}


void beep(int arg, emachine_t* em) {
	note_t* beep = (note_t *)malloc(sizeof(note_t));
    beep->pitch = (char) (PITCH_A4);
	beep->length = (char) (1); 

	dsound_set_duration(10);
	dsound_play(beep);
}


void write_count(int arg, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	write_int(em, CT, k+1);
}

void set_rot1_sensor(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_1, 0);
}

void set_rot2_sensor(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_2, 0);
}

void stop_a(int arg, emachine_t* em) {
	motor_a_speed(0);
	motor_a_dir(brake);

}

void stop_b(int arg, emachine_t* em) {
	motor_b_speed(0);
	motor_b_dir(brake);

}

void stop_c(int arg, emachine_t* em) {
	motor_c_speed(0);
	motor_c_dir(brake);
}

//tasks
void forward(int arg, emachine_t* em) {
  motor_a_speed(MAX_SPEED);
  motor_a_dir(fwd);
}

void pick(int arg, emachine_t* em) {
  	  motor_c_speed(MAX_SPEED/5);
	  motor_c_dir(fwd);
}

void drop (int arg, emachine_t* em) {
	  motor_c_speed(MAX_SPEED/4);
	  motor_c_dir(rev);
}

int left_turn(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
		motor_b_dir(fwd);
		motor_b_speed(MAX_SPEED/2);  //adjust the angle
	}
	stop_b(0,0);
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -TURN_LEFT_180) && (ROTATION_1 <= TURN_LEFT_180)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED/5);   //turn 180 degree
	}
	stop_a(0,0);
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
			motor_b_dir(rev);
			motor_b_speed(MAX_SPEED/2);  //allign itself
	}
	stop_b(0,0);
	return 0;
}

void output_CT(int arg, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	lcd_int(k);
}

int right_turn(int arg, emachine_t* em) {
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
		motor_b_dir(rev);
		motor_b_speed(MAX_SPEED/2);  //adjust the angle
	}
	stop_b(0,0);
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -TURN_RIGHT_180) && (ROTATION_1 <= TURN_RIGHT_180)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED/5);   //turn 180 degree
	}
	stop_a(0,0);
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
			motor_b_dir(fwd);
			motor_b_speed(MAX_SPEED/2);  //allign itself
	}
	stop_b(0,0);
	return 0;
}

void back_even(int arg, emachine_t* em) {
	int r, k, d;
	r = read_int(em, RS_1);
	k = read_int(em, CT);
	d = k * GAP_EVEN;

	if (r <= 0) {
		r = -r;
		r = r+112;
	}

	//go bwd
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -r) && (ROTATION_1 <= r)) {
		motor_a_dir(rev);
		motor_a_speed(MAX_SPEED);   
	}
	stop_a(0,0);

	//90 degree right turn
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
		motor_b_dir(rev);
		motor_b_speed(MAX_SPEED/2);  //adjust the angle
	}
	stop_b(0,0);
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -TURN_90_EVEN) && (ROTATION_1 <= TURN_90_EVEN)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED/5);   //turn 180 degree
	}
	stop_a(0,0);
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
			motor_b_dir(fwd);
			motor_b_speed(MAX_SPEED/2);  //allign itself
	}
	stop_b(0,0);

    //go down
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -d) && (ROTATION_1 <= d)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED);   //turn 180 degree
	}
	stop_a(0,0);    
}

void back_odd(int arg, emachine_t* em) {
	int r, k, d;
	r = read_int(em, RS_1);
	if (r <= 0) {
		r = -r;
	}

	r = FWD - r -32;
	k = read_int(em, CT);
	d = k* GAP_ODD;

	//go fwd
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -r) && (ROTATION_1 <= r)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED);   
	}
	stop_a(0,0);

	//90 degree left turn
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
		motor_b_dir(fwd);
		motor_b_speed(MAX_SPEED/2);  //adjust the angle
	}
	stop_b(0,0);
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -TURN_90_ODD) && (ROTATION_1 <= TURN_90_ODD)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED/5);   
	}
	stop_a(0,0);
	ds_rotation_set(&SENSOR_2, 0);
	while ((ROTATION_2 >= -ROT_LEFT_1 ) && (ROTATION_2 <= ROT_LEFT_1)) {
			motor_b_dir(rev);
			motor_b_speed(MAX_SPEED/2);  //allign itself
	}
	stop_b(0,0);
    
	//go down
	ds_rotation_set(&SENSOR_1, 0);
	while ((ROTATION_1 >= -d) && (ROTATION_1 <= d)) {
		motor_a_dir(fwd);
		motor_a_speed(MAX_SPEED);   //turn 180 degree
	}
	stop_a(0,0);
}

void turn_left(int arg, emachine_t* em) {
	motor_b_dir(fwd);
	motor_b_speed(MAX_SPEED);
}

void turn_right(int arg, emachine_t* em) {
	motor_b_dir(rev);
	motor_b_speed(MAX_SPEED);
}

int arrived_test(int m, emachine_t* em) {
	return 0;
}

//triggers
int arrived_even(int m, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	if (k%2== 0) {
		if ((ROTATION_1 <= - FWD) || (ROTATION_1 >= FWD)) {
			return 1; 
		}
		else 
			return 0; 
	}
	else
		return 0;
}

int arrived_odd(int m, emachine_t* em) {
	int k;
	k = read_int(em, CT);
	if (k%2 == 1){
		if ((ROTATION_1 <= - FWD) || (ROTATION_1 >= FWD)) {
			return 1; 
		}
		else 
			return 0;
	}
	else
		return 0;
}

int is_even(int m, emachine_t* em) {
	int k, l;
	k = read_int(em, CT);
	l = k/2;
	if (l*2 == k)
		return 1;
	else
		return 0;
}

int turned(int arg, emachine_t* em) {
	if ((ROTATION_2 <= -ROT_LEFT_1 ) || (ROTATION_2 >= ROT_LEFT_1)) {
		return 1; }
	else {
		return 0; }
}

int alligned(int arg, emachine_t* em) {
	if ((ROTATION_2 <= -ROT_LEFT_2 ) || (ROTATION_2 >= ROT_LEFT_2)) {
		return 1; }
	else {
		return 0; }
}

int dark(int arg, emachine_t* em) {
	if (read_int(em, LS) <= DARK) 
		return 1;
	else 
		return 0;
}


int main(int argc, char **argv) {

  emachine_t* em;
  inst_t *eco;
  int k;
  

  em = (emachine_t*) malloc(sizeof(emachine_t));
  em->eco_size = 34;
  em->i_size = 34;
  em->eco = eco = (inst_t*) malloc(em->eco_size * sizeof(inst_t));
  em->i = (int*) malloc(em->i_size * sizeof(int));

  for(k=0;k<em->i_size;k++) {
	  em->i[k] = 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
  }


  // the forward mode
  eco[0].opcode = CALL;
  eco[0].fn = &set_rot1_sensor;

  eco[1].opcode = CALL;
  eco[1].fn = &read_light_sensor;

  eco[2].opcode = CALL;
  eco[2].fn = &read_rot1_sensor;

  eco[3].opcode = COND;
  eco[3].fn = &arrived_even;
  eco[3].arg1 = 4; //if not arrived_even
  eco[3].arg2 = 16; //if arrived_even, go to left_turn

  eco[4].opcode = COND;
  eco[4].fn = &arrived_odd;
  eco[4].arg1 = 5; //if not arrived_odd
  eco[4].arg2 = 22; //if arrived_odd, go to right_turn

  eco[5].opcode = SCHEDULE;
  eco[5].fn = &forward;

  eco[6].opcode =FUTURE;
  eco[6].fn = &time_trigger;
  eco[6].arg1 = 200;
  eco[6].arg2 = 8;  

  eco[7].opcode = NOP;

  //check dark sensor
  eco[8].opcode = COND;
  eco[8].fn = &dark;
  eco[8].arg1 = 1;
  eco[8].arg2 = 10;

  eco[9].opcode = NOP;

  //stop and pick up
  eco[10].opcode = CALL;
  eco[10].fn = &read_rot1_sensor;
    
  eco[11].opcode = CALL;
  eco[11].fn = &stop_a;
 
  eco[12].opcode = FUTURE;
  eco[12].fn = &time_trigger;
  eco[12].arg1 = 2500;
  eco[12].arg2 = 28;

  eco[13].opcode = SCHEDULE;
  eco[13].fn = &pick;

  eco[14].opcode = SCHEDULE;
  eco[14].fn = &beep;

  eco[15].opcode = NOP;

  //left_turn mode after forward
  eco[16].opcode = CALL;
  eco[16].fn = &stop_a;

  eco[17].opcode = CALL;
  eco[17].fn = &write_count;

  eco[18].opcode = FUTURE;
  eco[18].fn = &time_trigger;
  eco[18].arg1 = 16000;
  eco[18].arg2 = 0;

  eco[19].opcode = SCHEDULE;
  eco[19].fn = &left_turn;

  eco[20].opcode = SCHEDULE;
  eco[20].fn = &output_CT;
 
  eco[21].opcode = NOP;

  //right_turn mode after forward
  eco[22].opcode = CALL;
  eco[22].fn = &stop_a;

  eco[23].opcode = CALL;
  eco[23].fn = &write_count;

  eco[24].opcode = FUTURE;
  eco[24].fn = &time_trigger;
  eco[24].arg1 = 16000;
  eco[24].arg2 = 0;

  eco[25].opcode = SCHEDULE;
  eco[25].fn = &right_turn;
  
  eco[26].opcode = SCHEDULE;
  eco[26].fn = &output_CT;

  eco[27].opcode = NOP;
 
  //stop mode_2 after pick up
  eco[28].opcode = CALL;
  eco[28].fn = &stop_c;

  eco[29].opcode = COND;
  eco[29].fn = &is_even;
  eco[29].arg1 = 32; 
  eco[29].arg2 = 30; //if the even trace 
  
  eco[30].opcode = SCHEDULE;
  eco[30].fn = &back_even;

  eco[31].opcode = NOP;

  eco[32].opcode = SCHEDULE;
  eco[32].fn = &back_odd;

  eco[33].opcode = NOP;
//check the size of the code

  ds_active(&SENSOR_1);
  ds_rotation_on(&SENSOR_1);

  ds_active(&SENSOR_2);
  ds_rotation_on(&SENSOR_2);

  ds_active(&SENSOR_3);


  
  Emachine(em, 10);
  //cputs("done");
  return 0;
}






