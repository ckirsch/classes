#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>


//sensor assignments
#define LIGHT_DATA 			LIGHT_1			//1 light sensor and two touch sensors
#define LIGHT_SENSOR 		SENSOR_1
#define ROT_STEER_DATA 		ROTATION_2		//2 steering rotation sensor
#define ROT_STEER_SENSOR 	SENSOR_2
#define ROT_DRIVE_DATA 		ROTATION_3		//3 drive rotation sensor
#define ROT_DRIVE_SENSOR 	SENSOR_3

  

void jog() 
{
	while(1)
	{
		motor_b_dir(brake);
		motor_b_speed(255);

		while(!TOUCH_1) {}	//wait for someone to push the button
		motor_b_dir(fwd);
		while(TOUCH_1) {}	//wait for someone to release the button
		motor_b_dir(brake);

		while(!TOUCH_1) {}	//wait for someone to push the button
		motor_b_dir(rev);
		while(TOUCH_1) {}	//wait for someone to release the button
	}
}


int main(int argc, char **argv) 
{
  	ds_active(&ROT_DRIVE_SENSOR);
  	ds_rotation_on(&ROT_DRIVE_SENSOR);
	ds_rotation_set(&ROT_DRIVE_SENSOR, 0);

	execi(&jog, 0, NULL, 2, DEFAULT_STACK_SIZE);

	while(1)
	{
		lcd_int(ROT_DRIVE_DATA);
		msleep(100);
	}

	return 0; //return immediately
}
