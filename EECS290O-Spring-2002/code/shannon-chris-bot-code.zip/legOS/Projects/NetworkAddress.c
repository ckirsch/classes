#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>
#include <dsound.h>
#include <lnp.h>
#include <lnp-logical.h>

//static const note_t robots[] = {{ PITCH_D4,  1 } };

unsigned char iCounter = 0;


void MyRxHandler(const unsigned char* Data, unsigned char Length, unsigned char Source)
{
//	dsound_play(robots);
	iCounter++;
} 

  
//void jog() 
//{
//	while(1)
//	{
//	}
//}

int main(int argc, char **argv) 
{

//	lnp_logical_range(1); //set range to far
	lnp_addressing_set_handler(2, MyRxHandler);

	while(1)
	{
		lcd_int(iCounter);
  		lnp_addressing_write(&iCounter, 1, 0 << 4 | 2, 2); //char *Data, char Length, char DestAddrAndPort		
    	msleep(100);
	}

	return 0; //return immediately
}
