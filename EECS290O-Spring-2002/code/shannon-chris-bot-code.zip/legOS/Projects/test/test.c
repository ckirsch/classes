#include<time.h>

int main(int argc, char** argv)
{
	return(sys_time);
}


