#include <conio.h>
#include <unistd.h>
#include <dsound.h>
#include <dmotor.h>
#include <dsensor.h>

/*
static const note_t robots[] = { 
  { PITCH_D4,  1 } };
*/


int Screen(int argc, char **argv) 
{
	int i = 0;

	while(1)
	{
		for(i = 0; i < 3; i++)
			{
				switch(i)
				{
					case 0:
						cputs("0");
						break;
					case 1:
						cputs("1");
						break;
					case 2:
						cputs("2");
						break;
					default:
						cputs("error");
				}

  				msleep(1000);
			}
	}
}
#ifdef 0
int Beep(int argc, char **argv) 
{
	int touched = 0;

	while(1)
	{	
		if(TOUCH_1)
		{
			if(!touched)
			{
			dsound_play(robots);
			touched = 1;
			}
		}
		else
			touched = 0;
		
		msleep(10);
	}
}

int Motor(int argc, char **argv) 
{
	int speed = 0;

	while(1)
	{
	  	motor_a_speed(100);
  		motor_a_dir(fwd);
		msleep(1000);
		motor_a_dir(rev);
		msleep(1000);  	 


/*  		motor_a_dir(fwd);
	  	motor_a_speed(0);
		msleep(1000);
	  	motor_a_speed(5);
		msleep(1000);

  		motor_a_dir(rev);
		msleep(1000);
		motor_a_speed(0);  
		msleep(1000);
	  	motor_a_speed(5);  
	  	msleep(1000);		   */



/*  		motor_a_dir(fwd);
		for(speed = 20; speed <= 100; speed += 20)
		{
	  		motor_a_speed(speed);
			msleep(1000);
		}

		for(speed = 100; speed >= 20; speed -= 20)
		{
	  		motor_a_speed(speed);
			msleep(1000);
		}

  		motor_a_dir(rev);
		for(speed = 20; speed <= 100; speed += 20)
		{
	  		motor_a_speed(speed);
			msleep(1000);
		}

		for(speed = 100; speed >= 20; speed -= 20)
		{
	  		motor_a_speed(speed);
			msleep(1000);
		}	*/
	}
}

int Light(int argc, char **argv) 
{
	while(1)
	{
	  	ds_active(&SENSOR_2);
	  	msleep(100);
	  	ds_passive(&SENSOR_2);
		motor_a_dir(rev);
		msleep(100);
	}
}


#endif

int main(int argc, char **argv) 
{
  execi(&Screen, 0, 0, 1, DEFAULT_STACK_SIZE);
//  execi(&Beep, 0, 0, 1, DEFAULT_STACK_SIZE);
//  execi(&Motor, 0, 0, 1, DEFAULT_STACK_SIZE);
//  execi(&Light, 0, 0, 1, DEFAULT_STACK_SIZE);

    
  return 0;
}
