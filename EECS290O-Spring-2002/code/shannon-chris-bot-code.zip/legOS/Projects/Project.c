#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>

//light sensor thresholds
#define TOUCHED 400
#define BLOCK_THRESH 60

//steering rotation sensor values
#define STEERING_REV 1920 //ticks per revolution of the steering wheel
#define EDGE 18 //distance from center of touch sensor to an edge
#define CENTER 0
#define TURN_LEFT 250
#define TURN_RIGHT -250

//drive rotation sensor values.  About 20 ticks per inch.  
#define DS_INIT 480 //24" horizontal search pattern: 
#define	DS_SUB 160 //vertical distance per horizontal line: 2 revolutions?
#define DR_90  212		 
#define DL_90  185 //250
//#define DR_180 DR_90 * 2
//#define DL_180 DL_90 * 2

//sensor assignments
#define LIGHT_DATA 			LIGHT_1			//1 light sensor and two touch sensors
#define LIGHT_SENSOR 		SENSOR_1
#define ROT_STEER_DATA 		ROTATION_2		//2 steering rotation sensor
#define ROT_STEER_SENSOR 	SENSOR_2
#define ROT_DRIVE_DATA 		ROTATION_3		//3 drive rotation sensor
#define ROT_DRIVE_SENSOR 	SENSOR_3

//priorities
//#define SEARCH_PRIORITY 1
//#define RESCUE_PRIORITY	2

//speeds
#define S_STEER_SPEED 20   //slow steering speed
#define F_STEER_SPEED 255 //150  //fast steering speed
#define ARM_SPEED 50
#define OVER_SHOOT 50 //20
#define F_DRIVE_SPEED 255 //100  //fast drive speed
#define S_DRIVE_SPEED 50   //slow drive speed

#define SLEEP_TIME 500
#define OPEN fwd
#define CLOSE rev


//global

//int position;
pid_t pid_search;
pid_t pid_rescue;


// wakeup functions
wakeup_t touch_wakeup(wakeup_t data)
{
	return(LIGHT_DATA > data);
}

wakeup_t no_touch_wakeup(wakeup_t data)
{
	return(LIGHT_DATA < data);
}


wakeup_t steer_wakeup_fwd(wakeup_t data)
{
	return(ROT_STEER_DATA >= data);	  
}

wakeup_t steer_wakeup_rev(wakeup_t data)
{
	return(ROT_STEER_DATA <= data);	  
}


wakeup_t drive_wakeup(wakeup_t data)  //wait until we get past an absolute distance (we reset the position every move)
{
	return(-ROT_DRIVE_DATA >= data);
}


void arm(short dir)	  //lifts up (CLOSE) or puts down (OPEN) the block.   
{		
	motor_a_speed(ARM_SPEED);
	motor_a_dir(dir);
	wait_event(&touch_wakeup, TOUCHED);	   //HOW CAN THIS WORK PUTTING IT DOWN?
	motor_a_speed(0);
	msleep(SLEEP_TIME);
}

void change_steering(int value)	 //move the steering wheel to an absolute position
{
//	int direction;
//	wakeup_t wakeup_data;
//	cputs("steer");


	if (value < ROT_STEER_DATA)	//compare target with current position
	{
//		cputs("less");
//		direction = rev;
//		wakeup_data = value + OVER_SHOOT;

		motor_c_dir(rev);
		motor_c_speed(F_STEER_SPEED);
//		wait_event(&steer_wakeup_rev, value + OVER_SHOOT);
		while(ROT_STEER_DATA > value + OVER_SHOOT) {}

		motor_c_speed(S_STEER_SPEED);
		while(ROT_STEER_DATA > value) {}
//		wait_event(&steer_wakeup_rev, value);
	}
	else if (value > ROT_STEER_DATA)   //don't do anything if we tell it to go where it already is
	{
//		cputs("great");
//		direction = fwd;
//		wakeup_data = value - OVER_SHOOT;

		motor_c_dir(fwd);
		motor_c_speed(F_STEER_SPEED);
		while(ROT_STEER_DATA < value - OVER_SHOOT) {}
//		wait_event(&steer_wakeup_fwd, value - OVER_SHOOT);

		motor_c_speed(S_STEER_SPEED);
		while(ROT_STEER_DATA < value) {}
//		wait_event(&steer_wakeup_fwd, value);
	}

	motor_c_dir(brake);
	motor_c_speed(255); //full braking
	msleep(SLEEP_TIME);
}
 
void calibrate(void)  //homing routine for the steering wheel
{
//  	int center;

	//activate light and touch sensors		//sensor init
	ds_active(&LIGHT_SENSOR);    
	//activate steering rotation sensor
  	ds_active(&ROT_STEER_SENSOR);
  	ds_rotation_on(&ROT_STEER_SENSOR);
	ds_rotation_set(&ROT_STEER_SENSOR, 0);

	//move until we hit the touch sensor
/*    motor_c_speed(F_STEER_SPEED);			// start steering motor 
    motor_c_dir(fwd);						// in forward direction
    wait_event(&touch_wakeup, TOUCHED);		// wait touch sensor on 

	//stop after we hit the touch sensor.  We should still be on the touch sensor.
//	motor_c_speed(0);						// turn off motor
//	msleep(SLEEP_TIME);						// wait for motor to stop 

	//move slowly in the same direction until we are off the sensor.
  	motor_c_speed(S_STEER_SPEED);			// run motor slowly 
	wait_event(&no_touch_wakeup, TOUCHED);	// wait touch sensor off

	//stop
//	motor_c_speed(0);						// turn off motor
//	msleep(SLEEP_TIME);						// wait for motor to stop

	//turn around 180
	center = ROT_STEER_DATA + (STEERING_REV / 2) - EDGE;
	change_steering(center);				//steer to center
	ds_rotation_set(&ROT_STEER_SENSOR, 0);	//set center to 0		*/
}

void drive(int distance)  //move the drive wheels a relative distance
{
//	cputs("drive");
	ds_rotation_set(&ROT_DRIVE_SENSOR, 0); //reset absolute position to 0
	motor_b_speed(F_DRIVE_SPEED);
	motor_b_dir(fwd);
	wait_event(&drive_wakeup, distance - OVER_SHOOT);  //move fast to within a certain distance of the target...

	motor_b_speed(S_DRIVE_SPEED);					   //then slow down
	wait_event(&drive_wakeup, distance);

	motor_b_dir(brake);								   //stop
	motor_b_speed(255);								   //full braking
	msleep(SLEEP_TIME);								   //wait until we're stopped?
}  

void search()  //thread that runs the spiral search pattern.  
//leg	distance
//1		DS_INIT
//2		DS_INIT - DS_SUB	   after first one, every two are same distance
//3		DS_INIT - DS_SUB
//4		DS_INIT - 2 * DS_SUB
//5		DS_INIT - 2 * DS_SUB
//...
{
	int orientation = 1;  //the leg we're on.  tells us how long to make the leg

	ds_active(&ROT_DRIVE_SENSOR);
  	ds_rotation_on(&ROT_DRIVE_SENSOR);
	arm(OPEN);

	while((DS_INIT - (DS_SUB * (orientation >> 1))) > 0) //keep going until we get to the center of the spiral
	{
		drive(DS_INIT - (DS_SUB * (orientation >> 1)) - 40 * (orientation > 1));	//drive straight.  Subtract difference between car length and line spacing		   
		change_steering(TURN_LEFT);					//turn left
		drive(DL_90);								//make 90 degree turn
		orientation++;							    //increment number of turns
		change_steering(CENTER);					//turn center
	}
}

void rescue()  //thread that monitors the light sensor to se if we found the block
{
	wait_event(&no_touch_wakeup, BLOCK_THRESH);	//wait for the block to be found
	kill(pid_search);							//stop the search algorithm
	motor_b_speed(0);							//stop moving
	motor_b_dir(brake);
	arm(CLOSE);
}

int main(int argc, char **argv) 
{
  	calibrate();
	pid_search = execi(&search, 0, NULL, 2, DEFAULT_STACK_SIZE);
//	pid_rescue = execi(&rescue, 0, NULL, 2, DEFAULT_STACK_SIZE);

	while(1)
	{
		lcd_int(ROT_STEER_DATA);
		msleep(500);
	}

	return 0; //return immediately
}
