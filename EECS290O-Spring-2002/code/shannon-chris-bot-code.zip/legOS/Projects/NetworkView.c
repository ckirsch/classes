#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>
#include <dsound.h>
#include <lnp.h>
#include <lnp-logical.h>

//static const note_t robots[] = {{ PITCH_D4,  1 } };
/*
unsigned char iCounter = 0;


void MyRxHandler(const unsigned char* Data, unsigned char Length) //, unsigned char Source)
{
	dsound_play(robots);
	iCounter++;


}
*/
  
//void jog() 
//{
//	while(1)
//	{					 
//	}
//}

/*
int main(int argc, char **argv) 
{
	unsigned char i = 0;
	lnp_logical_range(1); //set range to far
//	lnp_integrity_set_handler(MyRxHandler);

	for(i = 0; 1; i++)
	{
		lcd_int(i);
		while(!TOUCH_1) {}	//wait for someone to push the button
		lnp_integrity_write(&i, 1); //char *Data, char Length, char DestAddrAndPort		
		dsound_play(robots);
		while(TOUCH_1) {}	//wait for someone to release the button
//    	msleep(100);
	}

	return 0; //return immediately
}
*/


int main(int argc, char **argv) 
{
	int i = 0;
	lnp_logical_range(1); //set range to far

	while(1)
	{
		if(getchar() == KEY_VIEW) 
		{
			while(lnp_integrity_write(&i, 1)) //char *Data, char Length, char DestAddrAndPort		
			{
			i++;  //collisions
			lcd_int(i);
			}

//			dsound_play(robots);
		}
	}

	return 0; //return immediately
}
