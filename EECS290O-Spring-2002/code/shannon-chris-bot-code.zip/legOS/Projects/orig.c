#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>

//light sensor thresholds
#define TOUCHED 400
#define BLOCK_THRESH 60

//steering rotation sensor values
#define STEERING_REV 1920 //this is correct
#define EDGE 18 //distance from center of touch sensor to an edge
#define CENTER 0
#define TURN_LEFT 200
#define TURN_RIGHT -200

//drive rotation sensor values
#define DS_INIT 400 //horizontal search pattern: 
#define	DS_SUB 50 //vertical distance per horizontal line: 2 revolutions?
#define DR_90  212
#define DL_90  250
#define DR_180 DR_90*2
#define DL_180 DL_90*2

//sensor assignments
#define LIGHT_DATA 			LIGHT_1
#define LIGHT_SENSOR 		SENSOR_1
#define ROT_STEER_DATA 		ROTATION_2
#define ROT_STEER_SENSOR 	SENSOR_2
#define ROT_DRIVE_DATA 		ROTATION_3
#define ROT_DRIVE_SENSOR 	SENSOR_3

//priorities
#define SEARCH_PRIORITY 1
#define RESCUE_PRIORITY	2

//speeds
#define S_STEER_SPEED 20
#define F_STEER_SPEED 150
#define ARM_SPEED 50
#define OVER_SHOOT 20
#define F_DRIVE_SPEED 100
#define S_DRIVE_SPEED 50

#define SLEEP_TIME 500
#define OPEN fwd
#define CLOSE rev


//global
int orientation = 1;
int position;
pid_t pid_search;
pid_t pid_rescue;


// wakeup functions
wakeup_t touch_wakeup(wakeup_t data)
{return(LIGHT_DATA>data);}
wakeup_t no_touch_wakeup(wakeup_t data)
{return(LIGHT_DATA<data);}
wakeup_t steer_wakeup(wakeup_t data)
{return(ROT_STEER_DATA==data);}
wakeup_t drive_wakeup(wakeup_t data)
{return((ROT_DRIVE_DATA*(-1))>=data);}


void arm(short dir)
{		
	motor_a_speed(ARM_SPEED);
	motor_a_dir(dir);
	wait_event(&touch_wakeup,TOUCHED);
	motor_a_speed(0);
	msleep(SLEEP_TIME);
}
void change_steering(int value)
{
	int direction;
	wakeup_t wakeup_data;
	if (value < ROT_STEER_DATA)
	{
		direction = rev;
		wakeup_data = value + OVER_SHOOT;
	}
	else
	{
		direction = fwd;
		wakeup_data = value - OVER_SHOOT;
	}
	motor_c_dir(direction);
	motor_c_speed(F_STEER_SPEED);
	wait_event(&steer_wakeup,wakeup_data);
	motor_c_speed(S_STEER_SPEED);
	wait_event(&steer_wakeup,value);
	motor_c_speed(0);
	motor_c_dir(brake);
	msleep(SLEEP_TIME);
}
 
void calibrate(void) 
{
  	int center;
	//activate light and touch sensors		//sensor init
	ds_active(&LIGHT_SENSOR);    
	//activate steering rotation sensor
  	ds_active(&ROT_STEER_SENSOR);
  	ds_rotation_on(&ROT_STEER_SENSOR);
	ds_rotation_set(&ROT_STEER_SENSOR,0);

    motor_c_speed(F_STEER_SPEED);				// start steering motor 
    motor_c_dir(fwd);						// in forward direction
    wait_event(&touch_wakeup,TOUCHED);		// wait touch sensor on 
	motor_c_speed(0);						// turn off motor
	msleep(SLEEP_TIME);						// wait for motor to stop 
  	motor_c_speed(S_STEER_SPEED);			// run motor slowely 
	wait_event(&no_touch_wakeup,TOUCHED);	// wait touch sensor off
	motor_c_speed(0);						// turn off motor
	msleep(SLEEP_TIME);						// wait for motor to stop
	center = ROT_STEER_DATA + (STEERING_REV/2) - EDGE;
	change_steering(center);				//steer to center
	ds_rotation_set(&ROT_STEER_SENSOR,0);	//set center to 0		*/
}
void drive(int distance)
{
	ds_rotation_set(&ROT_DRIVE_SENSOR,0);
	motor_b_speed(F_DRIVE_SPEED);
	motor_b_dir(fwd);
	wait_event(&drive_wakeup,distance-OVER_SHOOT);
	motor_b_speed(S_DRIVE_SPEED);
	wait_event(&drive_wakeup,distance);
	motor_b_speed(0);
	motor_b_dir(brake);
	msleep(SLEEP_TIME);
}
void search()
{
	ds_active(&ROT_DRIVE_SENSOR);
  	ds_rotation_on(&ROT_DRIVE_SENSOR);
	arm(OPEN);
	while((DS_INIT-(DS_SUB*(orientation>>1)))>0)
	{
	
	drive(DS_INIT-(DS_SUB*(orientation>>1)));	//drive straight		   
	change_steering(TURN_LEFT);					//turn left
	drive(DL_90);								//make 90 degree turn
	orientation += 1;							//increment number of turns
	change_steering(CENTER);					//turn center

	}
}

void rescue()
{
	wait_event(&no_touch_wakeup,BLOCK_THRESH);
	kill(pid_search);
	motor_b_speed(0);
	motor_b_dir(brake);
	arm(CLOSE);
}

int main(int argc, char **argv) 
{
  	calibrate();
	pid_search=execi(&search, 0, NULL, 2, DEFAULT_STACK_SIZE);
	pid_rescue=execi(&rescue, 0, NULL, 3, DEFAULT_STACK_SIZE);
	return 0;
}
