#include <conio.h>
#include <unistd.h>		    
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>
#include <dsound.h>
#include <lnp.h>
#include <lnp-logical.h>

static const note_t robots[] = {{ PITCH_D4,  1 } };

//unsigned char iCounter = 0;


void MyRxHandler(const unsigned char* Data, unsigned char Length) //, unsigned char Source)
{
//	dsound_play(robots);   //just beep and display the incoming data
	lcd_int(*((int*) Data));
//	iCounter++;
}

  

int main(int argc, char **argv) 
{
	int i = 0;
	lnp_integrity_set_handler(MyRxHandler);

	lnp_logical_range(1); //set range to far

	for(i = 0; 1; i++)
	{
		if(getchar() == KEY_VIEW) 
		{
			while(lnp_integrity_write(&i, 2)) //char *Data, char Length, char DestAddrAndPort		
			{
//				i++;	   //collisions
//				lcd_int(i);
//				msleep(100);
			}
		}
//		msleep(500);
	}

	return 0; //return immediately
}
