#include <conio.h>
#include <unistd.h>
#include <dbutton.h>
#include <dsensor.h>
#include <dmotor.h>

//light sensor thresholds
#define TOUCHED 400
#define BLOCK_THRESH 55	  //sensor must read below this to see block

//steering rotation sensor values
//#define STEERING_REV 1920 //ticks per revolution of the steering wheel
//#define EDGE 18 //distance from center of touch sensor to an edge
#define CENTER 0
#define TURN_LEFT 300
#define TURN_RIGHT -300

//drive rotation sensor values.  About 20 ticks per inch.  
#define STRAIGHT_LENGTH 480 //24" horizontal search pattern:
#define SPACING_LENGTH  170 //distance between legs 
#define DR_90  133.5		 
#define DL_90  131 
#define DR_180 DR_90 * 2
#define DL_180 DL_90 * 2

//sensor assignments
#define LIGHT_DATA 			LIGHT_1			//1 light sensor and two touch sensors
#define LIGHT_SENSOR 		SENSOR_1
#define ROT_STEER_DATA 		ROTATION_2		//2 steering rotation sensor
#define ROT_STEER_SENSOR 	SENSOR_2
#define ROT_DRIVE_DATA 		-ROTATION_3		//3 drive rotation sensor
#define ROT_DRIVE_SENSOR 	SENSOR_3

//priorities
//#define SEARCH_PRIORITY 1
//#define RESCUE_PRIORITY	2

//speeds
#define S_STEER_SPEED 20   //slow steering speed
#define F_STEER_SPEED 255 //150  //fast steering speed
#define ARM_SPEED 50
#define OVER_SHOOT 50 //20
#define F_DRIVE_SPEED 255 //100  //fast drive speed
#define S_DRIVE_SPEED 50   //slow drive speed

#define SLEEP_TIME 500
#define OPEN fwd
#define CLOSE rev


//global

//int position;
pid_t pid_search;
pid_t pid_rescue;


// wakeup functions
wakeup_t touch_wakeup(wakeup_t data)
{
	return(LIGHT_DATA > data);
}

wakeup_t no_touch_wakeup(wakeup_t data)
{
	return(LIGHT_DATA < data);
}


wakeup_t drive_wakeup(wakeup_t data)  //wait until we get past an absolute distance (we reset the position every move)
{
	return(ROT_DRIVE_DATA >= data);
}


void arm(short dir)	  //lifts up (CLOSE) or puts down (OPEN) the block.   
{		
	motor_a_speed(ARM_SPEED);
	motor_a_dir(dir);
	wait_event(&touch_wakeup, TOUCHED);	   
	motor_a_speed(0);
	msleep(SLEEP_TIME);
}

void change_steering(int value)	 //move the steering wheel to an absolute position
{
//	cputs("steer");

	if (value < ROT_STEER_DATA)	//compare target with current position
	{
//		cputs("less");

		motor_c_dir(rev);
		motor_c_speed(F_STEER_SPEED);
		while(ROT_STEER_DATA > value + OVER_SHOOT) {}

		motor_c_speed(S_STEER_SPEED);
		while(ROT_STEER_DATA > value) {}
	}
	else if (value > ROT_STEER_DATA)   //don't do anything if we tell it to go where it already is
	{
//		cputs("great");

		motor_c_dir(fwd);
		motor_c_speed(F_STEER_SPEED);
		while(ROT_STEER_DATA < value - OVER_SHOOT) {}

		motor_c_speed(S_STEER_SPEED);
		while(ROT_STEER_DATA < value) {}
	}

	motor_c_dir(brake);
	motor_c_speed(255); //full braking
	msleep(SLEEP_TIME);
}
 

void drive(int distance)  //move the drive wheels a relative distance
{
//	cputs("drive");

	if(distance > 0)
	{
		ds_rotation_set(&ROT_DRIVE_SENSOR, 0); //reset absolute position to 0

		motor_b_dir(fwd);
		motor_b_speed(S_DRIVE_SPEED);					   //small acceleration.  assumes no really small moves.
		msleep(500);

		motor_b_speed(F_DRIVE_SPEED);
		wait_event(&drive_wakeup, distance - OVER_SHOOT);  //move fast to within a certain distance of the target...

		motor_b_speed(S_DRIVE_SPEED);					   //then slow down
		wait_event(&drive_wakeup, distance);

		motor_b_dir(brake);								   //stop
		motor_b_speed(255);								   //full braking
		msleep(SLEEP_TIME);								   //wait until we're stopped?
	}
}  

int iLeg = 0;  //the straightaway we're on

void search()  //thread that runs the spiral search pattern.  
{
	while(1) //keep going until we find the block
	{
		drive(STRAIGHT_LENGTH);	//drive straight.  Subtract difference between car length and line spacing		   
		change_steering(TURN_LEFT);					//turn left
		drive(DL_180);								//make 90 degree turn
		change_steering(CENTER);					//turn center
		iLeg++;

		drive(STRAIGHT_LENGTH);	//drive straight.  Subtract difference between car length and line spacing		   
		change_steering(TURN_RIGHT);				//turn left
		drive(DR_180);								//make 90 degree turn
		change_steering(CENTER);					//turn center
		iLeg++;
	}
}

void rescue()  //thread that monitors the light sensor to see if we found the block
{
	int iCapturePosition = 0;

//	wait_event(&no_touch_wakeup, BLOCK_THRESH);	//wait for the block to be found
	while(LIGHT_DATA > BLOCK_THRESH) {}
	kill(pid_search);							//stop the search algorithm
	motor_b_speed(0);							//stop moving
	motor_b_dir(brake);
	arm(CLOSE);

	iCapturePosition = ROT_DRIVE_DATA;  //need to latch the position because the next time we call drive, the position will be reset

	if(iLeg % 2) //on an odd leg (facing opposite way we started)
	{
		cputs("opp");

		drive(STRAIGHT_LENGTH - iCapturePosition);	//drive straight.  Finish the leg.  		   
	}
	else //on an even leg (facing same way we started)
	{
		cputs("same");

		//make a u turn
		change_steering(TURN_LEFT);				//turn left
		drive(DL_180);								//make 90 degree turn
		change_steering(CENTER);					//turn center

		drive(iCapturePosition);	//drive straight.  Finish the leg.  		   

		iLeg++;  //pretend we're on the next leg so the following logic will send us the right distance home
	}

	cputs("left");
	change_steering(TURN_LEFT);					//turn left

	if(iLeg <= 1) //don't need to do this for legs 0 and 1 
	{
		drive(DL_180);	
	}
	else 
	{
		drive(DL_90);								//make 90 degree turn
		change_steering(CENTER);					//turn center

		cputs("fwd");
		drive((iLeg - 1) * SPACING_LENGTH);	//drive straight.		   

		cputs("left2");
		change_steering(TURN_LEFT);					//turn left
		drive(DL_90);								//make 90 degree turn
	}

	change_steering(CENTER);					//turn center

	arm(OPEN);
}


int main(int argc, char **argv) 
{
	//activate light and touch sensors		//sensor init
	ds_active(&LIGHT_SENSOR); 
	   
	//activate steering rotation sensor
  	ds_active(&ROT_STEER_SENSOR);
  	ds_rotation_on(&ROT_STEER_SENSOR);
	ds_rotation_set(&ROT_STEER_SENSOR, 0);
	
	motor_c_dir(brake);
	motor_c_speed(255); //full braking on the steering wheel initially

	ds_active(&ROT_DRIVE_SENSOR);
  	ds_rotation_on(&ROT_DRIVE_SENSOR);
	ds_rotation_set(&ROT_DRIVE_SENSOR, 0); //reset absolute position to 0

	arm(OPEN);	//do this before threads start so we can release the block
	msleep(1000);
	pid_search = execi(&search, 0, NULL, 2, DEFAULT_STACK_SIZE);
	pid_rescue = execi(&rescue, 0, NULL, 2, DEFAULT_STACK_SIZE);

	while(1)
	{
		lcd_int(ROT_DRIVE_DATA); //LIGHT_DATA); //iLeg); //ROT_STEER_DATA);
		msleep(500);
	}

	return 0; //return immediately
}
