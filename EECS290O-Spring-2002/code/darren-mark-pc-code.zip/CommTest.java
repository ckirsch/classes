package lnp;

import java.io.*;


/**
* Uses the LNPManager class and the LNPListener interface to receive and send messages to an RCX.
* To run:  java lnp.CommTest
*/

public class CommTest implements LNPListener
{
	static LNPManager manager = LNPManager.getInstance("COM1");  //Gets the LNPManager connected with the COM1 port
	//String waypt = null;
	//int sendData[] = new int[3];
	//byte sendBytes[] = new byte[6];

	public static float TICKS_PER_CM = (float)38.0;  //nnumber of quarter rotation ticks per cm
	public static float TICKS_PER_DEGREE = (float)(480.0/90.0);  //number of ticks per degree

	/*void ConsoleReader() {
		BufferedReader console = new BufferedReader (new InputStreamReader(System.in));

		System.out.println("Enter next waypoint (x,y):");
		try {
			System.out.println("x:");
			waypt[0] = Integer.parseInt(console.readLine());
		} catch (IOException e) {
			System.out.println("Error reading from console.");	
		}
		try {
			System.out.println("y:");
			waypt[1] = Integer.parseInt(console.readLine());
		} catch (IOException e) {
			System.out.println("Error reading from console.");	
		}

	}*/

	/*void ConsoleReader1() {
		//BufferedReader console = new BufferedReader (new InputStreamReader(System.in));
		//System.out.println("Enter one of the following control Modes with parameters: mode,param1,param2");
		//System.out.println("0 -- stop.");
		//System.out.println("1 -- const. steer angle, const. speed");
		//System.out.println("2 -- const. steer angle, travel distance");
		//System.out.println("3 -- turn to theta, travel distance");
		//System.out.println("4 -- goto x, y");
		
		//try {
		//	int index;
			waypt = console.readLine();
			sendData[0]= Integer.parseInt(waypt.substring(0,1));
			sendBytes[0]=(new Integer(sendData[0])).byteValue();
			if(sendData[0]!=0) {
				index=waypt.indexOf(',',3);
				sendData[1]=Integer.parseInt(waypt.substring(2,index));
				sendBytes[1]=(byte) (sendData[1]>>8);
				sendBytes[2]=(byte) sendData[1];
				sendData[2]=Integer.parseInt(waypt.substring(index+1));
				sendBytes[3]=(byte) (sendData[2]>>8);
				sendBytes[4]=(byte) sendData[2];
			}
		//} catch (Exception e) {
		//	System.out.println("Error reading from console.");
		//}
	}*/



	//LNPListener INTERFACE METHODS -----------------------------
	/**
	* Prints as a string the received integrity packet.
	*/
	public void integrityReceived(byte [] buffer)
	{
		String buffer2 = new String(buffer);

		System.out.println("Message received");
		System.out.println(buffer2);

		// Sends a response to sender
		manager.integrityWrite("rcv");
	}
	/**
	* Prints as a string the received integrity packet, the destination port, the source
	* host and the source port.
	*/
	public void addressingReceived(byte [] buffer, byte toPort, byte fromHost, byte fromPort)
	{
		String buffer1 = new String(buffer);		
		int result[] = new int[4];
		
		if (fromHost != 16) 
		{
			//System.out.println("Received, Host: "+fromHost+" Port: "+fromPort+" to PC Port: "+toPort);
			for(int i=0;i+1<buffer.length;i+=2) {
				result[i/2]=(buffer[i+1]<<8) + (((int)buffer[i]<<24)>>>24);
			}
			
			System.out.println("Theta="+result[0]+" ("+result[0]/TICKS_PER_DEGREE+" deg), x="+result[1]+ " ("+result[1]/TICKS_PER_CM+" cm), y="+result[2]+" ("+result[2]/TICKS_PER_CM+" cm)");
		}
		
		// Sends a response to sender (except the PC which is host 16) from port 9 to host 0, port 5
		if (fromHost != 16) 
		{
			//manager.addressingWrite("rcv", (byte)9, (byte)0x0, (byte)5);
		}
	}
	/**
	* Prints an error message when a packet with a wrong checksum is received.
	*/
	public void wrongChecksumReceived()
	{
		System.out.println("Wrong checksum received");
		//manager.addressingWrite("err", (byte)9, (byte)0x0, (byte)5);
	}
	//End LNPListener-----------------------------------



	public static void main(String args[])
	{
		//int index;
		CommTest com = new CommTest();  //Creating an instance of CommTest object
		manager.addLNPListener(com);	  //Subscribes to all incoming packets
		SendGui mygui = new SendGui();

		//do {
		//	com.ConsoleReader1();
		//	System.out.println("Mode Change to " + com.sendData[0] + " :(" + com.sendData[1] + ", " + com.sendData[2] + " ) sent");
		//	manager.addressingWrite(com.sendBytes, (byte)9, (byte)0x0, (byte)5);
		//} while (true);

		/*if (mygui.mystring == null) mygui.mystring = "0";
		com.waypt = mygui.mystring; 
		com.sendData[0]= Integer.parseInt(com.waypt.substring(0,1));
		com.sendBytes[0]=(new Integer(com.sendData[0])).byteValue();
		if(com.sendData[0]!=0) {
			index=com.waypt.indexOf(',',3);
			com.sendData[1]=Integer.parseInt(com.waypt.substring(2,index));
			com.sendBytes[1]=(byte) (com.sendData[1]>>8);
			com.sendBytes[2]=(byte) com.sendData[1];
			com.sendData[2]=Integer.parseInt(com.waypt.substring(index+1));
			com.sendBytes[3]=(byte) (com.sendData[2]>>8);
			com.sendBytes[4]=(byte) com.sendData[2];
		}

		System.out.println("Mode Change to " + com.sendData[0] + " :(" + com.sendData[1] + ", " + com.sendData[2] + " ) sent");
		manager.addressingWrite(com.sendBytes, (byte)9, (byte)0x0, (byte)5);*/
	}

}