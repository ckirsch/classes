package lnp;

//v 1.3
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SendGui implements ActionListener {
	static float TICKS_PER_CM = (float)38.0;  //nnumber of rotation ticks per cm
	static float TICKS_PER_DEGREE = (float)(480.0/90.0);  //number of ticks per degree
    JFrame sendFrame;
    JPanel sendPanel;
    JTextField myData;
    JLabel dataLabel, buttonLabel, mySpace; 
    JLabel myLabel0, myLabel1, myLabel2, myLabel3, myLabel4, myLabel5, myLabel6;
    JButton sendButton;
    String mystring = null;

    // Constructor
    public SendGui() {
	// Create the frame and container.
	sendFrame = new JFrame("Java LegOS Communication");
	sendFrame.setSize(5000, 1000);
	sendPanel= new JPanel();
	sendPanel.setLayout(new GridLayout(12, 2));
	
	// Add the widgets.
	addWidgets();

	// Add the panel to the frame.
	sendFrame.getContentPane().add(sendPanel, BorderLayout.CENTER);

	// Exit when the window is closed.
        //sendFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	// Show the GUI.
	sendFrame.pack();
	sendFrame.setVisible(true);
    }

    // Create and add the widgets for GUI.
    private void addWidgets() {
	// Create widgets.
	myData = new JTextField(2);
	dataLabel = new JLabel("Data", SwingConstants.LEFT);
	sendButton = new JButton("Send...");
	buttonLabel = new JLabel(" ", SwingConstants.LEFT);
	mySpace = new JLabel(" ", SwingConstants.LEFT);
	myLabel0 = new JLabel("Modes", SwingConstants.CENTER);
	myLabel1 = new JLabel("0 -- Stop", SwingConstants.LEFT);
	myLabel2 = new JLabel("1 -- const. steer angle, const. speed", SwingConstants.LEFT);
	myLabel3 = new JLabel("2 -- const. steer angle, travel distance", SwingConstants.LEFT);
	myLabel4 = new JLabel("3 -- turn to theta (degrees), travel distance (cm)", SwingConstants.LEFT);
	myLabel5 = new JLabel("4 -- goto x, y (cm)", SwingConstants.LEFT);
	myLabel6 = new JLabel("5 -- goto x, y  (cm) backwards", SwingConstants.LEFT);

	// Listen to events from Convert button.
	sendButton.addActionListener(this);

	// Add widgets to container.
	sendPanel.add(myData);
	sendPanel.add(dataLabel);
	sendPanel.add(sendButton);
	sendPanel.add(buttonLabel);
	sendPanel.add(myLabel0);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel1);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel2);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel3);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel4);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel5);
	sendPanel.add(mySpace);
	sendPanel.add(myLabel6);
	sendPanel.add(mySpace);
	
      dataLabel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
	//buttonLabel.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
	
    }


    // Implementation of ActionListener interface.
    public void actionPerformed(ActionEvent event){

	LNPManager man = LNPManager.getInstance("COM1");
	mystring = myData.getText();
	buttonLabel.setText(mystring);

	String waypt = null;
	int sendData[] = new int[3];
	byte sendBytes[] = new byte[6];
	int index;

	

	if (mystring == null) mystring = "0";
	waypt = mystring; 
	sendData[0]= Integer.parseInt(waypt.substring(0,1));
	sendBytes[0]=(new Integer(sendData[0])).byteValue();
	if(sendData[0]!=0) {
		index=waypt.indexOf(',',3);
		sendData[1]=Integer.parseInt(waypt.substring(2,index));
		if(sendData[0]==3) sendData[1]=(int) (sendData[1]*TICKS_PER_DEGREE);
		else if(sendData[0]>3) sendData[1]=(int) (sendData[1]*TICKS_PER_CM);
		sendBytes[1]=(byte) (sendData[1]>>8);
		sendBytes[2]=(byte) sendData[1];
		sendData[2]=Integer.parseInt(waypt.substring(index+1));
		if(sendData[0]>2) sendData[2]=(int)(sendData[2]*TICKS_PER_CM);
		sendBytes[3]=(byte) (sendData[2]>>8);
		sendBytes[4]=(byte) sendData[2];
	}

	System.out.println("Mode Change to " + sendData[0] + " :(" + sendData[1] + ", " + sendData[2] + " ) sent");
	man.addressingWrite(sendBytes, (byte)9, (byte)0x0, (byte)5);
	myData.setText("");
    }

}
