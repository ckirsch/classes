extern void internal_I_CAR ();
extern void internal_I_FROM_N ();
extern void internal_I_FROM_NC ();
extern int internal_reset ();
extern int internal ();
extern void internal_O_TO_NC ();
extern void internal_O_CAR_TURN ();



