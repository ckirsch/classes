// inside node


#include "tos.h"
#include "internal.h"
#include "DETECT_CAR.h"
#include "../detect_car_shared/DETECT_CAR_EXTRA.h"

#define NODE_ID 2  //(1,2) my ID
#define DUMB_NODE 3  //(0,3) node next to me that is working with me
#define OTHER_SMART_NODE 1  // (2,1) smart node at other end of the street

#define TOS_FRAME_TYPE DETECT_CAR_frame
TOS_FRAME_BEGIN(DETECT_CAR_frame) {
  char sendPending;
  TOS_Msg message;
  unsigned char dark;
  unsigned char outsideDetected;
  unsigned char insideDetected;
  unsigned char numberOfCars;
  unsigned char sendSecondMessage;  //this is a hack for now
}
TOS_FRAME_END(DETECT_CAR_frame);

char TOS_COMMAND(DETECT_CAR_INIT)(){
  //init my state
  VAR(sendPending) = 0;
  VAR(dark) = 0;
  VAR(outsideDetected) = 0;
  VAR(insideDetected) = 0;
  VAR(numberOfCars) = 0;
  VAR(sendSecondMessage) = 0;
  internal_reset();
  internal();
  //init other components that i use
  TOS_CALL_COMMAND(DETECT_CAR_SUB_DISPLAY_INIT)(); 
  TOS_CALL_COMMAND(DETECT_CAR_SUB_SENSOR_INIT)(); 
  TOS_CALL_COMMAND(DETECT_CAR_SUB_COMM_INIT)();
  TOS_COMMAND(DETECT_CAR_DISPLAY_INT)((short) 0);  // turn LEDS off initially
  return 1;
}

char TOS_COMMAND(DETECT_CAR_START)(){
  //when we start, do nothing except start the clock
  TOS_CALL_COMMAND(DETECT_CAR_SUB_CLOCK_INIT)(128,6); 
  return 1;
}

char sendMessage(unsigned char sourceNodeID, unsigned char info) {
  //fire a RF message off over the broadcast channel
  detect_car_msg_payload* messagePayload = (detect_car_msg_payload*)VAR(message).data;
  if (!VAR(sendPending)) {
    VAR(sendPending) = 1;
    messagePayload->sourceNodeID = sourceNodeID;
    messagePayload->info = info;  //could i somehow use TOS_LOCAL_ADDRESS ??
    if (TOS_CALL_COMMAND(DETECT_CAR_SEND_MSG)(TOS_BCAST_ADDR, AM_MSG(DETECT_CAR_RECEIVE_MSG), &VAR(message))) {
      //  TOS_COMMAND(DETECT_CAR_DISPLAY_INT)((short) 4);
      return 1;
    } else {
      VAR(sendPending) = 0; //request failed, free buffer
    }
  }
  return 0;
}

void TOS_EVENT(DETECT_CAR_CLOCK_EVENT)(){
  //every clock tick get new sensor data
  if (VAR(sendSecondMessage) == 1) {
    sendMessage(NODE_ID, 1);
    VAR(sendSecondMessage) = 0;
  }
  TOS_COMMAND(DETECT_CAR_SENSOR_GET_DATA)();
}


char TOS_EVENT(DETECT_CAR_SENSOR_DATA_READY)(short data){
  // new reading from sensor; check it's value; if it just went dark then
  // update your state, and tell the others if necessary
  short normalized = (7 - ((data >> 7) & 0x7));
  if (normalized >= LIGHT_THRESHOLD) { //i just saw something (it is dark out)
    if (VAR(dark) == 0) { // ...and that wasn't there before (it used to be light out)
      VAR(dark) = 1;
      //   newDetection(1);
      internal_I_CAR();
      internal();
    }
  } else  {//it is light out (i'm not seeing anything)
    VAR(dark) = 0;  //it's light out
    internal();}
  return 1;
}

TOS_MsgPtr TOS_MSG_EVENT(DETECT_CAR_RECEIVE_MSG)(TOS_MsgPtr val){
  // i just received a RF packet from someone else
  detect_car_msg_payload* messagePayload_ptr = (detect_car_msg_payload*) val->data;
  if (messagePayload_ptr->sourceNodeID == DUMB_NODE) { //if it is my helper dumb node
    //newDetection(0);
  internal_I_FROM_N();
  internal();}
  else if (messagePayload_ptr->sourceNodeID == OTHER_SMART_NODE) {  //it's the smart node on the other side of the street
    /*    if (messagePayload_ptr->info == 1)  // another car just entered on the other side of the street
      newDetection(2);
    if (messagePayload_ptr->info == 2)  // a car just left at the other end of the street
  }
    */
    internal_I_FROM_NC();
    internal();
  }
  return val;
}

char TOS_EVENT(DETECT_CAR_MSG_SEND_DONE)(TOS_MsgPtr sentBuffer){
  // a RF message i was trying to send could be done
  if (VAR(sendPending) && sentBuffer == &VAR(message)) {
    VAR(sendPending) = 0;
    return 1;
  }
  return 0;
}
#include "internal.c"
