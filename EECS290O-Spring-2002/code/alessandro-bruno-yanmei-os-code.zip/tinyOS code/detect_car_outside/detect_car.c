// outside node

#include "tos.h"
#include "DETECT_CAR.h"
#include "extnode.h"
#include "../detect_car_shared/detect_car_extra.h"

#define NODE_ID 0 //(0,3)

#define TOS_FRAME_TYPE DETECT_CAR_frame
TOS_FRAME_BEGIN(DETECT_CAR_frame) {
  char sendPending;
  unsigned char dark;
  TOS_Msg message;
}
TOS_FRAME_END(DETECT_CAR_frame);

char TOS_COMMAND(DETECT_CAR_INIT)(){
  VAR(sendPending) = 0;
  VAR(dark) = 0;  //initially it is light out
  TOS_CALL_COMMAND(DETECT_CAR_SUB_DISPLAY_INIT)(); 
  TOS_CALL_COMMAND(DETECT_CAR_SUB_SENSOR_INIT)(); 
  TOS_CALL_COMMAND(DETECT_CAR_SUB_COMM_INIT)();
  TOS_COMMAND(DETECT_CAR_DISPLAY_INT)((short) 0);
  extnode_reset();
  extnode();
  return 1;
}

char TOS_COMMAND(DETECT_CAR_START)(){
  TOS_CALL_COMMAND(DETECT_CAR_SUB_CLOCK_INIT)(128,6); 
  return 1;
}

void TOS_EVENT(DETECT_CAR_CLOCK_EVENT)(){
  TOS_COMMAND(DETECT_CAR_SENSOR_GET_DATA)();
}

char sendMessage(unsigned char sourceNodeID, unsigned char info) {
  detect_car_msg_payload* messagePayload = (detect_car_msg_payload*)VAR(message).data;
  if (!VAR(sendPending)) {
    VAR(sendPending) = 1;
    messagePayload->sourceNodeID = sourceNodeID;
    messagePayload->info = info;  //TOS_LOCAL_ADDRESS ??
    if (TOS_CALL_COMMAND(DETECT_CAR_SEND_MSG)(TOS_BCAST_ADDR, AM_MSG(DETECT_CAR_RECEIVE_MSG), &VAR(message))) {
      return 1;
    } else {
      VAR(sendPending) = 0; //request failed, free buffer
    }
  }
  return 0;
}

char TOS_EVENT(DETECT_CAR_SENSOR_DATA_READY)(short data){
  short normalized = (7 - ((data >> 7) & 0x7));
  if (normalized >= LIGHT_THRESHOLD) { //i just saw something (it is dark out)
    if (VAR(dark) == 0) { // ...and that wasn't there before (it used to be light out)
      VAR(dark) = 1;
      extnode_I_CAR();
      // sendMessage(NODE_ID, 0);  //send the info: i'm dumb and i see something
      extnode();
    }
  } else //it is light out (i'm not seeing anything)
    VAR(dark) = 0;  //it's light out
  TOS_COMMAND(DETECT_CAR_DISPLAY_INT)(normalized);  //always display your sensor reading to the LEDS
  return 1;
}

TOS_MsgPtr TOS_MSG_EVENT(DETECT_CAR_RECEIVE_MSG)(TOS_MsgPtr val){
  return val;  //drop any packets sent to me (because i'm dumb)
}

char TOS_EVENT(DETECT_CAR_MSG_SEND_DONE)(TOS_MsgPtr sentBuffer){
  if (VAR(sendPending) && sentBuffer == &VAR(message)) {
    VAR(sendPending) = 0;
    return 1;
  }
  return 0;
}
#include "external.c"
