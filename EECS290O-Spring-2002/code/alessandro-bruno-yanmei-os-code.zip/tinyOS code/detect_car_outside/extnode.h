extern void extnode_I_CAR ();
extern int extnode();
extern int extnode_reset();
