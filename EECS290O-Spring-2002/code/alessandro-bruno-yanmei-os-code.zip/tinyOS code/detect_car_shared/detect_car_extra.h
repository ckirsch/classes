#define LIGHT_THRESHOLD 3
#define MY_CLOCK_RATE tick1ps

//our message payload structure
typedef struct{
  unsigned char sourceNodeID;
  unsigned char info;
} detect_car_msg_payload;
//
// sourceNodeID:
//  0 - outside left
//  1 - inside left
//  2 - inside right
//  3 - outside right
//  4 - car coming from left
//  5 - car coming from right
//
// info:
//  0 - i'm dumb and i see something
//  1 - i'm smart and i know a car just entered
//  2 - i'm smart and i know a car just left
//  3 - there is 2 cars -- EVADE!!! AHHHH!

// outside nodes are "dumb", they just fire off packets when they see something
// inside nodes are "smart", they maintain state and communicate with each other
