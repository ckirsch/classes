#ifndef __MOVECAR1___
#define __MOVECAR1___
#include "super.h"
//ACCEPTS
char TOS_COMMAND(MOVECAR1_INIT)(void);
char TOS_COMMAND(MOVECAR1_START)(void);
//HANDLES
void TOS_EVENT(MOVECAR1_CLOCK_EVENT)(void);
char TOS_EVENT(MOVECAR1_MSG_SEND_DONE)(TOS_MsgPtr msg);
TOS_MsgPtr TOS_EVENT(MOVECAR1_SERVO)(TOS_MsgPtr val);
void TOS_EVENT(MOVECAR1_SERVO_EVENT)(int servo, unsigned char control);
//SIGNALS
//USES
char TOS_COMMAND(MOVECAR1_DISPLAY_INT)(short val);
char TOS_COMMAND(MOVECAR1_SEND_MSG)(short addr, char type,TOS_MsgPtr data);
char TOS_COMMAND(MOVECAR1_SETDIR)(char direction);
char TOS_COMMAND(MOVECAR1_SETSPEED)(unsigned char speed);
char TOS_COMMAND(MOVECAR1_SUB_CLOCK_INIT)(unsigned char interval);
char TOS_COMMAND(MOVECAR1_SUB_DISPLAY_INIT)();
char TOS_COMMAND(MOVECAR1_SUB_INIT)();
char TOS_COMMAND(MOVECAR1_TURN)(char turn);
//INTERNAL
#endif //__MOVECAR1___//
