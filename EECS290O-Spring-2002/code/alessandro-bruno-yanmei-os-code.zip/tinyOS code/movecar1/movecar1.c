/*
 * Bruno Sinopoli
 * 
 * 4/29/2002
 * 
 *
 *
 * History:
 * 4/29/2002 - created.
 *
 */

#include "tos.h"
#include "dbg.h"
#include "MOVECAR1.h"
#include "../detect_car_shared/DETECT_CAR_EXTRA.h"

// Speed constants
#define SPEED1 17
#define SPEED2 20
#define OFF 0

// Turn constants (far left=0, far right=40)
#define LEFT 10
#define STRAIGHT 20
#define RIGHT 30
#define EVADE_TIME 5
#define NODE_ID 4  //(4,5) my ID
#define START_TIME 1
#define STOP_TIME 20
#define TURN_TIME 3


// Direction constants
#define FORWARD 1
#define REVERSE 0

typedef struct{
  int src;
  int servo;
  int control;
} servo_msg;

typedef struct{
  unsigned char id;
  unsigned char info;
} avoidance;


// Frame declaration
#define TOS_FRAME_TYPE MOVECAR1_frame
TOS_FRAME_BEGIN(MOVECAR1_frame){
  TOS_Msg message;
  char mode;    // mode: 0 - normal, 1 - manuever
  char action;  //action: 0 - stop, 1 - go straight, 2 - turn left, 3 - turn right
  unsigned char tick;
  unsigned char mtick; //ticks for manouvering
  TOS_Msg msg;
  char sending;
}
TOS_FRAME_END(MOVECAR1_frame);

char TOS_COMMAND(MOVECAR1_INIT)(){
  // Initialize sub-components needed here
  // dbg(DBG_BOOT,("Movecar initialized.\n"));
  VAR(tick) = 0;
  VAR(sending) = 0;
  VAR(mode) = 0;
  VAR(mtick) = 0;
  VAR(action) = 0;
  TOS_CALL_COMMAND(MOVECAR1_DISPLAY_INT)((short) 0);
  return TOS_CALL_COMMAND(MOVECAR1_SUB_INIT)();
}

char TOS_COMMAND(MOVECAR1_START)(){
  // Start clock
  return TOS_CALL_COMMAND(MOVECAR1_SUB_CLOCK_INIT)(tick1ps);
}

void takeaction(){
  switch (VAR(mtick)) {
    //  case 0:  //stop
    //    TOS_COMMAND(DETECT_CAR_DISPLAY_INT)((short) 0);
    //  break;
  case 1:  //turn right
    TOS_CALL_COMMAND(MOVECAR1_SETSPEED)(SPEED2);
    TOS_CALL_COMMAND(MOVECAR1_SETDIR)(FORWARD);
    TOS_CALL_COMMAND(MOVECAR1_TURN)(RIGHT);
    break;
  case 2:  //turn left
    TOS_CALL_COMMAND(MOVECAR1_SETSPEED)(SPEED2);
    TOS_CALL_COMMAND(MOVECAR1_SETDIR)(FORWARD);
    TOS_CALL_COMMAND(MOVECAR1_TURN)(LEFT);
    break;
  case 3:  // go straight
    TOS_CALL_COMMAND(MOVECAR1_SETSPEED)(SPEED1);
    TOS_CALL_COMMAND(MOVECAR1_SETDIR)(FORWARD);
    TOS_CALL_COMMAND(MOVECAR1_TURN)(STRAIGHT);
    break;
  default: //????
    //  TOS_CALL_COMMAND(DETECT_CAR_DISPLAY_INT)((short) 7);
  }
}


void TOS_EVENT(MOVECAR1_CLOCK_EVENT)(){
  VAR(tick)++;
  
  switch (VAR(mode)) {
  case 0:  //normal driving mode
    if (VAR(tick) >= STOP_TIME)
      TOS_CALL_COMMAND(MOVECAR1_SETSPEED)(OFF);
    else {
      TOS_CALL_COMMAND(MOVECAR1_SETSPEED)(SPEED1);
      TOS_CALL_COMMAND(MOVECAR1_SETDIR)(FORWARD);
      TOS_CALL_COMMAND(MOVECAR1_TURN)(STRAIGHT);
    }
    break;
  default: // case 1: LOOK OUT!!
    VAR(mtick)++;
    takeaction();
    if (VAR(mtick) >= TURN_TIME){
      VAR(mtick) = 0;
      VAR(mode) = 0;  //go back to normal time
    }  
  }
}  
 void TOS_EVENT(MOVECAR1_SERVO_EVENT)(int servo, unsigned char control) {
  servo_msg* message = (servo_msg*)VAR(msg).data;
  if (!VAR(sending)) {
    VAR(sending) = 1;
    message->src = TOS_LOCAL_ADDRESS;
    message->servo = servo;
    message->control = control;
    /*    if (TOS_CALL_COMMAND(MOVECAR1_SEND_MSG)(1, AM_MSG(MOVECAR1_SERVO), &VAR(msg)))
      return;
    else
    VAR(sending) = 0; */
  }
  return;
}


char TOS_EVENT(MOVECAR1_MSG_SEND_DONE)(TOS_MsgPtr sentBuffer) {
  VAR(sending) = 0;
  return 1;
}

TOS_MsgPtr TOS_MSG_EVENT(MOVECAR1_SERVO)(TOS_MsgPtr val) {
  avoidance* messagePayload_ptr = (avoidance*) val->data;
  if (messagePayload_ptr->info == 3) { ///AHHHHH! LOOK OUT!
    VAR(mode) = 1;
    TOS_CALL_COMMAND(MOVECAR1_DISPLAY_INT)((short) 7);  //light the LEDS up
  }    
  return val;
}
 





