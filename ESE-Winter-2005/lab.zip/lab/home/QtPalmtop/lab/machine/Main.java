/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.applet.Applet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Toolkit;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class Main extends Applet {
	private static Frame frame = null;

	private static Machine machine = null;

	private static boolean isConsole = false;

	private static boolean isMaster = false;
	private static boolean isSlave = false;

	public Main() {
		setBackground(Color.white);
	}

	public void init() {
		machine = new Machine("Machine", this, frame, isConsole, isMaster, isSlave);

		initPrograms();
	}

	private static void initPrograms() {
		EProgram program1 = new EProgram("2 Tasks", 2000);

		new Task(program1, "Control", new functionality.Control());
		new Task(program1, "Navigation", new functionality.Navigation());

		new Trigger(program1, "Timer");

		new ECode(program1, ECode.SCHEDULE, 0);
		new ECode(program1, ECode.SCHEDULE, 1);
		new ECode(program1, ECode.FUTURE, 0, 4, 2000);
		new ECode(program1, ECode.RETURN);
		new ECode(program1, ECode.SCHEDULE, 1);
		new ECode(program1, ECode.FUTURE, 0, 0, 2000);
		new ECode(program1, ECode.RETURN);

		new SCode(program1, SCode.DISPATCH, 1);
		new SCode(program1, SCode.DISPATCH, 0);
		new SCode(program1, SCode.IDLE, 2000);
		new SCode(program1, SCode.DISPATCH, 1);
		new SCode(program1, SCode.IDLE, 4000);
		new SCode(program1, SCode.FORK, 0);
		new SCode(program1, SCode.RETURN);

		machine.addEProgram(program1);

		EProgram program = new EProgram("2 Tasks, Preemptive", 2000);

		new Task(program, "Control", new functionality.Control());
		new Task(program, "Navigation", new functionality.Navigation());

		new Trigger(program, "Timer");

		new ECode(program, ECode.SCHEDULE, 0);
		new ECode(program, ECode.SCHEDULE, 1);
		new ECode(program, ECode.FUTURE, 0, 4, 2000);
		new ECode(program, ECode.RETURN);
		new ECode(program, ECode.SCHEDULE, 1);
		new ECode(program, ECode.FUTURE, 0, 0, 2000);
		new ECode(program, ECode.RETURN);

		new SCode(program, SCode.DISPATCH, 1);
		new SCode(program, SCode.DISPATCH, 0, 2000);
		new SCode(program, SCode.IDLE, 2000);
		new SCode(program, SCode.DISPATCH, 1);
		new SCode(program, SCode.DISPATCH, 0, 4000);
		new SCode(program, SCode.IDLE, 4000);
		new SCode(program, SCode.FORK, 0);
		new SCode(program, SCode.RETURN);

		machine.addEProgram(program);

		program = new EProgram("1 Task, Sliced", 500);

		new Task(program, "Filter", new functionality.Filter());

		new Trigger(program, "Timer");

		new ECode(program, ECode.SCHEDULE, 0);
		new ECode(program, ECode.FUTURE, 0, 0, 2000);
		new ECode(program, ECode.RETURN);

		new SCode(program, SCode.DISPATCH, 0, 500);
		new SCode(program, SCode.IDLE, 1000);
		new SCode(program, SCode.DISPATCH, 0, 1500);
		new SCode(program, SCode.IDLE, 2000);
		new SCode(program, SCode.FORK, 0);
		new SCode(program, SCode.RETURN);


		machine.addEProgram(program);

		if (!isSlave && frame != null) {
			// Single CPU Tennis

			program = new EProgram("Tennis", 100);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveBall", new functionality.MoveBall());
			new Task(program, "MoveRacketN", new functionality.MoveRacketN());
			new Task(program, "MoveRacketS", new functionality.MoveRacketS());
			new Task(program, "MoveRacketW", new functionality.MoveRacketW());
			new Task(program, "MoveRacketE", new functionality.MoveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.FUTURE, 0, 0, 1000);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 100);
			new SCode(program, SCode.IDLE, 100);
			new SCode(program, SCode.DISPATCH, 1, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 2, 300);
			new SCode(program, SCode.IDLE, 300);
			new SCode(program, SCode.DISPATCH, 3, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 4, 500);
			new SCode(program, SCode.IDLE, 500);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Two CPU Tennis, external receiver, Player 1

			program = new EProgram("2Host ExR Player1", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveBall", new functionality.MoveBall());
			new Task(program, "SendBall", new functionality.SendBall());
			new Task(program, "MoveRacketW", new functionality.MoveRacketW());
			new Task(program, "SendRacketW", new functionality.SendRacketW());
			new Task(program, "MoveRacketE", new functionality.MoveRacketE());
			new Task(program, "SendRacketE", new functionality.SendRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 200);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 2);
			new SCode(program, SCode.DISPATCH, 3, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 4);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Two CPU Tennis, external receiver, Player 2

			program = new EProgram("2Host ExR Player2", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveRacketN", new functionality.MoveRacketN());
			new Task(program, "SendRacketN", new functionality.SendRacketN());
			new Task(program, "MoveRacketS", new functionality.MoveRacketS());
			new Task(program, "SendRacketS", new functionality.SendRacketS());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 2);
			new SCode(program, SCode.DISPATCH, 3, 600);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 4, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Two CPU Tennis, Player 1

			program = new EProgram("2Host Player1", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveBall", new functionality.MoveBall());
			new Task(program, "SendBall", new functionality.SendBall());
			new Task(program, "ReceiveRacketN", new functionality.ReceiveRacketN());
			new Task(program, "ReceiveRacketS", new functionality.ReceiveRacketS());
			new Task(program, "MoveRacketW", new functionality.MoveRacketW());
			new Task(program, "SendRacketW", new functionality.SendRacketW());
			new Task(program, "MoveRacketE", new functionality.MoveRacketE());
			new Task(program, "SendRacketE", new functionality.SendRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.SCHEDULE, 7);
			new ECode(program, ECode.SCHEDULE, 8);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 2, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 3, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 4);
			new SCode(program, SCode.DISPATCH, 5, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 6);
			new SCode(program, SCode.DISPATCH, 7, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 8, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Two CPU Tennis, Player 2

			program = new EProgram("2Host Player2", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "ReceiveBall", new functionality.ReceiveBall());
			new Task(program, "MoveRacketN", new functionality.MoveRacketN());
			new Task(program, "SendRacketN", new functionality.SendRacketN());
			new Task(program, "MoveRacketS", new functionality.MoveRacketS());
			new Task(program, "SendRacketS", new functionality.SendRacketS());
			new Task(program, "ReceiveRacketW", new functionality.ReceiveRacketW());
			new Task(program, "ReceiveRacketE", new functionality.ReceiveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.SCHEDULE, 7);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 1);
			new SCode(program, SCode.DISPATCH, 2, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 3);
			new SCode(program, SCode.DISPATCH, 4, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 5, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 6, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 7, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, external receiver, Player 1

			program = new EProgram("5Host ExR Player1", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveBall", new functionality.MoveBall());
			new Task(program, "SendBall", new functionality.SendBall());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 200);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 2, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, external receiver, Player 2

			program = new EProgram("5Host ExR Player2 N", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveRacketN", new functionality.MoveRacketN());
			new Task(program, "SendRacketN", new functionality.SendRacketN());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 400);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 2, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, external receiver, Player 3

			program = new EProgram("5Host ExR Player3 S", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveRacketS", new functionality.MoveRacketS());
			new Task(program, "SendRacketS", new functionality.SendRacketS());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 600);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 2, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, external receiver, Player 4

			program = new EProgram("5Host ExR Player4 W", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveRacketW", new functionality.MoveRacketW());
			new Task(program, "SendRacketW", new functionality.SendRacketW());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 800);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 2, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, external receiver, Player 5

			program = new EProgram("5Host ExR Player5 E", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveRacketE", new functionality.MoveRacketE());
			new Task(program, "SendRacketE", new functionality.SendRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 2, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, Player 1

			program = new EProgram("5Host Player1", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "MoveBall", new functionality.MoveBall());
			new Task(program, "SendBall", new functionality.SendBall());
			new Task(program, "ReceiveRacketN", new functionality.ReceiveRacketN());
			new Task(program, "ReceiveRacketS", new functionality.ReceiveRacketS());
			new Task(program, "ReceiveRacketW", new functionality.ReceiveRacketW());
			new Task(program, "ReceiveRacketE", new functionality.ReceiveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0);
			new SCode(program, SCode.DISPATCH, 1, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 2, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 3, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 4, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, Player 2

			program = new EProgram("5Host Player2 N", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "ReceiveBall", new functionality.ReceiveBall());
			new Task(program, "MoveRacketN", new functionality.MoveRacketN());
			new Task(program, "SendRacketN", new functionality.SendRacketN());
			new Task(program, "ReceiveRacketS", new functionality.ReceiveRacketS());
			new Task(program, "ReceiveRacketW", new functionality.ReceiveRacketW());
			new Task(program, "ReceiveRacketE", new functionality.ReceiveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 1);
			new SCode(program, SCode.DISPATCH, 2, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 3, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 4, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, Player 3

			program = new EProgram("5Host Player3 S", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "ReceiveBall", new functionality.ReceiveBall());
			new Task(program, "ReceiveRacketN", new functionality.ReceiveRacketN());
			new Task(program, "MoveRacketS", new functionality.MoveRacketS());
			new Task(program, "SendRacketS", new functionality.SendRacketS());
			new Task(program, "ReceiveRacketW", new functionality.ReceiveRacketW());
			new Task(program, "ReceiveRacketE", new functionality.ReceiveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 1, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 2);
			new SCode(program, SCode.DISPATCH, 3, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 4, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, Player 4

			program = new EProgram("5Host Player4 W", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "ReceiveBall", new functionality.ReceiveBall());
			new Task(program, "ReceiveRacketN", new functionality.ReceiveRacketN());
			new Task(program, "ReceiveRacketS", new functionality.ReceiveRacketS());
			new Task(program, "MoveRacketW", new functionality.MoveRacketW());
			new Task(program, "SendRacketW", new functionality.SendRacketW());
			new Task(program, "ReceiveRacketE", new functionality.ReceiveRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 1, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 2, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 3);
			new SCode(program, SCode.DISPATCH, 4, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);

			// Five CPU Tennis, Player 5

			program = new EProgram("5Host Player5 E", 200);

			new Resource(program, "TennisBoard", new functionality.TennisBoard());

			new Trigger(program, "Timer");

			new Task(program, "ReceiveBall", new functionality.ReceiveBall());
			new Task(program, "ReceiveRacketN", new functionality.ReceiveRacketN());
			new Task(program, "ReceiveRacketS", new functionality.ReceiveRacketS());
			new Task(program, "ReceiveRacketW", new functionality.ReceiveRacketW());
			new Task(program, "MoveRacketE", new functionality.MoveRacketE());
			new Task(program, "SendRacketE", new functionality.SendRacketE());
			new Task(program, "RepaintGame", new functionality.RepaintGame());

			new ECode(program, ECode.SCHEDULE, 0);
			new ECode(program, ECode.SCHEDULE, 1);
			new ECode(program, ECode.SCHEDULE, 2);
			new ECode(program, ECode.SCHEDULE, 3);
			new ECode(program, ECode.SCHEDULE, 4);
			new ECode(program, ECode.SCHEDULE, 5);
			new ECode(program, ECode.SCHEDULE, 6);
			new ECode(program, ECode.FUTURE, 0, 0, 1400);
			new ECode(program, ECode.RETURN);

			new SCode(program, SCode.DISPATCH, 0, 200);
			new SCode(program, SCode.IDLE, 200);
			new SCode(program, SCode.DISPATCH, 1, 400);
			new SCode(program, SCode.IDLE, 400);
			new SCode(program, SCode.DISPATCH, 2, 600);
			new SCode(program, SCode.IDLE, 600);
			new SCode(program, SCode.DISPATCH, 3, 800);
			new SCode(program, SCode.IDLE, 800);
			new SCode(program, SCode.DISPATCH, 4);
			new SCode(program, SCode.DISPATCH, 5, 1000);
			new SCode(program, SCode.IDLE, 1000);
			new SCode(program, SCode.DISPATCH, 6, 1400);
			new SCode(program, SCode.IDLE, 1400);
			new SCode(program, SCode.FORK, 0);
			new SCode(program, SCode.RETURN);

			machine.addEProgram(program);
		}

		machine.selectEProgram(program1);
	}

	private static class RedrawListener extends ComponentAdapter {
		public void componentShown(ComponentEvent event) {
			machine.resize();
		}

		public void componentResized(ComponentEvent event) {
			machine.resize();
		}
	}

	private static class ConsoleExitListener extends WindowAdapter {
		public void windowClosing(WindowEvent event) {
			frame.dispose();

			System.exit(0);
		}
	}

	private static class MachineExitListener extends WindowAdapter {
		public void windowOpened(WindowEvent event) {
			machine.resize();
		}

		public void windowActivated(WindowEvent event) {
			machine.resize();
		}

		public void windowDeiconified(WindowEvent event) {
			machine.resize();
		}

		public void windowClosing(WindowEvent event) {
			frame.dispose();

			System.exit(0);
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length == 0) {
			machine = new Machine("Machine", null, null, isConsole, isMaster, isSlave);

			initPrograms();

			machine.go();
		} else if (args[0].equals("slave-no-console")) {
			isSlave = true;
			
			machine = new Machine("Machine", null, null, isConsole, isMaster, isSlave);

			initPrograms();

			machine.connect();
		} else {
			frame = new Frame("Embedded Software Lab 0.2");

			int width = Toolkit.getDefaultToolkit().getScreenSize().width;
			int height = Toolkit.getDefaultToolkit().getScreenSize().height;

			if (width < 600) {
				frame.setLocation(0, 0);
				frame.setSize(width, height);
			} else {
				frame.setLocation((width - 200) / 4, (height - 220) / 4);
				frame.setSize((width + 200) / 2, (height + 220) / 2);
			}

			Main main = new Main();

			frame.add(main, BorderLayout.CENTER);

			if (args[0].equals("slave-with-console")) {
				frame.setBackground(Color.gray);

				frame.addWindowListener(new ConsoleExitListener());

				isSlave = true;
				isConsole = true;

				main.init();
				main.start();

				frame.setVisible(true);

				machine.connect();
			} else {
				frame.setBackground(Color.white);

				if (args[0].equals("master")) {
					isMaster = true;
					isSlave = false;
				} else if (args[0].equals("slave")) {
					isMaster = false;
					isSlave = true;
				}

				frame.addWindowListener(new MachineExitListener());
				frame.addComponentListener(new RedrawListener());

				main.init();
				main.start();

				frame.setVisible(true);
			}
		}
	}

}
