/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.io.Serializable;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class EProgram implements Serializable {
	private String name;
	private int timeStep;
	
	// Resource
	
	private Resource resource = null;
	
	// E Code
	
	private static final int MAX_EPROGRAM = 1000;
	private final ECode[] eProgram = new ECode[MAX_EPROGRAM];

	private int numberOfEInstructions = 0;

	// S Code
	
	private static final int MAX_SPROGRAM = 1000;
	private final SCode[] sProgram = new SCode[MAX_SPROGRAM];

	private int numberOfSInstructions = 0;

	// Triggers
	
	private static final int MAX_TRIGGERS = 1;
	private Trigger[] triggers = new Trigger[MAX_TRIGGERS];

	private int numberOfTriggers = 0;
	
	// Tasks
	
	protected static final int MAX_TASKS = 10;
	private Task[] tasks = new Task[MAX_TASKS];

	private int numberOfTasks = 0;

	// Drivers
	
	protected static final int MAX_DRIVERS = 10;
	private Driver[] drivers = new Driver[MAX_DRIVERS];

	private int numberOfDrivers = 0;

	// Conditions
	
	protected static final int MAX_CONDITIONS = 10;
	private Condition[] conditions = new Condition[MAX_CONDITIONS];

	private int numberOfConditions = 0;

	// E Program
		
	public EProgram(String name, int timeStep) {
		this.name = name;
		
		this.timeStep = timeStep;
	}

	// Resource
	
	public void add(Resource resource) {
		if (isResourceDeclared())
			throw new RuntimeException("Maximum number of resources exceeded!");
		else
			this.resource = resource;
	}

	public Resource getResource() {
		return resource;
	}

	public boolean isResourceDeclared() {
		return resource != null;
	}
	
	// E Code

	public void add(ECode instruction) {
		if (numberOfEInstructions < MAX_EPROGRAM)
			eProgram[numberOfEInstructions++] = instruction;
		else
			throw new RuntimeException("Maximum number of E Code instructions exceeded!");
	}

	public ECode getEInstruction(int address) {
		return eProgram[address];
	}

	public int getNumberOfEInstructions() {
		return numberOfEInstructions;
	}

	public void dumpECode(Console console) {
		console.setSize(numberOfEInstructions);
		
		for (int i = 0; i < numberOfEInstructions; i++)
			console.println("" + eProgram[i]);
	}

	// S Code

	public void add(SCode instruction) {
		if (numberOfSInstructions < MAX_SPROGRAM)
			sProgram[numberOfSInstructions++] = instruction;
		else
			throw new RuntimeException("Maximum number of S Code instructions exceeded!");
	}

	public SCode getSInstruction(int address) {
		return sProgram[address];
	}

	public int getNumberOfSInstructions() {
		return numberOfSInstructions;
	}
	
	public void dumpSCode(Console console) {
		console.setSize(numberOfSInstructions);
		
		for (int i = 0; i < numberOfSInstructions; i++)
			console.println("" + sProgram[i]);
	}

	// Triggers

	public void add(Trigger trigger) {
		if (numberOfTriggers < MAX_TRIGGERS)
			triggers[numberOfTriggers++] = trigger;
		else
			throw new RuntimeException("Maximum number of triggers exceeded!");
	}
	
	public Trigger getTrigger(int index) {
		return triggers[index];
	}

	private boolean isTriggerDeclared(int index) {
		return index < numberOfTriggers;
	}

	// Tasks
	
	public void add(Task task) {
		if (numberOfTasks < MAX_TASKS)
			tasks[numberOfTasks++] = task;
		else
			throw new RuntimeException("Maximum number of tasks exceeded!");
	}
	
	public Task getTask(int index) {
		return tasks[index];
	}

	private boolean isTaskDeclared(int index) {
		return index < numberOfTasks;
	}

	public int getNumberOfTasks() {
		return numberOfTasks;
	}

	// Drivers
	
	public void add(Driver driver) {
		if (numberOfDrivers < MAX_DRIVERS)
			drivers[numberOfDrivers++] = driver;
		else
			throw new RuntimeException("Maximum number of drivers exceeded!");
	}
	
	public Driver getDriver(int index) {
		return drivers[index];
	}

	private boolean isDriverDeclared(int index) {
		return index < numberOfDrivers;
	}

	public int getNumberOfDrivers() {
		return numberOfDrivers;
	}

	// Conditions
	
	public void add(Condition condition) {
		if (numberOfConditions < MAX_CONDITIONS)
			conditions[numberOfConditions++] = condition;
		else
			throw new RuntimeException("Maximum number of conditions exceeded!");
	}
	
	public Condition getCondition(int index) {
		return conditions[index];
	}

	private boolean isConditionDeclared(int index) {
		return index < numberOfConditions;
	}

	public int getNumberOfConditions() {
		return numberOfConditions;
	}

	// E Program

	public int getTimeStep() {
		return timeStep;
	}

	public String toString() {
		return name;
	}
	
}
