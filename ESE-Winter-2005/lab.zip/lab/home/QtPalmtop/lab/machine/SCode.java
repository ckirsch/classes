/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.io.Serializable;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class SCode implements Serializable {
	public static final int NOP = 0;
	public static final int DISPATCH = 1;
	public static final int IDLE = 2;
	public static final int FORK = 3;
	public static final int RETURN = 4;

	private EProgram program = null;

	private int address = 0;

	private int opcode = NOP;
	private int arg1 = -1;
	private int arg2 = -1;
	private int arg3 = -1;

	private String comment = "";

	public int sState = 0;

	public SCode(EProgram program, int opcode) {
		this.program = program;

		this.address = program.getNumberOfSInstructions();
		this.opcode = opcode;

		program.add(this);
	}

	public SCode(EProgram program, int opcode, int arg1) {
		this(program, opcode);

		this.arg1 = arg1;
	}

	public SCode(EProgram program, int opcode, int arg1, int arg2) {
		this(program, opcode, arg1);

		this.arg2 = arg2;
	}

	public SCode(EProgram program, int opcode, int arg1, int arg2, int arg3) {
		this(program, opcode, arg1, arg2);

		this.arg3 = arg3;
	}

	private String optionalArgToString(int arg, String delimiter) {
		return arg >= 0 ? (delimiter + arg) : "";
	}

	public String toString() {
		String string = "" + address + ": ";

		switch (opcode) {
			case NOP :
				string += "nop()";
				break;
			case DISPATCH :
				string += "dispatch(" + program.getTask(arg1) + optionalArgToString(arg2, ",") + ")";
				break;
			case IDLE :
				string += "idle(" + optionalArgToString(arg1, "") + ")";
				break;
			case FORK :
				string += "fork(" + arg1 + ")";
				break;
			case RETURN :
				string += "return()";
				break;
			default :
				throw new RuntimeException(
					"S Machine: unknown opcode " + opcode + " at address " + address);
		}

		return string;
	}

	/**
	 * Returns the arg1.
	 * @return int
	 */
	public int getArg1() {
		return arg1;
	}

	/**
	 * Returns the arg2.
	 * @return int
	 */
	public int getArg2() {
		return arg2;
	}

	/**
	 * Returns the arg3.
	 * @return int
	 */
	public int getArg3() {
		return arg3;
	}

	/**
	 * Returns the comment.
	 * @return String
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Returns the opcode.
	 * @return int
	 */
	public int getOpcode() {
		return opcode;
	}

}
