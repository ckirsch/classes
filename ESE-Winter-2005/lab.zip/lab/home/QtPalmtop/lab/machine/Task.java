/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.io.Serializable;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class Task implements Serializable {
	private EProgram program;

	private String name;
	private int index = -1;

	private TaskInterface code;

	public Task(EProgram program, String name, TaskInterface code) {
		this.program = program;
		this.name = name;

		this.index = program.getNumberOfTasks();

		this.code = code;

/*
		try {
			code =
				(TaskInterface) this
					.getClass()
					.getClassLoader()
					.loadClass("functionality." + name)
					.newInstance();
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(name + " not found!");
		} catch (IllegalAccessException e) {
			throw new RuntimeException(name + " could not be accessed!");
		} catch (InstantiationException e) {
			throw new RuntimeException(name + " could not be instantiated!");
		}
*/

		program.add(this);
	}

	public void execute(Object resource) {
		code.run(resource);
	}

	public String getName() {
		return name;
	}

	public int getIndex() {
		return index;
	}

	public String toString() {
		return getName();
	}

}
