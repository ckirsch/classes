/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.io.Serializable;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class ECode implements Serializable {
	public static final int NOP = 0;
	public static final int FUTURE = 1;
	public static final int CALL = 2;
	public static final int SCHEDULE = 3;
	public static final int IF = 4;
	public static final int JUMP = 5;
	public static final int RETURN = 6;

	private EProgram program = null;

	private int address = 0;

	private int opcode = NOP;
	private int arg1 = -1;
	private int arg2 = -1;
	private int arg3 = -1;

	private int annotation = -1;

	private String comment = "";

	public ECode(EProgram program, int opcode) {
		this.program = program;

		this.address = program.getNumberOfEInstructions();
		this.opcode = opcode;

		program.add(this);
	}

	public ECode(EProgram program, int opcode, String comment) {
		this(program, opcode);

		this.comment = comment;
	}

	public ECode(EProgram program, int opcode, int arg1) {
		this(program, opcode);

		this.arg1 = arg1;
	}

	public ECode(EProgram program, int opcode, int arg1, String comment) {
		this(program, opcode, arg1);

		this.comment = comment;
	}

	public ECode(EProgram program, int opcode, int arg1, int arg2) {
		this(program, opcode, arg1);

		this.arg2 = arg2;
	}

	public ECode(EProgram program, int opcode, int arg1, int arg2, String comment) {
		this(program, opcode, arg1, arg2);

		this.comment = comment;
	}

	public ECode(EProgram program, int opcode, int arg1, int arg2, int arg3) {
		this(program, opcode, arg1, arg2);

		this.arg3 = arg3;
	}

	public ECode(EProgram program, int opcode, int arg1, int arg2, int arg3, String comment) {
		this(program, opcode, arg1, arg2, arg3);

		this.comment = comment;
	}

	public String toString() {
		String string = "" + address + ": ";

		switch (opcode) {
			case NOP :
				string += "nop()";
				break;
			case FUTURE :
				string += "future(" + program.getTrigger(arg1) + "," + arg2 + "," + arg3 + ")";
				break;
			case CALL :
				string += "call(" + program.getDriver(arg1) + ")";
				break;
			case SCHEDULE :
				string += "schedule(" + program.getTask(arg1) + ")";
				break;
			case IF :
				string += "if(" + program.getCondition(arg1) + "," + arg2 + "," + arg3 + ")";
				break;
			case JUMP :
				string += "jump(" + arg1 + ")";
				break;
			case RETURN :
				string += "return(" + (annotation >= 0 ? "[" + annotation + "]" : "") + ")";
				break;
			default :
				throw new RuntimeException(
					"E Machine: unknown opcode " + opcode + " at address " + address);
		}

		return string;
	}

	/**
	 * Returns the arg1.
	 * @return int
	 */
	public int getArg1() {
		return arg1;
	}

	/**
	 * Returns the arg2.
	 * @return int
	 */
	public int getArg2() {
		return arg2;
	}

	/**
	 * Returns the arg3.
	 * @return int
	 */
	public int getArg3() {
		return arg3;
	}

	/**
	 * Returns the comment.
	 * @return String
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Returns the opcode.
	 * @return int
	 */
	public int getOpcode() {
		return opcode;
	}

	/**
	 * Returns the annotation.
	 * @return int
	 */
	public int getAnnotation() {
		return annotation;
	}

	/**
	 * Sets the annotation.
	 * @param annotation The annotation to set
	 */
	public void setAnnotation(int annotation) {
		this.annotation = annotation;
	}

}
