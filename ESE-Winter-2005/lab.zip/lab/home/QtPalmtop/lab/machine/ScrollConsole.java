/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.ScrollPane;
import java.awt.TextField;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class ScrollConsole extends Console {
	private ScrollPane codeOut = new ScrollPane();
	private GridLayout codeLayout = new GridLayout(1, 1);
	private Panel codePanel = new Panel(codeLayout);

	private int firstBinding = -1;

	public ScrollConsole() {
		codeOut.add(codePanel);
	}

	public synchronized void print(String string) {
		TextField textField = new TextField(string, 30);

		textField.setEditable(false);

		codePanel.add(textField);
	}

	public synchronized void println(String string) {
		print(string);
	}

	public Component getConsole() {
		return codeOut;
	}

	private int computePosition(int index, int fieldHeight, int paneHeight) {
		return index * fieldHeight - (paneHeight - fieldHeight) / 2;
	}

	private void setScrollPosition(int index) {
		codeOut.setScrollPosition(
			0,
			computePosition(
				index,
				codePanel.getComponent(index).getSize().height,
				codeOut.getViewportSize().height));
	}

	public synchronized void red(int index) {
		codePanel.getComponent(index).setForeground(Color.red);

		setScrollPosition(index);
	}

	public synchronized void resetRed(int index) {
		codePanel.getComponent(index).setForeground(Color.black);
	}

	public synchronized void blue(int index) {
		codePanel.getComponent(index).setForeground(Color.blue);

		// FIXME: only shows single trigger queue programs correctly
		if (firstBinding < 0)
			firstBinding = index;
	}

	public synchronized void resetBlue() {
		firstBinding = -1;
	}

	public synchronized void resetBlue(int index) {
		codePanel.getComponent(index).setForeground(Color.black);

		resetBlue();
	}

	public synchronized void setBluePosition() {
		if (firstBinding >= 0)
			setScrollPosition(firstBinding);
	}

	public synchronized void setSize(int size) {
		codeLayout.setRows(size);
	}

	public synchronized void reset() {
		codePanel.removeAll();
	}

}
