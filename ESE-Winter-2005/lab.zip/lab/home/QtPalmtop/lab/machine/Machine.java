/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package machine;

import java.applet.Applet;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.ScrollPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import java.util.ArrayList;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class Machine extends Thread {
	private static final int TIMER_PRIORITY = MAX_PRIORITY;
	private static final int MACHINE_PRIORITY = TIMER_PRIORITY - 1;
	private static final int TASK_PRIORITY = MACHINE_PRIORITY - 1;
	private static final int MASTER_PRIORITY = TASK_PRIORITY - 1;
	private static final int IP_PRIORITY = MASTER_PRIORITY;
	private static final int SLAVE_PRIORITY = MASTER_PRIORITY;

	// Machine

	private boolean waitingMachine = false;

	private boolean softwareEvent;
	private boolean environmentEvent;

	private boolean tracingMachine;
	private boolean stepOver;

	// Timer

	private Timer timer;

	private int time;
	private int timeStep;

	private final int TIME_OVERFLOW = 60000;

	// E Program

	private final ArrayList ePrograms = new ArrayList();

	private EProgram eProgram;

	private Object resource;

	// E Machine

	private static final int MAX_TRIGGER_BINDINGS = 10;

	private final int[] bindingTrigger = new int[MAX_TRIGGER_BINDINGS];
	private final int[] bindingAddress = new int[MAX_TRIGGER_BINDINGS];
	private final int[] bindingDelta = new int[MAX_TRIGGER_BINDINGS];
	private final int[] bindingState = new int[MAX_TRIGGER_BINDINGS];

	private int numberOfBindings;

	private int timeSafetyMonitor;

	// S Machine

	private static final int MAX_THREADS = 1;

	private final TaskThread[] threadTaskThread = new TaskThread[MAX_THREADS];

	private final int[] threadTrigger = new int[MAX_THREADS];
	private final int[] threadAddress = new int[MAX_THREADS];
	private final int[] threadDelta = new int[MAX_THREADS];
	private final int[] threadState = new int[MAX_THREADS];

	private static final int ENV_TRIGGER = 0;
	private static final int SOFT_TRIGGER = 1;

	private int numberOfThreads;

	private int runningThread;

	// Task Threads

	private TaskThread[] taskThreads = new TaskThread[EProgram.MAX_TASKS];

	private boolean suspendNotAvailable = false;

	// Consoles

	private boolean log = true;

	private Console console = null;
	private Console eConsole = null;
	private Console sConsole = null;

	// Protocol

	private boolean isMaster = false;
	private boolean isSlave = false;

	private final int ECODE = 0;
	private final int DISCONNECT = 1;
	private final int GO = 2;
	private final int TICK = 3;

	private final byte IP = 0;
	private final byte GETIP = 1;

	// Master

	private Master master = null;

	// IP

	private IPSender ipSender = null;

	// Slave

	private Slave slave = null;

	private boolean isConnected = false;

	// GUI

	private MachineGUI machineGUI = null;

	public Machine(
		String name,
		Applet applet,
		Frame frame,
		boolean isConsole,
		boolean isMaster,
		boolean isSlave) {
		super(name);

		setPriority(MACHINE_PRIORITY);

		this.isMaster = isMaster;
		this.isSlave = isSlave;

		if (applet != null) {
			console = new WindowConsole();

			if (isConsole) {
				eConsole = console;
				sConsole = console;

				Panel consolePanel = new Panel(new BorderLayout());
				consolePanel.add(console.getConsole(), BorderLayout.CENTER);

				applet.add(consolePanel);
			} else {
				eConsole = new ScrollConsole();
				sConsole = new ScrollConsole();

				machineGUI = new MachineGUI(applet, frame);
			}
		} else {
			console = new SystemConsole(System.out);

			eConsole = console;
			sConsole = console;
		}

		if (isMaster) {
			master = new Master();

			ipSender = new IPSender();
		}

		resetMachine();

		start();

		timer = new Timer("Timer of " + name);

		timer.start();
	}

	private void resetMachine() {
		// Machine

		softwareEvent = false;
		environmentEvent = false;

		tracingMachine = false;
		stepOver = false;

		// E Console

		eConsole.resetBlue();

		// S Console

		sConsole.resetBlue();

		// Timer

		timeStep = 1000;
		time = -timeStep;

		// E Program

		if (eProgram != null && eProgram.isResourceDeclared())
			eProgram.getResource().destruct(resource);

		eProgram = null;

		resource = null;

		// E Machine

		numberOfBindings = 0;

		timeSafetyMonitor = 0;

		// S Machine

		numberOfThreads = 0;

		runningThread = -1;

		// Task Threads

		for (int taskIndex = 0; taskIndex < EProgram.MAX_TASKS; taskIndex++)
			if (taskThreads[taskIndex] != null) {
				taskThreads[taskIndex].resetTaskThread();

				taskThreads[taskIndex] = null;
			}

		// GUI

		if (machineGUI != null)
			machineGUI.resetMachineGUI();
	}

	public void run() {
		synchronized (this) {
			while (true) {
				reset();

				waiting();

				preemption();

				reaction();

				scheduling();
			}
		}
	}

	private void reset() {
		environmentEvent = false;
		softwareEvent = false;
	}

	private void waiting() {
		waitingMachine = true;

		if (tracingMachine && machineGUI != null) {
			tracingMachine = false;
			stepOver = false;

			if (!isSlave || !isConnected) {
				machineGUI.goButton.setEnabled(true);
				machineGUI.tickButton.setEnabled(true);
				machineGUI.programMenu.setEnabled(true);
				machineGUI.logButton.setEnabled(true);
			}

			if (isMaster && machineGUI.slaveMenu.getItemCount() > 0) {
				machineGUI.sendButton.setEnabled(true);
				machineGUI.disconnectButton.setEnabled(true);
			}

			if (isSlave && !isConnected)
				machineGUI.connectButton.setEnabled(true);
		}

		try {
			wait();
		} catch (InterruptedException e) {
			throw new RuntimeException("Waiting " + this +" interrupted!");
		}

		if (tracingMachine && machineGUI != null) {
			machineGUI.logButton.setEnabled(false);
			machineGUI.logButton.setLabel("NoLogging");

			log = true;
		}

		//logln(Integer.toBinaryString(timeSafetyMonitor));

		waitingMachine = false;
	}

	private void preemption() {
		if (log && machineGUI != null)
			machineGUI.trafficHistory.envSoftInstants();

		if (softwareEvent) {
			if (runningThread >= 0) {
				TaskThread runningTaskThread = threadTaskThread[runningThread];

				//int threadIndex = runningTaskThread.getThreadIndex();
				//softUpdateAddress(threadIndex);
				//completedTaskThread = runningTaskThread;

				runningTaskThread.disable();

				if (machineGUI != null) {
					machineGUI.taskGUIs[runningTaskThread.getIndex()].completed = false;

					machineGUI.taskGUIs[runningTaskThread.getIndex()].redrawTaskGUI();
				}

				threadTaskThread[runningThread] = null;
				threadTrigger[runningThread] = SOFT_TRIGGER;
			} else
				throw new RuntimeException(this +": inconsistent software event!");
		} else if (environmentEvent) {
			//envUpdateAddresses();

			if (runningThread >= 0) {
				TaskThread runningTaskThread = threadTaskThread[runningThread];

				//preemptedTaskThread = runningTaskThread;

				runningTaskThread.preempt();

				if (machineGUI != null) {
					machineGUI.taskGUIs[runningTaskThread.getIndex()].completeButton.setEnabled(false);

					machineGUI.taskGUIs[runningTaskThread.getIndex()].redrawTaskGUI();
				}
			}
		} else
			throw new RuntimeException(this +": unknown event!");

		runningThread = -1;

		if (log && machineGUI != null)
			machineGUI.trafficHistory.redrawTrafficHistory();
	}

	private void reaction() {
		while (true) {
			int currentTriggerBinding = 0;

			int pc = -1;

			for (; currentTriggerBinding < numberOfBindings; currentTriggerBinding++) {
				if ((eProgram.getTrigger(bindingTrigger[currentTriggerBinding]))
					.isEnabled(
						time,
						bindingDelta[currentTriggerBinding],
						bindingState[currentTriggerBinding],
						TIME_OVERFLOW)) {
					pc = bindingAddress[currentTriggerBinding];

					break;
				}
			}

			if (pc < 0) {
				logln("");

				if (log)
					eConsole.setBluePosition();

				stepOver = false;

				if (numberOfBindings == 0 && machineGUI != null)
					machineGUI.stopMachine();

				return;
			}

			for (int nextTriggerBinding = currentTriggerBinding + 1;
				nextTriggerBinding < numberOfBindings;
				nextTriggerBinding++) {
				bindingTrigger[nextTriggerBinding - 1] = bindingTrigger[nextTriggerBinding];
				bindingAddress[nextTriggerBinding - 1] = bindingAddress[nextTriggerBinding];
				bindingDelta[nextTriggerBinding - 1] = bindingDelta[nextTriggerBinding];
				bindingState[nextTriggerBinding - 1] = bindingState[nextTriggerBinding];
			}

			numberOfBindings--;

			eConsole.resetBlue(pc);

			while (pc >= 0) {
				ECode fetchedEInstruction = eProgram.getEInstruction(pc);

				int fetchedOpCode = fetchedEInstruction.getOpcode();
				int fetchedArg1 = fetchedEInstruction.getArg1();
				int fetchedArg2 = fetchedEInstruction.getArg2();
				int fetchedArg3 = fetchedEInstruction.getArg3();

				logln("E: " + time + "ms: " + fetchedEInstruction);

				int savePC = pc;

				if (log)
					eConsole.red(savePC);

				if (tracingMachine && !stepOver && machineGUI != null) {
					machineGUI.eStepButton.setEnabled(true);
					machineGUI.eStepOverButton.setEnabled(true);

					try {
						wait();
					} catch (InterruptedException e) {
						throw new RuntimeException("Tracing " + this +" interrupted!");
					}
				}

				switch (fetchedOpCode) {
					case ECode.CALL :
						eProgram.getDriver(fetchedArg1).call(resource);

						pc++;

						break;
					case ECode.SCHEDULE :
						if ((timeSafetyMonitor & (1 << fetchedArg1)) == 0) {
							taskThreads[fetchedArg1].schedule();

							timeSafetyMonitor |= 1 << fetchedArg1;
						} else {
							if (log && machineGUI != null) {
								machineGUI.trafficHistory.setTimeSafetyViolation(fetchedArg1);

								machineGUI.trafficHistory.redrawTrafficHistory();
							}

							logln("E: time safety violation of task " + eProgram.getTask(fetchedArg1) + ".");
						}

						if (machineGUI != null)
							machineGUI.taskGUIs[fetchedArg1].redrawTaskGUI();

						pc++;

						break;
					case ECode.IF :
						if (eProgram.getCondition(fetchedArg1).evaluate(resource))
							pc = fetchedArg2;
						else
							pc = fetchedArg3;

						break;
					case ECode.JUMP :
						pc = fetchedArg1;

						break;
					case ECode.FUTURE :
						if (numberOfBindings < MAX_TRIGGER_BINDINGS) {
							bindingTrigger[numberOfBindings] = fetchedArg1;
							bindingAddress[numberOfBindings] = fetchedArg2;
							bindingDelta[numberOfBindings] = fetchedArg3;
							bindingState[numberOfBindings] = time;

							numberOfBindings++;

							if (log)
								eConsole.blue(fetchedArg2);

							pc++;
						} else
							throw new RuntimeException(this +": trigger queue overflow!");

						break;
					case ECode.RETURN :
						pc = -1;

						//int fetchedEAnnotation = fetchedEInstruction.getAnnotation();

						//if (fetchedEAnnotation >= 0) {
						//sConsole.resetRed(scheduleAddress[0]);

						//scheduleAddress[0] = fetchedEAnnotation;
						//scheduleTime[0] = time;

						//preemptionAddress[0] = fetchedEAnnotation;
						//preemptionTime[0] = -1;
						//}

						break;
					case ECode.NOP :
						pc++;

						break;
					default :
						throw new RuntimeException(
							this +": unknown opcode " + fetchedOpCode + " at address " + pc);

				}

				logln("E: pc: " + pc);

				eConsole.resetRed(savePC);
			}
		}
	}

	private void scheduling() {
		while (true) {
			int currentThread = 0;

			int pc = -1;
			int forkState = -1;

			for (; currentThread < numberOfThreads; currentThread++) {
				if (isThreadEnabled(currentThread)) {
					pc = threadAddress[currentThread];

					forkState = threadState[currentThread];

					break;
				}

				if (threadTaskThread[currentThread] != null)
					runningThread = currentThread;
			}

			if (pc < 0) {
				logln("");

				if (log)
					sConsole.setBluePosition();

				stepOver = false;

				if (runningThread >= 0) {
					TaskThread runningTaskThread = threadTaskThread[runningThread];

					runningTaskThread.dispatch(0, tracingMachine);

					if (machineGUI != null) {
						if (machineGUI.taskGUIs[runningTaskThread.getIndex()].completed)
							machineGUI.taskGUIs[runningTaskThread.getIndex()].completeButton.setEnabled(true);

						machineGUI.taskGUIs[runningTaskThread.getIndex()].redrawTaskGUI();
					}
				}

				return;
			}

			for (int nextThread = currentThread + 1; nextThread < numberOfThreads; nextThread++) {
				threadTaskThread[nextThread - 1] = threadTaskThread[nextThread];

				threadTrigger[nextThread - 1] = threadTrigger[nextThread];
				threadAddress[nextThread - 1] = threadAddress[nextThread];
				threadDelta[nextThread - 1] = threadDelta[nextThread];
				threadState[nextThread - 1] = threadState[nextThread];
			}

			numberOfThreads--;

			sConsole.resetBlue(pc);

			while (pc >= 0) {
				SCode fetchedSInstruction = eProgram.getSInstruction(pc);

				int fetchedOpCode = fetchedSInstruction.getOpcode();
				int fetchedArg1 = fetchedSInstruction.getArg1();

				logln("S: " + time + "ms: " + fetchedSInstruction);

				int savePC = pc;

				if (log)
					sConsole.red(savePC);

				if (tracingMachine && !stepOver) {
					machineGUI.sStepButton.setEnabled(true);
					machineGUI.sStepOverButton.setEnabled(true);

					try {
						wait();
					} catch (InterruptedException e) {
						throw new RuntimeException("Tracing " + this +" interrupted!");
					}
				}

				switch (fetchedOpCode) {
					case SCode.DISPATCH :
						if (taskThreads[fetchedArg1].isWaiting()) {
							pc++;

							break;
						} else
							runningThread = numberOfThreads;

						int fetchedArg2 = fetchedSInstruction.getArg2();

						createThread(
							fetchedArg1,
							fetchedArg2 < 0 ? SOFT_TRIGGER : ENV_TRIGGER,
							pc + 1,
							fetchedArg2,
							forkState);

						pc = -1;

						break;
					case SCode.IDLE :
						createThread(-1, ENV_TRIGGER, pc + 1, fetchedArg1, forkState);

						pc = -1;

						break;
					case SCode.FORK :
						createThread(-1, ENV_TRIGGER, fetchedArg1, 0, time);

						pc++;

						break;
					case SCode.RETURN :
						pc = -1;

						break;
					case SCode.NOP :
						pc++;

						break;
					default :
						throw new RuntimeException(
							this +": unknown opcode " + fetchedOpCode + " at address " + pc);
				}

				logln("S: pc: " + pc);

				if (log)
					sConsole.resetRed(savePC);
			}
		}
	}

	private synchronized void envTrigger(boolean tracing) {
		tracingMachine = tracing;

		environmentEvent = true;

		time = (time + timeStep) % TIME_OVERFLOW;

		if (time == 0)
			console.reset();

		if (isMaster)
			master.syncUDPSlaves(tracing);

		notifyAll();
	}

	private synchronized void softTrigger(boolean tracingTask) {
		tracingMachine = tracingTask;

		if (tracingMachine && machineGUI != null) {
			machineGUI.goButton.setEnabled(false);
			machineGUI.tickButton.setEnabled(false);
			machineGUI.programMenu.setEnabled(false);
			machineGUI.logButton.setEnabled(false);

			if (isMaster) {
				machineGUI.sendButton.setEnabled(false);
				machineGUI.disconnectButton.setEnabled(false);
			}

			if (isSlave)
				machineGUI.connectButton.setEnabled(false);
		}

		softwareEvent = true;

		notifyAll();
	}

	private synchronized void step() {
		notifyAll();
	}

	private synchronized void stepOver() {
		stepOver = true;

		notifyAll();
	}

	private void createThread(int taskIndex, int trigger, int address, int delta, int state) {
		if (numberOfThreads < MAX_THREADS) {
			if (taskIndex < 0)
				threadTaskThread[numberOfThreads] = null;
			else
				threadTaskThread[numberOfThreads] = taskThreads[taskIndex];

			threadTrigger[numberOfThreads] = trigger;
			threadAddress[numberOfThreads] = address;
			threadDelta[numberOfThreads] = delta;
			threadState[numberOfThreads] = state;

			numberOfThreads++;

			if (log)
				sConsole.blue(address);
		} else
			throw new RuntimeException(this +": thread overflow!");
	}

	private boolean isThreadEnabled(int threadIndex) {
		if (threadTrigger[threadIndex] == SOFT_TRIGGER)
			return threadTaskThread[threadIndex] == null;
		else if (threadTrigger[threadIndex] == ENV_TRIGGER) {
			if (threadDelta[threadIndex] < 0)
				return false;
			else if (threadState[threadIndex] > time)
				return threadState[threadIndex] + threadDelta[threadIndex] <= time + TIME_OVERFLOW;
			else
				return threadState[threadIndex] + threadDelta[threadIndex] <= time;
		} else
			throw new RuntimeException(this +": unknown trigger type!");
	}

	/*
	private boolean isPreemptionTime(int scheduleTime, int preemptionTime) {
		if (preemptionTime < 0)
			return false;
		else if (scheduleTime > time)
			return scheduleTime + preemptionTime <= time + TIME_OVERFLOW;
		else
			return scheduleTime + preemptionTime <= time;
	}
	
		private void updateAddresses(int threadIndex, int nextScheduleAddress) {
			if (preemptionTime[threadIndex] >= 0) {
				if (preemptionTime[threadIndex] == time) {
					preemptionTime[threadIndex] = -1;
	
					sConsole.resetRed(scheduleAddress[threadIndex]);
	
					scheduleAddress[threadIndex] = nextScheduleAddress;
				}
			} else {
				sConsole.resetRed(scheduleAddress[threadIndex]);
	
				scheduleAddress[threadIndex] = nextScheduleAddress;
			}
		}
	
		private void softUpdateAddress(int threadIndex) {
			updateAddresses(threadIndex, scheduleAddress[threadIndex] + 1);
		}
	
		private void envUpdateAddresses() {
			for (int threadIndex = 0; threadIndex < MAX_THREADS; threadIndex++)
				updateAddresses(threadIndex, preemptionAddress[threadIndex]);
		}
	
		private int computePreemptionAddress(int address, int defaultAddress) {
			return address >= 0 ? address : defaultAddress;
		}
	
		private int computePreemptionTime(int defaultTime, int threadIndex) {
			return preemptionTime[threadIndex] >= 0
				? preemptionTime[threadIndex]
				: (defaultTime >= 0 ? (defaultTime + scheduleTime[threadIndex]) % TIME_OVERFLOW : -1);
		}
	*/

	private void log(String string) {
		if (log)
			console.print(string);
	}

	private void logln(String string) {
		if (log)
			console.println(string);
	}

	public void selectEProgram(EProgram eProgram) {
		this.eProgram = eProgram;

		if (eProgram.isResourceDeclared())
			resource = eProgram.getResource().construct();

		for (int taskIndex = 0; taskIndex < eProgram.getNumberOfTasks(); taskIndex++) {
			Task task = eProgram.getTask(taskIndex);

			addTaskThread(task, taskIndex);
		}

		eProgram.dumpECode(eConsole);
		eConsole.println();

		eProgram.dumpSCode(sConsole);
		sConsole.println();

		if (machineGUI != null) {
			eConsole.blue(0);
			eConsole.setBluePosition();

			sConsole.blue(0);
			sConsole.setBluePosition();

			resize();
		}

		timeStep = eProgram.getTimeStep();
		time = -timeStep;

		bindingTrigger[0] = 0;
		bindingAddress[0] = 0;
		bindingDelta[0] = timeStep;
		bindingState[0] = time;

		numberOfBindings++;

		createThread(-1, ENV_TRIGGER, 0, 0, 0);

		console.println(eProgram + " loaded.");
	}

	private void addTaskThread(Task task, int taskIndex) {
		taskThreads[taskIndex] = new TaskThread(task);

		taskThreads[taskIndex].start();

		if (machineGUI != null)
			machineGUI.addTaskGUI(taskThreads[taskIndex], taskIndex);
	}

	public void addEProgram(EProgram eProgram) {
		ePrograms.add(eProgram);

		if (machineGUI != null)
			machineGUI.programMenu.addItem("" + eProgram);
	}

	// Machine

	public void go() {
		timer.go();
	}

	public void connect() {
		slave = new Slave();

		if (!isConnected)
			slave = null;
	}

	// Timer

	private class Timer extends Thread {
		private boolean waitingTimer = false;

		private boolean tracingTimer = true;

		private long sleep = 0;
		private long slept = 0;

		public Timer(String name) {
			setName(name);

			setPriority(TIMER_PRIORITY);
		}

		public void run() {
			synchronized (this) {
				while (true) {
					if (sleep > 0)
						logln(getName() + " sleeps for: " + sleep);

					waiting(sleep);

					slept = System.currentTimeMillis();

					envTrigger(false);

					slept = System.currentTimeMillis() - slept;

					sleep = timeStep;

					if (slept < sleep)
						sleep = sleep - slept;
				}
			}
		}

		private void waiting(long sleep) {
			waitingTimer = true;

			while (true) {
				try {
					wait(sleep);
				} catch (InterruptedException e) {
					throw new RuntimeException("Waiting " + this +" interrupted!");
				}

				if (tracingTimer)
					sleep = 0;
				else
					break;
			}

			waitingTimer = false;
		}

		public synchronized void go() {
			if (tracingTimer) {
				tracingTimer = false;

				notifyAll();
			} else
				throw new RuntimeException("Non-tracing " + this +" go!");
		}

		public synchronized void trace() {
			if (tracingTimer)
				throw new RuntimeException("Tracing " + this +" traced again!");
			else
				tracingTimer = true;
		}

		public synchronized void tick() {
			if (tracingTimer)
				envTrigger(true);
			else
				throw new RuntimeException("Non-tracing " + this +" ticked!");
		}

	}

	// Tasks

	private class TaskThread extends Thread {
		private Task task;

		private String name;

		private boolean waitingTaskThread = false;
		private boolean goTaskThread = true;

		private int threadIndex = -1;

		private boolean dispatched = false;
		private boolean preempted = false;
		private boolean scheduled = false;

		private boolean tracingTask = false;

		public TaskThread(Task task) {
			super(task.getName());

			this.task = task;

			name = task.getName();

			if (name.length() > 1)
				name = name.substring(0, 1) + name.substring(name.length() - 1, name.length());

			this.setPriority(TASK_PRIORITY);
		}

		public void run() {
			waiting();

			while (goTaskThread) {
				execute();

				complete();

				waiting();
			}

			console.println(this +" exits.");
		}

		private synchronized void waiting() {
			waitingTaskThread = true;

			tracingTask = false;

			try {
				wait();
			} catch (InterruptedException e) {
				throw new RuntimeException("Waiting " + this +" interrupted!");
			}

			waitingTaskThread = false;
		}

		private void execute() {
			task.execute(resource);
		}

		private void complete() {
			if (tracingTask) {
				if (machineGUI != null) {
					machineGUI.taskGUIs[getIndex()].completed = true;

					machineGUI.taskGUIs[getIndex()].completeButton.setEnabled(true);
				}
			} else
				Machine.this.softTrigger(false);
		}

		private void resetTaskThread() {
			while (!waitingTaskThread)
				yield();

			synchronized (this) {
				goTaskThread = false;

				notifyAll();
			}
		}

		private void disable() {
			if (preempted)
				throw new RuntimeException("Preempted " + this +" completed by " + Machine.this +"!");
			else if (!dispatched)
				throw new RuntimeException("Undispatched " + this +" completed by " + Machine.this +"!");
			else if (!scheduled)
				throw new RuntimeException("Unscheduled " + this +" completed by " + Machine.this +"!");
			else {
				while (!waitingTaskThread)
					yield();

				dispatched = false;
				scheduled = false;

				threadIndex = -1;

				timeSafetyMonitor &= ~(1 << getIndex());

				logln(this +" completed.");
			}
		}

		private void preempt() {
			if (preempted)
				throw new RuntimeException("Preempted " + this +" preempted by " + Machine.this +" again!");
			else {
				dispatched = false;
				preempted = true;

				if (suspendNotAvailable)
					logln("Suspending " + this +" not possible, suspend not available!");
				else
					try {
						suspend();

						logln(this +" preempted by " + Machine.this +".");
					} catch (NoSuchMethodError e) {
						logln("Cannot suspend " + this +", suspend not available!");

						suspendNotAvailable = true;
					}
			}
		}

		private void schedule() {
			if (preempted || dispatched || scheduled)
				throw new RuntimeException(
					"Preempted, dispatched, or scheduled "
						+ this
						+ " scheduled by "
						+ Machine.this
						+ " again!");
			else
				scheduled = true;
		}

		private void dispatch(int threadIndex, boolean tracingMachine) {
			if (preempted) {
				dispatched = true;
				preempted = false;

				if (suspendNotAvailable)
					logln("Resuming " + this +" not necessary, suspend not available!");
				else
					try {
						resume();

						logln(this +" resumed by " + Machine.this +".");
					} catch (NoSuchMethodError e) {
						logln("Cannot resume " + this +", resume not available!");
					}
			} else if (dispatched)
				throw new RuntimeException(
					"Non-preempted but dispatched " + this +" dispatched by " + Machine.this +" again!");
			else if (scheduled) {
				dispatched = true;

				this.threadIndex = threadIndex;

				synchronized (this) {
					tracingTask = tracingMachine;

					notifyAll();
				}

				logln(this +" started.");
			}
		}

		private boolean isDisabled() {
			return !scheduled;
		}

		private boolean isScheduled() {
			return scheduled && !dispatched;
		}

		private boolean isRunning() {
			return scheduled && dispatched;
		}

		private boolean isWaiting() {
			return !preempted && !dispatched && !scheduled;
		}

		private int getIndex() {
			return task.getIndex();
		}

		private int getThreadIndex() {
			return threadIndex;
		}

		public String toString() {
			return getName();
		}

		public String getShortName() {
			return name;
		}

	}

	// Master

	private class Master extends Thread {
		public static final int MASTER_PORT = 49152;

		private final ArrayList slaveSockets = new ArrayList();
		private final ArrayList slaveReceivers = new ArrayList();

		private MulticastSocket sendSocket;

		private InetAddress group;

		private DatagramPacket sendPacket;

		private byte[] sendBuffer = new byte[TimerSlave.BUFFER_SIZE];

		public Master() {
			super("Master");

			this.setPriority(MASTER_PRIORITY);

			try {
				sendSocket = new MulticastSocket();
			} catch (IOException e) {
				throw new RuntimeException("Cannot open master sync socket!");
			}

			try {
				group = InetAddress.getByName(TimerSlave.SYNC_GROUP);
			} catch (UnknownHostException e) {
				throw new RuntimeException("Unknown multicast group for timer slave!");
			}

			sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, group, TimerSlave.SYNC_PORT);

			start();
		}

		private void acceptSlaves() throws IOException {
			ServerSocket masterSocket = new ServerSocket(MASTER_PORT);

			try {
				while (true) {
					Socket slaveSocket = masterSocket.accept();

					OutputStream output = new ObjectOutputStream(slaveSocket.getOutputStream());

					synchronized (this) {
						slaveSockets.add(slaveSocket);
						slaveReceivers.add(output);

						if (machineGUI != null)
							machineGUI.slaveMenu.addItem("" + slaveSocket.getInetAddress().getHostAddress());
					}

					if (machineGUI != null) {
						machineGUI.sendButton.setEnabled(true);
						machineGUI.disconnectButton.setEnabled(true);
					}

					console.println("Connected to " + slaveSocket + ".");
				}
			} finally {
				for (int slaveIndex = 0; slaveIndex < slaveSockets.size(); slaveIndex++)
					disconnectSlave(slaveIndex);

				masterSocket.close();

				sendSocket.close();
			}
		}

		public void run() {
			try {
				acceptSlaves();
			} catch (IOException e) {
				throw new RuntimeException(
					this +" has IO problem on port: " + MASTER_PORT + " (" + e + ")");
			}
		}

		private void sendECode(int slaveIndex) {
			synchronized (this) {
				ObjectOutputStream output = (ObjectOutputStream) slaveReceivers.get(slaveIndex);

				try {
					output.write(ECODE);

					output.writeObject(eProgram);

					output.flush();
				} catch (IOException e) {
					console.println(this +" could not send E code on port: " + MASTER_PORT);
				}
			}

			console.println("Send " + eProgram.getNumberOfEInstructions() + " E code instructions.");
		}

		private void disconnectSlave(int slaveIndex) {
			String stringSocket = null;

			synchronized (this) {
				Socket slaveSocket = (Socket) slaveSockets.get(slaveIndex);
				OutputStream output = (OutputStream) slaveReceivers.get(slaveIndex);

				stringSocket = "" + slaveSocket;

				try {
					output.write(DISCONNECT);

					output.write(log ? 1 : 0);

					output.flush();

					slaveSocket.close();
				} catch (IOException e) {
					console.println(this +" could not close socket on port: " + MASTER_PORT);
				}

				slaveSockets.remove(slaveIndex);
				slaveReceivers.remove(slaveIndex);

				if (machineGUI != null) {
					machineGUI.slaveMenu.remove(slaveIndex);

					if (machineGUI.slaveMenu.getItemCount() == 0) {
						machineGUI.sendButton.setEnabled(false);
						machineGUI.disconnectButton.setEnabled(false);
					}
				}
			}

			console.println("Disconnected from " + stringSocket + ".");
		}

		private void syncUDPSlaves(boolean tracingSlaves) {
			sendBuffer[0] = (byte) (log ? 1 : 0);

			try {
				sendSocket.send(sendPacket, TimerSlave.SYNC_HOPS);

				//receiveSocket.receive(receivePacket);
			} catch (IOException e) {
				throw new RuntimeException("Cannot send sync packet!");
			}
		}

		private void syncTCPSlaves(boolean tracingSlaves) {
			for (int slaveIndex = 0; slaveIndex < slaveReceivers.size(); slaveIndex++) {
				OutputStream output = (OutputStream) slaveReceivers.get(slaveIndex);

				try {
					if (tracingSlaves)
						output.write(TICK);
					else {
						output.write(GO);

						output.write(log ? 1 : 0);
					}

					output.flush();
				} catch (IOException e) {
					throw new RuntimeException(this +" could not tick on port: " + MASTER_PORT + "!");
				}
			}
		}
	}

	// IP

	private class IPSender extends Thread {
		private static final int IP_PORT = 49153;
		private static final String IP_GROUP = "225.0.0.0";
		private static final byte IP_HOPS = 1;

		private MulticastSocket sendReceiveSocket;
		private InetAddress sendReceiveGroup;
		private DatagramPacket sendReceivePacket;

		private static final int BUFFER_SIZE = 1;
		private byte[] sendReceiveBuffer = new byte[BUFFER_SIZE];

		public IPSender() {
			super("IP Sender");

			this.setPriority(IP_PRIORITY);

			try {
				sendReceiveSocket = new MulticastSocket(IP_PORT);
			} catch (IOException e) {
				throw new RuntimeException("Cannot open IP socket!");
			}

			try {
				sendReceiveGroup = InetAddress.getByName(IP_GROUP);
			} catch (UnknownHostException e) {
				throw new RuntimeException("Unknown multicast group for IP!");
			}

			try {
				sendReceiveSocket.joinGroup(sendReceiveGroup);
			} catch (IOException e) {
				throw new RuntimeException("Cannot join multicast group for IP!");
			}

			sendReceivePacket = new DatagramPacket(sendReceiveBuffer, sendReceiveBuffer.length);

			start();
		}

		public void run() {
			try {
				while (true) {
					sendReceiveSocket.receive(sendReceivePacket);

					switch (sendReceiveBuffer[0]) {
						case IP :

							break;
						case GETIP :
							console.println("IP requested from " + sendReceivePacket.getAddress());

							sendReceiveBuffer[0] = IP;

							try {
								sendReceiveSocket.send(sendReceivePacket, IP_HOPS);
							} catch (IOException e) {
								throw new RuntimeException("Cannot send IP packet!");
							}

							break;
						default :
							throw new RuntimeException(
								this +": unknown command " + sendReceiveBuffer[0] + " received!");
					}
				}
			} catch (IOException e) {
				throw new RuntimeException("Problem receiving IP request!");
			} finally {
				try {
					sendReceiveSocket.leaveGroup(sendReceiveGroup);
				} catch (IOException e) {
					throw new RuntimeException("Cannot leave multicast group for IP!");
				}

				sendReceiveSocket.close();
			}
		}
	}

	// Slave

	private class Slave extends Thread {
		private Socket masterSocket = null;

		// Timer Slave

		private TimerSlave timerSlave = null;

		public Slave() {
			super("Slave");

			this.setPriority(SLAVE_PRIORITY);

			connectMaster();

			if (isConnected) {
				timerSlave = new TimerSlave();

				start();
			}
		}

		public void run() {
			try {
				ObjectInputStream input = new ObjectInputStream(masterSocket.getInputStream());

				while (isConnected) {
					int command = input.read();

					switch (command) {
						case GO :
							receiveLogOnOff(input);

							Machine.this.envTrigger(false);

							break;
						case TICK :
							Machine.this.envTrigger(true);

							break;
						case ECODE :
							receiveECode(input);

							break;
						case DISCONNECT :
							receiveLogOnOff(input);

							disconnectMaster();

							break;
						default :
							throw new RuntimeException(this +": unknown command " + command + " received!");
					}
				}
			} catch (IOException e) {
				disconnectMaster();
			}
		}

		private void receiveECode(ObjectInputStream input) {
			try {
				EProgram inputProgram = (EProgram) input.readObject();

				console.println(
					"Received "
						+ inputProgram.getNumberOfEInstructions()
						+ " E code instructions for program "
						+ (ePrograms.size() + 1)
						+ ".");

				addEProgram(inputProgram);

				if (machineGUI != null)
					machineGUI.programMenu.select(machineGUI.programMenu.getItemCount() - 1);

				resetMachine();

				selectEProgram(inputProgram);
			} catch (IOException e) {
				console.println(this +" could not receive E code.");
			} catch (ClassNotFoundException e) {
				console.println(this +" could not handle E code.");
			}
		}

		private void receiveLogOnOff(ObjectInputStream input) {
			try {
				log = input.readByte() > 0 ? true : false;
			} catch (IOException e) {
				console.println(this +" could not log status.");
			}

			if (machineGUI != null) {
				if (log)
					machineGUI.logButton.setLabel("NoLogging");
				else
					machineGUI.logButton.setLabel(" Logging ");
			}
		}

		private void connectMaster() {
			MulticastSocket requestSocket;
			InetAddress requestGroup;
			DatagramPacket requestPacket;

			byte[] requestBuffer = new byte[IPSender.BUFFER_SIZE];

			try {
				requestSocket = new MulticastSocket();
			} catch (IOException e) {
				throw new RuntimeException("Cannot open request socket!");
			}

			try {
				requestGroup = InetAddress.getByName(IPSender.IP_GROUP);
			} catch (UnknownHostException e) {
				throw new RuntimeException("Unknown multicast group for IP request!");
			}

			try {
				requestSocket.joinGroup(requestGroup);
			} catch (IOException e) {
				throw new RuntimeException("Cannot join multicast group for IP request!");
			}

			requestPacket =
				new DatagramPacket(requestBuffer, requestBuffer.length, requestGroup, IPSender.IP_PORT);

			requestBuffer[0] = GETIP;

			try {
				requestSocket.send(requestPacket, IPSender.IP_HOPS);
			} catch (IOException e) {
				throw new RuntimeException("Cannot send IP request packet!");
			}

			boolean gotIP = false;

			console.println("Trying to get Master IP.");

			while (!gotIP) {
				try {
					requestSocket.receive(requestPacket);
				} catch (IOException e) {
					throw new RuntimeException("Cannot receive IP packet!");
				}

				switch (requestBuffer[0]) {
					case IP :
						gotIP = true;

						break;
					case GETIP :

						break;
					default :
						throw new RuntimeException(this +": unknown answer " + requestBuffer[0] + " received!");
				}
			}

			InetAddress masterInetAddress = requestPacket.getAddress();

			console.println("Master IP " + masterInetAddress + " received.");

			try {
				requestSocket.leaveGroup(requestGroup);
			} catch (IOException e) {
				throw new RuntimeException("Cannot leave multicast group for IP request!");
			}

			requestSocket.close();

			try {
				masterSocket = new Socket(masterInetAddress, Master.MASTER_PORT);

				isConnected = true;

				if (machineGUI != null) {
					machineGUI.connectButton.setEnabled(false);
					machineGUI.connectButton.setLabel("Connected");

					machineGUI.goButton.setEnabled(false);
					machineGUI.tickButton.setEnabled(false);
					machineGUI.programMenu.setEnabled(false);
					machineGUI.logButton.setEnabled(false);
				}

				console.println("Connected to " + masterSocket + ".");
			} catch (IOException e) {
				console.println("Could not connect to port: " + Master.MASTER_PORT + " (" + e + ")");
			}
		}

		private void disconnectMaster() {
			String stringSocket = "" + masterSocket;

			try {
				masterSocket.close();
			} catch (IOException e) {
				throw new RuntimeException(this +" cannot close socket (" + e + ")");
			}

			isConnected = false;

			if (machineGUI != null) {
				machineGUI.connectButton.setEnabled(true);
				machineGUI.connectButton.setLabel(" Connect ");

				machineGUI.goButton.setEnabled(true);
				machineGUI.tickButton.setEnabled(true);
				machineGUI.programMenu.setEnabled(true);
				machineGUI.logButton.setEnabled(true);
			}

			console.println("Disconnected from " + stringSocket + ".");

			timerSlave.exitTimer = true;

			slave = null;

			if (machineGUI == null)
				System.exit(0);
		}
	}

	// Timer Slave

	private class TimerSlave extends Thread {
		private static final int SYNC_PORT = 49154;
		private static final String SYNC_GROUP = "226.0.0.0";
		private static final byte SYNC_HOPS = 1;

		private MulticastSocket receiveSocket;

		private InetAddress group;

		private DatagramPacket receivePacket;

		private static final int BUFFER_SIZE = 1;

		private byte[] receiveBuffer = new byte[BUFFER_SIZE];

		private boolean exitTimer = false;

		public TimerSlave() {
			super("TimerSlave");

			this.setPriority(TIMER_PRIORITY);

			try {
				receiveSocket = new MulticastSocket(SYNC_PORT);
			} catch (IOException e) {
				throw new RuntimeException("Cannot open slave sync socket!");
			}

			try {
				group = InetAddress.getByName(SYNC_GROUP);
			} catch (UnknownHostException e) {
				throw new RuntimeException("Unknown multicast group for timer slave!");
			}

			try {
				receiveSocket.joinGroup(group);
			} catch (IOException e) {
				throw new RuntimeException("Cannot join multicast group for timer slave!");
			}

			receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

			start();
		}

		public void run() {
			try {
				while (true) {
					receiveSocket.receive(receivePacket);

					if (exitTimer)
						break;
					else {
						log = receiveBuffer[0] > 0 ? true : false;

						if (machineGUI != null) {
							if (log)
								machineGUI.logButton.setLabel("NoLogging");
							else
								machineGUI.logButton.setLabel(" Logging ");
						}

						Machine.this.envTrigger(false);
					}
				}
			} catch (IOException e) {
				throw new RuntimeException("Problem receiving sync signal!");
			}

			try {
				receiveSocket.leaveGroup(group);
			} catch (IOException e) {
				throw new RuntimeException("Cannot leave multicast group for timer slave!");
			}

			receiveSocket.close();
		}
	}

	// GUI

	public void resize() {
		machineGUI.resizeMachineGUI();
	}

	private class MachineGUI {
		private Applet applet = null;
		private ScrollPane appletPane = null;

		private Frame frame = null;

		private Button goButton = null;
		private boolean goStatus = false;
		private Button tickButton = null;

		private Button eStepButton = null;
		private Button eStepOverButton = null;

		private Choice programMenu = null;
		private Button resetButton = null;
		private Button logButton = null;

		private Button sStepButton = null;
		private Button sStepOverButton = null;

		// Traffic History

		private TrafficHistory trafficHistory = null;

		private Panel timingPanel = null;
		private Panel softwarePanel = null;

		// Tasks

		private final TaskGUI[] taskGUIs = new TaskGUI[EProgram.MAX_TASKS];

		private int trafficLightWidth = 0;

		// Master

		private Choice slaveMenu = null;

		private Button sendButton = null;
		private Button disconnectButton = null;

		// Slave

		private Button connectButton = null;

		private final int brightness = 180;

		private final Color lightred = new Color(255, brightness, brightness);
		private final Color lightyellow = new Color(255, 255, brightness);
		private final Color lightgreen = new Color(brightness, 255, brightness);

		public MachineGUI(Applet applet, Frame frame) {
			this.applet = applet;
			this.frame = frame;

			initMachineGUI();
		}

		private void initMachineGUI() {
			//Panel appletPanel = new Panel(new GridLayout(3, 1));

			Panel appletPanel = applet;
			appletPanel.setLayout(new GridLayout(3, 1));

			// Top

			Panel environmentPanel = new Panel(new FlowLayout(FlowLayout.LEFT));

			goButton = new Button("  Go  ");
			goButton.addActionListener(new GoButton());
			environmentPanel.add(goButton);

			tickButton = new Button("Tick");
			tickButton.addActionListener(new TickButton());
			environmentPanel.add(tickButton);

			softwarePanel = new Panel(new FlowLayout(FlowLayout.LEFT));

			Panel eventPanel = new Panel(new BorderLayout());
			eventPanel.add(environmentPanel, BorderLayout.NORTH);
			eventPanel.add(softwarePanel, BorderLayout.CENTER);

			timingPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
			trafficHistory = new TrafficHistory();
			timingPanel.add(trafficHistory);

			Panel executionPanel = new Panel(new BorderLayout());
			executionPanel.add(eventPanel, BorderLayout.WEST);
			executionPanel.add(timingPanel, BorderLayout.CENTER);

			Panel topPanel = new Panel(new BorderLayout());
			topPanel.add(new Panel(), BorderLayout.NORTH);
			topPanel.add(executionPanel, BorderLayout.SOUTH);

			appletPanel.add(topPanel);

			// Middle

			Panel eMachine = new Panel(new BorderLayout());
			eMachine.add(eConsole.getConsole(), BorderLayout.CENTER);

			eStepButton = new Button("Step");
			eStepButton.setEnabled(false);
			eStepButton.addActionListener(new EStepButton());

			eStepOverButton = new Button("Over");
			eStepOverButton.setEnabled(false);
			eStepOverButton.addActionListener(new EStepOverButton());

			Panel eButtonPanel = new Panel(new GridLayout(2, 1));
			eButtonPanel.add(eStepButton);
			eButtonPanel.add(eStepOverButton);

			Panel ePanel = new Panel(new FlowLayout(FlowLayout.LEFT));
			ePanel.add(eButtonPanel);
			eMachine.add(ePanel, BorderLayout.WEST);

			Panel sMachine = new Panel(new BorderLayout());
			sMachine.add(sConsole.getConsole(), BorderLayout.CENTER);

			sStepButton = new Button("Step");
			sStepButton.setEnabled(false);
			sStepButton.addActionListener(new SStepButton());

			sStepOverButton = new Button("Over");
			sStepOverButton.setEnabled(false);
			sStepOverButton.addActionListener(new SStepOverButton());

			Panel sButtonPanel = new Panel(new GridLayout(2, 1));
			sButtonPanel.add(sStepButton);
			sButtonPanel.add(sStepOverButton);

			Panel sPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
			sPanel.add(sButtonPanel);
			sMachine.add(sPanel, BorderLayout.EAST);

			Panel machines = new Panel(new GridLayout(1, 2));
			machines.add(eMachine);
			machines.add(sMachine);

			appletPanel.add(machines);

			// Bottom

			Panel consolePanel = new Panel(new BorderLayout());
			consolePanel.add(console.getConsole(), BorderLayout.CENTER);

			programMenu = new Choice();
			programMenu.addItemListener(new ProgramMenu());

			Panel programButtonPanel = new Panel();

			//resetButton = new Button("  Reset  ");
			//resetButton.addActionListener(new ResetButton());
			//programButtonPanel.add(resetButton);

			logButton = new Button("No Logging");
			logButton.addActionListener(new LogButton());
			programButtonPanel.add(logButton);

			Panel controlPanel = new Panel(new BorderLayout());
			controlPanel.add(programMenu, BorderLayout.NORTH);
			controlPanel.add(programButtonPanel, BorderLayout.CENTER);

			if (isMaster) {
				Panel masterAllPanel = new Panel(new BorderLayout());

				slaveMenu = new Choice();

				masterAllPanel.add(slaveMenu, BorderLayout.NORTH);

				Panel masterPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
				Panel masterButtonPanel = new Panel(new GridLayout(2, 1));

				sendButton = new Button("Send E Code");
				sendButton.setEnabled(false);
				sendButton.addActionListener(new SendButton());
				masterButtonPanel.add(sendButton);

				disconnectButton = new Button("   Disconnect   ");
				disconnectButton.setEnabled(false);
				disconnectButton.addActionListener(new DisconnectButton());
				masterButtonPanel.add(disconnectButton);

				masterPanel.add(masterButtonPanel);
				masterAllPanel.add(masterPanel, BorderLayout.CENTER);

				controlPanel.add(masterAllPanel, BorderLayout.SOUTH);
			} else if (isSlave) {
				Panel slaveButtonPanel = new Panel();

				connectButton = new Button(" Connect ");
				connectButton.addActionListener(new ConnectButton());
				slaveButtonPanel.add(connectButton);

				controlPanel.add(slaveButtonPanel, BorderLayout.SOUTH);
			}

			consolePanel.add(controlPanel, BorderLayout.WEST);

			appletPanel.add(consolePanel);

			//osAppletPane = new ScrollPane();
			//osAppletPane.setSize(getWindowWidth(), getWindowHeight());

			//osAppletPane.add(appletPanel);

			//osApplet.add(osAppletPane);
		}

		private void resetMachineGUI() {
			for (int taskIndex = 0; taskIndex < EProgram.MAX_TASKS; taskIndex++)
				taskGUIs[taskIndex] = null;

			trafficLightWidth = 0;

			softwarePanel.removeAll();

			trafficHistory.resetTrafficHistory();

			eConsole.reset();
			sConsole.reset();
		}

		private void resizeMachineGUI() {
			trafficHistory.resizeTrafficHistory();

			for (int taskIndex = 0; taskIndex < eProgram.getNumberOfTasks(); taskIndex++)
				taskGUIs[taskIndex].resizeTaskGUI();

			//osAppletPane.setSize(getWindowWidth(), getWindowHeight());

			applet.validate();

			//if (frame != null)
			//	frame.setVisible(true);
		}

		private void addTaskGUI(TaskThread taskThread, int taskGUIIndex) {
			taskGUIs[taskGUIIndex] = new TaskGUI(taskThread);

			trafficHistory.addTaskThread(taskThread);
		}

		private int getWindowWidth() {
			if (frame != null)
				return frame.getSize().width;
			else
				return applet.getSize().width;
		}

		private int getWindowHeight() {
			if (frame != null)
				return frame.getSize().height;
			else
				return applet.getSize().height;
		}

		/*
				private int getPaneWidth() {
					return getWindowWidth() > 500 ? getWindowWidth() : 500;
				}
		
				private int getPaneHeight() {
					return getWindowHeight() > 300 ? getWindowHeight() : 300;
				}
		*/

		private void stopMachine() {
			if (goStatus) {
				goStatus = false;

				goButton.setLabel("Go");

				tickButton.setEnabled(true);
				programMenu.setEnabled(true);
				logButton.setEnabled(true);

				if (isMaster && slaveMenu.getItemCount() > 0) {
					sendButton.setEnabled(true);
					disconnectButton.setEnabled(true);
				}

				if (isSlave && !isConnected)
					connectButton.setEnabled(true);

				timer.trace();
			}
		}

		private class GoButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				if (goStatus)
					stopMachine();
				else {
					goStatus = true;

					goButton.setLabel("Stop");

					tickButton.setEnabled(false);
					programMenu.setEnabled(false);
					logButton.setEnabled(false);

					if (isMaster) {
						sendButton.setEnabled(false);
						disconnectButton.setEnabled(false);
					}

					if (isSlave)
						connectButton.setEnabled(false);

					timer.go();
				}
			}
		}

		private class TickButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				goButton.setEnabled(false);
				tickButton.setEnabled(false);
				programMenu.setEnabled(false);

				if (isMaster) {
					sendButton.setEnabled(false);
					disconnectButton.setEnabled(false);
				}

				if (isSlave)
					connectButton.setEnabled(false);

				timer.tick();
			}
		}

		private class EStepButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				eStepButton.setEnabled(false);
				eStepOverButton.setEnabled(false);

				step();
			}
		}

		private class EStepOverButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				eStepButton.setEnabled(false);
				eStepOverButton.setEnabled(false);

				stepOver();
			}
		}

		private class ProgramMenu implements ItemListener {
			public void itemStateChanged(ItemEvent event) {
				resetMachine();

				selectEProgram((EProgram) ePrograms.get(programMenu.getSelectedIndex()));
			}
		}

		private class ResetButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {}
		}

		private class LogButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				if (log) {
					log = false;

					logButton.setLabel(" Logging ");
				} else {
					log = true;

					logButton.setLabel("NoLogging");
				}
			}
		}

		private class SStepButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				sStepButton.setEnabled(false);
				sStepOverButton.setEnabled(false);

				step();
			}
		}

		private class SStepOverButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				sStepButton.setEnabled(false);
				sStepOverButton.setEnabled(false);

				stepOver();
			}
		}

		private class SendButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				int selectedSlaveIndex = slaveMenu.getSelectedIndex();

				master.sendECode(selectedSlaveIndex);
			}
		}

		private class DisconnectButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				int selectedSlaveIndex = slaveMenu.getSelectedIndex();

				master.disconnectSlave(selectedSlaveIndex);
			}
		}

		private class ConnectButton implements ActionListener {
			public void actionPerformed(ActionEvent event) {
				connect();
			}
		}

		private class TrafficHistory extends Canvas {
			private final ArrayList taskHistories = new ArrayList();

			private final int MAX_TIME_INSTANTS = 10;
			private final int MAX_SOFT_INSTANTS = 6;

			private int numberOfTimeInstants = 0;
			private int currentTimeInstant = -1;

			private final int[] timeOfInstant = new int[MAX_TIME_INSTANTS];

			private final int[] numberOfSoftInstants = new int[MAX_TIME_INSTANTS];
			private int currentSoftInstant = -1;

			private int boxX, boxY, boxDX, boxDY;

			private int x, y, timeLineX, timeLineY, timeLineDX, timeLineDY;
			private int timeBoxX, timeBoxY, timeBoxDX, timeBoxDY;

			public TrafficHistory() {
				super();

				resetTrafficHistory();

				resizeTrafficHistory();
			}

			public void paint(Graphics graphics) {
				super.paint(graphics);

				graphics.setColor(Color.black);

				graphics.drawLine(timeLineX, timeLineY, timeLineX + timeLineDX, timeLineY);
				graphics.drawLine(
					timeLineX + timeLineDX - 5,
					timeLineY - 5,
					timeLineX + timeLineDX,
					timeLineY);
				graphics.drawLine(
					timeLineX + timeLineDX - 5,
					timeLineY + 5,
					timeLineX + timeLineDX,
					timeLineY);
				graphics.drawString("Real Time", timeLineX + timeLineDX - 30, timeLineY - 10);

				graphics.drawLine(
					timeLineX,
					timeLineY + timeLineDY,
					timeLineX + timeLineDX,
					timeLineY + timeLineDY);
				graphics.drawLine(
					timeLineX + timeLineDX - 5,
					timeLineY + timeLineDY - 5,
					timeLineX + timeLineDX,
					timeLineY + timeLineDY);
				graphics.drawLine(
					timeLineX + timeLineDX - 5,
					timeLineY + timeLineDY + 5,
					timeLineX + timeLineDX,
					timeLineY + timeLineDY);
				graphics.drawString("Soft Time", timeLineX + timeLineDX - 30, timeLineY + timeLineDY + 20);

				drawHistory(graphics);
			}

			private void drawHistory(Graphics graphics) {
				final int timeStepDX = timeBoxDX / MAX_TIME_INSTANTS;
				final int softStepDX = timeStepDX / MAX_SOFT_INSTANTS;

				final int stepDY = timeBoxDY / taskHistories.size();
				final int taskDY = stepDY / 2;

				for (int taskIndex = 0; taskIndex < taskHistories.size(); taskIndex++) {
					TaskHistory taskHistory = getTaskHistory(taskIndex);

					int currentX = timeBoxX;
					int currentY = timeBoxY + taskIndex * stepDY + (stepDY - taskDY) / 2;

					graphics.drawString(
						taskHistory.taskThread.getShortName(),
						x,
						currentY + (stepDY - taskDY) / 2 + 5);

					for (int timeInstant = 0; timeInstant < numberOfTimeInstants; timeInstant++) {
						int actualInstant = getActualInstant(timeInstant);

						for (int softInstant = 0;
							softInstant < numberOfSoftInstants[actualInstant] + 1;
							softInstant++) {
							int currentDX = 0;

							if (softInstant == 0) {
								if (timeInstant > 0) {
									currentDX =
										timeStepDX
											- (softStepDX * numberOfSoftInstants[getActualInstant(timeInstant - 1)]);

									graphics.setColor(taskHistory.timeSoftInstants[actualInstant][softInstant]);
									graphics.fillRect(currentX, currentY, currentDX, taskDY);
								}

								graphics.setColor(Color.black);
								graphics.drawString(
									"" + timeOfInstant[actualInstant],
									currentX + currentDX - 10,
									timeLineY - 10);
								graphics.drawLine(
									currentX + currentDX - 1,
									timeLineY - 5,
									currentX + currentDX - 1,
									timeBoxY + timeBoxDY - (stepDY - taskDY) / 2 - 2);
							} else {
								currentDX = softStepDX;

								graphics.setColor(taskHistory.timeSoftInstants[actualInstant][softInstant]);
								graphics.fillRect(currentX, currentY, currentDX, taskDY);

								graphics.setColor(Color.black);
								graphics.drawLine(
									currentX + currentDX - 1,
									timeLineY + timeLineDY + 5,
									currentX + currentDX - 1,
									timeBoxY + (stepDY - taskDY) / 2);
							}

							if (taskHistory.timeSafetyViolations[actualInstant][softInstant]) {
								graphics.drawLine(
									currentX + currentDX - softStepDX,
									currentY - taskDY / 2,
									currentX + currentDX - softStepDX / 3,
									currentY - taskDY / 6);
								graphics.drawLine(
									currentX + currentDX - softStepDX / 3,
									currentY - taskDY / 6,
									currentX + currentDX - softStepDX * 2 / 3,
									currentY + taskDY / 6);
								graphics.drawLine(
									currentX + currentDX - softStepDX * 2 / 3,
									currentY + taskDY / 6,
									currentX + currentDX - 1,
									currentY + taskDY / 2);
								graphics.drawLine(
									currentX + currentDX - softStepDX / 3,
									currentY + taskDY / 2,
									currentX + currentDX - 1,
									currentY + taskDY / 2);
								graphics.drawLine(
									currentX + currentDX - 3,
									currentY + taskDY / 2 - softStepDX / 3,
									currentX + currentDX - 1,
									currentY + taskDY / 2);
							}

							currentX += currentDX;
						}
					}
				}

				for (int timeInstant = 0; timeInstant < numberOfTimeInstants - 1; timeInstant++) {}
			}

			private int getActualInstant(int timeInstant) {
				return numberOfTimeInstants < MAX_TIME_INSTANTS
					? timeInstant
					: (timeInstant + 1 + currentTimeInstant) % MAX_TIME_INSTANTS;
			}

			private void envSoftInstants() {
				if (softwareEvent)
					instant(false);

				if (environmentEvent)
					instant(true);
			}

			private void instant(boolean timeInstant) {
				if (timeInstant) {
					currentSoftInstant = 0;

					if (numberOfTimeInstants < MAX_TIME_INSTANTS) {
						numberOfTimeInstants++;

						currentTimeInstant++;
					} else
						currentTimeInstant = (currentTimeInstant + 1) % MAX_TIME_INSTANTS;

					timeOfInstant[currentTimeInstant] = time;
				} else {
					if (currentSoftInstant < MAX_SOFT_INSTANTS) {
						currentSoftInstant++;
					} else
						throw new RuntimeException("Too many software events!");
				}

				numberOfSoftInstants[currentTimeInstant] = currentSoftInstant;

				for (int taskIndex = 0; taskIndex < taskHistories.size(); taskIndex++) {
					TaskHistory taskHistory = getTaskHistory(taskIndex);

					if (taskHistory.taskThread.isDisabled())
						taskHistory.timeSoftInstants[currentTimeInstant][currentSoftInstant] = Color.red;
					else if (taskHistory.taskThread.isScheduled())
						taskHistory.timeSoftInstants[currentTimeInstant][currentSoftInstant] = Color.yellow;
					else if (taskHistory.taskThread.isRunning())
						taskHistory.timeSoftInstants[currentTimeInstant][currentSoftInstant] = Color.green;

					taskHistory.timeSafetyViolations[currentTimeInstant][currentSoftInstant] = false;
				}
			}

			private TaskHistory getTaskHistory(int taskIndex) {
				return (TaskHistory) taskHistories.get(taskIndex);
			}

			private void setTimeSafetyViolation(int taskIndex) {
				getTaskHistory(taskIndex).timeSafetyViolations[currentTimeInstant][currentSoftInstant] =
					true;
			}

			private void resetTrafficHistory() {
				taskHistories.clear();

				numberOfTimeInstants = 0;

				currentTimeInstant = -1;
				currentSoftInstant = -1;
			}

			private void resizeTrafficHistory() {
				boxDX = getWindowWidth() - trafficLightWidth - 150;
				boxDY = getWindowHeight() / 6;

				x = boxDX / 100;
				y = boxDY / 100;

				boxX = x;
				boxY = y;

				timeLineX = boxX + 20;
				timeLineY = boxY + 20;

				timeLineDX = boxDX - 40;
				timeLineDY = boxDY;

				timeBoxX = timeLineX + 10;
				timeBoxY = timeLineY + 10;

				timeBoxDX = timeLineDX - 20;
				timeBoxDY = timeLineDY - 20;

				setSize(boxX + boxDX + 30, boxY + boxDY + 50);
			}

			private void redrawTrafficHistory() {
				repaint();
			}

			private void addTaskThread(TaskThread taskThread) {
				taskHistories.add(new TaskHistory(taskThread));
			}

			private class TaskHistory {
				private TaskThread taskThread = null;

				// Caution: we get MAX_SOFT_INSTANTS + 1 entries because entry 0 is needed for the time instant
				private final Color[][] timeSoftInstants =
					new Color[MAX_TIME_INSTANTS][MAX_SOFT_INSTANTS + 1];

				private final boolean[][] timeSafetyViolations =
					new boolean[MAX_TIME_INSTANTS][MAX_SOFT_INSTANTS + 1];

				public TaskHistory(TaskThread taskThread) {
					this.taskThread = taskThread;
				}
			}
		}

		// Task GUI

		private class TaskGUI extends Canvas {
			private TaskThread taskThread;

			private int x, y, boxX, boxY, boxDX, boxDY;
			private int circleD, circleLD, circleRD;
			private int redX, redY, yellowX, yellowY, greenX, greenY;

			private Button completeButton;
			private boolean completed = false;

			public TaskGUI(TaskThread taskThread) {
				super();

				this.taskThread = taskThread;

				Panel taskPanel = new Panel(new BorderLayout());

				taskPanel.add(this, BorderLayout.WEST);

				Panel buttonPanel = new Panel(new FlowLayout(FlowLayout.LEFT));

				completeButton = new Button("Complete");
				completeButton.setEnabled(false);
				completeButton.addActionListener(new CompleteButton());

				buttonPanel.add(completeButton);

				taskPanel.add(buttonPanel, BorderLayout.SOUTH);

				softwarePanel.add(taskPanel);

				resizeTaskGUI();
			}

			public void paint(Graphics graphics) {
				super.paint(graphics);

				graphics.setColor(Color.gray);
				graphics.fillRect(boxX + 3, boxY + 3, boxDX, boxDY);

				graphics.setColor(Color.black);
				graphics.fillRect(boxX, boxY, boxDX, boxDY);

				drawRedLight(graphics);
				drawYellowLight(graphics);
				drawGreenLight(graphics);

				graphics.setColor(Color.black);
				graphics.setFont(new Font(null, Font.PLAIN, 9));
				graphics.drawString(taskThread.getShortName(), x, boxY + (boxDY >> 1) + 5);
			}

			private void drawRedLight(Graphics graphics) {
				if (taskThread.isDisabled()) {
					graphics.setColor(Color.red);
					graphics.fillOval(redX, redY, circleD, circleD);
				} else {
					graphics.setColor(lightred);
					graphics.fillOval(redX, redY, circleD, circleD);
					graphics.setColor(Color.black);
					graphics.drawLine(redX + circleLD, redY + circleLD, redX + circleRD, redY + circleRD);
					graphics.drawLine(redX + circleLD, redY + circleRD, redX + circleRD, redY + circleLD);
				}
			}

			private void drawYellowLight(Graphics graphics) {
				if (taskThread.isScheduled()) {
					graphics.setColor(Color.yellow);
					graphics.fillOval(yellowX, yellowY, circleD, circleD);
				} else {
					graphics.setColor(lightyellow);
					graphics.fillOval(yellowX, yellowY, circleD, circleD);
					graphics.setColor(Color.black);
					graphics.drawLine(
						yellowX + circleLD,
						yellowY + circleLD,
						yellowX + circleRD,
						yellowY + circleRD);
					graphics.drawLine(
						yellowX + circleLD,
						yellowY + circleRD,
						yellowX + circleRD,
						yellowY + circleLD);
				}
			}

			private void drawGreenLight(Graphics graphics) {
				if (taskThread.isRunning()) {
					graphics.setColor(Color.green);
					graphics.fillOval(greenX, greenY, circleD, circleD);
				} else {
					graphics.setColor(lightgreen);
					graphics.fillOval(greenX, greenY, circleD, circleD);
					graphics.setColor(Color.black);
					graphics.drawLine(
						greenX + circleLD,
						greenY + circleLD,
						greenX + circleRD,
						greenY + circleRD);
					graphics.drawLine(
						greenX + circleLD,
						greenY + circleRD,
						greenX + circleRD,
						greenY + circleLD);
				}
			}

			private void resizeTaskGUI() {
				boxDX = (15 * getWindowWidth() + 45 * getWindowHeight()) / 1500;
				boxDY = 3 * boxDX;

				circleD = (boxDX * 8) / 10;

				// x^2 + y^2 = z^2 and x = y : 2 * x^2 = z^2 : z = sqrt(2) * x and sqrt(2) * 10 ~ 14
				circleLD = (circleD * 14 - circleD * 10) / 20;
				circleRD = circleD - circleLD;

				x = boxDX / 20 + 10;
				y = boxDY / 20;

				boxX = x + 15;
				boxY = y;

				redX = boxX + (boxDX - circleD) / 2;
				redY = boxY + (boxDX - circleD) / 2;
				yellowX = redX;
				yellowY = redY + boxDX;
				greenX = yellowX;
				greenY = yellowY + boxDX;

				trafficLightWidth = eProgram.getNumberOfTasks() * (boxDX + 20);

				setSize(boxX + boxDX + 25, boxY + boxDY + 10);
			}

			private void redrawTaskGUI() {
				if (log)
					repaint();
			}

			private class CompleteButton implements ActionListener {
				public void actionPerformed(ActionEvent event) {
					completed = false;

					completeButton.setEnabled(false);

					Machine.this.softTrigger(true);
				}
			}
		}
	}

}
