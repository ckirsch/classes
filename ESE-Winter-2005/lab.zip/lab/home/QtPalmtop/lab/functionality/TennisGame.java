/*

 Copyright (c) 2002 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

*/

package functionality;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.IOException;
import java.io.InterruptedIOException;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;

/**
 * @author cm@eecs.berkeley.edu
 *
 */
public class TennisGame extends Canvas implements Runnable {
	private Frame gameFrame;

	private final int frameDX = 205;
	private final int frameDY = 225;

	protected boolean goBall = true;

	private boolean gameOver = true;
	private boolean startGame = false;

	private int lostN = 0;
	private int lostS = 0;
	private int lostW = 0;
	private int lostE = 0;

	private final int timeStep = 1200;

	private final int SPEED_LIMIT = timeStep / 34;

	// Networking

	private static final byte HOPS = 1;

	private static final String GROUP = "227.0.0.0";
	private static final int PORT = 49155;
	private MulticastSocket sendSocket;
	private MulticastSocket receiveSocket;
	private InetAddress group;
	private DatagramPacket sendPacket;
	private DatagramPacket receivePacket;
	private byte[] sendBuffer = new byte[BUFFER_SIZE];
	private byte[] receiveBuffer = new byte[BUFFER_SIZE];

	private static final String BALL_GROUP = "228.0.0.0";
	private static final String RACKET_N_GROUP = "228.1.0.0";
	private static final String RACKET_S_GROUP = "228.2.0.0";
	private static final String RACKET_W_GROUP = "228.3.0.0";
	private static final String RACKET_E_GROUP = "228.4.0.0";

	private static final int BALL_PORT = 49156;
	private static final int RACKET_N_PORT = 49157;
	private static final int RACKET_S_PORT = 49158;
	private static final int RACKET_W_PORT = 49159;
	private static final int RACKET_E_PORT = 49160;

	private MulticastSocket sendBallSocket;
	private MulticastSocket sendRacketNSocket;
	private MulticastSocket sendRacketSSocket;
	private MulticastSocket sendRacketWSocket;
	private MulticastSocket sendRacketESocket;

	private MulticastSocket receiveBallSocket;
	private MulticastSocket receiveRacketNSocket;
	private MulticastSocket receiveRacketSSocket;
	private MulticastSocket receiveRacketWSocket;
	private MulticastSocket receiveRacketESocket;

	private InetAddress ballGroup;
	private InetAddress racketNGroup;
	private InetAddress racketSGroup;
	private InetAddress racketWGroup;
	private InetAddress racketEGroup;

	private DatagramPacket sendBallPacket;
	private DatagramPacket sendRacketNPacket;
	private DatagramPacket sendRacketSPacket;
	private DatagramPacket sendRacketWPacket;
	private DatagramPacket sendRacketEPacket;

	private DatagramPacket receiveBallPacket;
	private DatagramPacket receiveRacketNPacket;
	private DatagramPacket receiveRacketSPacket;
	private DatagramPacket receiveRacketWPacket;
	private DatagramPacket receiveRacketEPacket;

	private static final int BUFFER_SIZE = 10;

	private byte[] sendBallBuffer = new byte[BUFFER_SIZE];
	private byte[] sendRacketNBuffer = new byte[BUFFER_SIZE];
	private byte[] sendRacketSBuffer = new byte[BUFFER_SIZE];
	private byte[] sendRacketWBuffer = new byte[BUFFER_SIZE];
	private byte[] sendRacketEBuffer = new byte[BUFFER_SIZE];

	private byte[] receiveBallBuffer = new byte[BUFFER_SIZE];
	private byte[] receiveRacketNBuffer = new byte[BUFFER_SIZE];
	private byte[] receiveRacketSBuffer = new byte[BUFFER_SIZE];
	private byte[] receiveRacketWBuffer = new byte[BUFFER_SIZE];
	private byte[] receiveRacketEBuffer = new byte[BUFFER_SIZE];

	private static final byte BALL = 0;
	private static final byte RACKET_N = 1;
	private static final byte RACKET_S = 2;
	private static final byte RACKET_W = 3;
	private static final byte RACKET_E = 4;

	private Receiver receiver;

	// Graphics

	private int canvasDX = frameDX - 5;
	private int canvasDY = frameDY - 25;

	private int boardN, boardS, boardW, boardE;
	private int clipN, clipS, clipW, clipE;

	private int canvasCX, canvasCY;

	private int ballX, ballY;

	private int ballD;

	private int ballVX;
	private int ballVY;

	private int racketNX, racketSX, racketWY, racketEY;

	private int racketNSDX, racketNSDY, racketWEDX, racketWEDY;
	private int racketNSDXH, racketWEDYH;

	private int racketNXD, racketSXD, racketWYD, racketEYD;
	private int racketNV, racketSV, racketWV, racketEV;

	public TennisGame() {
		// Networking

		try {
			sendSocket = new MulticastSocket();

			receiveSocket = new MulticastSocket(PORT);
		} catch (IOException e) {
			throw new RuntimeException("Cannot open send/receive sockets!");
		}

		try {
			group = InetAddress.getByName(GROUP);
		} catch (UnknownHostException e) {
			throw new RuntimeException("Unknown multicast group!");
		}

		try {
			receiveSocket.joinGroup(group);
		} catch (IOException e) {
			throw new RuntimeException("Cannot join multicast group!");
		}

		sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, group, PORT);
		receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);

		/*
				try {
					sendBallSocket = new MulticastSocket();
					sendRacketNSocket = new MulticastSocket();
					sendRacketSSocket = new MulticastSocket();
					sendRacketWSocket = new MulticastSocket();
					sendRacketESocket = new MulticastSocket();
		
					receiveBallSocket = new MulticastSocket(BALL_PORT);
					receiveRacketNSocket = new MulticastSocket(RACKET_N_PORT);
					receiveRacketSSocket = new MulticastSocket(RACKET_S_PORT);
					receiveRacketWSocket = new MulticastSocket(RACKET_W_PORT);
					receiveRacketESocket = new MulticastSocket(RACKET_E_PORT);
		
					receiveBallSocket.setSoTimeout(1000);
					receiveRacketNSocket.setSoTimeout(1000);
					receiveRacketSSocket.setSoTimeout(1000);
					receiveRacketWSocket.setSoTimeout(1000);
					receiveRacketESocket.setSoTimeout(1000);
				} catch (IOException e) {
					throw new RuntimeException("Cannot open send/receive sockets!");
				}
		
				try {
					ballGroup = InetAddress.getByName(BALL_GROUP);
					racketNGroup = InetAddress.getByName(RACKET_N_GROUP);
					racketSGroup = InetAddress.getByName(RACKET_S_GROUP);
					racketWGroup = InetAddress.getByName(RACKET_W_GROUP);
					racketEGroup = InetAddress.getByName(RACKET_E_GROUP);
				} catch (UnknownHostException e) {
					throw new RuntimeException("Unknown multicast group!");
				}
		
				try {
					receiveBallSocket.joinGroup(ballGroup);
					receiveRacketNSocket.joinGroup(racketNGroup);
					receiveRacketSSocket.joinGroup(racketSGroup);
					receiveRacketWSocket.joinGroup(racketWGroup);
					receiveRacketESocket.joinGroup(racketEGroup);
				} catch (IOException e) {
					throw new RuntimeException("Cannot join multicast group!");
				}
		
				sendBallPacket =
					new DatagramPacket(sendBallBuffer, sendBallBuffer.length, ballGroup, BALL_PORT);
				sendRacketNPacket =
					new DatagramPacket(sendRacketNBuffer, sendRacketNBuffer.length, racketNGroup, RACKET_N_PORT);
				sendRacketSPacket =
					new DatagramPacket(sendRacketSBuffer, sendRacketSBuffer.length, racketSGroup, RACKET_S_PORT);
				sendRacketWPacket =
					new DatagramPacket(sendRacketWBuffer, sendRacketWBuffer.length, racketWGroup, RACKET_W_PORT);
				sendRacketEPacket =
					new DatagramPacket(sendRacketEBuffer, sendRacketEBuffer.length, racketEGroup, RACKET_E_PORT);
		
				receiveBallPacket = new DatagramPacket(receiveBallBuffer, receiveBallBuffer.length);
				receiveRacketNPacket = new DatagramPacket(receiveRacketNBuffer, receiveRacketNBuffer.length);
				receiveRacketSPacket = new DatagramPacket(receiveRacketSBuffer, receiveRacketSBuffer.length);
				receiveRacketWPacket = new DatagramPacket(receiveRacketWBuffer, receiveRacketWBuffer.length);
				receiveRacketEPacket = new DatagramPacket(receiveRacketEBuffer, receiveRacketEBuffer.length);
		*/

		/*
				initSend(sendBallSocket, sendBallPacket, receiveBallSocket, receiveBallPacket);
				initSend(sendRacketNSocket, sendRacketNPacket, receiveRacketNSocket, receiveRacketNPacket);
				initSend(sendRacketSSocket, sendRacketSPacket, receiveRacketSSocket, receiveRacketSPacket);
				initSend(sendRacketWSocket, sendRacketWPacket, receiveRacketWSocket, receiveRacketWPacket);
				initSend(sendRacketESocket, sendRacketEPacket, receiveRacketESocket, receiveRacketEPacket);
		*/

		receiver = new Receiver();

		// Graphics

		setSize(canvasDX, canvasDY);

		ballD = (canvasDX + canvasDY) / 30;

		canvasCX = canvasDX / 2 - ballD / 2;
		canvasCY = canvasDY / 2 - ballD / 2;

		ballX = canvasCX;
		ballY = canvasCY;

		randomBallV();

		racketNSDX = ballD * 5;
		racketNSDY = ballD;
		racketWEDX = ballD;
		racketWEDY = ballD * 5;

		racketNSDXH = racketNSDX / 2;
		racketWEDYH = racketWEDY / 2;

		racketNX = canvasDX / 2 - racketNSDX / 2;
		racketSX = racketNX;
		racketWY = canvasDY / 2 - racketWEDY / 2;
		racketEY = racketWY;

		racketNXD = racketNX;
		racketSXD = racketSX;
		racketWYD = racketWY;
		racketEYD = racketEY;

		racketNV = racketNXD - racketNX;
		racketSV = racketSXD - racketSX;
		racketWV = racketWYD - racketWY;
		racketEV = racketEYD - racketEY;

		boardN = racketNSDY;
		boardS = canvasDY - racketNSDY;
		boardW = racketWEDX;
		boardE = canvasDX - racketWEDX;

		clipN = boardN;
		clipS = boardS - ballD;
		clipW = boardW;
		clipE = boardE - ballD;

		addMouseListener(new MouseFollower());

		gameFrame = new Frame("College Tennis");

		gameFrame.setLocation(0, 0);
		gameFrame.setSize(frameDX, frameDY);
		gameFrame.setBackground(Color.white);

		gameFrame.setResizable(false);

		gameFrame.addWindowListener(new ExitListener());

		gameFrame.add(this);

		gameFrame.setVisible(true);
	}

	public void destruct() {
		exitGame();
	}

	public void run() {
		while (goBall) {
			synchronized (this) {
				try {
					wait(timeStep);
				} catch (InterruptedException e) {
					throw new RuntimeException("Waiting " + this +" interrupted!");
				}
			}

			moveBall();

			moveRacketN();
			moveRacketS();
			moveRacketW();
			moveRacketE();

			repaintGame();
		}

		exitGame();
	}

	public void paint(Graphics graphics) {
		super.paint(graphics);

		drawAll(graphics);
	}

	private void drawAll(Graphics graphics) {
		graphics.setColor(Color.black);

		graphics.drawLine(0, boardN, boardW, boardN);
		graphics.drawLine(boardW, 0, boardW, boardN);

		graphics.drawLine(boardE, boardN, canvasDX, boardN);
		graphics.drawLine(boardE, 0, boardE, boardN);

		graphics.drawLine(0, boardS, boardW, boardS);
		graphics.drawLine(boardW, boardS, boardW, canvasDY);

		graphics.drawLine(boardE, boardS, canvasDX, boardS);
		graphics.drawLine(boardE, boardS, boardE, canvasDY);

		drawBall(graphics);

		drawRacketN(graphics);
		drawRacketS(graphics);
		drawRacketW(graphics);
		drawRacketE(graphics);

		drawResult(graphics);
	}

	private void drawBall(Graphics graphics) {
		graphics.setColor(Color.black);

		//graphics.fillOval(ballX, ballY, ballD, ballD);

		graphics.fillRect(ballX, ballY, ballD, ballD);

		//graphics.setColor(Color.white);

		//graphics.drawString("$", ballX + 3, ballY + ballD - 2);
	}

	private void drawRacketN(Graphics graphics) {
		graphics.setColor(Color.blue);

		graphics.fillRect(racketNX, boardN - racketNSDY, racketNSDX, racketNSDY);

		graphics.setColor(Color.yellow);

		graphics.drawString(" Berkeley", racketNX, boardN - 1);
	}

	private void drawRacketS(Graphics graphics) {
		graphics.setColor(Color.red);

		graphics.fillRect(racketSX, boardS, racketNSDX, racketNSDY);

		graphics.setColor(Color.white);

		graphics.drawString(" Stanford", racketSX, boardS + racketNSDY - 1);
	}

	private void drawRacketW(Graphics graphics) {
		graphics.setColor(Color.black);

		graphics.fillRect(0, racketWY, racketWEDX, racketWEDY);

		graphics.setColor(Color.white);

		graphics.drawString("M", 0, racketWY + 20);
		graphics.drawString("I", 3, racketWY + 32);
		graphics.drawString("T", 1, racketWY + 44);
	}

	private void drawRacketE(Graphics graphics) {
		graphics.setColor(Color.green);

		graphics.fillRect(boardE, racketEY, racketWEDX, racketWEDY);

		graphics.setColor(Color.red);

		graphics.drawString("C", boardE + 1, racketEY + 20);
		graphics.drawString("M", boardE + 1, racketEY + 32);
		graphics.drawString("U", boardE + 1, racketEY + 44);
	}

	private void drawResult(Graphics graphics) {
		if (gameOver) {
			graphics.setColor(Color.red);

			if (lostE != 0)
				graphics.drawString("CMU lost", canvasCX - 30, canvasCY);
			else if (lostW != 0)
				graphics.drawString("MIT lost", canvasCX - 30, canvasCY);
			else if (lostS != 0)
				graphics.drawString("Stanford lost", canvasCX - 30, canvasCY);
			else if (lostN != 0)
				graphics.drawString("Berkeley lost", canvasCX - 30, canvasCY);
		}
	}

	protected void moveBall() {
		//sendBuffer[0]++;

		//send();

		//receive();

		if (gameOver) {
			if (startGame) {
				startGame = false;

				gameOver = false;

				lostE = lostW = lostS = lostN = 0;

				ballX = canvasCX;
				ballY = canvasCY;

				randomBallV();
			}
		} else {
			ballX += ballVX;
			ballY += ballVY;

			//System.out.println("X: " + ballX + ", Y: " + ballY);

			if (ballX > clipE) {
				lostE = ballX - clipE;

				ballX = clipE;

				if (ballVY > 0) {
					lostS = ballVY * lostE / ballVX;

					ballY -= lostS;

					if (ballY > clipS)
						lostE = 0;
					else if (ballY == clipS)
						if (lostE > lostS)
							lostS = 0;
						else if (lostE < lostS)
							lostE = 0;
						else {
							// Hit corner symmetrically: no loosers
							lostE = lostS = 0;

							ballVX = - (ballVX - 1);
							ballVY = - (ballVY + 1);
						}
					else
						lostS = 0;
				} else {
					lostN = -ballVY * lostE / ballVX;

					ballY += lostN;

					if (ballY < clipN)
						lostE = 0;
					else if (ballY == clipN)
						if (lostE > lostN)
							lostN = 0;
						else if (lostE < lostN)
							lostE = 0;
						else {
							// Hit corner symmetrically: no loosers
							lostE = lostN = 0;

							ballVX = - (ballVX - 1);
							ballVY = - (ballVY + 1);
						}
					else
						lostN = 0;
				}
			} else if (ballX < clipW) {
				lostW = clipW - ballX;

				ballX = clipW;

				if (ballVY > 0) {
					lostS = ballVY * lostW / -ballVX;

					ballY -= lostS;

					if (ballY > clipS)
						lostW = 0;
					else if (ballY == clipS)
						if (lostW > lostS)
							lostS = 0;
						else if (lostW < lostS)
							lostW = 0;
						else {
							// Hit corner symmetrically: no loosers
							lostW = lostS = 0;

							ballVX = - (ballVX + 1);
							ballVY = - (ballVY - 1);
						}
					else
						lostS = 0;
				} else {
					lostN = -ballVY * lostW / -ballVX;

					ballY += lostN;

					if (ballY < clipN)
						lostW = 0;
					else if (ballY == clipN)
						if (lostW > lostN)
							lostN = 0;
						else if (lostW < lostN)
							lostW = 0;
						else {
							// Hit corner symmetrically: no loosers
							lostW = lostN = 0;

							ballVX = - (ballVX + 1);
							ballVY = - (ballVY - 1);
						}
					else
						lostN = 0;
				}
			}

			if (ballY > clipS) {
				lostS = ballY - clipS;

				ballY = clipS;

				ballX -= ballVX * lostS / ballVY;
			} else if (ballY < clipN) {
				lostN = clipN - ballY;

				ballY = clipN;

				ballX -= ballVX * lostN / -ballVY;
			}

			if (lostE != 0) {
				if (ballY > (racketEY - (ballD >> 1))
					&& (ballY < (racketEY + racketWEDY - (ballD >> 1)))) {
					lostE = 0;

					ballVY += (racketEV >> 1) - 1;

					if (ballVY >= (SPEED_LIMIT - 2))
						ballVY = SPEED_LIMIT - 2;
					else if (ballVY <= - (SPEED_LIMIT - 2))
						ballVY = 2 - SPEED_LIMIT;

					if (ballVY > 0)
						ballVX = ballVY - SPEED_LIMIT;
					else
						ballVX = -ballVY - SPEED_LIMIT;
				} else
					ballX += ballD >> 1;
			} else if (lostW != 0) {
				if (ballY > (racketWY - (ballD >> 1))
					&& (ballY < (racketWY + racketWEDY - (ballD >> 1)))) {
					lostW = 0;

					ballVY += (racketWV >> 1) - 1;

					if (ballVY >= (SPEED_LIMIT - 2))
						ballVY = SPEED_LIMIT - 2;
					else if (ballVY <= - (SPEED_LIMIT - 2))
						ballVY = 2 - SPEED_LIMIT;

					if (ballVY > 0)
						ballVX = -ballVY + SPEED_LIMIT;
					else
						ballVX = ballVY + SPEED_LIMIT;
				} else
					ballX -= ballD >> 1;
			} else if (lostS != 0) {
				if (ballX > (racketSX - (ballD >> 1))
					&& (ballX < (racketSX + racketNSDX - (ballD >> 1)))) {
					lostS = 0;

					ballVX += (racketSV >> 1) - 1;

					if (ballVX >= (SPEED_LIMIT - 2))
						ballVX = SPEED_LIMIT - 2;
					else if (ballVX <= - (SPEED_LIMIT - 2))
						ballVX = 2 - SPEED_LIMIT;

					if (ballVX > 0)
						ballVY = ballVX - SPEED_LIMIT;
					else
						ballVY = -ballVX - SPEED_LIMIT;
				} else
					ballY += ballD >> 1;
			} else if (lostN != 0) {
				if (ballX > (racketNX - (ballD >> 1))
					&& (ballX < (racketNX + racketNSDX - (ballD >> 1)))) {
					lostN = 0;

					ballVX += (racketNV >> 1) - 1;

					if (ballVX >= (SPEED_LIMIT - 2))
						ballVX = SPEED_LIMIT - 2;
					else if (ballVX <= - (SPEED_LIMIT - 2))
						ballVX = 2 - SPEED_LIMIT;

					if (ballVX > 0)
						ballVY = -ballVX + SPEED_LIMIT;
					else
						ballVY = ballVX + SPEED_LIMIT;
				} else
					ballY -= ballD >> 1;
			}

			if (lostE + lostW + lostS + lostN != 0) {
				gameOver = true;

				//System.out.println("E: " + lostE + ", W: " + lostW + ", S: " + lostS + ", N: " + lostN);
			}
		}
	}

	/*
		private void initSend(
			MulticastSocket sendSocket,
			DatagramPacket sendPacket,
			MulticastSocket receiveSocket,
			DatagramPacket receivePacket) {
			try {
				sendSocket.send(sendPacket, (byte) 0);
	
				receiveSocket.receive(receivePacket);
			} catch (IOException e) {
				throw new RuntimeException("Cannot send multicast packet!");
			}
		}
	*/

	private void send(MulticastSocket sendSocket, DatagramPacket sendPacket) {
		try {
			sendSocket.send(sendPacket, HOPS);

			//receiveSocket.receive(receivePacket);
		} catch (IOException e) {
			throw new RuntimeException("Cannot send multicast packet!");
		}

		//System.out.println("Send: " + sendBuffer[1]);
	}

	private void receive(MulticastSocket receiveSocket, DatagramPacket receivePacket) {
		try {
			receiveSocket.receive(receivePacket);
		} catch (InterruptedIOException e) {
			return;
		} catch (IOException e) {
			throw new RuntimeException("Cannot receive multicast packet!");
		}

		//System.out.println(
		//	"Received: " + receiveBuffer[1]
		//		+ ", from: "
		//		+ receivePacket.getAddress()
		//		+ ", port: "
		//		+ receivePacket.getPort());
	}

	private class Receiver extends Thread {
		private boolean exitReceiver = false;

		public Receiver() {
			super("Receiver");

			this.setPriority(Thread.MIN_PRIORITY);

			start();
		}

		public void run() {
			while (!exitReceiver) {
				receive(receiveSocket, receivePacket);

				switch (receiveBuffer[0]) {
					case BALL :
						ballX = ((int) receiveBuffer[1]) + 128;
						ballY = ((int) receiveBuffer[2]) + 128;
						ballVX = receiveBuffer[3];
						ballVY = receiveBuffer[4];

						lostN = receiveBuffer[5];
						lostS = receiveBuffer[6];
						lostW = receiveBuffer[7];
						lostE = receiveBuffer[8];

						gameOver = receiveBuffer[9] > 0 ? true : false;

						break;
					case RACKET_N :
						racketNX = ((int) receiveBuffer[1]) + 128;
						racketNV = receiveBuffer[2];

						break;
					case RACKET_S :
						racketSX = ((int) receiveBuffer[1]) + 128;
						racketSV = receiveBuffer[2];

						break;
					case RACKET_W :
						racketWY = ((int) receiveBuffer[1]) + 128;
						racketWV = receiveBuffer[2];

						break;
					case RACKET_E :
						racketEY = ((int) receiveBuffer[1]) + 128;
						racketEV = receiveBuffer[2];

						break;
					default :
						throw new RuntimeException("Unknown packet received!");
				}
			}

			try {
				receiveSocket.leaveGroup(group);
			} catch (IOException e) {
				throw new RuntimeException("Cannot leave multicast group!");
			}

			receiveSocket.close();
		}
	}

	protected void sendBall(
		byte[] sendBuffer,
		MulticastSocket sendSocket,
		DatagramPacket sendPacket) {
		sendBuffer[0] = BALL;

		sendBuffer[1] = (byte) (ballX - 128);
		sendBuffer[2] = (byte) (ballY - 128);
		sendBuffer[3] = (byte) ballVX;
		sendBuffer[4] = (byte) ballVY;

		sendBuffer[5] = (byte) lostN;
		sendBuffer[6] = (byte) lostS;
		sendBuffer[7] = (byte) lostW;
		sendBuffer[8] = (byte) lostE;

		sendBuffer[9] = (byte) (gameOver ? 1 : 0);

		send(sendSocket, sendPacket);
	}

	protected void sendBall() {
		sendBall(sendBuffer, sendSocket, sendPacket);

		//sendBall(sendBallBuffer, sendBallSocket, sendBallPacket);
	}

	protected void receiveBall() {
		receive(receiveBallSocket, receiveBallPacket);

		ballX = ((int) receiveBallBuffer[1]) + 128;
		ballY = ((int) receiveBallBuffer[2]) + 128;
		ballVX = receiveBallBuffer[3];
		ballVY = receiveBallBuffer[4];

		lostN = receiveBallBuffer[5];
		lostS = receiveBallBuffer[6];
		lostW = receiveBallBuffer[7];
		lostE = receiveBallBuffer[8];

		gameOver = receiveBallBuffer[9] > 0 ? true : false;
	}

	protected void moveRacketN() {
		racketNV = (racketNXD - racketNX) >> 1;

		racketNX += racketNV;
	}

	protected void sendRacketN(
		byte[] sendBuffer,
		MulticastSocket sendSocket,
		DatagramPacket sendPacket) {
		sendBuffer[0] = RACKET_N;

		sendBuffer[1] = (byte) (racketNX - 128);
		sendBuffer[2] = (byte) racketNV;

		send(sendSocket, sendPacket);
	}

	protected void sendRacketN() {
		sendRacketN(sendBuffer, sendSocket, sendPacket);

		//sendRacketN(sendRacketNBuffer, sendRacketNSocket, sendRacketNPacket);
	}

	protected void receiveRacketN() {
		receive(receiveRacketNSocket, receiveRacketNPacket);

		racketNX = ((int) receiveRacketNBuffer[1]) + 128;
		racketNV = receiveRacketNBuffer[2];
	}

	protected void moveRacketS() {
		racketSV = (racketSXD - racketSX) >> 1;

		racketSX += racketSV;
	}

	protected void sendRacketS(
		byte[] sendBuffer,
		MulticastSocket sendSocket,
		DatagramPacket sendPacket) {
		sendBuffer[0] = RACKET_S;

		sendBuffer[1] = (byte) (racketSX - 128);
		sendBuffer[2] = (byte) racketSV;

		send(sendSocket, sendPacket);
	}

	protected void sendRacketS() {
		sendRacketS(sendBuffer, sendSocket, sendPacket);

		//sendRacketS(sendRacketSBuffer, sendRacketSSocket, sendRacketSPacket);
	}

	protected void receiveRacketS() {
		receive(receiveRacketSSocket, receiveRacketSPacket);

		racketSX = ((int) receiveRacketSBuffer[1]) + 128;
		racketSV = receiveRacketSBuffer[2];
	}

	protected void moveRacketW() {
		racketWV = (racketWYD - racketWY) >> 1;

		racketWY += racketWV;
	}

	protected void sendRacketW(
		byte[] sendBuffer,
		MulticastSocket sendSocket,
		DatagramPacket sendPacket) {
		sendBuffer[0] = RACKET_W;

		sendBuffer[1] = (byte) (racketWY - 128);
		sendBuffer[2] = (byte) racketWV;

		send(sendSocket, sendPacket);
	}

	protected void sendRacketW() {
		sendRacketW(sendBuffer, sendSocket, sendPacket);

		//sendRacketW(sendRacketWBuffer, sendRacketWSocket, sendRacketWPacket);
	}

	protected void receiveRacketW() {
		receive(receiveRacketWSocket, receiveRacketWPacket);

		racketWY = ((int) receiveRacketWBuffer[1]) + 128;
		racketWV = receiveRacketWBuffer[2];
	}

	protected void moveRacketE() {
		racketEV = (racketEYD - racketEY) >> 1;

		racketEY += racketEV;
	}

	protected void sendRacketE(
		byte[] sendBuffer,
		MulticastSocket sendSocket,
		DatagramPacket sendPacket) {
		sendBuffer[0] = RACKET_E;

		sendBuffer[1] = (byte) (racketEY - 128);
		sendBuffer[2] = (byte) racketEV;

		send(sendSocket, sendPacket);
	}

	protected void sendRacketE() {
		sendRacketE(sendBuffer, sendSocket, sendPacket);

		//sendRacketE(sendRacketEBuffer, sendRacketESocket, sendRacketEPacket);
	}

	protected void receiveRacketE() {
		receive(receiveRacketESocket, receiveRacketEPacket);

		racketEY = ((int) receiveRacketEBuffer[1]) + 128;
		racketEV = receiveRacketEBuffer[2];
	}

	protected void repaintGame() {
		repaint();
	}

	private void randomBallV() {
		ballVX = ((int) (Math.random() * 2)) == 0 ? -1 : 1;

		int randomV = ((int) (Math.random() * SPEED_LIMIT / 3)) + (SPEED_LIMIT / 3);

		ballVX = ballVX * randomV;

		ballVY = ((int) (Math.random() * 2)) == 0 ? -1 : 1;

		if (ballVX > 0)
			ballVY = ballVY * (SPEED_LIMIT - ballVX);
		else
			ballVY = ballVY * (SPEED_LIMIT + ballVX);
	}

	private class MouseFollower extends MouseAdapter {
		public void mouseReleased(MouseEvent event) {
			int x = event.getX();
			int y = event.getY();

			if (y < boardN || y > boardS) {
				if (x > boardW && x < boardE) {
					if (x < boardW + racketNSDXH)
						x = boardW;
					else if (x > boardE - racketNSDXH)
						x = boardE - racketNSDX;
					else
						x = x - racketNSDXH;

					if (y < boardN)
						racketNXD = x;
					else
						racketSXD = x;
				} else
					return;
			} else if (x < boardW || x > boardE) {
				if (y < boardN + racketWEDYH)
					y = boardN;
				else if (y > boardS - racketWEDYH)
					y = boardS - racketWEDY;
				else
					y = y - racketWEDYH;

				if (x < boardW)
					racketWYD = y;
				else
					racketEYD = y;
			} else
				startGame = true;

			// System.out.println(racketNXD + ", " + racketSXD + ", " + racketWYD + ", " + racketEYD);
		}
	}

	protected void exitGame() {
		receiver.exitReceiver = true;

		sendSocket.close();

		/*
				try {
					receiveBallSocket.leaveGroup(ballGroup);
					receiveRacketNSocket.leaveGroup(racketNGroup);
					receiveRacketSSocket.leaveGroup(racketSGroup);
					receiveRacketWSocket.leaveGroup(racketWGroup);
					receiveRacketESocket.leaveGroup(racketEGroup);
				} catch (IOException e) {
					throw new RuntimeException("Cannot leave multicast group!");
				}
		
				sendBallSocket.close();
				sendRacketNSocket.close();
				sendRacketSSocket.close();
				sendRacketWSocket.close();
				sendRacketESocket.close();
		
				receiveBallSocket.close();
				receiveRacketNSocket.close();
				receiveRacketSSocket.close();
				receiveRacketWSocket.close();
				receiveRacketESocket.close();
		*/

		gameFrame.dispose();
	}

	private class ExitListener extends WindowAdapter {
		public void windowClosing(WindowEvent event) {
			goBall = false;
		}
	}

}
