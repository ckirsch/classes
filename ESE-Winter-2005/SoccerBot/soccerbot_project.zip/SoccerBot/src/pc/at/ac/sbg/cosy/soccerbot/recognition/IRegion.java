/* SoccerBot - Recognition Library - IRegion
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;

/**
 * IRegion defines a set of (4-connected) pixels that is used to give
 * a semantic description of an image.
 * @author Peter Wild
 *
 */
public interface IRegion extends Comparable{
	/**
	 * Returns region id (may be used for retrieving additional region information)
	 * @return unique region id
	 */
	int getId();
	
	/**
	 * Sets the region id (may be used for retrieving additional region information) 
	 * @param id region identifier
	 */
	void setId(int id);
	
	/**
	 * Returns hsv value in 32-bit hsv format (0xHHHHSSVV)
	 * @return average hsv value encoded in 32-bit format (0xHHHHSSVV)
	 */
	int getHSV();
	
	/**
	 * Sets the region hsv value
	 * @param hsv average hsv value encoded in 32-bit format (0xHHHHSSVV)
	 */
	void setHSV(int hsv);
	
	/**
	 * Returns the center x-coordinate (midpoint) of the recognized region (used for robot navigation) 
	 * @return center of region
	 */
	int getCenter_X();
	
	/**
	 * Returns the center y-coordinate (midpoint) of the recognized region (used for robot navigation) 
	 * @return center of region
	 */
	int getCenter_Y();
	/**
	 * sets the center x-coordinate (midpoint) of the recognized region (used for robot navigation)
	 * @param center_x center of region
	 */
	void setCenter_X(int center_x);
	
	/**
	 * sets the center y-coordinate (midpoint) of the recognized region (used for robot navigation)
	 * @param center_y center of region
	 */
	void setCenter_Y(int center_y);
	/**
	 * Returns the maximum width of the region
	 * @return width of region
	 */
	int getWidth();
	/**
	 * Sets the maximum width of the region
	 * @param width width of region
	 */
	void setWidth(int width);
	/**
	 * Returns the maximum height of the region
	 * @return height of region
	 */
	int getHeight();
	/**
	 * Sets the maximum height of the region
	 * @param height height of region
	 */
	void setHeight(int height);
	/**
	 * Returns the numberf of pixels within the region
	 * @return number of pixels
	 */
	int getSize();
	/**
	 * Sets the size (number of pixels) of the region
	 * @param size number of pixels
	 */
	void setSize(int size);
	/**
	 * Returns information whether region may be clipped (at boundary of image)
	 * @return whether region is clipped
	 */
	boolean getClipped();
	/**
	 * Sets clipping information (at boundary of image)
	 * @param clipped whether region is clipped
	 */
	void setClipped(boolean clipped);
	
	/**
	 * Deep copy of region
	 * @return deep copy
	 */
	IRegion copy();
}
