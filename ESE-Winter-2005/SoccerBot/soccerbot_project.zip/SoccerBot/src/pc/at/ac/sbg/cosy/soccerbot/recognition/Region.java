/* SoccerBot - Recognition Library - Region
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;

/**
 * Region for Split and Merge Technique
 * @author Peter Wild
 *
 */
public class Region implements IRegion{
	
	private int id, hsv, center_x, center_y, height, width, size;
	private boolean clipped;
	
	/**
	 * Default Constructor
	 *
	 */
	public Region(){
		this(0,0,0,0,0,0,0,false);
	}

	/**
	 * Constructor
	 * @param id number of the region
	 * @param hsv average color value in hsv
	 * @param center_x center x-coordinate
	 * @param center_y center y-coordinate
	 * @param height height of the region
	 * @param width width of the region
	 * @param size number of pixels within region
	 * @param clipped intersects with image boundary
	 */
	public Region(int id, int hsv, int center_x, int center_y, int height, int width, int size, boolean clipped)
	{
		this.id = id;
		this.hsv = hsv;
		this.center_x = center_x;
		this.center_y = center_y;
		this.height = height;
		this.width = width;
		this.size = size;
		this.clipped = clipped;
	}
	/**
	 * @see IRegion#getId()
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * @see IRegion#getHSV()
	 */
	public int getHSV() {
		return this.hsv;
	}

	/**
	 * @see IRegion#getCenter_X()
	 */
	public int getCenter_X() {
		return this.center_x;
	}

	/**
	 * @see IRegion#getCenter_Y()
	 */
	public int getCenter_Y() {
		return this.center_y;
	}

	/**
	 * @see IRegion#getHeight()
	 */
	public int getHeight() {
		return this.height;
	}

	/**
	 * @see IRegion#getSize()
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * @see IRegion#getWidth()
	 */
	public int getWidth() {
		return this.width;
	}
	
	/**
	 * @see IRegion#setHSV(int)
	 */
	public void setHSV(int hsv) {
		this.hsv = hsv;
	}

	/**
	 * @see IRegion#setCenter_X(int)
	 */
	public void setCenter_X(int center_x) {
		this.center_x = center_x;
	}

	/**
	 * @see IRegion#setCenter_Y(int)
	 */
	public void setCenter_Y(int center_y) {
		this.center_y = center_y;
	}

	/**
	 * @see IRegion#setHeight(int)
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * @see IRegion#setSize(int)
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * @see IRegion#setWidth(int)
	 */
	public void setWidth(int width) {
		this.width = width;
	}
	
	/**
	 * @see IRegion#setId(int)
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * @see IRegion#getClipped()
	 */
	public boolean getClipped(){
		return this.clipped;
	}
	
	/**
	 * @see IRegion#setClipped(boolean)
	 */
	public void setClipped(boolean clipped) {
		this.clipped = clipped;
	}
	
	/**
	 * For sorting, compares by region size
	 * @param region region to be compared to
	 * @return compare value
	 */
	public int compareTo(Object region) {
		if (region instanceof IRegion){
			return ((IRegion)region).getSize() - this.getSize();
		}
		throw new ClassCastException("Regions can be compared with Regions only.");
	}

	/**
	 * @see IRegion#copy()
	 */
	public IRegion copy() {
		return new Region(id, hsv, center_x, center_y, height, width, size, clipped);
	}
}
