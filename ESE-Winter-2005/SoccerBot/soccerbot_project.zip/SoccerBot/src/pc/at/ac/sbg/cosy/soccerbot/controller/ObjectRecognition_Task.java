/* SoccerBot - Giotto Controller Classes - ObjectRecognition_task
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/


package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.TaskInterface;
import giotto.functionality.table.Parameter;

import java.awt.image.BufferedImage;
import java.io.Serializable;

import at.ac.sbg.cosy.soccerbot.controller.gui.ControllerGUI;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;
import at.ac.sbg.cosy.soccerbot.recognition.SoccerRecognitionService;
import at.ac.sbg.cosy.soccerbot.recognition.splitmerge.LoadImageService;

/**
 * The main task which takes an image as input, sends it to the
 * image processing classes and acquires information about where
 * the ball is positioned within the scene. According to theses
 * information the controller decides in which direction to send the Soccerbot
 * next.
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
@SuppressWarnings("serial")
public class ObjectRecognition_Task implements TaskInterface, Serializable 
{	
	/**
	 * @see TaskInterface#run(giotto.functionality.table.Parameter)
	 */
    public void run(Parameter p) {    	
    	
    	BufferedImage inputImage = ((BufferedImage_port)p.getPortVariable(0)).getImage();
    	LoadImageService.doService(inputImage);
		SoccerRecognitionService.doService();
		IRegion ball = SoccerRecognitionService.getBall();
		if (ControllerGUI.getInstance() != null){
			ControllerGUI.getInstance().updateImage(ball);
		}
        // Set the output ports
        ((Region_port)p.getPortVariable(1)).setRegion(ball);
    }
}
