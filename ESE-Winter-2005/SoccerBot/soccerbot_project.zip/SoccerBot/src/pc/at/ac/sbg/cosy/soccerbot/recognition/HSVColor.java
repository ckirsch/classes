/* SoccerBot - Recognition Library - HSVColor
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;


/**
 * Library for HSV Color conversion / information extraction
 * @author Peter Wild
 *
 */
public class HSVColor {
	/**
	 * Extracts the hue channel value out of an hsv int value
	 * @param color int-color value in 32-bit hsv format (0xHHHHSSVV)
	 * @return hue value
	 */
	public static int get_H(int color){
		return ((color >> 16) & 0xFFFF);
	}
	
	/**
	 * Extracts the saturation channel value out of an hsv int value
	 * @param color int-color value in 32-bit hsv format (0xHHHHSSVV)
	 * @return saturation value
	 */	
	public static int get_S(int color){
		return ((color >> 8) & 0xFF);
	}
	
	/**
	 * Extracts the value channel value out of an hsv int value
	 * @param color int-color value in 32-bit hsv format (0xHHHHSSVV)
	 * @return brightness (value) value
	 */
	public static int get_V(int color){
		return (color & 0xFF);
	}
	
	/**
	 * Creates an hsv format representation of three hue, saturation, value channel values
	 * hue within 0x00 - 0xFFFF, all others within 0x00 - 0xFF. Converts (h 0xFFFF, s 0xFF, v 0xFF -> hsv 0xFFFFFFFF).
	 * @param h hue value in 0x00 - 0xFFFF
	 * @param s saturation value in 0x00 - 0xFF
	 * @param v brightness (value) value in 0x00 - 0xFF
	 * @return hsv 32-bit format (0xAARRGGBB) representation
	 */
	public static int hsv(int h, int s, int v)
	{
		return (((h & 0xFFFF) << 16) | ((s & 0xFF) << 8) | (v & 0xFF));
	}
	
	/**
	 * Converts hsv values into rgb values (lossy transformation)
	 * alpha channel is not used (set to 255).
	 * @param hsv hsv 32-bit format (0xHHHHSSVV) representation
	 * @return argb 32-bit format (0xAARRGGBB) representation of according hsv
	 */
	public static int hsv2rgb(int hsv)
	{
		int r, g, b, p, q, t, s = get_S(hsv), v = get_V(hsv), i;
		double h = get_H(hsv), f;
		
		if( s == 0 ) {// achromatic (grey)
			r = v;
			g = v;
			b = v;
		}
		else {
			h = h * 6 / 65535;// sector 0 to 5
			i = (int)(h);
			f = h - i;// factorial part of h
			p = v * ( 255 - s ) / 255;
			q = (int)(v * ( 255 - s * f ) / 255);
			t = (int)(v * ( 255 - s * ( 1 - f )) / 255);
			switch( i ) {
				case 0: r = v; g = t; b = p; break;
				case 1: r = q; g = v; b = p; break;
				case 2: r = p; g = v; b = t; break;
				case 3: r = p; g = q; b = v; break;
				case 4: r = t; g = p; b = v; break;
				default: r = v; g = p; b = q; break;
			}
		}
		return RGBColor.rgb(r,g,b);
	}

}
