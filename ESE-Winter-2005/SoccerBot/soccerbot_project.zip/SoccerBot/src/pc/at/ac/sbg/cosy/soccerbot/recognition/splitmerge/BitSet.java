/* SoccerBot - SplitAndMerge Library - BitSet
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition.splitmerge;
/**
 * Library for storage of sets of single bits
 * @author Peter Wild
 *
 */
public class BitSet {
	/**
	 * Calculates the size of a new BitSet as int array which has space for at 
	 * least size bits and pads the rest (modulo 32)
	 * @param size > 0 number of bits within bitset
	 * @return int array as bit set container
	 */
	public static int calculateSize(int size)
	{
		return (size + ((32 - size % 32) % 32)) / 32;
	}
	
	/**
	 * Returns a specified bit within a bitset implemented as integer-array
	 * @param array initialized bitset
	 * @param index >= 0, < array.length * 32 position of bit within bitset
	 * @return 0 if bit is not set, 1 if bit is set
	 */
	public static int getBit(int[] array, int index)
	{
		return (array[index / 32] >> (31 - index % 32)) & 0x1;
	}
	
	/**
	 * Sets a bit within a bitset implemented as integer-array (sets bit to 1)
	 * @param array initialized bitset
	 * @param index >= 0, < array.length * 32 position of bit within bitset
	 */
	public static void setBit(int[] array, int index)
	{
		array[index / 32] |= (1 << (31 - index % 32));
	}
	
	/**
	 * Releases a bit within a bitset implemented as integer-array (sets bit to 0)
	 * @param array initialized bitset
	 * @param index >= 0, < array.length * 32 position of bit within bitset
	 */
	public static void releaseBit(int[] array, int index)
	{
		array[index / 32] &= (0xFFFFFFFF ^ 1 << (31 - index % 32));
	}
	
	/**
	 * Returns the total number of bits set to 1 within bitSet
	 * @param bitSet int array used as a set of bits that can be accessed directly
	 * @return how many bits are set to 1
	 */
	public static int bitCount(int[] bitSet){
		int count = 0, data;
    	for (int i=0; i < bitSet.length; i++)
    	{
    		data = bitSet[i];
    		if (data != 0){
    			for (int j=0; j < 32; j++){
    				count += data & 0x1;
    				data = data >> 1;
    			}
    		}
    	}
    	return count;
	}
	
	/**
	 * Returns the index of the first bit set to 1 within bitSet
	 * @param bitSet int array used as a set of bits that can be accessed directly
	 * @return first bit, that is 1
	 */
	public static int firstBit(int[] bitSet){
		int data;
    	for (int i=0; i < bitSet.length; i++)
    	{
    		data = bitSet[i];
    		if (data != 0){
    			for (int j=0; j < 32; j++){
    				if ((data & 0x80000000) != 0) return (i*32+j);
    				data = data << 1;
    			}
    		}
    	}
    	return -1;
	}
	
	/**
	 * Copies source BitSet into target Bitset, requires both BitSets to be initialized and of
	 * same length.
	 * @param sourceBitSet source of deep copy operation
	 * @param targetBitSet target of deep copy operation
	 */
	public static void copy(int[] sourceBitSet, int[] targetBitSet)
	{
		for (int i=0; i < sourceBitSet.length; i++)
			targetBitSet[i] = sourceBitSet[i];
	}
}
