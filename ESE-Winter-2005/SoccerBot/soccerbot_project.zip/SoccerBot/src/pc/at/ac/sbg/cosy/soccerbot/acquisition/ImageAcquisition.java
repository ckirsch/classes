/* SoccerBot - Image Acquisition Library
Copyright (C) 2005 Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.acquisition;

import java.awt.Dimension;
import java.awt.image.BufferedImage;

import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.Player;
import javax.media.control.FormatControl;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.util.BufferToImage;


/**
 * @author Georg Klima
 * Implements the imageacquisition.
 * Acquires images from an predefined source with an predefined resolution and colordepth.  
 */
public class ImageAcquisition implements IImageAcquisition {
	
	/**
	 * The device name URL: vfw://[Devicename]devicenumber
	 * Example: vfw://0 specifies the fist capture device, a usb webcam, must be register at the jmf.
	 */
	public static final String DEVICE = "vfw://1";
	
	/**
	 * The predefined colordepth of 24 bits.
	 */
	public static final int BIT_PER_PIXEL = 24;
	
	/**
	 * The predefined resolution of 352x288.
	 */
	public static final Dimension RESOLUTION = new Dimension(352,288); 
	
	private Player player = null;
	private FrameGrabbingControl frameGrabbingControl = null;
	private BufferToImage converter = null;
	private VideoFormat format = null;
	private static IImageAcquisition instance = null;
	
	/**
	 * Instanciates this service.
	 * Service is still not useable at its best quality since brighteness control takes some time.
	 */
	private ImageAcquisition(){
		try {
			player = Manager.createRealizedPlayer(new MediaLocator(DEVICE));
			
			frameGrabbingControl = (FrameGrabbingControl)player.getControl("javax.media.control.FrameGrabbingControl");
			FormatControl formatControl = (FormatControl)player.getControl("javax.media.control.FormatControl");
			Format [] supportedFormats = formatControl.getSupportedFormats();
			for (int i = 0 ; i < supportedFormats.length ; i++)
				if(supportedFormats[i] instanceof RGBFormat && ((RGBFormat)supportedFormats[i]).getBitsPerPixel() >= BIT_PER_PIXEL && ((RGBFormat)supportedFormats[i]).getSize().equals(RESOLUTION)){
					//System.out.println("Selected capture format: " + ((RGBFormat)supportedFormats[i]));
					formatControl.setFormat(supportedFormats[i]);
				}
			
			player.realize();
			player.prefetch();
			player.start();
		} catch (Exception e) {
			System.out.println("Error in IAS");
			e.printStackTrace();
		}
	}			
	
	/**
	 * @see ImageAcquisition#init()
	 */
	public boolean init(){
		if((format = (VideoFormat)frameGrabbingControl.grabFrame().getFormat()) != null){
			converter = new BufferToImage(format);
			return true;
		}
		return false;
	}
	
	/**
	 * Creates a new singelton instance of this service
	 */
	public static void newInstance(){
		if (instance != null){
			instance.close();
		}
		instance = new ImageAcquisition();
	}
	
	public static IImageAcquisition getInstance(){
		return instance;
	}
	
	/**
	 * @see ImageAcquisition#capture()
	 */
	public BufferedImage capture(){
		return (BufferedImage)converter.createImage(frameGrabbingControl.grabFrame());
	}
	
	/**
	 * @see ImageAcquisition#close()
	 */
	public void close(){
		player.close();
		player.deallocate();
		instance = null;
	}
	
	/**
	 * Stops this service
	 */
	protected void finalize(){
		close();
	}
	
	/**
	 * @see ImageAcquisition#getResolution()
	 */
	public Dimension getResolution() {
		return format.getSize();
	}

}
