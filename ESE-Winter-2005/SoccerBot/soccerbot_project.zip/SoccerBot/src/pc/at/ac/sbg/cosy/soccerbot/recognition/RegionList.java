/* SoccerBot - Recognition Library - RegionList
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;

import java.util.Arrays;

/**
 * Static Region List
 * @author Peter Wild
 *
 */
public class RegionList implements IRegionCollector{
	
	private static final int CONFIG_MAXCOUNT = 5000;
	private static IRegion[] regionPool = new IRegion[CONFIG_MAXCOUNT];
	private static int listSize = 0;
	private static RegionList singleton = new RegionList();
	
	/**
	 * Aquire private static singleton 
	 * @return singleton region list
	 */
	public static RegionList getInstance(){
		return singleton;
	}
	
	/**
	 * Provate constructor
	 */
	private RegionList(){
		for (int i=0; i < regionPool.length; i++){
			regionPool[i] = new Region();
		}
	}

	/**
	 * Returns current size of list
	 * @return size of list
	 */
	public int size() {
		return listSize;
	}

	/**
	 * Returns emptyness of list
	 * @return true, if this list is empty
	 */
	public boolean isEmpty() {
		return (listSize==0);
	}

	/**
	 * Returns the index-th region
	 * @param index index which region to return
	 * @return region at position index
	 */
	public IRegion getRegion(int index) {
		return regionPool[index % CONFIG_MAXCOUNT];
	}

	/**
	 * Shallow reset
	 */
	public void reset(){
		listSize = 0;
	}
	
	/**
	 * Increases the number of accessible elements by 1
	 */
	public void increment(){
		listSize++;
	}
	
	/**
	 * Does a region sorting of all accessible regions
	 */
	public void sort(){
		if (!isEmpty()) Arrays.sort(regionPool,0,listSize - 1);
	}

	/**
	 * @see IRegionCollector#addRegion(int, int, int, int, int, int, int, boolean)
	 */
	public void addRegion(int id, int hsv, int center_x, int center_y, int height, int width, int size, boolean clipped) {
		IRegion regionToChange = regionPool[listSize % CONFIG_MAXCOUNT];
		regionToChange.setId(id);
		regionToChange.setHSV(hsv);
		regionToChange.setCenter_X(center_x);
		regionToChange.setCenter_Y(center_y);
		regionToChange.setHeight(height);
		regionToChange.setWidth(width);
		regionToChange.setSize(size);
		regionToChange.setClipped(clipped);
		increment();
	}
}
