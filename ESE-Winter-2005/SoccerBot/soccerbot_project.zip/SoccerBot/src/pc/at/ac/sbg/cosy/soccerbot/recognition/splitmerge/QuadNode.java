/* SoccerBot - SplitAndMerge Library - QuadNode
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition.splitmerge;

/**
 * Library for linear (array) representation of quadtree nodes
 * @author Peter Wild
 *
 */
public class QuadNode {
	
	/**
	 * Calculates the logarithus dualis ld to a given number > 0 by shifting
	 * @param number > 0 natural number
	 * @return ld(number)
	 */
	private static int log2(int number){
		int result = 0;
		for (int i=1; result<31 && (i <= number); result++){
			i = i << 1;
		}
		return result-1;
	}
	
	/**
	 * Calculates the maximum hierarchy level if image is decomosed using quadtrees.
	 * @param size > 0, has to be a power of 2 (1,2,4,8,16,32,64,128,256,512) image width of square image
	 * @return maxumum hierarchy of quadtree for full decomposition
	 */
	public static int calculateMaxHierarchy(int size)
	{
		return log2(size);
	}
	
	/**
	 * Creates a new array of QuadNode int values that can be indexed using
	 * the method position() with the Quad_Tree format (quad_h, quad_x, quad_y).
	 * @param mayHierarchy maximum hierarchy
	 * @return array holding full Quad Tree information to a square image of size 2^{maxHierarchy}
	 */
	public static int calculateSize(int mayHierarchy)
	{
		return (1 - (1 << (2*(mayHierarchy+1)))) / (1 - 4);
	}
	
	/**
	 * Conversion Quad_Tree format (quad_h, quad_x, quad_y) -> Linear array.
	 * 
	 * Calculates array position according to formula of geometric series: 
	 * 
	 * position = (1 - 4^{quad_h}) / (1 - 4) + quad_x + quad_y * (2^{quad_h}), that is
	 * position = #slots_occupied_by_previous_hierarchies + #columns + #lines*line_length.   
	 * 
	 * @param quad_h >= 0 Hierarchy level quad_h starting at 0 - whole image
	 * @param quad_x >= 0, < 2^{quad_h} Quadtree node raster distance from left (column) x-position quad_x starting at 0 - leftmost
	 * @param quad_y >= 0, < 2^{quad_h} Quadtree node raster distance from top (line) y-position quad_y starting at 0 - top
	 * @return Quadtree array position  p ( 0 <= p < (1 - 4^{max_h}) / (1 - 4))
	 */
	// Example:
	// +---------------+
	// |               |
	// |               | 
    // |               |
	// |       0       |     0: quad_h = 0, quad_x = 0, quad_y = 0;
	// |               |
	// |               |
	// |               |
	// +---------------+
	// 
	// +-------+-------+
	// |       |       |
	// |   1   |   2   |     1: quad_h = 1, quad_x = 0, quad_y = 0;
	// |       |       |     2: quad_h = 1, quad_x = 1, quad_y = 0;
	// +-------+-------+     3: quad_h = 1, quad_x = 0, quad_y = 1;
	// |       |       |     4: quad_h = 1, quad_x = 1, quad_y = 1;
	// |   3   |   4   |
	// |       |       |
	// +-------+-------+
	// 
	// +---+---+---+---+
	// | 5 | 6 | 7 | 8 |     5: quad_h = 2, quad_x = 0, quad_y = 0;
	// +---+---+---+---+     6: quad_h = 2, quad_x = 1, quad_y = 0;
	// | 9 |10 |11 |12 |     7: quad_h = 2, quad_x = 2, quad_y = 0;
	// +---+---+---+---+     8: quad_h = 2, quad_x = 3, quad_y = 0;
	// |13 |14 |15 |16 |     ...
	// +---+---+---+---+     19: quad_h = 2, quad_x = 2, quad_y = 3;
	// |17 |18 |19 |20 |     20: quad_h = 2, quad_x = 3, quad_y = 3;
	// +---+---+---+---+
	//
	public static int position(int quad_h, int quad_x, int quad_y){
		return (1 - (1 << 2*quad_h)) / (1 - 4) + quad_x + quad_y * (1 << quad_h);
	}
	
	/**
	 * Reversing the formula from QuadNode.position this calculates the 
	 * first parameter quad_h of the Quad_Tree format (quad_h, quad_x, quad_y)
	 * out of the linear representation. The formula is derived inverting 
	 * 
	 * position = (1 - 4^{quad_h}) / (1 - 4) + quad_x + quad_y * (2^{quad_h), 
	 * 
	 * since (1 - 4^{quad_h}) / (1 - 4) is monotone ascending and the additional part
	 * A = quad_x + quad_y * (2^{quad_h)) can be bounded by 4^{quad_h}.
	 * @param position linear array position of quadtree node
	 * @return quad_h for Quad_Tree format
	 */
	public static int quad_h(int position){
		return log2(1-position*(1-4))/2;
	}
	
	/**
	 * Reversing the formula from QuadNode.position this calculates the 
	 * second parameter quad_x of the Quad_Tree format (quad_h, quad_x, quad_y)
	 * out of the linear representation. The formula is derived using
	 * 
	 * position = (1 - 4^{quad_h}) / (1 - 4) + quad_x + quad_y * (2^{quad_h).
	 * 
	 * @param quad_h >= 0 Hierarchy level quad_h starting at 0 - whole image
	 * @param position linear array position of quadtree node
	 * @return quad_x for Quad_Tree format
	 */
	public static int quad_x(int quad_h, int position){
		return (position - ((1 - (1 << 2*quad_h)) / (1 - 4))) % (1 << quad_h);
	}
	
	/**
	 * Reversing the formula from QuadNode.position this calculates the 
	 * second parameter quad_y of the Quad_Tree format (quad_h, quad_x, quad_y)
	 * out of the linear representation. The formula is derived using
	 * 
	 * position = (1 - 4^{quad_h}) / (1 - 4) + quad_x + quad_y * (2^{quad_h).
	 * 
	 * @param quad_h >= 0 Hierarchy level quad_h starting at 0 - whole image
	 * @param position linear array position of quadtree node
	 * @return quad_y for Quad_Tree format
	 */
	public static int quad_y(int quad_h, int position){
		return (position - ((1 - (1 << 2*quad_h)) / (1 - 4))) / (1 << quad_h);
	}
	
	/**
	 * Returns all child positions (as linear array positions) of a given quadtree node
	 * (as linear array position). Calculates positions according to the following formula:
	 * 
	 * position -> (quad_h, quad_x, quad_y) -> child 0: (quad_h + 1, 2*quad_x, 2*quad_y)
	 *                                      -> child 1: (quad_h + 1, 2*quad_x + 1, 2*quad_y)
	 *                                      -> child 2: (quad_h + 1, 2*quad_x, 2*quad_y + 1)
	 *                                      -> child 3: (quad_h + 1, 2*quad_x + 1, 2*quad_y + 1)
	 * 
	 * 
	 * 
	 * @param child_num >= 0, < 4 child number 
	 * @param position linear array position of quadtree node to which childs are to be calculated
	 * @return linear array position of child child_num
	 */
	// Example: 
	// +-------+-------+
	// |       |       |		parent node 3 in hierarchy level 1.
	// |   1   |   2   |     	calculating children of node 3 in hierarchy level 2.
	// |       |       |     	
	// +-------+-------+        +---+---+
	// |       |       |        |13 |14 |
	// |   3   |   4   |   -->  +---+---+
	// |       |       |        |17 |18 |
	// +-------+-------+        +---+---+
	// child_position(0,3) -> 13
	// child_position(1,3) -> 14
	// child_position(2,3) -> 17
	// child_position(3,3) -> 18 
	//
	public static int child_position(int child_num, int position)
	{
		int quad_h = quad_h(position);
		return position(quad_h + 1, 2*quad_x(quad_h,position) + child_num % 2,2*quad_y(quad_h,position) + child_num / 2);
	}
	
	/**
	 * Returns parent position (as linear array positions) of a given quadtree node
	 * (as linear array position). Calculates position according to the following formula:
	 * 
	 * position -> (quad_h, quad_x, quad_y) -> parent: (quad_h - 1, ceil(quad_x/2), ceil(quad_y/2))
	 * @param position linear array position of quadtree node to which parent is to be calculated
	 * @return linear array position of parent
	 */
	public static int parent_position(int position)
	{
		int quad_h = quad_h(position);
		return position(quad_h - 1, quad_x(quad_h,position)/2,quad_y(quad_h,position)/2);
	}
	
	/**
	 * Calculates the upper left coordinate of a quadNode within the observed image.
	 *   
	 * 
	 * @param position linear array position of quadtree node to which image coordinate is to be calculated
	 * @param imageHierarchy Level, at which the image is contained (for which it starts at index 0)
	 * @return upper left pixel coordinate (starting at upper left index 0) where QuadNode starts
	 */
	// Example:
	// QuadTree at level 1:
	// +-------+-------+
	// |       |       |
	// |   1   |   2   |
	// |       |       | 
	// +-------+-------+     QuadtreeNode at position 3 (1,0,1) in quadtree format (quad_h, quad_x, quad_y)
	// |       |       |     maps to the following Coordinates within the image at hierarchy level 2:
	// |   3   |   4   |
	// |       |       |
	// +-------+-------+
	// 
	// Image at level 2:
	// +---+---+---+---+
	// | 0 | 1 | 2 | 3 | 
	// +---+---+---+---+
	// | 4 | 5 | 6 | 7 |
	// +---+---+---+---+     upperLeft(3,2) --> 8, because 8 is the upper left pixel which corresponds to
	// | 8 | 9 |10 |11 |     QuadtreeNode 3
	// +---+---+---+---+ 
	// |12 |13 |14 |15 |
	// +---+---+---+---+  
	//
	public static int upperLeft(int position,int imageHierarchy){
		int quad_h = quad_h(position);
		return quad_x(quad_h,position) * (1 << (imageHierarchy - quad_h)) + quad_y(quad_h,position) * (1 << (imageHierarchy - quad_h)) * (1 << imageHierarchy);
	}
	
	/**
	 * Calculates the lower right coordinate of a quadNode within the observed image.   
	 * 
	 * @param position linear array position of quadtree node to which image coordinate is to be calculated
	 * @param imageHierarchy Level, at which the image is contained (for which it starts at index 0)
	 * @return lower right pixel coordinate (starting at upper left index 0) where QuadNode ends
	 */
	// Example:
	// 
	// QuadTree at level 1:
	// +-------+-------+
	// |       |       |
	// |   1   |   2   |
	// |       |       | 
	// +-------+-------+     QuadtreeNode at position 3 (1,0,1) in quadtree format (quad_h, quad_x, quad_y)
	// |       |       |     maps to the following Coordinates within the image at hierarchy level 2:
	// |   3   |   4   |
	// |       |       |
	// +-------+-------+
	// 
	// Image at level 2:
	// +---+---+---+---+
	// | 0 | 1 | 2 | 3 | 
	// +---+---+---+---+
	// | 4 | 5 | 6 | 7 |
	// +---+---+---+---+     lowerRight(3,2) --> 13, because 13 is the lower right pixel which corresponds to
	// | 8 | 9 |10 |11 |     QuadtreeNode 3
	// +---+---+---+---+ 
	// |12 |13 |14 |15 |
	// +---+---+---+---+ 
	public static int lowerRight(int position, int imageHierarchy){
		int quad_h = quad_h(position);
		return (quad_x(quad_h,position) + 1) * (1 << (imageHierarchy - quad_h)) - 1 + ((quad_y(quad_h,position) + 1) * (1 << (imageHierarchy - quad_h))-1)* (1 << imageHierarchy);
	}
	
	/**
	 * Calculates the position of neighbor situated at the right/lower/left/upper side 
	 * of the quadtree node, if it exists, else returns -1 as error value.
	 * 
	 * 
	 * 
	 * @param neighbor_num >= 0, < 4 neighbor number (0: right, 1: lower, 2: left, 3: upper)  
	 * @param position linear array position of quadtree node to which image coordinate is to be calculated
	 * @return linear array position of neighboring node at the same hierarchy level
	 */
	// Example:
	// +---+---+---+---+	hierarchyNeighbor(0,14) -> 15
	// | 5 | 6 | 7 | 8 |	hierarchyNeighbor(1,14) -> 18
	// +---+---+---+---+	hierarchyNeighbor(2,14) -> 13
	// | 9 |10 |11 |12 |	hierarchyNeighbor(3,14) -> 10
	// +---+---+---+---+	hierarchyNeighbor(0,16) -> -1 (does not exist)
	// |13 |14 |15 |16 | 	hierarchyNeighbor(1,18) -> -1 (does not exist)
	// +---+---+---+---+ 	hierarchyNeighbor(2,13) -> -1 (does not exist)
	// |17 |18 |19 |20 |	hierarchyNeighbor(3,6) -> -1 (does not exist)
	// +---+---+---+---+  
	//
	public static int hierarchyNeighbor(int neighbor_num, int position)
	{
		int quad_h = quad_h(position), coord;
		int result = -1;
		if (neighbor_num % 4 == 0){ // right neighbor
			coord = quad_x(quad_h,position);
			if (coord < (1 << quad_h) - 1) result = position + 1;
		}
		else if (neighbor_num % 4 == 1){ // lower neighbor
			coord = quad_y(quad_h,position);
			if (coord < (1 << quad_h) - 1) result = position + (1 << quad_h);
		}
		else if (neighbor_num % 4 == 2){ // left neighbor
			coord = quad_x(quad_h,position);
			if (coord > 0) return position - 1;
		}
		else { // upper neighbor
			coord = quad_y(quad_h,position);
			if (coord > 0) return position - (1 << quad_h);
		}
		return result;
	}
}
