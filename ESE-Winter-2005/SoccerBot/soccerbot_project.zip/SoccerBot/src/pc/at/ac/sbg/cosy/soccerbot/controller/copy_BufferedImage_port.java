/* SoccerBot - Giotto Controller Classes - copy_BufferedImage_port
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.DriverInterface;
import giotto.functionality.table.Parameter;

import java.io.Serializable;

/**
 * Additional Class needed for the BufferedImage_port:
 * copies the image from one port variable to the other
 * (Be aware, that only a reference is passed here, so
 * the BufferedImage isn't realy copied)!
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
@SuppressWarnings("serial")
public class copy_BufferedImage_port implements DriverInterface, Serializable {

	/**
     * @see giotto.functionality.interfaces.DriverInterface#run(Parameter)
     */
    public void run(Parameter p) {
        BufferedImage_port b0 = (BufferedImage_port)p.getPortVariable(0);
        BufferedImage_port b1 = (BufferedImage_port)p.getPortVariable(1);
        b1.copyValueFrom(b0);
    }
}
