/* SoccerBot - Image Acquisition Library
Copyright (C) 2005 Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.acquisition;

import java.awt.Dimension;
import java.awt.image.BufferedImage;

public interface IImageAcquisition {

	/**
	 * Captures a Image from the capture device DEVICE and returns it as a java.awt.Image
	 * @return Returns a java.awt.Image containing the captured Image.
	 */
	public BufferedImage capture();

	/**
	 * Terminates this service, after calling this methode the service is no longer available. 
	 */
	public void close();
	
	/**
	 * Once the capture device has settled this function returns the resolution of the captured image.
	 * @return returns the resolution of the captured image.
	 */
	public Dimension getResolution();
	
	/**
	 * Tries to init this service
	 * @return returns true if successful </br> returns false if unsuccessful
	 */
	public boolean init();



}