/* SoccerBot - SplitAndMerge Library - LoadImageService
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition.splitmerge;

import java.awt.image.BufferedImage;

/**
 * Service for loading a buffered image into the SplitMergeService
 * @author Peter Wild
 *
 */
public class LoadImageService {
	/**
	 * Retrieves image data out of a bufferedImage
	 * stores as int array of 32 bit argb format image data (0xAARRGGBB)
	 * @param pic buffered image to extract image content
	 * @param target int array where to store image data
	 * @param offset offset within target
	 * @param startX starting X position within pic
	 * @param startY starting Y position wihin pic
	 */
	private static void getImageData(BufferedImage pic, int[] target, int offset, int startX, int startY){
		pic.getRGB(startX,startY,SplitMergeService.CONFIG_IMGSIZE,SplitMergeService.CONFIG_IMGSIZE,target,offset,SplitMergeService.CONFIG_IMGSIZE); 
	}
	
	/**
	 * Retrieves image data out of a bufferedImage and crops, if necessary
	 * pic has to be of size > 256x256
	 * stores as int array of 32 bit argb format image data (0xAARRGGBB)
	 * @param pic buffered image to extract image content
	 * @param target int array where to store image data
	 * @param offset offset within target
	 */
	private static void getCroppedImageData(BufferedImage pic, int[] target, int offset){
		getImageData(pic,target,offset,(pic.getWidth()-SplitMergeService.CONFIG_IMGSIZE)/2,(pic.getHeight()-SplitMergeService.CONFIG_IMGSIZE)/2);
	}
	
	/**
	 * Loads an image of size > 256x256 into SplitMergeService
	 * @param image image to be loaded
	 */
	public static void doService(BufferedImage image)
	{
		getCroppedImageData(image,SplitMergeService.QUADTREE_AV,QuadNode.position(SplitMergeService.CONFIG_MAXHIERARCHY,0,0));
	}
}
