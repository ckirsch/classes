/* SoccerBot - Graphical Controller - ControllerGUI
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller.gui;

import java.awt.Color;
import java.awt.TextArea;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JLabel;
import at.ac.sbg.cosy.soccerbot.recognition.HSVColor;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;
import at.ac.sbg.cosy.soccerbot.recognition.RGBColor;
import at.ac.sbg.cosy.soccerbot.recognition.bestfit.BestFitBallDetectService;
import at.ac.sbg.cosy.soccerbot.recognition.splitmerge.SplitMergeService;

/**
 * Graphical user interface
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 *
 */
@SuppressWarnings("serial")
public class ControllerGUI extends JFrame implements IControllerGUI{

	private JPanel jContentPane = null;
	private JMenuBar mnbMenu = null;
	private JMenu mnuHelp = null;
	private JMenuItem mniAbout = null;
	private JLabel lblImage = null;
	private TextArea txaConsole = null;
	private BufferedImage image = new BufferedImage(SplitMergeService.CONFIG_IMGSIZE, SplitMergeService.CONFIG_IMGSIZE,BufferedImage.TYPE_INT_RGB);
	private JMenu mnuCalibrate = null;
	private JMenuItem mniBall = null;
	private JPanel pnlBallColor = null;
	private JPanel pnlThreshold = null;
	private static ControllerGUI singleton = null;
	
	/**
	 * Creates a new instance of a GUI
	 */
	public static void newInstance(){
		if (singleton != null){
			singleton.dispose();
		}
		singleton = new ControllerGUI();
		singleton.setVisible(true);
	}
	
	/**
	 * Returns the current instance
	 * @return current GUI instance
	 */
	public static IControllerGUI getInstance(){
		return singleton;
	}
	
	/**
	 * Writes some text to internal console
	 * @param text message to be displayed
	 */
	public static void write(String text){
		if (getInstance() != null) getInstance().addText(text);
	}
	
	/**
	 * This is the default constructor
	 */
	public ControllerGUI() {
		super();
		initialize();
	}

	/**
	 * Initialization procedure
	 */
	private void initialize() {
		this.setName("frmControllerGUI");
		this.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
		this.setJMenuBar(getMnbMenu());
		this.setBounds(new java.awt.Rectangle(0,0,400,600));
		this.setContentPane(getJContentPane());
		this.setTitle("SoccerBot Controller");
		this.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent e) {
				singleton = null;
				ControllerGUI.this.setVisible(false);
				JOptionPane.showMessageDialog(ControllerGUI.this,"Shutdown complete","SoccerBot Exit Notification",JOptionPane.INFORMATION_MESSAGE);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			lblImage = new JLabel();
			lblImage.setBounds(new java.awt.Rectangle(0,0,256,256));
			lblImage.setText("");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(lblImage, null);
			jContentPane.add(getTxaConsole(), null);
			jContentPane.add(getPnlBallColor(), null);
			jContentPane.add(getPnlThreshold(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes mnbMenu
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getMnbMenu() {
		if (mnbMenu == null) {
			mnbMenu = new JMenuBar();
			mnbMenu.add(getMnuHelp());
			mnbMenu.add(getMnuCalibrate());
		}
		return mnbMenu;
	}

	/**
	 * This method initializes mnuHelp
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMnuHelp() {
		if (mnuHelp == null) {
			mnuHelp = new JMenu();
			mnuHelp.setText("Help");
			mnuHelp.add(getMniAbout());
		}
		return mnuHelp;
	}

	/**
	 * This method initializes mniAbout	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMniAbout() {
		if (mniAbout == null) {
			mniAbout = new JMenuItem();
			mniAbout.setText("About");
			mniAbout.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JOptionPane.showMessageDialog(ControllerGUI.this,"SoccerBot Controller\nA project for PS Echtzeitsysteme WS 2005, University of Salzburg\nProject team: Peter Wild, Georg Klima, Krystian Szczurek.\nAcademic supervisor: Christoph Kirsch.","About SoccerBot",JOptionPane.INFORMATION_MESSAGE);
				}
			});
		}
		return mniAbout;
	}

	/**
	 * This method initializes txaConsole	
	 * @return javax.swing.JTextArea	
	 */
	private TextArea getTxaConsole() {
		if (txaConsole == null) {
			txaConsole = new TextArea();
			txaConsole.setBounds(new java.awt.Rectangle(0,280,392,270));
		}
		return txaConsole;
	}

	/**
	 * This method initializes mnuCalibrate		
	 * @return javax.swing.JMenu	
	 */
	private JMenu getMnuCalibrate() {
		if (mnuCalibrate == null) {
			mnuCalibrate = new JMenu();
			mnuCalibrate.setText("Calibrate");
			mnuCalibrate.add(getMniBall());
		}
		return mnuCalibrate;
	}

	/**
	 * This method initializes mniBall	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getMniBall() {
		if (mniBall == null) {
			mniBall = new JMenuItem();
			mniBall.setText("Update Threshold");
			mniBall.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					BestFitBallDetectService.setHSVBallColor(RGBColor.rgb2hsv(pnlBallColor.getBackground().getRGB()));
				}
			});
		}
		return mniBall;
	}

	/**
	 * This method initializes pnlBallColor	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getPnlBallColor() {
		if (pnlBallColor == null) {
			pnlBallColor = new JPanel();
			pnlBallColor.setBounds(new java.awt.Rectangle(280,15,100,30));
			int color = HSVColor.hsv2rgb(BestFitBallDetectService.getHSVBallColor());
			pnlBallColor.setBackground(new Color(color));
		}
		return pnlBallColor;
	}

	/**
	 * This method initializes pnlThreshold	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getPnlThreshold() {
		if (pnlThreshold == null) {
			pnlThreshold = new JPanel();
			pnlThreshold.setBounds(new java.awt.Rectangle(280,50,100,30));
			int color = HSVColor.hsv2rgb(BestFitBallDetectService.getHSVBallColor());
			pnlThreshold.setBackground(new Color(color));
			pnlThreshold.addMouseListener(new java.awt.event.MouseAdapter() {
				public void mouseClicked(java.awt.event.MouseEvent e) {
					pnlThreshold.setBackground(JColorChooser.showDialog(ControllerGUI.this,"BallColor",pnlThreshold.getBackground()));
					BestFitBallDetectService.setHSVBallColor(RGBColor.rgb2hsv(pnlThreshold.getBackground().getRGB()));
					
				}
			});
		}
		return pnlThreshold;
	}
	
	/**
	 * @see IControllerGUI#addText(String)
	 */
	public synchronized void addText(String s) {
		txaConsole.setText(txaConsole.getText() + "\n" + s);
		txaConsole.setCaretPosition(txaConsole.getText().length());
	}

	/**
	 * @see IControllerGUI#updateImage(IRegion)
	 */
	public synchronized void updateImage(IRegion ball) {
		ImageUpdateService.doService(this.image,ball);
		if (ball != null) this.pnlBallColor.setBackground(new Color(HSVColor.hsv2rgb(ball.getHSV())));
		lblImage.setIcon(new ImageIcon(this.image));
		int color = HSVColor.hsv2rgb(BestFitBallDetectService.getHSVBallColor());
		pnlThreshold.setBackground(new Color(color));
	}

	/**
	 * @see IControllerGUI#close()
	 */
	public void close() {
		this.dispose();
		singleton = null;
	}
}
