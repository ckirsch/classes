/* SoccerBot - Recognition Library - LabColor
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;

/**
 * Library for Lab Color conversion / information extraction
 * @author Peter Wild
 *
 */
public class LabColor {
	
	/**
	 * Extracts the L channel value out of an argb int value
	 * @param color lab-color value in 3x64-bit lab format (0xLLLLLLLLLLLLLLLLAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBB)
	 * @return L channel value
	 */
	public static double get_L(double[] color){
		return color[0];
	}
	
	/**
	 * Extracts the a channel value out of an argb int value
	 * @param color lab-color value in 3x64-bit lab format (0xLLLLLLLLLLLLLLLLAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBB)
	 * @return a channel value
	 */
	public static double get_a(double[] color){
		return color[1];
	}
	
	/**
	 * Extracts the b channel value out of an argb int value
	 * @param color lab-color value in 3x64-bit lab format (0xLLLLLLLLLLLLLLLLAAAAAAAAAAAAAAAABBBBBBBBBBBBBBBB)
	 * @return b channel value
	 */
	public static double get_b(double[] color){
		return color[2];
	}
	
	/**
	 * Returns the distance of two Lab values
	 * @param lab1 first lab color operand
	 * @param lab2 second lab color operand
	 * @return distance in CIE Lab color space
	 */
	public static int distance(double[] lab1, double[] lab2)
	{
		return (int)Math.sqrt((lab1[0]-lab2[0])*(lab1[0]-lab2[0])+(lab1[1]-lab2[1])*(lab1[1]-lab2[1])+(lab1[2]-lab2[2])*(lab1[2]-lab2[2]));
	}
}
