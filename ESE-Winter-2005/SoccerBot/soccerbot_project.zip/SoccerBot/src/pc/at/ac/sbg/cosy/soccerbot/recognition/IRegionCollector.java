/* SoccerBot - Recognition Library - IRegionCollector
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;

/**
 * IRegionCollector defines classes capable of copllecting (new) regions
 * a semantic description of an image.
 * @author Georg Klima, Krystian Szczurek, Peter Wild
 *
 */
public interface IRegionCollector{
	/**
	 * Adds a new region to a collection
	 * @param id identification number of the region
	 * @param hsv average color in 32 bit hsv format
	 * @param center_x central x coordinate (with respect to full image)
	 * @param center_y central y coordinate (with respect to full image)
	 * @param height height of the region
	 * @param width width of the region
	 * @param size number of pixels within region
	 * @param clipped region is at boundary (clipped)
	 */
	void addRegion(int id, int hsv, int center_x, int center_y, int height, int width, int size, boolean clipped);
	
	/**
	 * Returns current size of list
	 * @return size of list
	 */
	int size();

	/**
	 * Returns the index-th region
	 * @param index index which region to return
	 * @return region at position index
	 */
	IRegion getRegion(int index);
}
