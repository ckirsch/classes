/* SoccerBot - Giotto Controller Classes - Byte_port
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.PortVariable;
import java.io.Serializable;
import at.ac.sbg.cosy.soccerbot.rcxdrive.CommandEvent;

/**
 * A port for transfering a byte message.
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
@SuppressWarnings("serial")
public class Byte_port implements PortVariable, Serializable {
	
	/**
	 * private byte
	 */
	private byte _value;

	/**
	 * Copies its internal state from a source port variable
	 */
    public void copyValueFrom(PortVariable source) {
    	_value = ((Byte_port)source).getByteValue();
    }
    
    /**
     * Returns its internal state
     * @return byte value (from controller)
     */
    public byte getByteValue() {
        return _value;
    }
    
    /**
     * Sets its internal state
     * @param value byte value
     */
    public void setByteValue(byte value) {
    	_value = value;
    }

    /**
     * Prints its state (byte value interpreted as rcxdrive.CommandEvent)
     */
    public String toString() {
    	String messageText = "";
    	
    	switch (_value)
    	{
    	case CommandEvent.CMD_STOP:
    		messageText = "STOP";
    		break;
    	case CommandEvent.CMD_FORWARD:
    		messageText = "FORWARD";
    		break;
    	case CommandEvent.CMD_REVERSE:
    		messageText = "REVERSE";
    		break;
    	case CommandEvent.CMD_CURVE_LEFT:
    		messageText = "CURVE_LEFT";
    		break;
    	case CommandEvent.CMD_CURVE_RIGHT:
    		messageText = "CURVE_RIGHT";
    		break;
    	case CommandEvent.CMD_TURN_LEFT:
    		messageText = "TURN_LEFT";
    		break;
    	case CommandEvent.CMD_TURN_RIGHT:
    		messageText = "TURN_RIGHT";
    		break;
    	default:
    		messageText = "ERROR: UNKNOWN MESSAGE ID!";
    	}
    	return _value + ": " + messageText;
    }

}
