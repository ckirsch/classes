/* SoccerBot - Recognition Library - HSVSimilarity
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;


/**
 * Library for determining similarity of colors in HSV space
 * Original hsv color similarity concept by Volker Rehrmann, University of Koblenz
 * @author Peter Wild
 *
 */
public class HSVSimilarity {
	/**
	 * HUEDISTANCE matrix
	 * direction up: less saturated
	 * direction down: more saturated
	 * direction left: darker
	 * direction right: brighter
	 */
	public static final int[][] WILD_HUEDISTANCE =
	{{360,360,360,360,360,360,360,360,360,360,360,360,360,360,360,360}, // 0
	 {360,360,360,180,180,180,180,180,180,180,180,180,180,180,180,180}, // 1
	 {360,360,360, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120, 120}, // 2
	 {360, 90, 60, 60, 60, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50}, // 3
	 {360, 60, 60, 60, 60, 70, 60, 60, 50, 50, 40, 40, 45, 45, 45, 45}, // 4
	 {360, 50, 50, 50, 40, 50, 40, 40, 40, 40, 45, 45, 47, 47, 45, 45}, // 5
	 {360, 50, 50, 50, 40, 40, 40, 40, 35, 35, 35, 37, 37, 35, 35, 35}, // 6 
	 {360, 50, 50, 50, 40, 40, 40, 40, 35, 35, 37, 37, 35, 35, 35, 35}, // 7 
	 {360, 50, 50, 50, 40, 40, 35, 35, 35, 37, 37, 35, 35, 35, 35, 35}, // 8 
	 {360, 50, 50, 50, 40, 40, 35, 35, 37, 37, 35, 35, 35, 35, 35, 35}, // 9 
	 {360, 50, 50, 40, 40, 40, 35, 37, 37, 35, 35, 35, 35, 35, 34, 34}, // 10 
	 {360, 50, 40, 37, 37, 37, 37, 37, 35, 35, 35, 35, 35, 34, 34, 33}, // 11
	 {360, 50, 40, 37, 37, 37, 37, 35, 35, 35, 35, 35, 34, 34, 33, 33}, // 12
	 {360, 50, 40, 37, 37, 37, 37, 35, 35, 35, 35, 34, 34, 33, 33, 32}, // 13
	 {360, 50, 40, 37, 37, 37, 35, 35, 35, 35, 34, 34, 33, 33, 32, 31}, // 14
	 {360, 50, 40, 37, 37, 35, 35, 35, 35, 34, 34, 33, 33, 32, 31, 30} // 15
	};
	
	/**
	 * SATDISTANCE matrix
	 */
	public static final int[][] WILD_SATDISTANCE =
	{{31, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 0
	 {31, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 1
	 {31, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 2
	 {31, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 3
	 {31, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 4
	 {31, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 5
	 {31, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8}, // 6
	 {31, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8}, // 7
	 {31, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8}, // 8
	 {31, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9}, // 9
	 {31, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9}, // 10
	 {31, 6, 7, 8, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10}, // 11
	 {31, 6, 7, 8, 9, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11}, // 12
	 {31, 6, 7, 8, 9, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11}, // 13
	 {31, 6, 7, 8, 9, 10, 10, 10, 11, 11, 12, 12, 12, 12, 12, 12}, // 14
	 {31, 6, 7, 8, 9, 10, 10, 10, 11, 11, 12, 12, 12, 12, 12, 12} // 15
	};

	/**
	 * VALDISTANCE matrix
	 */
	public static final int[][] WILD_VALDISTANCE =
	{{31, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 0
	 {31, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 1
	 {31, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 2
	 {31, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 3
	 {31, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 4
	 {31, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 5
	 {31, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 6
	 {31, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 7
	 {31, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 8
	 {31, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 9
	 {31, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 10
	 {31, 4, 5, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 11
	 {31, 4, 5, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 12
	 {31, 4, 5, 6, 6, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8}, // 13
	 {31, 4, 5, 6, 6, 7, 7, 8, 8, 8, 8, 8, 9, 9, 9, 9}, // 14
	 {31, 4, 5, 6, 6, 7, 7, 8, 8, 8, 8, 8, 9, 9, 9, 9} // 15
	};
	
	/**
	 * HUEDISTANCE matrix by Volker Rehrmann, University of Koblenz, Germany
	 * direction up: less saturated
	 * direction down: more saturated
	 * direction left: darker
	 * direction right: brighter
	 */
	public static final int[][] REHRMANN_HUEDISTANCE =
	{{360,360,360,360,360,360,360,360,360,360,360,360,360,360,360,360}, // 0
	 {360,360,360,360,360,360,360,360,360,360,360,360,360,360,360,360}, // 1
	 {360,360,360, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90}, // 2
	 {360, 30, 30, 30, 21, 20, 19, 18, 17, 16, 16, 16, 16, 16, 16, 16}, // 3
	 {360, 26, 24, 22, 20, 18, 17, 16, 15, 14, 13, 13, 13, 13, 13, 13}, // 4
	 {360, 20, 19, 18, 17, 16, 15, 15, 14, 14, 13, 13, 13, 13, 13, 13}, // 5
	 {360, 20, 18, 16, 15, 15, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13}, // 6 
	 {360, 20, 18, 16, 15, 15, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13}, // 7 
	 {360, 20, 18, 16, 15, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 8 
	 {360, 18, 17, 16, 15, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 9 
	 {360, 18, 17, 16, 15, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 10 
	 {360, 16, 15, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 11
	 {360, 16, 15, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 12
	 {360, 16, 15, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 13
	 {360, 16, 15, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13}, // 14
	 {360, 16, 15, 14, 14, 14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13} // 15
	};

	/**
	 * SATDISTANCE matrix by Volker Rehrmann, University of Koblenz, Germany
	 */
	public static final int[][] REHRMANN_SATDISTANCE =
	{{15, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 0
	 {15, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 1
	 {15, 5, 4, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 2
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 3
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 4
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 5
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 6
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 7
	 {15, 5, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 8
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 9
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 10
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 11
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 12
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 13
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 14
	 {15, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4} // 15
	};

	/**
	 * VALDISTANCE matrix by Volker Rehrmann, University of Koblenz, Germany
	 */
	public static final int[][] REHRMANN_VALDISTANCE =
	{{31, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 0
	 {31, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 1
	 {31, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, // 2
	 {31, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 3
	 {31, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, // 4
	 {31, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 5
	 {31, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4}, // 6
	 {31, 2, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, // 7
	 {31, 2, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6}, // 8
	 {31, 2, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6}, // 9
	 {31, 2, 4, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, // 10
	 {31, 2, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 11
	 {31, 2, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 12
	 {31, 2, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 13
	 {31, 2, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7}, // 14
	 {31, 2, 4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7} // 15
	};
	
	/**
	 * Checks for similarity between two hsv color values according to
	 * a similarity check by Volker Rehrmann, University of Koblenz, Germany
	 * 
	 * isSimilar(hsv1,hsv2) = true gdw.
	 * 
	 * |h1 - h2| <= hue_thresh
	 * |s1 - s2| <= sat_thresh
	 * |v1 - v2| <= val_thresh with
	 * hue_thresh = huematrix
	 * sat_thresh = satmatrix
	 * val_thresh = valmatrix
	 * 
	 * where
	 * 
	 * hi = hue value of hsvi in [0,...,360]
	 * si = saturation value of hsvi in [0...15]
	 * vi = value value of hsvi in [0...15]
	 * @param hsv1 first hsv value
	 * @param hsv2 second hsv value
	 * @return true, if both color values are similar
	 */
	public static boolean isSimilar(int hsv1, int hsv2, int[][] huematrix, int[][] satmatrix, int[][] valmatrix)
	{
		int h1 = HSVColor.get_H(hsv1) / 182, h2 = HSVColor.get_H(hsv2) / 182, s1 = HSVColor.get_S(hsv1) / 17, s2 = HSVColor.get_S(hsv2) / 17, v1 = HSVColor.get_V(hsv1) / 17, v2 = HSVColor.get_V(hsv2) / 17;
		return Math.min(Math.abs(h1 - h2),360 - Math.abs(h1 - h2)) <= huematrix[Math.min(s1,s2)][Math.max(v1,v2)] && Math.abs(s1 - s2) <= satmatrix[Math.min(s1,s2)][Math.max(v1,v2)] && Math.abs(v1 - v2) <= valmatrix[Math.min(s1,s2)][Math.max(v1,v2)];
	}
	
	/**
	 * Checks for similarity between two hsv color values according to
	 * a similarity check by Volker Rehrmann, University of Koblenz, Germany
	 * 
	 * isSimilar(hsv1,hsv2) = true gdw.
	 * 
	 * |h1 - h2| <= hue_thresh
	 * |s1 - s2| <= sat_thresh
	 * |v1 - v2| <= val_thresh with
	 * hue_thresh = REHRMANN_HUEDISTANCE[min(s1,s2),max(v1,v2)]
	 * sat_thresh = REHRMANN_SATDISTANCE[min(s1,s2),max(v1,v2)]
	 * val_thresh = REHRMANN_VALDISTANCE[min(s1,s2),max(v1,v2)]
	 * 
	 * where
	 * 
	 * hi = hue value of hsvi in [0,...,360]
	 * si = saturation value of hsvi in [0...15]
	 * vi = value value of hsvi in [0...15]
	 * @param hsv1 first hsv value
	 * @param hsv2 second hsv value
	 * @return true, if both color values are similar
	 */
	public static boolean isSimilar(int hsv1, int hsv2)
	{
		return isSimilar(hsv1, hsv2, REHRMANN_HUEDISTANCE, REHRMANN_SATDISTANCE, REHRMANN_VALDISTANCE);
	}
	
	/**
	 * Calculates the average hue value of four given (sorted) hue values withoin 0x0000-0xFFFF
	 * For the parameters the relation h1 <= h2 <= h3 <= h4 holds.
	 * @param h1 > 0, < 65535 first hue value
	 * @param h2 > 0, < 65535 second hue value
	 * @param h3 > 0, < 65535 third hue value
	 * @param h4 > 0, < 65535 fourth hue value
	 * @return average hue value of h1, h2, h3, h4
	 */
	private static int avgHue(int h1, int h2, int h3, int h4){
		int dist12 = Math.min(Math.abs(h1 - h2),65536-Math.abs(h1 - h2));
		int dist23 = Math.min(Math.abs(h2 - h3),65536-Math.abs(h2 - h3));
		int dist34 = Math.min(Math.abs(h3 - h4),65536-Math.abs(h3 - h4));
		int dist41 = Math.min(Math.abs(h4 - h1),65536-Math.abs(h4 - h1));
		int maxdist = Math.max(Math.max(dist12,dist23),Math.max(dist34,dist41));
		if (dist41 == maxdist)
			return (h1 + (dist12 + dist23 + dist34)/3) % 65535;
		else if (dist34 == maxdist)
			return (h4 + (dist41 + dist12 + dist23)/3) % 65535;
		else if (dist23 == maxdist)
			return (h3 + (dist34 + dist41 + dist12)/3) % 65535;
		else
			return (h2 + (dist23 + dist34 + dist41)/3) % 65535;
	}
	
	/**
	 * Calculates the average hsv color of four given hsv colors
	 * @param hsv1 hsv color in 32-bit hsv format (0xHHHHSSVV)
	 * @param hsv2 hsv color in 32-bit hsv format (0xHHHHSSVV)
	 * @param hsv3 hsv color in 32-bit hsv format (0xHHHHSSVV)
	 * @param hsv4 hsv color in 32-bit hsv format (0xHHHHSSVV)
	 * @return average color of hsv1, hsv2, hsv3 and hsv4
	 */
	public static int average(int hsv1, int hsv2, int hsv3, int hsv4)
	{
		int h1 = HSVColor.get_H(hsv1), h2 = HSVColor.get_H(hsv2), h3 = HSVColor.get_H(hsv3), h4 = HSVColor.get_H(hsv4);
		int hue;
		// explicit sort
		if (h1 < h2){
			if (h2 < h3){
				if (h3 < h4){
					hue = avgHue(h1, h2, h3, h4);
				}
				else {
					if (h2 < h4){
						hue = avgHue(h1, h2, h4, h3);
					}
					else {
						if (h1 < h4){
							hue = avgHue(h1, h4, h2, h3);
						}
						else{
							hue = avgHue(h4, h1, h2, h3);
						}
					}
				}
			}
			else{
				if (h1 < h3){
					if (h2 < h4){
						hue = avgHue(h1, h3, h2, h4);
					}
					else {
						if (h3 < h4){
							hue = avgHue(h1, h3, h4, h2);
						}
						else {
							if (h1 < h4){
								hue = avgHue(h1, h4, h3, h2);
							}
							else {
								hue = avgHue(h4, h1, h3, h2);
							}
						}
					}
				}
				else {
					if (h2 < h4){
						hue = avgHue(h3, h1, h2, h4);
					}
					else {
						if (h1 < h4){
							hue = avgHue(h3, h1, h4, h2);
						}
						else{
							if (h3 < h4){
								hue = avgHue(h3, h4, h1, h2);
							}
							else {
								hue = avgHue(h4, h3, h1, h2);
							}
						}
					}
				}
			}
		}
		else{
			if (h1 < h3){
				if (h3 < h4){
					hue = avgHue(h2, h1, h3, h4);
				}
				else {
					if (h1 < h4){
						hue = avgHue(h2, h1, h4, h3);
					}
					else {
						if (h2 < h4){
							hue = avgHue(h2, h4, h1, h3);
						}
						else{
							hue = avgHue(h4, h2, h1, h3);
						}
					}
				}
			}
			else{
				if (h2 < h3){
					if (h1 < h4){
						hue = avgHue(h2, h3, h1, h4);
					}
					else {
						if (h3 < h4){
							hue = avgHue(h2, h3, h4, h1);
						}
						else {
							if (h2 < h4){
								hue = avgHue(h2, h4, h3, h1);
							}
							else {
								hue = avgHue(h4, h2, h3, h1);
							}
						}
					}
				}
				else {
					if (h1 < h4){
						hue = avgHue(h3, h2, h1, h4);
					}
					else {
						if (h2 < h4){
							hue = avgHue(h3, h2, h4, h1);
						}
						else{
							if (h3 < h4){
								hue = avgHue(h3, h4, h2, h1);
							}
							else {
								hue = avgHue(h4, h3, h2, h1);
							}
						}
					}
				}
			}
		}
		
		return HSVColor.hsv(
				hue,
				(HSVColor.get_S(hsv1) + HSVColor.get_S(hsv2) + HSVColor.get_S(hsv3) + HSVColor.get_S(hsv4))/4,
				(HSVColor.get_V(hsv1) + HSVColor.get_V(hsv2) + HSVColor.get_V(hsv3) + HSVColor.get_V(hsv4))/4);
	}
}