/* SoccerBot - RCX Drive Control
 Copyright (C) 2005 Georg Klima
 
 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.
 
 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.
 
 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 
 Contact:
 Peter Wild, pwild - at - cosy.sbg.ac.at
 University of Salzburg, Austria
 */
package at.ac.sbg.cosy.soccerbot.rcxdrive;

import java.io.*;
import josx.rcxcomm.*;

/**
 * Communications api for driving the RCX
 * @author Georg Klima
 */
public class RCXDrive implements IRCXDrive {
	
	private RCXLNPPort port = null;
	private byte[]cmd = new byte[2];
	
	private InputStream is = null;
	private DataInputStream dis = null;
	private DataOutput dos = null;
	
	private static IRCXDrive rcxDrive = null;
	
	private RCXDrive(){
		try {
			port = new RCXLNPPort();
			is = port.getInputStream();
			dis = new DataInputStream(is);		
			dos = port.getDataOutput();
			cmd[1]=(byte)200;
		} catch (IOException e) {
			System.out.println("Error setting up RCXDrive.");
			e.printStackTrace();
		}
	}
	
	/**
	 * Get a new singelton instance of the RCXDrive.
	 */
	public static void newInstance(){
		if(rcxDrive != null){
			rcxDrive.close();
		}
		rcxDrive = new RCXDrive();
	}
	
	/**
	 * Returns the actual instance of an RCXDrive
	 * @return current instance
	 */
	public static IRCXDrive getInstance(){
		return rcxDrive;
	}
	
	/**
	 * Execute the predifined command();
	 */
	private void execute(){
		try {
			dos.write(cmd);
		} catch (IOException e) {System.out.println("Communications error"); e.printStackTrace(); }
	}
	
	/**
	 * Sends exit command
	 */
	private void exit(){
		cmd[0]=CommandEvent.CMD_EXIT;
		execute();
	}
	
	/**
	 * @see at.ac.sbg.cosy.soccerbot.rcxdrive.IRCXDrive#close()
	 */
	public void close(){
		try {
			exit();
			dis.close();
			is.close();
		} catch (IOException e) {e.printStackTrace();}
		port.close();
		rcxDrive = null;
	}
	
	/**
	 * @see at.ac.sbg.cosy.soccerbot.rcxdrive.IRCXDrive#setPower(byte power)
	 */
	public void setPower(byte power) {
		cmd[1] = power;		
	}
	
	/**
	 * @see at.ac.sbg.cosy.soccerbot.rcxdrive.IRCXDrive#sendCommand(byte command)
	 */
	public void sendCommand(byte command) {
		cmd[0] = command;
		execute();
	}
	
	/**
	 * @see at.ac.sbg.cosy.soccerbot.rcxdrive.IRCXDrive#getBumper()
	 */
	public boolean getBumper() {
		boolean bumped = false;
		try{
			while(dis.available() > 0)
				if(dis.readByte() == CommandEvent.EVT_BUMPER)
					bumped = true;
		}catch(Exception e){System.out.println("Communications error"); e.printStackTrace();}
		return bumped;
	}
}
