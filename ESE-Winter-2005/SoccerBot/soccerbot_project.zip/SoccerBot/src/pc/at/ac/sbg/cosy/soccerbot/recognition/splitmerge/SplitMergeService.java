/* SoccerBot - SplitAndMerge Library - SplitMergeService
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition.splitmerge;

import at.ac.sbg.cosy.soccerbot.recognition.RGBColor;
import at.ac.sbg.cosy.soccerbot.recognition.HSVSimilarity;
import at.ac.sbg.cosy.soccerbot.recognition.IRegionCollector;
/**
 * Service class providing all entry points for performing the 
 * Split and Merge algorithm
 * @author Peter Wild
 *
 */
public class SplitMergeService {
	/**
	 * Length of square image, image size has to be CONFIG_IMGSIZE^2
	 */
	public static final int CONFIG_IMGSIZE = 256;
	/**
	 * Hierarchy level at which the image resides, has to be QuadNode.calculateMaxHierarchy(CONFIG_IMGSIZE) - that is log2(CONFIG_IMGSIZE)
	 */
	public static final int CONFIG_MAXHIERARCHY = 8;
	/**
	 * Int array holding all average node color / quadtree_up /quadtree_down values within the splitMerge phase.
	 * After grouping holds region appliance information.
	 * Size has to be QuadNode.calculateSize(CONFIG_MAXHIERARCHY).
	 */
	public static int[] QUADTREE_AV = new int[87381];
	/**
	 * Bit set holding information whether a quadtree node exists within the image.
	 * Size has to be BitSet.calculateSize(QUADTREE_AV.length).
	 */
	public static int[] QUADTREE_BITSET = new int[2731];
	/**
	 * Temporal Bitset for calculations, has to be of same size as QUADTREE_BITSET
	 */
	private static int[] TEMP_BITSET = new int[2731];
	/**
	 * Temporal queue for calculatzions, has to be of size CONFIG_IMGSIZE^2
	 */
	private static int[] TEMP_QUEUE = new int[65536];
	/**
	 * Temporal stack for calculations (neighbor retrieval), has to be of size CONFIG_MAXHIERARCHY
	 */
	private static int[] TEMP_STACK = new int[8];
	/**
	 * Encodes information whether a quadtree node is further subdivided (QUADTREE_DOWN)
	 */
	private static final int QUADTREE_DOWN = 0x00000000;
	/**
	 * Encodes information whether a quadtree node is a part of a (merged) quadtree node (QUADTREE_UP)
	 */
	private static final int QUADTREE_UP = 0xFFFFFFFF;
	
	/**
	 * This is the main entry point for performing the Split and Merge Algorithm
	 * image has to be contained within int array QUADTREE_AV
	 * @param collector list, which stores a vector describing a list of regions within the image
	 */
	public static void doService(IRegionCollector collector)
	{
		SplitMergeService.splitMerge(CONFIG_MAXHIERARCHY,QUADTREE_BITSET,QUADTREE_AV);
		BitSet.copy(QUADTREE_BITSET,TEMP_BITSET);
		SplitMergeService.group(CONFIG_MAXHIERARCHY,QUADTREE_BITSET,QUADTREE_AV,TEMP_BITSET,TEMP_QUEUE,TEMP_STACK, collector);
	}
	
	/**
	 * Creates a quadtree structure reflected in bitSet using data in quadTreeAv by performing the following tasks:
	 * Tasks: 
	 *  - copy original picture in argb values into quadTreeAv and convert pixel values to HSV
	 *  - create QuadTree performing merge step (we start with a fully splitted quadTree)
	 *  - at each merge step update bitSet and quadTreeAv by computing average pixel value of node
	 *  
	 * A similarity check of 4 children is used to estimate if a merge is possible.
	 * The procedure updates bitSet and quadTreeAv to hold all necessary quadTree information
	 * 
	 * @param maxHierarchy the maximum hierarchy level of embedded argbImage
	 * @param bitSet the structure reflecting information whether a node is occupied or not
	 * @param quadTreeAv the structure reflecting average pixel values of quadtree nodes
	 */
	public static void splitMerge(int maxHierarchy, int[] bitSet, int[] quadTreeAv)
	{
		// Copy the original picture and save pixel value as average HSV value
		int start = QuadNode.position(maxHierarchy,0,0);
		int imgSize = (1<<2*maxHierarchy);
		for (int x=0; x < imgSize; x++){
			quadTreeAv[start+x] = RGBColor.rgb2hsv(quadTreeAv[start+x]);
			// mark quadTree entry
			BitSet.setBit(bitSet,start+x);
		}
		// now go up and make similarity checks
		for (int h = maxHierarchy-1; h >= 0; h--){
			int size = (1 << h);
			for (int x=0; x<size; x++){
				for (int y=0; y<size; y++){
					int pos = QuadNode.position(h,x,y);
					int c1 = QuadNode.child_position(0,pos);
					int c2 = QuadNode.child_position(1,pos);
					int c3 = QuadNode.child_position(2,pos);
					int c4 = QuadNode.child_position(3,pos);
					if (BitSet.getBit(bitSet,c1) == 1 && BitSet.getBit(bitSet,c2)  == 1 && BitSet.getBit(bitSet,c3)  == 1 && BitSet.getBit(bitSet,c4) == 1){
						// calculate average
						quadTreeAv[pos] = HSVSimilarity.average(quadTreeAv[c1],quadTreeAv[c2],quadTreeAv[c3],quadTreeAv[c4]);
						// make homogenity check
						// if all average values are Similar
						if (HSVSimilarity.isSimilar(quadTreeAv[c1],quadTreeAv[c2]) && 
							HSVSimilarity.isSimilar(quadTreeAv[c1],quadTreeAv[c3]) && 
							HSVSimilarity.isSimilar(quadTreeAv[c1],quadTreeAv[c4]) && 
							HSVSimilarity.isSimilar(quadTreeAv[c2],quadTreeAv[c3]) && 
							HSVSimilarity.isSimilar(quadTreeAv[c2],quadTreeAv[c4]) && 
							HSVSimilarity.isSimilar(quadTreeAv[c3],quadTreeAv[c4])){
								BitSet.setBit(bitSet,pos);
								BitSet.releaseBit(bitSet,c1);
								BitSet.releaseBit(bitSet,c2);
								BitSet.releaseBit(bitSet,c3);
								BitSet.releaseBit(bitSet,c4);
								quadTreeAv[c1] = QUADTREE_UP;
								quadTreeAv[c2] = QUADTREE_UP;
								quadTreeAv[c3] = QUADTREE_UP;
								quadTreeAv[c4] = QUADTREE_UP;
						}
						else {
							BitSet.releaseBit(bitSet,pos);
						}
					}
					else {
						quadTreeAv[pos] = QUADTREE_DOWN;
						BitSet.releaseBit(bitSet,pos);
					}
				}
			}
		}
	}
	
	/**
	 * Appends all neighbors of the node specified through queueProcessPtr and queue
	 * to the queue and increases queueAppendPtr appropriately.
	 * 
	 * Returns the new queueAppendPtr
	 * @param maxHierarchy the maximum hierarchy level of embedded argbImage
	 * @param bitSet contains information whether the quadNode entry exists or not
	 * @param quadTreeAv is the structure reflecting average pixel values of quadtree nodes
	 * @param todoBitSet contains information which node has already been processed and is already contained in a region
	 * @param queue where to insert new elements of the region
	 * @param stack stack used for processing neighbors
	 * @param collector results are stored using this collector
	 */
	public static void group(int maxHierarchy, int[] bitSet, int[] quadTreeAv, int[] todoBitSet, int[] queue, int[] stack, IRegionCollector collector){
		// carry region information
		int size = (1<<maxHierarchy);
		int region_id = 0, region_size, region_hsv, region_upperLeft, region_lowerRight;
		// we start with the biggest quadtree node
		int startNode = BitSet.firstBit(todoBitSet);
		// while there are still nodes to be processed
		while (startNode != -1){
			BitSet.releaseBit(todoBitSet,startNode);
			region_size = (1 << 2*(maxHierarchy - QuadNode.quad_h(startNode)));
			region_hsv = quadTreeAv[startNode];
			region_upperLeft = QuadNode.upperLeft(startNode,maxHierarchy);
			region_lowerRight = QuadNode.upperLeft(startNode,maxHierarchy);
			// start a new queue for region growing
			// push the node onto the queue
			// process all his neighbors and repeat this process while the queue is not empty
			int queueAppendPtr = 1;// where to insert new queue elements
			int queueProcessPtr = 0;// the region where neighbors are to be processed and appropriate nodes are appended to the queue
			queue[queueProcessPtr] = startNode;
			// while there are still nodes to be processed
			while (queueProcessPtr < queueAppendPtr){
				// loop for all directions
				for(int direction = 0; direction < 4; direction++){
					int stackPtr = 0;
					stack[stackPtr++] = QuadNode.hierarchyNeighbor(direction,queue[queueProcessPtr]);
					if (stack[0] != -1){ // neighbors exist
						// while stack is not empty
						while (stackPtr > 0){
							// pop node from stack
							int node = stack[--stackPtr];
							//	check if node bit is set (OK, we have found exact neighbor)
							if (BitSet.getBit(bitSet,node) == 1){
								// basic case: we have found the exact neighbor
								// now test it to be enqueued: the node is not yet contained in another region + the similarity 
								// criteria holds
								if (BitSet.getBit(todoBitSet,node) == 1 && HSVSimilarity.isSimilar(quadTreeAv[node],region_hsv)){
									BitSet.releaseBit(todoBitSet,node);
									// if necessary, all nodes of a region may be recovered using this region_id
									quadTreeAv[node] = region_id;
									// recalculate size
									region_size += (1 << 2*(maxHierarchy - QuadNode.quad_h(node)));
									// recalculate position
									int tempCoord = QuadNode.upperLeft(node,maxHierarchy);
									region_upperLeft = Math.min(region_upperLeft%size,tempCoord%size)+ Math.min(region_upperLeft/size,tempCoord/size)*size;
									tempCoord = QuadNode.lowerRight(node,maxHierarchy);
									region_lowerRight = Math.max(region_lowerRight%size,tempCoord%size)+ Math.max(region_lowerRight/size,tempCoord/size)*size;
									// append to queue
									queue[queueAppendPtr++] = node;
								}
							}
							else if (quadTreeAv[node] == QUADTREE_UP){
								// in this case only one neighbor exists in upper direction, so go up until neighbor is found
								// push parent on stack [for whole chain only one node will be on the stack]
								stack[stackPtr++] = QuadNode.parent_position(node);
							}
							else { //quadTreeAv[node] == QUADTREE_DOWN
								// in this bad case we have to further step down in the quadtree to find 
								// multiple neighbors - build up stack for node addresses, worst case stack size: log(length of image)
								if (direction==0){ // push left hand children
									stack[stackPtr++] = QuadNode.child_position(2,node);
									stack[stackPtr++] = QuadNode.child_position(0,node);
								}
								else if (direction==1){ // push upper children
									stack[stackPtr++] = QuadNode.child_position(1,node);
									stack[stackPtr++] = QuadNode.child_position(0,node);
								}
								else if (direction==2){ // put right hand children
									stack[stackPtr++] = QuadNode.child_position(3,node);
									stack[stackPtr++] = QuadNode.child_position(1,node);
								}
								else { // push lower children
									stack[stackPtr++] = QuadNode.child_position(3,node);
									stack[stackPtr++] = QuadNode.child_position(2,node);
								}
							}
						}
					}
				}
				queueProcessPtr++;
			}
			quadTreeAv[startNode] = region_id;
			int tempWidth = 1 + region_lowerRight%size - region_upperLeft%size;
			int tempHeight = 1+region_lowerRight/size - region_upperLeft/size;
			boolean isClipped = (region_lowerRight%size == size) || (region_lowerRight/size == size) || (region_upperLeft%size == 0) || (region_upperLeft/size == 0);
			collector.addRegion(region_id,region_hsv,region_upperLeft%size + tempWidth/2,region_upperLeft/size + tempHeight/2,tempHeight,tempWidth,region_size,isClipped);
			// now we have processed all elements within queue and are about to create a new region;
			region_id++;
			startNode = BitSet.firstBit(todoBitSet);
		}
	}

}