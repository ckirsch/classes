/* SoccerBot - RCX Drive Control
Copyright (C) 2005 Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.rcxdrive;

/**
 * Command & event codes
 * @author Georg Klima
 */
public interface CommandEvent {
	/**
	 * Drive forward
	 */
	public static final byte CMD_FORWARD = 0;
	/**
	 * Drive a left curve
	 */
	public static final byte CMD_CURVE_LEFT = 1;
	/**
	 * Drive a right curve
	 */
	public static final byte CMD_CURVE_RIGHT = 2;
	/**
	 * Turn left
	 */
	public static final byte CMD_TURN_LEFT = 3;
	/**
	 * Turn right
	 */
	public static final byte CMD_TURN_RIGHT = 4;
	/**
	 * Stop
	 */
	public static final byte CMD_STOP = 5;
	/**
	 * Reverse
	 */
	public static final byte CMD_REVERSE = 6;
	/**
	 * Exit
	 */
	public static final byte CMD_EXIT = 7;
	/**
	 * @deprecated
	 */
	public static final byte CMD_BRICK_IT = 69;
	/**
	 * @deprecated
	 */
	public static final byte CMD_SELFDESTRUCT = 66;
	/**
	 * @deprecated
	 */
	public static final byte CMD_MAYBE_SELFDESTRUCT = 99;
	
	// Added: if the SoccerBot is supposed continue doing what it did in the last cycle,
	// then this command is used (Needed for the SendMessage2Robot_Actuator)
	/**
	 * reduces communication overhead upon sending commands 
	 * which would instruct the robot to perform an action it 
	 * is currently performing
	 */
	public static final byte CMD_CONTINUE_LAST = 10;
	/**
	 * Bumper-event
	 */
	public static final byte EVT_BUMPER = 53;
}
