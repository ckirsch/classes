/* SoccerBot - Giotto Controller Classes - Controller_State_port
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.PortVariable;
import java.io.Serializable;

/**
 * A port for transfering internal state information of the controller 
 * between cycles
 * consists of an (int _state, byte _lastCommand) tuple
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
@SuppressWarnings("serial")
public class Controller_State_port implements PortVariable, Serializable {
	
	// FOUND states
	/**
	 * ball found in center
	 */
	public static final int FOUND_CENTER = 0;
	/**
	 * ball found in left part of the image
	 */
	public static final int FOUND_LEFT = 1;
	/**
	 * ball found in right part of the image
	 */
	public static final int FOUND_RIGHT = 2;
	/**
	 * ball found and caught
	 */
	public static final int FOUND_CAUGHT = 3;
	// SEARCHING states
	/**
	 * searching for the ball turning left
	 */
	public static final int SEARCH_LEFT_TURN = 4;
	/**
	 * searching for the ball turning right
	 */
	public static final int SEARCH_RIGHT_TURN = 5;
	// LOST states: NOT REALLY NEEDED (2006.01.11)!
	// public static final int LOST_LEFT = 6;
	// public static final int LOST_RIGHT = 7;

	/**
	 * internal state encoded as int
	 */
    private int _state;
    /**
     * last rcxdrive.CommandEvent
     */
    private byte _lastCommand;

    /**
	 * Copies its internal state from a source port variable.
	 */
    public void copyValueFrom(PortVariable source) {
    	_state = ((Controller_State_port)source).getState();
    	_lastCommand = ((Controller_State_port)source).getLastCommand();
    }
    
    /**
     * Returns state
     * @return controller state
     */
    public int getState() {
        return _state;
    }
    
    /**
     * Sets state
     * @param newState new controller state
     */
    public void setState(int newState) {
    	_state = newState;
    }
    
    /**
     * Returns last command
     * @return last rcxcommand.CommandEvent
     */
    public byte getLastCommand() {
    	return _lastCommand;
    }

    /**
     * Sets last command
     * @param newCommand last rcxcommand.CommandEvent
     */
    public void setLastCommand(byte newCommand) {
    	_lastCommand = newCommand;
    }
    
    /**
     * Prints internal state
     */
    public String toString() {
    	String stateText = "";
    	
    	switch (_state)
    	{
    	case Controller_State_port.FOUND_CENTER:
    		stateText = "FOUND_CENTER";
    		break;
    	case Controller_State_port.FOUND_LEFT:
    		stateText = "FOUND_LEFT";
    		break;
    	case Controller_State_port.FOUND_RIGHT:
    		stateText = "FOUND_RIGHT";
    		break;
    	case Controller_State_port.FOUND_CAUGHT:
    		stateText = "FOUND_CAUGHT";
    		break;
    	case Controller_State_port.SEARCH_LEFT_TURN:
    		stateText = "SEARCH_LEFT_TURN";
    		break;
    	case Controller_State_port.SEARCH_RIGHT_TURN:
    		stateText = "SEARCH_RIGHT_TURN";
    		break;
    	/*case SAFBC_State_port.LOST_LEFT:
    		stateText = "LOST_LEFT";
    		break;
    	case SAFBC_State_port.LOST_RIGHT:
    		stateText = "LOST_RIGHT";
    		break;*/
    	default:
    		stateText = "ERROR: UNKNOWN STATE!";
    	}
    	return _state + ": " + stateText;
    }

}
