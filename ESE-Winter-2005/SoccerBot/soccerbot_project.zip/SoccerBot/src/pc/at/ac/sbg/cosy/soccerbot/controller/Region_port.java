/* SoccerBot - Giotto Controller Classes - Region_port
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.PortVariable;
import java.io.Serializable;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;

/**
 * A port for a recognized region (ball used for controller)
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
@SuppressWarnings("serial")
public class Region_port implements PortVariable, Serializable {
	
	/**
	 * private region
	 */
	private IRegion _value;

	/**
	 * Deep Copies its internal state from a source port variable.
	 */
	public void copyValueFrom(PortVariable source) {
		if (((Region_port)source).getRegion() != null){
			_value = ((Region_port)source).getRegion().copy();
		}
		else {
			_value = null;
		}
    }
 
	/**
     * Returns its internal state
     * @return region (from object recognition)
     */
    public IRegion getRegion() {
        return _value;
    }
 
    /**
     * Sets internal state
     * @param value region from object recognition
     */
    public void setRegion(IRegion value) {
        _value = value;
    }
 
    /**
     * @see Object#toString()
     */
    public String toString() {
        return "Region";
    }
}
