/* SoccerBot - Graphical Controller - IControllerGUI
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller.gui;

import at.ac.sbg.cosy.soccerbot.recognition.IRegion;

/**
 * Interface for graphical control units for SoccerBot
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
public interface IControllerGUI {
	/**
	 * Adds some text to the internal console
	 * @param s message to be displayed
	 */
	public void addText(String s);
	/**
	 * Updates the actual camera image (and may display recognized objects)
	 * @param ball detected tennisball-region
	 */
	public void updateImage(IRegion ball);
	/**
	 * Closes the graphical user interface
	 *
	 */
	public void close();
}
