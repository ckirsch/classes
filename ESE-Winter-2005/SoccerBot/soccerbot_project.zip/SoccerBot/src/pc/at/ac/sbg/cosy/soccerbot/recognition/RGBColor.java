/* SoccerBot - Recognition Library - RGBColor
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition;


/**
 * Library for RGB Color conversion / information extraction
 * @author Peter Wild
 *
 */
public class RGBColor {
	
	/**
	 * Extracts the red channel value out of an rgb int value
	 * @param color int-color value in 32-bit rgb format (0x00RRGGBB)
	 * @return red channel value
	 */	
	public static int get_R(int color){
		return ((color >> 16) & 0xFF);
	}
	
	/**
	 * Extracts the green channel value out of an rgb int value
	 * @param color int-color value in 32-bit rgb format (0x00RRGGBB)
	 * @return green channel value
	 */	
	public static int get_G(int color){
		return ((color >> 8) & 0xFF);
	}
	
	/**
	 * Extracts the blue channel value out of an rgb int value
	 * @param color int-color value in 32-bit rgb format (0x00RRGGBB)
	 * @return blue channel value
	 */
	public static int get_B(int color){
		return (color & 0xFF);
	}
	
	/**
	 * Creates an argb format representation of four alpha, red, green, blue channel values
	 * within 0x00 - 0xFF. Converts (r 0xFF, g 0xFF, b 0xFF -> rgb 0x00FFFFFF).
	 * @param r red color value in 0x00 - 0xFF
	 * @param g green color value in 0x00 - 0xFF
	 * @param b blue color value in 0x00 - 0xFF
	 * @return argb 32-bit format (0xAARRGGBB) representation
	 */
	public static int rgb(int r, int g, int b)
	{
		return (((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF));
	}
	
	/**
	 * Converts rgb values into hsv values (lossy transformation)
	 * usually hsv values are displayed as h = [0,360], s = [0,100], v = [0,100], so simply
	 * transform the used space h = [0,65535], s= [0,255], v= [0,255] to your needs.
	 * @param rgb argb 32-bit format (0xAARRGGBB) representation
	 * @return hsv 32-bit format (0xHHHHSSVV) representation of according rgb
	 */
	public static int rgb2hsv(int rgb)
	{
		int min, max, r = get_R(rgb), g = get_G(rgb), b = get_B(rgb), delta, v, s, h;
		if (r <= g) {
		    min = r;
		    max = g;
		}
		else
		{
		    min = g;
		    max = r ;
		}
		if (b<min) min = b;
		if (b>max) max = b;
		  
		v = max;
		delta = max - min;
		
		if( max != 0 )
			s = (delta*255) / max;
		else {
			// r = g = b = 0		// s = 0, v is undefined
			s = 0;
		}
		if (s==0) 
			h = -1;
		else
		{
			if( r == max )
				h = ( g - b ) * 65535 / (delta*6);		// between yellow & magenta
			else if( g == max )
				h = 2*65535/6 + ( b - r ) * 65535 / (delta*6);	// between cyan & yellow
			else
				h = 4*65535/6 + ( r - g ) * 65535 / (delta*6);	// between magenta & cyan
			if( h < 0 )
				h += 65535;
		}
		return HSVColor.hsv((int)h,s,v);
	}
	
	/**
	 * Converts rgb values into lab values (lossy transformation)
	 * usually lab values are displayed as L = [0,100], a = [0,100], b = [0,100], so simply
	 * transform the used space L = [0,255], a= [0,255], b= [0,255] to your needs.
	 * @param rgb argb 32-bit format (0xAARRGGBB) representation
	 * @param lab initialized array of length 3 containing lab representation of according rgb after call
	 */
	public static void rgb2lab(int rgb, double[] lab)
	{ 
		int r = get_R(rgb), g = get_G(rgb), bl = get_B(rgb);
		final double X0 = 0.982, Y0 = 1.000, Z0 = 1.183;
		double x = 0.607*r/255 + 0.174*g/255 + 0.201*bl/255, y = 0.299*r/255 + 0.587*g/255 + 0.114*bl/255, z = 0.066*g/255 + 1.117*bl/255;
		lab[0] = (25 * Math.pow(100*y/Y0,1./3) - 16);
		lab[1] = 500*(Math.pow(x/X0,1./3)-Math.pow(y/Y0,1./3));
		lab[2] = 200*(Math.pow(x/X0,1./3)-Math.pow(z/Z0,1./3));
	}
}
