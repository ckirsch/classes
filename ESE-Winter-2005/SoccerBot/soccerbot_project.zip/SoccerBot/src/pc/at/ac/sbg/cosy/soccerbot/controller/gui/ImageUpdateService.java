/* SoccerBot - Graphical Controller - ImageUpdateService
Copyright (C) 2006 Peter Wild, Krystian Szczurek, Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import at.ac.sbg.cosy.soccerbot.recognition.HSVColor;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;
import at.ac.sbg.cosy.soccerbot.recognition.RGBColor;
import at.ac.sbg.cosy.soccerbot.recognition.RegionList;
import at.ac.sbg.cosy.soccerbot.recognition.splitmerge.BitSet;
import at.ac.sbg.cosy.soccerbot.recognition.splitmerge.QuadNode;
import at.ac.sbg.cosy.soccerbot.recognition.splitmerge.SplitMergeService;

/**
 * Updates the image according to temporarily saved data within 
 * the SplitMergeService
 * @author Peter Wild, Krystian Szczurek, Georg Klima
 */
public class ImageUpdateService {
	
	private static int[] image = new int[SplitMergeService.CONFIG_IMGSIZE*SplitMergeService.CONFIG_IMGSIZE];
	
	/**
     * Renews all pixels belonging to region region_id in the image array to reflect a 
     * specific region that is coloured with color.
     * @param color region region_id is coloured with this 32 bit argb format (0xAARRGGBB) color
     * @param region_id region that should be coloured in image
     * @param quadTreeAv is the structure reflecting region ids of quadtree nodes
     * @param bitSet contains information whether the quadNode entry exists or not
     * @param size the length of square image
     * @param image initialized image array to be filled with argb 32 bit color information
     */
    private static void colorizeSingleRegion(int color, int region_id, int[] quadTreeAv, int[] bitSet, int size, int[] image){
    	int imageHierarchy = QuadNode.calculateMaxHierarchy(size);
		for (int i=0; i < quadTreeAv.length; i++)
    	{
    		if (BitSet.getBit(bitSet,i) == 1 && quadTreeAv[i] == region_id) {
    			int ul = QuadNode.upperLeft(i,imageHierarchy);
    			int lr = QuadNode.lowerRight(i,imageHierarchy);
    			for (int x = ul % size; x <= lr % size; x++){
    				for (int y = ul / size; y <= lr / size; y++){
    					image[x + y * size] = color;
    				}
    			}
    		}
    	}
    }
    
	/**
	 * Renews all pixels in the image array to reflect the calculated regions in Vector regions.
	 * Therefore all quadtree nodes are identified by their region and are assigned a color dependent
	 * of colorMode (for COLORMODE_RANDOM all regions are assigned random colors, for COLORMODE_REGCOLOR 
	 * they receive their region color). Quadtree pixels assigned a non-existent regioln ID are black.
	 * @param regions the resulting vector out of a split and merge routine
	 * @param quadTreeAv is the structure reflecting region ids of quadtree nodes
	 * @param bitSet contains information whether the quadNode entry exists or not
	 * @param size the length of square image
	 * @param image initialized image array to be filled with argb 32 bit color information
	 */
	private static void colorizeRegions(int[] quadTreeAv, int[] bitSet, int size, int[] image)
	{
		RegionList rl = RegionList.getInstance();
		int[] colors = new int[rl.size()];
		for (int i=0; i < colors.length; i++){
			colors[rl.getRegion(i).getId()] = HSVColor.hsv2rgb(rl.getRegion(i).getHSV());
		}
		int imageHierarchy = QuadNode.calculateMaxHierarchy(size);
		for (int i=0; i < quadTreeAv.length; i++)
    	{
    		if (BitSet.getBit(bitSet,i) == 1) {
    			int color = RGBColor.rgb(0,0,0);
    			if (quadTreeAv[i] >= 0 && quadTreeAv[i] < colors.length) color = colors[quadTreeAv[i]];
    			int ul = QuadNode.upperLeft(i,imageHierarchy);
    			int lr = QuadNode.lowerRight(i,imageHierarchy);
    			for (int x = ul % size; x <= lr % size; x++){
    				for (int y = ul / size; y <= lr / size; y++){
    					image[x + y * size] = color;
    				}
    			}
    		}
    	}
	}
	
	/**
	 * Draws a rectangle around a region
	 * @param source where to paint the region
	 * @param region region to be painted
	 */
	private static void drawRegionRectangle(BufferedImage source, IRegion region) {
        // Copy image to buffered image
        Graphics g = source.createGraphics();
        g.setColor(new Color(255,0,255));
        // Paint the image onto the buffered image
        g.drawRect(region.getCenter_X() - region.getWidth()/2,region.getCenter_Y() - region.getHeight()/2,region.getWidth(),region.getHeight());
        g.setColor(new Color(255,200,255));
        g.fillOval(Math.max(region.getCenter_X() - 1,0),Math.max(region.getCenter_Y() - 1,0),3,3);
        g.dispose();
    }
	
	/**
	 * Loads current split and merge-prepared camera image and paints ball into image
	 * @param pic image to be displayed
	 * @param ball detected region to be displayed
	 */
	public static synchronized void doService(BufferedImage pic, IRegion ball)
	{
		colorizeRegions(SplitMergeService.QUADTREE_AV,SplitMergeService.QUADTREE_BITSET,SplitMergeService.CONFIG_IMGSIZE,image);
		if (ball != null) colorizeSingleRegion(RGBColor.rgb(255,0,255),ball.getId(),SplitMergeService.QUADTREE_AV,SplitMergeService.QUADTREE_BITSET,SplitMergeService.CONFIG_IMGSIZE,image);
		pic.setRGB(0,0,SplitMergeService.CONFIG_IMGSIZE,SplitMergeService.CONFIG_IMGSIZE,image,0,SplitMergeService.CONFIG_IMGSIZE);
		if (ball != null) drawRegionRectangle(pic,ball);
	}
}
