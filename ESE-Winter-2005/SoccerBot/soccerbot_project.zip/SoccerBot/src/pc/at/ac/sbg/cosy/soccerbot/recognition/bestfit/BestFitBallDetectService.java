/* SoccerBot - Recognition Library - BestFitBallDetectService
Copyright (C) 2005 Peter Wild

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.recognition.bestfit;

import at.ac.sbg.cosy.soccerbot.recognition.RGBColor;
import at.ac.sbg.cosy.soccerbot.recognition.HSVColor;
import at.ac.sbg.cosy.soccerbot.recognition.HSVSimilarity;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;
import at.ac.sbg.cosy.soccerbot.recognition.IRegionCollector;
import at.ac.sbg.cosy.soccerbot.recognition.LabColor;

/**
 * Recognizes the ball out of a list of regions
 * @author Peter Wild
 */
public class BestFitBallDetectService {
	
	/**
	 * Test color for red balls
	 */
	public static final int HSVBALLCOLOR_RED = HSVColor.hsv(0,255,255);
	/**
	 * Test color for red candle
	 */
	public static final int HSVBALLCOLOR_CANDLERED = HSVColor.hsv(64500,255,200);
	/**
	 * Test color for tennis ball (good results with eyetoy camera)
	 */
	public static final int HSVBALLCOLOR_TENNISBALLGREEN = HSVColor.hsv(13653,128,200);
	/**
	 * Another test color for tennis ball
	 */
	public static final int HSVBALLCOLOR_TENNISBALLYELLOW = HSVColor.hsv(11650,200,200);
	
	private static final int CONFIG_MINSIZE = 64;
	private static int hsvBallColor = HSVBALLCOLOR_TENNISBALLGREEN;
	private static double[] labBallColor = new double[3];
	private static double[] labTemp = new double[3];
	
	/**
	 * Retrieves Ball Color
	 * @return hsv ball color
	 */
	public static int getHSVBallColor() {
		return hsvBallColor;
	}
	
	/**
	 * Sets ball color as 32 bit hsv value
	 * @param hsvBallColor hsv color of ball
	 */
	public static void setHSVBallColor(int hsvBallColor) {
		BestFitBallDetectService.hsvBallColor = hsvBallColor;
	}
	
	/**
	 * This is the main entry point for performing the Ball Detect Algorithm
	 * regionList vector has to be sorted
	 * @return vector describing a list of regions within the image
	 */
	public static IRegion doService(IRegionCollector collector)
	{
		RGBColor.rgb2lab(HSVColor.hsv2rgb(hsvBallColor),labBallColor);
		int distance, minDistance = Integer.MAX_VALUE;
		IRegion bestRegion = null, region;
		for (int i=0; i < collector.size(); i++){
			region = collector.getRegion(i);
			if (region.getSize() >= CONFIG_MINSIZE){
				RGBColor.rgb2lab(HSVColor.hsv2rgb(region.getHSV()),labTemp);
				distance = LabColor.distance(labBallColor,labTemp);
				if (distance < minDistance && (HSVSimilarity.isSimilar(region.getHSV(),hsvBallColor,HSVSimilarity.REHRMANN_HUEDISTANCE,HSVSimilarity.REHRMANN_SATDISTANCE,HSVSimilarity.REHRMANN_VALDISTANCE) && ((double)region.getWidth() / region.getHeight())< 2.5 && ((double)region.getWidth() / region.getHeight())> 0.5)){
					minDistance = distance;
					bestRegion = region;
				}
			}
		}
		return bestRegion;
	}
}

