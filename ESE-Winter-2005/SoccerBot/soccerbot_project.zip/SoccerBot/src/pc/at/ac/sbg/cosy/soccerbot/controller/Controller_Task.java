/* SoccerBot - Giotto Controller Classes - Controller_Task
Copyright (C) 2006 Krystian Szczurek

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/
package at.ac.sbg.cosy.soccerbot.controller;

import giotto.functionality.interfaces.TaskInterface;
import giotto.functionality.table.Parameter;

import java.io.Serializable;

import at.ac.sbg.cosy.soccerbot.controller.gui.ControllerGUI;
import at.ac.sbg.cosy.soccerbot.rcxdrive.CommandEvent;
import at.ac.sbg.cosy.soccerbot.recognition.IRegion;

/**
 * The main task which takes an image as input, sends it to the
 * image processing classes and acquires information about where
 * the ball is positioned within the scene. According to theses
 * information it decides in which direction to send the Soccerbot
 * next.
 * @author Krystian Szczurek
 */
@SuppressWarnings("serial")
public class Controller_Task implements TaskInterface, Serializable 
{	
	private int _left = 76; // 256 * 0.3
	private int _right = 180; // 256 * 0.7
	
	/**
	 * @see TaskInterface#run(giotto.functionality.table.Parameter)
	 */
    public void run(Parameter p) {    	
    	int newState = -1;
    	byte newCommand = -1;
    	
    	IRegion ball = ((Region_port)p.getPortVariable(0)).getRegion();
    	boolean bumped = ((Boolean_port)p.getPortVariable(1)).getBoolValue();
        int lastState = ((Controller_State_port)p.getPortVariable(3)).getState();
    	byte lastCommand = ((Controller_State_port)p.getPortVariable(3)).getLastCommand();
    	
    	ControllerGUI.write("Controller");
        
        if (ball != null) // ball somewhere in the scene
        {
        	int ballXPos = ball.getCenter_X();
        	
        	if (ballXPos < _left) // ball is in the left part of the image
        	{
        		newCommand = lastCommand != CommandEvent.CMD_CURVE_LEFT ? CommandEvent.CMD_CURVE_LEFT : CommandEvent.CMD_CONTINUE_LAST;
        		newState = Controller_State_port.FOUND_LEFT;
        	}
        	else if(ballXPos > _right) // ball is in the right part of the image
        	{
        		newCommand = lastCommand != CommandEvent.CMD_CURVE_RIGHT ? CommandEvent.CMD_CURVE_RIGHT : CommandEvent.CMD_CONTINUE_LAST;
        		newState = Controller_State_port.FOUND_RIGHT;
        	}
        	else // ball is in the center
        	{
        		newCommand = lastCommand != CommandEvent.CMD_FORWARD ? CommandEvent.CMD_FORWARD : CommandEvent.CMD_CONTINUE_LAST;
        		newState = Controller_State_port.FOUND_CENTER;
        	}
        }
        else // ball hasn't been found within the scene
        {
        	switch (lastState)
        	{
        	case Controller_State_port.FOUND_CENTER:
        	case Controller_State_port.FOUND_CAUGHT:
        	case Controller_State_port.FOUND_LEFT: // ball probably rolled out to the left of the picture
        	case Controller_State_port.SEARCH_LEFT_TURN: // already is searching in the left direction
        		newCommand = lastCommand != CommandEvent.CMD_TURN_LEFT ? CommandEvent.CMD_TURN_LEFT : CommandEvent.CMD_CONTINUE_LAST;
        		newState = Controller_State_port.SEARCH_LEFT_TURN;
        		break;
        	case Controller_State_port.FOUND_RIGHT: // ball probably rolled out to the right of the picture
        	case Controller_State_port.SEARCH_RIGHT_TURN: // already is searching in the right direction
        		newCommand = lastCommand != CommandEvent.CMD_TURN_RIGHT ? CommandEvent.CMD_TURN_RIGHT : CommandEvent.CMD_CONTINUE_LAST;
        		newState = Controller_State_port.SEARCH_RIGHT_TURN;
        		break;
        	}
        }

        // Update GUI
        if (ControllerGUI.getInstance() != null){
    		if (ball != null){
    			ControllerGUI.getInstance().addText("Ball Found: CenterX=" + ball.getCenter_X() + ", CenterY=" + ball.getCenter_Y() + ", Width=" + ball.getWidth());
            }
            else
            {
            	ControllerGUI.getInstance().addText("Ball NOT Found!!!");
            }
    		if (bumped) ControllerGUI.getInstance().close();
    	}
        
        // Set the new state of the task
        ((Controller_State_port)p.getPortVariable(3)).setState(newState);
        
        if (newCommand != CommandEvent.CMD_CONTINUE_LAST){
        	((Controller_State_port)p.getPortVariable(3)).setLastCommand(newCommand);
        // Set the output ports
        ((Byte_port)p.getPortVariable(2)).setByteValue(newCommand);
        }
    }
}
