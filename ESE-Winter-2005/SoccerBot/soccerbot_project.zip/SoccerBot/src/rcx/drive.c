/* SoccerBot - drive.c - embedded controller implementation
Copyright (C) 2006 Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/

#include <config.h>
#include <dmotor.h>
#include <dsensor.h>
#include <lnp/lnp.h>
#include <unistd.h>
#include <mem.h>
#include <conio.h>
#include <tm.h>
#include <rom/system.h>
#include <dsound.h>

#include "commandEvent.h"
#include "drive.h"

#define MOTOR_SPEED_BASE (MAX_SPEED/3)*2
#define RIGHT_DRIVE_COR 30

int got = 0;
unsigned char *cmd;
//char cmdlen;
unsigned char bump = EVT_BUMPER;
tid_t bumper_task;

/**
 * handels the network data, is the lnp_integrity_handler
 */
void getdata(unsigned char *inbuf, char len) {
  cmd = inbuf;
//  cmdlen = len;
  got = 1;
}

/**
 * "guard", evaluates true on new network data
 */
wakeup_t WaitForData(wakeup_t data) {
  return got;
}

/**
 * "guard", evaluates true on pressed bumper
 */
wakeup_t TouchSensorPress(wakeup_t data){
	return TOUCH_2;
}

/**
 * "guard", evaluates true on released bumper
 */
wakeup_t TouchSensorRelease(wakeup_t data){
	return !TOUCH_2;
}

/**
 * Kernel before me!
 */
int main(){

	lnp_integrity_set_handler((lnp_integrity_handler_t)&getdata); // setup the networking receive handler
	bumper_task = execi(touch_task, 0, NULL, PRIO_NORMAL, DEFAULT_STACK_SIZE); //setup the bumper task

	while(!shutdown_requested()){
		wait_event(WaitForData, 0); //wait for data, blocking
		got = 0;
		lcd_clear();
		switch (cmd[0]) {
			case CMD_FORWARD:			forward(cmd[1]);			break;
			case CMD_LEFT:    			left(cmd[1]); 			break;
			case CMD_RIGHT:				right(cmd[1]);			break;
			case CMD_TURN_LEFT:			turn_left(cmd[1]);		break;
			case CMD_TURN_RIGHT:			turn_right(cmd[1]);		break;
			case CMD_STOP:				stop();					break;
			case CMD_REVERSE:			reverse(cmd[1]);			break;
			case CMD_EXIT:				stop(); shutdown_task(bumper_task); exit(0);		break;
			case CMD_BRICK_IT:			brick_it();				break;
			case CMD_SELFDESTRUCT:		selfdestruct();			break;
			case CMD_MAYBE_SELFDESTRUCT:maybe_selfdestruct(); 	break;
			default:						failure();				break;
		}
	}
	//shutdown_task(bumper_task);
	return 0;
}

/**
 * What!?
 * Read the java doc of the pc side!
 */
void forward(unsigned char power){
	motor_a_dir(fwd);
	motor_c_dir(fwd);
	motor_a_speed(power - RIGHT_DRIVE_COR);
	motor_c_speed(power);	
}

/**
 * What!?
 * Read the java doc of the pc side!
 */
void reverse(unsigned char power){
	motor_a_dir(rev);
	motor_c_dir(rev);
	motor_a_speed(power - RIGHT_DRIVE_COR);
	motor_c_speed(power);	
}	

/**
 * What!?
 * Read the java doc of the pc side!
 */
void stop(){
	motor_a_dir(off);
	motor_c_dir(off);
	motor_a_speed(MIN_SPEED);
	motor_c_speed(MIN_SPEED);
}	

/**
 * What!?
 * Read the java doc of the pc side!
 */
void turn_right(unsigned char power){
	motor_a_dir(rev);
	motor_c_dir(fwd);
	motor_a_speed(power);
	motor_c_speed(power);
//	cputw(power);
}

/**
 * What!?
 * Read the java doc of the pc side!
 */
void turn_left(unsigned char power){
	motor_c_dir(rev);
	motor_a_dir(fwd);
	motor_a_speed(power);
	motor_c_speed(power);
//	cputw(power);
}

/**
 * What!?
 * Read the java doc of the pc side!
 */
void right(unsigned char power){
	motor_a_dir(fwd);
	motor_c_dir(fwd);
	motor_a_speed(MOTOR_SPEED_BASE - power / 2);
	motor_c_speed(MOTOR_SPEED_BASE + power / 3);
//	cputw(power);
}

/**
 * What!?
 * Read the java doc of the pc side!
 */
void left(unsigned char power){
	motor_a_dir(fwd);
	motor_c_dir(fwd);
	motor_c_speed(MOTOR_SPEED_BASE - power / 2);
	motor_a_speed(MOTOR_SPEED_BASE + power / 3);
//	cputw(power);
}

/**
 * halt on failure, be on the save side!
 */
void failure(){
	stop();
	dsound_system(DSOUND_SYS_MAX);
}

/**
 * Turns it into a real brick until......
 */
void brick_it(){
	power_off();
}

/**
 * here I'm certain that selfdestruct works, Bye, Bye!!!
 */
void selfdestruct(){
	reset();
}

/**
 * not sure if this really selfdestructs the brick, give it a try.
 */
void maybe_selfdestruct(){
	rom_reset();
}

/**
 * Waits for an interrupt / event from the touch sensor at port 2.
 */
int touch_task(int argc, char *argv[]){
	while(!shutdown_requested()){ // do it util the end
		wait_event(TouchSensorPress,0); // wait for press
		
		stop(); // halt me, I'm faster than the Network
		cputs("STOP"); // display something on the lcd
		lnp_integrity_write(&bump, 1); // send a callback message
		
		wait_event(TouchSensorRelease,0); //wait for release
	}
	exit(0); //don't know for what but it's nice
}

/*
int drive_task(int argc, char *argv[]){
	while(1){
		wait_event(WaitForData, 0);
		got = 0;
		
		switch (cmd[0]) {
			case FORWARD:	forward(cmd[1]);	break;
			case LEFT:    	left(cmd[1]); 		break;
			case RIGHT:		right(cmd[1]);		break;
			case TURN_LEFT:	turn_left(cmd[1]);	break;
			case TURN_RIGHT:turn_right(cmd[1]);	break;
			case STOP:		stop();				break;
			default:		failure();			break;
		}
	}	
}
*/

/*
	ds_active(&SENSOR_1);
	ds_active(&SENSOR_3);
	ds_rotation_set(&SENSOR_1,0);
	ds_rotation_set(&SENSOR_3,0);
	ds_rotation_on(&SENSOR_1);
	ds_rotation_on(&SENSOR_3);
*/	