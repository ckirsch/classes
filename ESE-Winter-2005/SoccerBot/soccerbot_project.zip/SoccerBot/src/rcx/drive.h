/* SoccerBot - drive.h - embedded controller header file
Copyright (C) 2006 Georg Klima

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Contact:
Peter Wild, pwild - at - cosy.sbg.ac.at
Krystian Szczurek, szczurek - at - cosy.sbg.ac.at
Georg Klima, gklima - at - cosy.sbg.ac.at
University of Salzburg, Austria
*/

void forward(unsigned char power);
void stop();
void left(unsigned char power);
void right(unsigned char power);
void turn_left(unsigned char power);
void turn_right(unsigned char power);
void reverse(unsigned char power);
void failure();
void brick_it();
void selfdestruct();
void maybe_selfdestruct();

int touch_task(int argc, char *argv[]);

wakeup_t WaitForData(wakeup_t data);
wakeup_t TouchSensorPress(wakeup_t data);
wakeup_t TouchSensorRelease(wakeup_t data);
