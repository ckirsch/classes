#!/usr/bin/env python
import sys, struct

if len(sys.argv) < 3:
    print sys.argv[0], "<input> <output>"
    sys.exit(1)

infilename = sys.argv[1]
outfilename = sys.argv[2]

def getinstream(filename):
    if filename == "-":
        return sys.stdin
    else:
        return file(filename)

def getoutstream(filename):
    if filename == "-":
        return sys.stdout
    else:
        return file(filename, "wb")

class Parser:
    # the recognized commands
    keywords = ["", "release", "dispatch", "future", "if", "jump", "idle", "return"]

    # bit positions where to place parameters
    params =   [
        (),
        (16, 0),
        (16, 0),
        (16, 0),
        (16, 0),
        (0,),
        (0,),
        ()
        ]

    def parse_command(self, line):
        """Parses one command and returns the resulting code word."""

        tokens = line.split()
        #print line_number, tokens
        instruction = self.keywords.index(tokens[0])
        i = 1
        # instruction is at bits 28..31
        word = instruction << 28
        for param in self.params[instruction]:
            try:
                val = tokens[i]
                try:
                    val = int(val)
                except ValueError:
                    if val in self.macros:
                        val = self.macros[val]
                    else:
                        l = self.labels.get(val, (-1, []))
                        l[1].append(self.word_position)
                        self.labels[val] = l
                        val = 65535
            except IndexError:
                val = 0
                print filename, line_number, "Error: Check parameter %d!" % i
            i += 1
            word += val << param
        return word

    def parse(self, filename):
        """Parses the given file, returns a list of code words."""

        self.macros = {} # maps macro names to values
        self.labels = {} # maps label names to (byte-position, [addresses])
        self.filename = filename
        self.line_number = 1
        self.word_position = 0

        words = []
        infile = getinstream(filename)

        for line in infile:
            comment = line.find("#")
            if comment >= 0:
                line = line[:comment]
            line = line.strip()
            if line:
                if line.find("=") >= 0:
                    # assignement, i.e. new macro
                    self.macros[line.split("=")[0].strip()] = int(line.split("=")[1])
                elif line.find(":") >= 0:
                    # label
                    label = line.split(":")[0]
                    if label in self.labels:
                        l = self.labels[label]
                        if l[0] != -1:
                            print self.filename, self.line_number, "Error: Duplicate label %s!" % label
                        else:
                            self.labels[label] = (self.word_position, l[1])
                    else:
                        self.labels[label] = (self.word_position, [])
                else:
                    # code
                    words.append(self.parse_command(line))
                    self.word_position += 1
            self.line_number += 1

        # Store ECODE and SCODE
        self.ECODE = self.labels["ECODE"][0]
        self.SCODE = self.labels["SCODE"][0]
        del self.labels["ECODE"]
        del self.labels["SCODE"]

        # Relocate all label addresses.
        for label in self.labels.items():
            position = label[1][0]
            relocations = label[1][1]
            if not relocations:
                print "Warning: Unused label %s!" % label[0]
            if position == -1:
                print "Error: Undefined label %s!" % label[0]
            else:
                for relocation in relocations:
                    word = words[relocation]
                    word = word & 0xffff0000L
                    word += position
                    words[relocation] = word

        return words

parser = Parser()
words = parser.parse(infilename)
outfile = getoutstream(outfilename)

n = len(words)
outfile.write("/* Code generated with compiler.py from \"%s\", do not hand edit. */\n" % infilename);
outfile.write("const word BASE_FREQUENCY = %d;\n" % parser.macros["FREQUENCY"]);
outfile.write("const word ECODE = 0x%04x;\n" % parser.ECODE);
outfile.write("const word SCODE = 0x%04x;\n" % parser.SCODE);
outfile.write("const word CODE[%d] =\n" % n);
outfile.write("{\n");
for i, word in enumerate(words):
    outfile.write("    0x%08xUL" % word)
    if i < n - 1:
        outfile.write(",")
    else:
        outfile.write(" ")
    com = (word & 0xf0000000L) >> 28
    p1 = (word & 0x0fff0000L) >> 16
    p2 = word & 0x0000ffffL
    outfile.write(" /* %04x: %s %03x %04x */\n" % (
        i, Parser.keywords[com].ljust(8), p1, p2))
outfile.write("};\n");
