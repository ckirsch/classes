/* AD&R - Advanced Dungeons & Robots.
 *
 * Stefan Esterer, Michael Park, Elias Pschernig
 *
 * The VM is based on the "Sortbot" code by Rainer Trummer and Robert
 * Loeffelberger.
 *
 */

#include "vm.c"

#define DARK_THRESH   40  //  0x2a
#define HEAD_SPEED 20
#define MAIN_SPEED 30

int left, right;
int turret; /* where is the turret (-1 = left, 0 = center, 1 = right) */
int turret_direction;
int ignore_turret;
int counter;

MotorPair *mPair;
LightSensor *lMain;

Motor  *mHead;
LightSensor *lHead;
RotationSensor *r;


/* Read the main light sensor. */
int check_turn(void)
{
	
    //schwarz gefunden
    if (  lMain->get() <= DARK_THRESH){
         ignore_turret = 0;
         return 0;
       }
    
    //weiss gefunden
    else
     //if(  ignore_turret == 0 )
     {
    	 ignore_turret = 1;
    	return 1;
    }
    
    return 0;
}


/* Move the tank. */
void do_move(void)
{
	if (counter > 2)
	{
		mPair->speed(mPair->max * 0.5);
		mPair->forward();
		}
    	//cputs("move ");
}

/* Turn the tank. */
void do_turn(void)
{
	//cputs("rota ");
	if(left == 1)
 		mPair->left();	
 	 else if(right == 1)
 	 	mPair->right();	 
}
	
/* Rotate the turret. */
void do_turret(void)
{
	 
	
		int pos = r->pos();
		
		lcd_int (counter);
		if (pos < 98) {
			mHead->forward(); //links
			if (turret_direction != 1)
				counter++;
			turret_direction = 1;
		}
		else if (pos > 102) {
			mHead->reverse(); //rechts
			if (turret_direction != -1)
				counter++;
			turret_direction = -1;
		}
		
		//if (  lMain->get() <= DARK_THRESH)
		{
		
			if (lHead->get() < DARK_THRESH)
			{
				if (pos < 99) {
					right = 1; left = 0;
					}
				else if (pos > 101) {
					left = 1; right = 0;
					}
			}
	
	}
}

void initialize(void)
{

	mPair = new MotorPair(Motor::A, Motor::C);
	lMain = new LightSensor(LightSensor::S1);
	mHead = new Motor(Motor::B);
	lHead = new LightSensor(LightSensor::S3);
	r = new RotationSensor(RotationSensor::S2, 100);
   	left = 0;
   	right = 0;
   	ignore_turret = 0;
   	turret_direction = 0;
   	counter = 0;

    add_condition(0, check_turn);

    add_task(0, do_move);
    add_task(1, do_turn);
    add_task(2, do_turret);
   
   mHead->speed(HEAD_SPEED);
    mHead->forward();
    

    cputs("start");
}

void deinitialize(void)
{
    motor_a_speed(off);
    motor_b_speed(off);
    motor_c_speed(off);
    ds_passive(&SENSOR_1);
    ds_passive(&SENSOR_2);
    ds_passive(&SENSOR_3);
}

MAIN
{
    const word *ecode_ip = CODE + ECODE;
    const word *scode_ip = CODE + SCODE;

    initialize();

    while (!shutdown_requested()) {
        ecode_ip = interpret(ecode_ip);
        if (!ecode_ip)
            break;
        scode_ip = interpret(scode_ip);
        if (!scode_ip)
            break;
    }
    
    deinitialize();
    return 1;
}

