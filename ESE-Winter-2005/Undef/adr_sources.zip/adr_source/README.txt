= What id does =

Please see our accompanying paper and slides for details on the project.

= How to compile =

First, you need to "compile" the "E/S Code". Do it like this:

python compiler.py panzer.ecode bytecode.c

It should create a file "bytecode.c", containing the instructions in the binary
format used by the VM interpreter.

Next, you need to compile the following files:

panzer.C vm.c bytecode.c

This is done using and adjusting the BrickOS makefiles, in whatever way that
works on your system. The result should be a file "panzer.lx", which you can
transfer to our bot's RCX.
