#ifdef EMULEGOS

#include "emuLegOs.h"
#include <stdlib.h>
#include <stdio.h>

#define MAIN int rcx_main(int argc, char **args)

#else

#include <dsensor.h>
#include <dmotor.h>
#include <unistd.h>
#include <conio.h>

#define MAIN int main(void)

#endif

/* See "compiler.py" for details on the machine code format. */

#define INST(x) ((x) >> 28)
#define P1(x) (((x) & ~0xf0000000UL) >> 16)
#define P2(x) (((x) & 0x0000ffffUL))
#define BUILD(x, y, z) (((x) << 28) | ((y) << 16) | (z))

enum
{
    INST_RELEASE = 1,
    INST_DISPATCH = 2,
    INST_FUTURE = 3,
    INST_IF = 4,
    INST_JUMP = 5,
    INST_IDLE = 6,
    INST_RETURN = 7
};

#ifdef EMULEGOS
char *op_names[] = {
    "none", "release", "dispatch", "future", "if", "jump", "idle", "return"
};
#endif

#define MAX_TASKS      10
#define MAX_CONDITIONS 10

int (*CondRef[MAX_CONDITIONS])(void);
void (*TaskRef[MAX_TASKS])(void);

typedef unsigned long word; // should be 32 bits

#include "bytecode.c"

static word TaskSet[MAX_TASKS];

void add_condition(int id, int (*c)(void))
{
    CondRef[id] = c;
}

void add_task(int id, void (*c)(void))
{
    TaskRef[id] = c;
}

/* Interprets code until a return instruction is encountered. The return value
 * tells what to execute next time.
 */
const word *interpret(const word *IP)
{
    word op, p1, p2;
    const word *jump = IP;

    for (;;)
    {
        op = INST(*IP);
        p1 = P1(*IP);
        p2 = P2(*IP);

        #ifdef EMULEGOS
        printf("%3d: %8s %lu %lu\n", IP - CODE, op_names[op], p1, p2);
        sleep(1);
        #endif

        if (op == INST_RELEASE)
        {
            word id = p2;
            if (!TaskSet[id])
            {
                TaskSet[id] = *IP;
            }
        }
        else if (op == INST_DISPATCH)
        {
            word id = p2;
            if (TaskSet[id])
            {
                word d = P1(TaskSet[id]) - BASE_FREQUENCY;
                if (d)
                {
                    /* Not ready yet. */
                    TaskSet[id] = BUILD(op, d, id);
                }
                else
                {
                    /* Execute. */
                    TaskRef[id]();
                    TaskSet[id] = 0;
                }
            }
        }
        else if (op == INST_FUTURE)
        {
            jump = CODE + p2;
            msleep(p1);
        }
        else if (op == INST_IF)
        {
            if (CondRef[p1]())
            {
                IP = CODE + p2;
                continue;
            }
        }
        else if (op == INST_JUMP)
        {
            jump = CODE + p2;
        }
        else if (op == INST_IDLE)
        {
            msleep(p2);
        }
        else if (op == INST_RETURN)
        {
            return jump;
        }
        IP++;
    }
}

