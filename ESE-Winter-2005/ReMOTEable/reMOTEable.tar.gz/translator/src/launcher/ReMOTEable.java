package launcher;
public class ReMOTEable {
	public static void main(String[] args) {
		if (args.length == 0) {
			gui(args);
		}
		else if (args.length == 1) {
			if (args[0].equals("--help")) {
				printHelp();
			}
			else if (args[0].equals("--gui")) {
				gui(args);	
			}
			else {
				translator.cmdl.Cmdl.main(args);
			}
		}
		else {
			printHelp();
		}
	}
	
	private static void printHelp() {
		System.out.println("");
		System.out.println("[--help|--gui|FILE]");
		System.out.println("");
		System.out.println("--help    Prints this help screen");
		System.out.println("--gui     Starts the graphical usre interface");
		System.out.println("FILE      Loads file FILE");
	}
	
	private static void gui(String[] args) {
		try {
			translator.gui.Gui.main(args);
		} catch(java.lang.InternalError ex) {
			System.out.println("\nProblems occurred when trying to start the graphical interface.\n" +
					"Please use the commandline interface instead.\nTry --help\n");
		}
	}
}
