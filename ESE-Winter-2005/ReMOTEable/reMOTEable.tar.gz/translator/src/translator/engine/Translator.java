package translator.engine;

import java.util.Vector;

public class Translator {
	private Vector<Element> out;
	private String[] in;
	
	public Translator (String input) throws WorkingErrorException, SolveingErrorException{
		out = new Vector<Element>();
		in = input.split("\n");
		work();
		solve();
	}
	
	public String getHumanReadable() {
		final String head = "\tlocalSlot->agent.mem";
		final String tail = ";";

		String ret = 
			"void initAutoGenAgent() {\n" +
			"\tvmSlot_t *localSlot;\n" +
			"\t//dont forget to change i!\n" +
			"\tlocalSlot = &vmSlot[i];\n\n" +
			"\tlocalSlot->agent.registers[0] = 0;\n" +
			"\tlocalSlot->agent.registers[1] = 0;\n" +
			"\tlocalSlot->agent.registers[2] = 0;\n" +
			"\tlocalSlot->agent.registers[3] = 0;\n" +
			"\tlocalSlot->agent.flags.pc = 0;\n" +
			"\tlocalSlot->agent.flags.ret_cmp = 0;\n" +
			"\tlocalSlot->agent.flags.rest_div = 0;\n" +
			"\tlocalSlot->agent.flags.overUnderFlow = 0;\n" +
			"\tlocalSlot->agent.flags.DivZero = 0;\n";
		int tmp;
		int memPos;
		
		for (memPos = 0; memPos < out.size(); memPos = memPos + 2) {
			tmp = out.get(memPos).intData;
			tmp = (tmp << 4) & 0xF0;
			if ((memPos + 1) < out.size()) {
				tmp = tmp + ((out.get(memPos + 1).intData) & 0x0F);
			}
			ret = ret + head + "[" + (memPos / 2) + "] = 0x" + Integer.toHexString(tmp) + 
				tail + "   \t// " + Integer.toBinaryString(tmp) + "\n"; 
		}
		ret = ret +	"\tlocalSlot->agent.mem[" + memPos / 2+ "]=0;\n" +  
			"\tlocalSlot->agent.cs_size = " + (memPos + 1)+ ";\n" +
			"\tlocalSlot->agent.ds_size = 0;\n" +
			"\tlocalSlot->state = VMSLOT_RUNNING;\n}";
		return (ret);
	}
	
	public String toString() {
		String ret = "";
		for (int i = 0; i < out.size(); i++) {
			System.out.println(out.get(i).intData);
		}
		return (ret);
	}
	
	private void work() throws WorkingErrorException{
		for (int line = 0; line < in.length; line++) {
			in[line] = in[line].toLowerCase();
			if (in[line].length() != 0) {
				if (in[line].startsWith(":")) {
					//jump target
					add(in[line]);
				}
				else if((in[line].startsWith("jmp")) &&
						(in[line].charAt(4)== ' ')){
					//jump itselfe
					add(in[line]);
					add(null);
					add(null);
				}
				else {
					Integer[] result;
					result = Table.lookUp(in[line]);
					for(int i = 0; i < result.length; i++) {
						add(result[i].intValue());
					}
				}
			}
		}	
	}
	
	private void solve() throws SolveingErrorException{
		String name;
		int target = 0, source = 0;
		int line;

		for (line = 0; line < out.size(); line ++) {
			if (out.get(line).getType().equals(Element.STRING)) {
				//found jump target or a jump
				//the name will be stored and searched for its partner
				if (out.get(line).strData.startsWith(":")) {
					//found jump target
					name = out.get(line).strData;
					name = name.substring(1);
					target = line;
					out.remove(target);
					
					for (source = 0; source < out.size(); source++) {
						if ((out.get(source).getType().equals(Element.STRING)) && 
								(out.get(source).strData.length() > 5) &&
								(out.get(source).strData.substring(5).startsWith(name))) {
							if (out.get(source).strData.startsWith("jmpt")) {
								out.remove(source);
								out.add(source, new Element(4));
							}
							else if (out.get(source).strData.startsWith("jmpf")) {
								out.remove(source);
								out.add(source, new Element(5));
							}
							else {
								throw new SolveingErrorException("jnz " + name);
							}
							out.remove(source + 1);
							out.remove(source + 1);
							out.add(source + 1, new Element((target >> 4) & 0x0F));
							out.add(source + 2, new Element(target & 0x0F));
						}
					}
				}
			}
		}
	}
	
	private void add(String add) {
		out.add(new Element(add));		
	}
	
	private void add(int add) {
		//Halfbytes!!
		out.add(new Element(add));		
	}
}
