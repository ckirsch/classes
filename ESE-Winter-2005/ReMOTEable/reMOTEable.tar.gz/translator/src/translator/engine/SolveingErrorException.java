package translator.engine;
public class SolveingErrorException extends Exception {
	private static final long serialVersionUID = -1669990001709042760L;

	public SolveingErrorException(String str) {
		super("Troubles while solveing: " + str);
	}
}