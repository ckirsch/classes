package translator.engine;
public class WorkingErrorException extends Exception {
	private static final long serialVersionUID = -1669990001709042760L;

	public WorkingErrorException(String str) {
		super("Troubles while working: " + str);
	}
}