package translator.engine;

public class Element {
	public static final String STRING = "str";
	public static final String INT = "int";
	public static final String DUMMY = "dummy";
	public int intData = 0;
	public String strData = "";
		
	private String type = "";
	
	public Element(Object value) {
		if (value == null) {
			type = DUMMY;
		}
		else {
			type = STRING;
			strData = (String) value;
		}
	}
	
//	public Element(String value) {
//		type = STRING;
//		strData = value;
//	}
	
	public Element(int value) {
		type = INT;
		intData = value;
	}
	
	public String getType() {
		return (type);
	}
}
