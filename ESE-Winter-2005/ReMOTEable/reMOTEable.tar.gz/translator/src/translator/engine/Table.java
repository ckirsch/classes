package translator.engine;

import java.util.Vector;

public class Table {
	public static Integer[] lookUp(String cmd) throws WorkingErrorException{
		final int NONE = 0;
		final int REG_REG = 1;
		final int REG_VAL = 2;
		final int REG_ADR = 3;
		final int ADR_REG = 4;
		final int VAL_VAL = 5;
		
		String splited[];
		Vector<Integer> retVector = new Vector<Integer>();
		Integer ret[] = new Integer[1];
		
		int type = 0;
		
		splited = cmd.split(" ");
		
		if (cmd.startsWith("xor ")) {
			type = REG_REG;
			retVector.add(0);
		}
		else if (cmd.startsWith("and ")) {
			type = REG_REG;
			retVector.add(1);
		}
		else if (cmd.startsWith("or ")) {
			type = REG_REG;
			retVector.add(2);
		}
		else if (cmd.startsWith("cmp ")) {
			type = REG_REG;
			retVector.add(3);
		}
//		else if (cmd.startsWith("jmpt ")) {
//			ret.add(4);
//		}
//		else if (cmd.startsWith("jmpf ")) {
//		ret.add(5);
//		}
		else if (cmd.startsWith("add ")) {
			type = REG_REG;
			retVector.add(6);
		}
		else if (cmd.startsWith("sub ")) {
			type = REG_REG;
			retVector.add(7);
		}
		else if (cmd.startsWith("div ")) {
			type = REG_REG;
			retVector.add(8);
		}
		else if (cmd.startsWith("mul ")) {
			type = REG_REG;
			retVector.add(9);
		}
		else if (cmd.startsWith("mov ")) {
			type = REG_VAL;
			retVector.add(10);
		}
		else if (cmd.startsWith("load ")) {
			type = REG_ADR;
			retVector.add(11);
		}
		else if (cmd.startsWith("store ")) {
			type = ADR_REG;
			retVector.add(12);
		}
		else if (cmd.startsWith("capcall ")) {
			type = VAL_VAL;
			retVector.add(13);
		}
		else if (cmd.startsWith("exit")) {
			type = NONE;
			retVector.add(15);
		}
		else {
			throw new WorkingErrorException(cmd + ": Cmd not found");
		}
		
		if (type == NONE) {
			
		}
		else if (type == REG_REG) {
			int tmp = 0;
			tmp = new Integer(splited[1]).intValue() & 0x03;
			tmp = (tmp << 2) & 0x0C;
			tmp = tmp + (new Integer(splited[2]).intValue() & 0x03);
			retVector.add(tmp);
		}
		else if ((type == REG_VAL) || (type == REG_ADR)) {
			retVector.add(new Integer(splited[1]).intValue() & 0x03);
			retVector.add((new Integer(splited[2]).intValue() >> 4) & 0x0F);
			retVector.add(new Integer(splited[2]).intValue() & 0x0F);
		}
		else if (type == ADR_REG) {
			retVector.add((new Integer(splited[1]).intValue() >> 4) & 0x0F);
			retVector.add(new Integer(splited[1]).intValue() & 0x0F);
			retVector.add(new Integer(splited[2]).intValue() & 0x03);
		}
		else if (type == VAL_VAL) {
			retVector.add(new Integer(splited[1]).intValue() & 0x0F);
			retVector.add(new Integer(splited[2]).intValue() & 0x0F);
		}
		else {
			throw new WorkingErrorException(cmd + ": Type not found");
		}
		
		ret = retVector.toArray(ret);
		return(ret);
	}
}
