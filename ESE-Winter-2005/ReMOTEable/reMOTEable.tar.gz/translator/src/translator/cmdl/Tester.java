package translator.cmdl;

import translator.engine.SolveingErrorException;
import translator.engine.Translator;
import translator.engine.WorkingErrorException;

public class Tester {
	public static void main(String[] args) {
		String test = "mov 0 0\n" +
			"mov 2 1\n" +
			":start1\n" +
			"mov 1 10\n" +
			":start2\n" +
			"sub 1 2\n" +
			"capcall 15 1\n" +
			"cmp 1 0\n" +
			"jmpf start2\n" +
			"capcall 14 0\n" + 
			"exit";
/*		
		String test = "mov 0 0\n" +
		"mov 2 1\n" +
		":start1\n" +
		"mov 1 10\n" +
		":start2\n" +
		"sub 1 2\n" +
		"capcall 15 1\n" +
		"cmp 1 0\n" +
		"jmpf start2\n" +
		"capcall 15 2\n" +
		"cmp 0 0\n" +
		"jmpt start1\n" +
		"capcall 15 0\n";
*/
/*		String test = ":start\n" +
			"capcall 1 0\n" +
			"cmp 0 0\n" +
			"jnz start\n";
*/		
		
		try {
			//new Translator(test).toString();
			System.out.println(new Translator(test).getHumanReadable());
		} catch (WorkingErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SolveingErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
