package translator.cmdl;

import java.io.*;

import translator.engine.Translator;

public class Cmdl {

	public static void main(String[] args) {
		PrintStream fout;
		
		String input = "";
		String output = "";
		if (args.length == 1) {
			try {
				String line;
				FileInputStream fin =  new FileInputStream(args[0]);
				BufferedReader myInput = new BufferedReader (new InputStreamReader(fin));
				while ((line = myInput.readLine()) != null) {  
					input += (line + "\n");
				}
			}
			catch (Exception e) {
				System.err.println("Error opening file");
			}
			if (!input.equals("")) {
				try {
					output = new Translator(input).getHumanReadable();
				} catch (Exception e) {
					System.err.println(e.getMessage());
				}
				try {
					fout = new PrintStream(new FileOutputStream(args[0] + ".out"));
					fout.println(output);
					fout.close();
					System.out.println("Wrote result to " + args[0] + ".out"); 
				}
				catch (Exception e) {
					System.err.println ("Error writing to file");
				}
			}
		}
	}
}
