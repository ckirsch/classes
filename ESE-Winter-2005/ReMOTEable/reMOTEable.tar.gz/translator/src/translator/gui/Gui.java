package translator.gui;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingUtilities;
import java.awt.Point;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JFrame;
import javax.swing.JDialog;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import javax.swing.JFileChooser;

import java.io.*;

import translator.engine.Translator;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;


public class Gui {

	private JFrame jFrame;  //  @jve:decl-index=0:visual-constraint="10,10"

	private JPanel jContentPane;

	private JMenuBar jJMenuBar;

	private JMenu fileMenu;

	private JMenu helpMenu;

	private JMenuItem exitMenuItem;

	private JMenuItem aboutMenuItem;

	private JDialog aboutDialog;  //  @jve:decl-index=0:visual-constraint="534,330"

	private JButton jTranslateButton = null;

	private JLabel jCodeLabel = null;

	private JLabel jSourceLabel = null;

	private JButton jSendButton = null;

	private JTextArea sourceTextArea = null;

	private JTextArea codeTextArea = null;

	private JFileChooser jFileChooser = null;  //  @jve:decl-index=0:visual-constraint="9,322"

	private JMenuItem openMenuItem = null;

	private JScrollPane jSourceScrollPane = null;

	private JScrollPane jCodeScrollPane = null;

	private JTextPane jAboutTextPane = null;

	/**
	 * This method initializes jFrame
	 * 
	 * @return javax.swing.JFrame
	 */
	private JFrame getJFrame() {
		if (jFrame == null) {
			jFrame = new JFrame();
			jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jFrame.setJMenuBar(getJJMenuBar());
			jFrame.setSize(600, 300);
			jFrame.setContentPane(getJContentPane());
			jFrame.setTitle("reMOTEable Translator");

		}
		return jFrame;
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			GridBagConstraints gridBagConstraints11 = new GridBagConstraints();
			gridBagConstraints11.fill = GridBagConstraints.BOTH;
			gridBagConstraints11.gridy = 1;
			gridBagConstraints11.weightx = 1.0;
			gridBagConstraints11.weighty = 1.0;
			gridBagConstraints11.gridx = 3;
			GridBagConstraints gridBagConstraints10 = new GridBagConstraints();
			gridBagConstraints10.fill = GridBagConstraints.BOTH;
			gridBagConstraints10.gridy = 1;
			gridBagConstraints10.weightx = 1.0;
			gridBagConstraints10.weighty = 1.0;
			gridBagConstraints10.gridx = 0;
			GridBagConstraints gridBagConstraints8 = new GridBagConstraints();
			gridBagConstraints8.fill = GridBagConstraints.BOTH;
			gridBagConstraints8.gridy = 1;
			gridBagConstraints8.weightx = 1.0;
			gridBagConstraints8.weighty = 1.0;
			gridBagConstraints8.gridx = 0;
			GridBagConstraints sendButtonGridBagConstraints = new GridBagConstraints();
			sendButtonGridBagConstraints.gridx = 3;
			sendButtonGridBagConstraints.insets = new Insets(10, -54, 5, -54);
			sendButtonGridBagConstraints.gridy = 2;
			GridBagConstraints sourceLabelGridBagConstraints = new GridBagConstraints();
			sourceLabelGridBagConstraints.gridx = 0;
			sourceLabelGridBagConstraints.gridy = 0;
			GridBagConstraints codeLabelGridBagConstraints21 = new GridBagConstraints();
			codeLabelGridBagConstraints21.gridx = 3;
			codeLabelGridBagConstraints21.gridy = 0;
			GridBagConstraints gridBagConstraints = new GridBagConstraints();
			gridBagConstraints.gridx = 0;
			gridBagConstraints.gridy = 0;
			GridBagConstraints transButtonGridBagConstraints = new GridBagConstraints();
			transButtonGridBagConstraints.gridx = 1;
			transButtonGridBagConstraints.gridy = 1;
			jContentPane = new JPanel();
			jContentPane.setLayout(new GridBagLayout());
			jContentPane.add(getJTranslateButton(), transButtonGridBagConstraints);
			jContentPane.add(getJCodeLabel(), codeLabelGridBagConstraints21);
			jContentPane.add(getJSourceLabel(), sourceLabelGridBagConstraints);
			jContentPane.add(getJSendButton(), sendButtonGridBagConstraints);
			jContentPane.add(getJSourceScrollPane(), gridBagConstraints10);
			jContentPane.add(getJCodeScrollPane(), gridBagConstraints11);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jJMenuBar	
	 * 	
	 * @return javax.swing.JMenuBar	
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getFileMenu());
			jJMenuBar.add(getHelpMenu());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getFileMenu() {
		if (fileMenu == null) {
			fileMenu = new JMenu();
			fileMenu.setText("File");
			fileMenu.add(getOpenMenuItem());
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}

	/**
	 * This method initializes jMenu	
	 * 	
	 * @return javax.swing.JMenu	
	 */
	private JMenu getHelpMenu() {
		if (helpMenu == null) {
			helpMenu = new JMenu();
			helpMenu.setText("Help");
			helpMenu.add(getAboutMenuItem());
		}
		return helpMenu;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getExitMenuItem() {
		if (exitMenuItem == null) {
			exitMenuItem = new JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});
		}
		return exitMenuItem;
	}

	/**
	 * This method initializes jMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getAboutMenuItem() {
		if (aboutMenuItem == null) {
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			aboutMenuItem.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JDialog aboutDialog = getAboutDialog();
					aboutDialog.pack();
					Point loc = getJFrame().getLocation();
					loc.translate(20, 20);
					aboutDialog.setLocation(loc);
					aboutDialog.setVisible(true);
				}
			});
		}
		return aboutMenuItem;
	}

	/**
	 * This method initializes aboutDialog	
	 * 	
	 * @return javax.swing.JDialog
	 */
	private JDialog getAboutDialog() {
		if (aboutDialog == null) {
			aboutDialog = new JDialog(getJFrame(), true);
			aboutDialog.setTitle("About");
			aboutDialog.setContentPane(getJAboutTextPane());
		}
		return aboutDialog;
	}

	/**
	 * This method initializes jTranslateButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJTranslateButton() {
		if (jTranslateButton == null) {
			jTranslateButton = new JButton();
			jTranslateButton.setText("Translate");
			jTranslateButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					try {
						getCodeTextArea().setText(
								new Translator(getSourceTextArea().getText()).getHumanReadable());
					} catch (Exception ex) {
						getCodeTextArea().setText(ex.getMessage());
					}
				}
			});
		}
		return jTranslateButton;
	}

	/**
	 * This method initializes jCodeLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getJCodeLabel() {
		if (jCodeLabel == null) {
			jCodeLabel = new JLabel();
			jCodeLabel.setText("Result");
		}
		return jCodeLabel;
	}

	/**
	 * This method initializes jSourceLabel	
	 * 	
	 * @return javax.swing.JLabel	
	 */
	private JLabel getJSourceLabel() {
		if (jSourceLabel == null) {
			jSourceLabel = new JLabel();
			jSourceLabel.setText("Source");
		}
		return jSourceLabel;
	}

	/**
	 * This method initializes jSendButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJSendButton() {
		if (jSendButton == null) {
			jSendButton = new JButton();
			jSendButton.setText("Send to Mote");
			jSendButton.setToolTipText("Not implemented yet");
			jSendButton.setEnabled(false);
		}
		return jSendButton;
	}

	/**
	 * This method initializes sourceTextArea	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private JTextArea getSourceTextArea() {
		if (sourceTextArea == null) {
			sourceTextArea = new JTextArea();
			sourceTextArea.setText("mov 0 0\n" +
					"mov 2 1\n" +
					":start1\n" +
					"mov 1 10\n" +
					":start2\n" +
					"sub 1 2\n" +
					"capcall 15 1\n" +
					"cmp 1 0\n" +
					"jmpf start2\n" +
					"capcall 15 2\n" +
					"cmp 0 0\n" +
					"jmpt start1\n" +
					"capcall 15 0\n" +
					"exit\n");
		}
		return sourceTextArea;
	}

	/**
	 * This method initializes codeTextArea	
	 * 	
	 * @return java.awt.TextArea	
	 */
	private JTextArea getCodeTextArea() {
		if (codeTextArea == null) {
			codeTextArea = new JTextArea();
			codeTextArea.setEditable(false);
		}
		return codeTextArea;
	}

	/**
	 * This method initializes jFileChooser	
	 * 	
	 * @return javax.swing.JFileChooser	
	 */
	private JFileChooser getJFileChooser() {
		if (jFileChooser == null) {
			jFileChooser = new JFileChooser();
			jFileChooser.setCurrentDirectory(new File("./"));
		}
		return jFileChooser;
	}

	/**
	 * This method initializes openMenuItem	
	 * 	
	 * @return javax.swing.JMenuItem	
	 */
	private JMenuItem getOpenMenuItem() {
		if (openMenuItem == null) {
			openMenuItem = new JMenuItem();
			openMenuItem.setText("Open");
			openMenuItem.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					int returnVal = getJFileChooser().showOpenDialog(getJFrame());
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						try {
							String line;
							FileInputStream fin =  new FileInputStream(
									jFileChooser.getSelectedFile().getAbsolutePath());
							BufferedReader myInput = new BufferedReader
								(new InputStreamReader(fin));
							getSourceTextArea().setText("");
							while ((line = myInput.readLine()) != null) {  
								getSourceTextArea().append(line + "\n");
							}
						}
						catch (Exception ex) {
						}
					}
				}
			});
		}
		return openMenuItem;
	}

	/**
	 * This method initializes jSourceScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJSourceScrollPane() {
		if (jSourceScrollPane == null) {
			jSourceScrollPane = new JScrollPane();
			jSourceScrollPane.setViewportView(getSourceTextArea());
		}
		return jSourceScrollPane;
	}

	/**
	 * This method initializes jCodeScrollPane	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	private JScrollPane getJCodeScrollPane() {
		if (jCodeScrollPane == null) {
			jCodeScrollPane = new JScrollPane();
			jCodeScrollPane.setViewportView(getCodeTextArea());
		}
		return jCodeScrollPane;
	}

	/**
	 * This method initializes jAboutTextPane	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	private JTextPane getJAboutTextPane() {
		if (jAboutTextPane == null) {
			jAboutTextPane = new JTextPane();
			jAboutTextPane.setText("Translator for the reMOTEable Project\n" +
					"\nAuthors:\n" +
					"  Alois HOFSTAETTER\n" +
					"  Bernhard KAST\n" +
					"  Horst STADLER\n");
			jAboutTextPane.setEditable(false);
		}
		return jAboutTextPane;
	}

	/**
	 * Launches this application
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Gui application = new Gui();
				application.getJFrame().setVisible(true);
			}
		});
	}

}
