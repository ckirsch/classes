#include "defines.h"


typedef struct header_t
{
   uint8_t sourceDestination; //4 bit source address; 4 bit destination address
   uint8_t sessionSequenceReserveLast; //3 bit session (=agent) 3 bit Sequence; 1 bit reserved; 1 bit Last Packet
} header_t;

typedef struct payload_t 
{
  uint8_t data[27];
} payload_t;

typedef struct packet_t
{
   header_t header;
   payload_t payload;
} packet_t;

typedef struct neighbour_t {
   uint ttl;
} neighbour_t;

/*
typedef struct discoveryPacket_t
{
   uint8_t sourceDestination;
   uint8_t data; //1010 1010 = requestDiscoveryAnswer (= areYouAlive?); Answer = 01010101 = 85
} discoveryPacket_t;*/

typedef struct flags_t
{
   uint pc; //guess ;)  invariant: pc must be < cs_size; BEWARE pc hops are in halfbytes!!!!
   uint ret_cmp; //returnValueHolder for compares
   uint rest_div; //rest of div
   uint overUnderFlow; //Overflow/Underflow
   uint DivZero; //Divsion by zero flag
} flags_t;

typedef struct agent_t
{
   uint cs_size; //code segment size; must be < 256; invariant: pc must be < cs_size
   uint ds_size; //data segment size; must be < 256;
   uint8_t registers[4]; //r0,r1,r2,r3
   flags_t flags; //see declaration above
   uint8_t mem[215]; //430 halfbytes
} agent_t;

typedef struct sendAckVerification_t
{
   uint8_t sent; // was send_Agent() initiated?
   uint8_t sessionNumber; //session Number (for sending/receiving)
   uint8_t ackCounter; //number of failed ack verification runs (for all packets!)
   uint8_t numberOfPacketsNeeded; //number of packets needed in the actual transmission session
} sendAckVerification_t;

typedef struct slotTable_t
{
   uint8_t sessionNumber;
   uint8_t src;

   uint8_t used;
   uint8_t runnable; //for receiving only: if all packets recv ==> runnable, else not runnable
   uint8_t length;
//   uint8_t ackReceivedSentTable; 
   uint8_t ackSentTable;
   uint8_t ackReceivedTable;
} slotTable_t;

typedef struct transport_t {
	uint8_t retries;
	uint8_t address;
	uint8_t sessionNr;
	uint8_t ackList;
} transport_t;

typedef struct vmSlot_t {
	uint8_t state;
	transport_t transport;
	agent_t agent;
	uint8_t remainingTicks;
} vmSlot_t;

enum {
	VMSLOT_FREE = 0,
	VMSLOT_RUNNING = 1,
	VMSLOT_FILLING = 2,
	VMSLOT_WAITING = 3,
	VMSLOT_WAITING_FOR_NEIGHBOURS = 4,
	VMSLOT_WAITING_TO_BE_SENT = 5,
	VMSLOT_WAITING_FOR_SEND_ACK = 6
};
