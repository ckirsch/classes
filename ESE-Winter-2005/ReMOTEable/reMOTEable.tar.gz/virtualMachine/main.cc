/* Created by Anjuta version 1.2.2 */
/*	This file will not be overwritten */

#include <iostream>

typedef unsigned char uint8_t; 

typedef struct flags_t
{
   uint8_t pc; //guess ;)  invariant: pc must be < cs_size
   //uint8_t actualShift; //needed because we have variably command sizes
   uint8_t ret_cmp; //returnValueHolder for compares
   uint8_t rest_div; //rest of div
   uint8_t overUnderDivZero; //Overflow/Underflow and Divsion by zero flags 00000000 OVERUNDZ
} flags_t;

typedef struct agent_t
{
   flags_t flags; //see declaration above
   uint8_t registers[4]; //ax,bx,cx,dx
   uint8_t cs_size; //code segment size; must be < 256; invariant: pc must be < cs_size
   uint8_t mem[215]; //430 halfbytes
} agent_t;


  agent_t actualAgent;
  agent_t agentQueue[4];
  uint8_t actualAgentID;


   void initAgent()
   {
      uint8_t i;
      actualAgentID = 0;
      
      for(i = 0; i < 4; i++) {
         agentQueue[i].cs_size = 0;
         agentQueue[i].registers[0] = 0; 
         agentQueue[i].registers[1] = 0;
         agentQueue[i].registers[2] = 0;
         agentQueue[i].registers[3] = 0;
      }
/*
 //and, or test;
      actualAgent.registers[0] = 1; //0000 0001
      actualAgent.registers[1] = 3; //0000 0011
      actualAgent.registers[2] = 7; //0000 0111
      actualAgent.registers[3] = 1; 
      actualAgent.mem[0] = 17; //and ax, bx = 00010001 = 17
      actualAgent.mem[1] = 33; //or ax, bx = 00100001 = 33
      actualAgent.mem[2] = 34; //or ax, cx = 00100010 = 81
      actualAgent.mem[3] = 19; //and ax, dx = 00010011 = 19
      actualAgent.mem[4] = 17; 
      actualAgent.mem[5] = 33; 
      actualAgent.mem[6] = 34; 
      actualAgent.mem[7] = 19; 
      actualAgent.mem[8] = 17; 
      actualAgent.mem[9] = 33; 
      actualAgent.mem[10] = 34; 
      actualAgent.mem[11] = 19; 
      actualAgent.mem[12] = 17; 
      actualAgent.mem[13] = 33; 
      actualAgent.mem[14] = 34; 
      actualAgent.mem[15] = 19; 
*/  

/*
 //add, sub test;
      actualAgent.registers[0] = 0; //0000 0000
      actualAgent.registers[1] = 1; //0000 0001
      actualAgent.mem[0] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[1] = 81;//add ax, bx = 0101 00 01 = 81
      actualAgent.mem[2] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[3] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[4] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[5] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[6] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[7] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[8] = 81; //add ax, bx = 0101 00 01 = 81
      actualAgent.mem[9] = 97; //sub ax, bx = 0110 00 01 = 97
      actualAgent.mem[10] = 97; //sub ax, bx = 0110 00 01 = 81
      actualAgent.mem[11] = 97; //sub ax, bx = 0110 00 01 = 81
      actualAgent.mem[12] = 97; //sub ax, bx = 0110 00 01 = 81
      actualAgent.mem[13] = 97; //sub ax, bx = 0110 00 01 = 81
      actualAgent.mem[14] = 97; //sub ax, bx = 0110 00 01 = 81
      actualAgent.mem[15] = 97; //sub ax, bx = 0110 00 01 = 81
   */

/*
    //xor test + cmp + jnz test (looping)
      actualAgent.registers[0] = 7; //0000 0111
      actualAgent.registers[1] = 0;
	  actualAgent.registers[2] = 255; //1111 1111
      actualAgent.registers[3] = 0;
      actualAgent.mem[0] = 0; //xor ax, ax = 0000 00 00
      actualAgent.mem[1] = 2; //xor ax,cx = 0000 00 10
      actualAgent.mem[2] = 0; //xor ax, ax = 0000 00 00
      actualAgent.mem[3] = 2; //xor ax,cx = 0000 00 10
      actualAgent.mem[4] = 0; //xor ax, ax = 0000 00 00
      actualAgent.mem[5] = 2; //xor ax,cx = 0000 00 10
      actualAgent.mem[6] = 0; //xor ax, ax = 0000 00 00
      actualAgent.mem[7] = 2; //xor ax,cx = 0000 00 10
      //actualAgent.mem[8] = 55; //cmp bx,dx = 00110111 //loop forever
	  actualAgent.mem[8] = 54; //cmp bx,cx = 00110110 //won't loop
      actualAgent.mem[9] = 64; //jnz 01000000 0000 //last 4 bits into next array index
      actualAgent.mem[10] = 0 + 15; //WARNING only 4 bits used; to test + was added (kill)
*/
      //actualAgent.mem[2] = 9;  //mov ax, value = 1001 00 00 | 0000 xxxx
      //actualAgent.mem[3] = 0;
	  
	  
	  /*
	     //mov + jnz test (jnz is used because it is a 12 bit call (for testing purposes))
      actualAgent.registers[0] = 0; //0000 0111      
      actualAgent.registers[1] = 0;
      actualAgent.registers[2] = 0; //1111 1111
      actualAgent.registers[3] = 0;
      actualAgent.mem[0] = 144; //mov ax, 1 = 1001(00)00 00000001
	  actualAgent.mem[1] = 1; 
	  actualAgent.mem[2] = 145; //mov bx, 2 = 1001(00)01 00000010
	  actualAgent.mem[3] = 2; 
	  actualAgent.mem[4] = 146; //mov cx, 3 = 1001(00)10 00000011
	  actualAgent.mem[5] = 3; 
	  actualAgent.mem[6] = 147; //mov dx, 4 = 1001(00)11 00000100
	  actualAgent.mem[7] = 4;
	  actualAgent.mem[8] = 49;//cmp ax,bx = 00110001
	  actualAgent.mem[9] = 64;//jnz 0 = 01000000 0000
	  actualAgent.mem[10] = 0 + 9;//part 2 of jnz; part 1 of mov ax, 255 = 1001 ...
	  actualAgent.mem[11] = 0 + 15;//part 2 of mov ax, 255 =... (00)00 1111 ...
	  actualAgent.mem[12] = 240 + 9;//part 3 of mov ax,255 = ... 1111 xxxx; mov bx, 254 = 1001 ...
	  actualAgent.mem[13] = 16 + 15; // bx, 254 = (00)01 1111 ...
	  actualAgent.mem[14] = 224 + 0; //...1110 xxxx
	  */
	  
	  /*
	  //testing LOAD()
	  actualAgent.registers[0] = 0; //0000 0111      
      actualAgent.registers[1] = 0;
      actualAgent.registers[2] = 0; //1111 1111
      actualAgent.registers[3] = 0;
	  
	  actualAgent.mem[0] = 160; //load ax, 0 = 1010(00)00 00000000
	  actualAgent.mem[1] = 0; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[2] = 160; //load ax, 2 = 1010(00)00 00000010
	  actualAgent.mem[3] = 2; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[4] = 160; //load ax, 4 = 1010(00)00 00000100
	  actualAgent.mem[5] = 4; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[6] = 160; //load ax, 6 = 1010(00)00 00000110
	  actualAgent.mem[7] = 6; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[8] = 160; //load ax, 8 = 1010(00)00 00001000
	  actualAgent.mem[9] = 8; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[10] = 160; //load ax, 10 = 1010(00)00 00001010
	  actualAgent.mem[11] = 10; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[12] = 160;
	  actualAgent.mem[13] = 12; 
	  actualAgent.mem[14] = 160;
	  actualAgent.mem[15] = 14; 
	  actualAgent.mem[16] = 160;
	  actualAgent.mem[17] = 16; 
	  */
	  
	  /*--------------------------------*/

/*
	  //DATA SEGMENT STUFF //fine byte alignment
      actualAgent.cs_size = 255; //this are HALFBYTES!!!!!! (add 1 here to get the real size!)
	  actualAgent.mem[128] = 255;
	  actualAgent.mem[129] = 254;
	  actualAgent.mem[130] = 7;
	  actualAgent.mem[131] = 6;
	  actualAgent.mem[132] = 5;
	  actualAgent.mem[133] = 4;
	  actualAgent.mem[134] = 3;
	  actualAgent.mem[135] = 2;
	  actualAgent.mem[136] = 1;
	  actualAgent.mem[137] = 0;
	*/  
	/*
		  //DATA SEGMENT STUFF //with shitty half byte alignment
      actualAgent.cs_size = 254; //this are HALFBYTES!!!!!!(add 1 here to get the real size!)
	  //memory entries are: 255,254.7.6.5.4.3.2.1,0; but we have a half-byte shift!!!!
	  actualAgent.mem[127] = 0 + 15; // 0000 1111 (1111 = head part of 255)
	  actualAgent.mem[128] = 240 + 15; // 1111 1111 (1111 = tail part of 255; 1111 = head part of 254)
	  actualAgent.mem[129] = 224 + 0; //1110 0000 = 224 (1110 = tail part of 254; 0000 = head part of 7)
	  actualAgent.mem[130] = 112 + 0;// 0111 = 7  ==> 01110000 = 112
	  actualAgent.mem[131] = 96; //actually 6; 1100000
	  actualAgent.mem[132] = 80; //5 ; 1010000
	  actualAgent.mem[133] = 64; //4; 1000000
	  actualAgent.mem[134] = 48; //3 ; 110000
	  actualAgent.mem[135] = 32; //2 ; 100000
	  actualAgent.mem[136] = 16; //1; 10000
	  actualAgent.mem[137] = 0; //0; 
	  */
	  
	/*  
	  //testing STORE()
	  
	  actualAgent.registers[0] = 255; //1111 0111      
      actualAgent.registers[1] = 123;
      actualAgent.registers[2] = 117; //1111 1111
      actualAgent.registers[3] = 23;
	  
	  actualAgent.mem[0] = 176; //store address(0), ax = 10110000 0000(00)00
	  actualAgent.mem[1] = 0 + 0; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[2] = 176; //store address(2), bx = 10110000 0010(00)01
	  actualAgent.mem[3] = 32 + 1; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  
	  actualAgent.mem[4] = 176; //store address(4), cx = 10110000 0100(00)10
	  actualAgent.mem[5] = 64 + 2; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[6] = 176; //store address(6), dx = 10110000 0110(00)11
	  actualAgent.mem[7] = 96 + 3; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[8] = 176; //store address(8), ax = 10110000 1000(00)00
	  actualAgent.mem[9] = 128 + 0; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[10] = 176; //store address(10), bx = 10110000 1010(00)01
	  actualAgent.mem[11] = 160 + 1; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)

	//loading to test if half-byte alignment stuff works also correcty
	  actualAgent.mem[12] = 160; //load ax, 0 = 1010(00)00 00000000
	  actualAgent.mem[13] = 0; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[14] = 160; //load ax, 2 = 1010(00)00 00000010
	  actualAgent.mem[15] = 2; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[16] = 160; //load ax, 4 = 1010(00)00 00000100
	  actualAgent.mem[17] = 4; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[18] = 160; //load ax, 6 = 1010(00)00 00000110
	  actualAgent.mem[19] = 6; //address: NOTE halfbyte addressing but register holds 1 byte! (therefore hop = 2)
	  actualAgent.mem[20] = 160; //load ax, 8 = 1010(00)00 00001000

	  
	  actualAgent.cs_size = 255; //this value is in HALFBYTES!!!!!! (add 1 here to get the real size!)
	  //actualAgent.cs_size = 254;//this value is in HALFBYTES!!!!!! (add 1 here to get the real size!)
	  */
	  
	  /*
	  //testing capcall
	  actualAgent.registers[0] = 255; //1111 0111      
      actualAgent.registers[1] = 123;
      actualAgent.registers[2] = 117; //1111 1111
      actualAgent.registers[3] = 23;
	  
	  actualAgent.mem[0] = 192 + 0; //capcall package(4bit), call(4bit): 12 = 1100 0000 [0000]
	  actualAgent.mem[1] = 0 + 12; //0000 (from above) 1100 (capcall) (capcall 0,1)
	  actualAgent.mem[2] = 0 + 1; 
	  actualAgent.mem[3] = 192 + 1; //capcall 1,1
	  actualAgent.mem[4] = 16 + 0; // 0001 0000
	  
	  actualAgent.cs_size = 255; //this value is in HALFBYTES!!!!!!!!! (add 1 here to get the real size!)
	  */
	  
	    //testing capcall 1st agent
	  agentQueue[0].registers[0] = 0;       
     agentQueue[0].registers[1] = 0;
     agentQueue[0].registers[2] = 0;
     agentQueue[0].registers[3] = 0;
	  
	  agentQueue[0].mem[0] = 192 + 0; //capcall package(4bit), call(4bit): 12 = 1100 0000 [0000]
	  agentQueue[0].mem[1] = 0 + 12; //0000 (from above) 1100 (capcall) (capcall 0,1)
	  agentQueue[0].mem[2] = 0 + 1; 
	  agentQueue[0].mem[3] = 192 + 1; //capcall 1,1
	  agentQueue[0].mem[4] = 16 + 3; // 0001 1100 ; cmp (ax, ax)
     agentQueue[0].mem[5] = 0 + 4; //ax,ax; jnz 0
     agentQueue[0].mem[6] = 0; //jnz 0
     	  
	  agentQueue[0].cs_size = 255; //this value is in HALFBYTES!!!!!!!!! (add 1 here to get the real size!)

//2nd agent
	  agentQueue[1].registers[0] = 0;       
     agentQueue[1].registers[1] = 0;
     agentQueue[1].registers[2] = 0;
     agentQueue[1].registers[3] = 0;
	  
	  agentQueue[1].mem[0] = 192 + 0; //capcall package(4bit), call(4bit): 12 = 1100 0000 [0000]
	  agentQueue[1].mem[1] = 0 + 12; //0000 (from above) 1100 (capcall) (capcall 0,1)
	  agentQueue[1].mem[2] = 0 + 1; 
	  agentQueue[1].mem[3] = 192 + 1; //capcall 1,1
	  agentQueue[1].mem[4] = 0 + 3; // 0001 1100 ; cmp (ax, ax)
     agentQueue[1].mem[5] = 0 + 4; //ax,ax; jnz 0
     agentQueue[1].mem[6] = 0; //jnz 0
	  
	  agentQueue[1].cs_size = 255; //this value is in HALFBYTES!!!!!!!!! (add 1 here to get the real size!)
   }
   

   void incPC()
   {
	   actualAgent.flags.pc = actualAgent.flags.pc + 1;
	   if (actualAgent.flags.pc >= actualAgent.cs_size) //this should not happen!
	   {
		   //TODO: something
	   }
		   
   }

   
   
	
   
void XOR()   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      
	reg1 = actualAgent.registers[numberOfRegister1]; 
    reg2 = actualAgent.registers[numberOfRegister2]; 	  

      reg1 = (reg1 & ~(reg2)) | (~(reg1) & reg2); //BEWARE !0 = 1 (NOT 0 = 1), therefore use of ~
      actualAgent.registers[numberOfRegister1] = reg1;
   }

   void AND() 
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      
	reg1 = actualAgent.registers[numberOfRegister1]; 
    reg2 = actualAgent.registers[numberOfRegister2]; 
      reg1 = reg1 & reg2;
      actualAgent.registers[numberOfRegister1] = reg1;

   }

   void OR()
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      
	reg1 = actualAgent.registers[numberOfRegister1]; 
    reg2 = actualAgent.registers[numberOfRegister2]; 

      //actualAgent.flags.actualShift = actualAgent.flags.actualShift + 4;
      reg1 = reg1 | reg2;
      actualAgent.registers[numberOfRegister1] = reg1;
   }

   void CMP()
   {
	   uint8_t numberOfRegister1,numberOfRegister2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      

      //actualAgent.flags.actualShift = actualAgent.flags.actualShift + 4;
      if (actualAgent.registers[numberOfRegister1] == actualAgent.registers[numberOfRegister2])
         actualAgent.flags.ret_cmp = 1;
      else
         actualAgent.flags.ret_cmp = 0;
      
   }
   
    void JNZ()
   {
      uint8_t addressPart1;
      uint8_t addressPart2;
      uint8_t address;

	  //printf("ret_cmp: %d\n",actualAgent.flags.ret_cmp);
		   
      if (actualAgent.flags.ret_cmp == 1)
      {
		 addressPart1= (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
		  incPC();
    	  addressPart2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
		  incPC();
	 
         address = addressPart1 | addressPart2; //combine them
		  printf("addr1: %d , addr2: %d, address: %d\n", addressPart1, addressPart2, address);
         actualAgent.flags.pc = address;      //jump
      }
	  else 
	  {
		  incPC(); //first address part
		  incPC(); //second address part
	  }
   }

   void ADD()
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      
	reg1 = actualAgent.registers[numberOfRegister1]; 
    reg2 = actualAgent.registers[numberOfRegister2]; 
      reg1 = reg1 + reg2;
      actualAgent.registers[numberOfRegister1] = reg1;
   }

   void SUB()
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      
	   reg1 = actualAgent.registers[numberOfRegister1]; 
       reg2 = actualAgent.registers[numberOfRegister2]; 
      reg1 = reg1 - reg2;
      actualAgent.registers[numberOfRegister1] = reg1;
   }

   //TODO: test (only tested indirectly via add (copy paste code)
   void DIV()
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();        
   
	   reg1 = actualAgent.registers[numberOfRegister1]; 
      reg2 = actualAgent.registers[numberOfRegister2]; 
	   
      reg1 = reg1 / reg2;
      actualAgent.flags.rest_div = reg1 % reg2;
      actualAgent.registers[numberOfRegister1] = reg1;     
   }

   //TODO: test (only tested indirectly via add (copy paste code)
   void MUL()
   {
	   uint8_t numberOfRegister1,numberOfRegister2,reg1,reg2;
	   
	numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>((((actualAgent.flags.pc+1) %2)*4)+2)) & 3;
	numberOfRegister2 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	incPC();      

	   reg1 = actualAgent.registers[numberOfRegister1]; 
      reg2 = actualAgent.registers[numberOfRegister2]; 

      reg1 = reg1 * reg2;
      actualAgent.registers[numberOfRegister1] = reg1;
   }

   void MOV()
   {
      uint8_t numberOfRegister1;
      uint8_t valuePart1;
      uint8_t valuePart2;
      uint8_t value;

	  numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	  incPC();
	  //printf("register: %d\n",  numberOfRegister1);
	  
	  if ((actualAgent.flags.pc % 2) ==0) //everything is fine
	  {
	      valuePart1 = actualAgent.mem[actualAgent.flags.pc/2] ;
	      incPC();
    	  valuePart2 =actualAgent.mem[actualAgent.flags.pc/2];
          incPC();
	  }
	  else //halfbytes are "in wrong order"
	  {
	      valuePart1 = (actualAgent.mem[actualAgent.flags.pc/2] << (4)) & 240;//shift it
	      incPC();
    	  valuePart2 =(actualAgent.mem[actualAgent.flags.pc/2] >>(4)) & 15;
          incPC();
	  }
	  
      value = valuePart1 | valuePart2; //combine them
	  //printf("value1: %d , value2: %d, value: %d\n",valuePart1,valuePart2,value);
      actualAgent.registers[numberOfRegister1] = value;
      
   }

   void LOAD()
   {
	  uint8_t numberOfRegister1;
      uint8_t addressPart1;
      uint8_t addressPart2;
      uint8_t relative_address;
	  uint8_t absolute_address;
	  uint8_t value, valuePart1,valuePart2;
	  uint8_t beginOfDS;

	   
	  numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	  incPC();
	  //printf("register: %d\n",  numberOfRegister1);
	  
	  if ((actualAgent.flags.pc % 2) ==0) //everything is fine
	  {
	      addressPart1 = actualAgent.mem[actualAgent.flags.pc/2] ;
	      incPC();
    	  addressPart2 =actualAgent.mem[actualAgent.flags.pc/2];
          incPC();
	  }
	  else //halfbytes are "in wrong order"
	  {
	      addressPart1 = (actualAgent.mem[actualAgent.flags.pc/2] << (4)) & 240;//shift it
	      incPC();
    	  addressPart2 =(actualAgent.mem[actualAgent.flags.pc/2] >>(4)) & 15;
          incPC();
	  }
	  
      relative_address = addressPart1 | addressPart2; //combine them
	  //printf("value1: %d , value2: %d, value: %d\n",valuePart1,valuePart2,value);
	  
	  //get value from DataSegment
	  beginOfDS = (actualAgent.cs_size + 1) / 2;
	  //printf("beginOfDS: %d\n",beginOfDS);
	  //printf("address:%d\n",relative_address);
	  
	  absolute_address = (relative_address/2) + beginOfDS;
	  
	  
		//check for correct alignment	  
	  if((beginOfDS %2 + relative_address%2) % 2 ==0)//alignment correct
	  {
		  //one byte or not one byte?
		  value = actualAgent.mem[absolute_address + (beginOfDS %2 + relative_address%2)] ;
	  }
	  else//halfbytes are "in wrong order"
	  {
		  valuePart1 = (actualAgent.mem[absolute_address] << (4)) & 240;//shift it
    	  valuePart2 =(actualAgent.mem[absolute_address + 1] >>(4)) & 15;
		  value = valuePart1 | valuePart2;
	  }
	  
      actualAgent.registers[numberOfRegister1] = value;
      
   }

   //STORE address, register (4 + 8 + (2) + 2)
   void STORE()
   {
	  uint8_t numberOfRegister1;
      uint8_t addressPart1;
      uint8_t addressPart2;
      uint8_t relative_address;
	  uint8_t absolute_address;
	  uint8_t value, valuePart1,valuePart2;
	  uint8_t beginOfDS;

	  /*
	   for (int i=126;i<132;i++)
	  {
		  printf("memory: pos %d  - value %x\n",i,actualAgent.mem[i]);
	  }		  
	  */
	   
	  if ((actualAgent.flags.pc % 2) ==0) //everything is fine
	  {
	      addressPart1 = actualAgent.mem[actualAgent.flags.pc/2] ;
	      incPC();
    	  addressPart2 =actualAgent.mem[actualAgent.flags.pc/2];
          incPC();
	  }
	  else //halfbytes are "in wrong order"
	  {
	      addressPart1 = (actualAgent.mem[actualAgent.flags.pc/2] << (4)) & 240;//shift it
	      incPC();
    	  addressPart2 =(actualAgent.mem[actualAgent.flags.pc/2] >>(4)) & 15;
          incPC();
	  }
	  
	  numberOfRegister1 = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 3;
	  incPC();
	  //printf("register: %d\n",  numberOfRegister1);

	  
      relative_address = addressPart1 | addressPart2; //combine them
	  
	  //get value from DataSegment
	  beginOfDS = (actualAgent.cs_size + 1) / 2;
	  //printf("beginOfDS: %d\n",beginOfDS);
	  //printf("address:%d\n",relative_address);
	  
	  absolute_address = (relative_address/2) + beginOfDS;
	  
	  
	  value = actualAgent.registers[numberOfRegister1]; 
	  
		//check for correct alignment	  
	  if((beginOfDS %2 + relative_address%2) % 2 ==0)//alignment correct
	  {
		  //one byte or not one byte?
		 actualAgent.mem[absolute_address + (beginOfDS %2 + relative_address%2)] = value;
	  }
	  else//halfbytes are "in wrong order"
	  {
		  valuePart1 = (value << (4)) & 240;//shift it
    	  valuePart2 =(value >>(4)) & 15;
		  //NOTE: add because otherwise other half-byte values would be overwritten!!!
		  actualAgent.mem[absolute_address] = actualAgent.mem[absolute_address] + valuePart1;
		  actualAgent.mem[absolute_address + 1] = + actualAgent.mem[absolute_address+1] + valuePart2;

	  }

  
	  
      
   }


   
   void CAPCALL_0_0_SEND()
   {
	   printf("CAPCALL_0_0_SEND()\n");
   }
   
   void CAPCALL_0_1_GET_ACTUAL_MOTE()
   {
	   printf("CAPCALL_0_1_GET_ACTUAL_MOTE()\n");
   }
   
   void CAPCALL_0_2_GET_NEIGHBOUR_MOTES()
   {
	   printf("CAPCALL_0_2_GET_NEIGHBOUR_MOTES()\n");
   }
   
   void CAPCALL_0_3_REPLICATE()
   {
	   printf("CAPCALL_0_3_REPLICATE()\n");
   }

   void CAPCALL()
   {
	   uint8_t package;
	   uint8_t capcall;
	   
  	   package= (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 15;
	   incPC();
       capcall = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 15;
 	   incPC();
	   
	   printf("package: %d , capcall: %d\n",package,capcall);
	   
	   if (package == 0)
	   {
		   if (capcall == 0)  CAPCALL_0_0_SEND();
		   else if (capcall == 1) CAPCALL_0_1_GET_ACTUAL_MOTE();
		   else if (capcall == 2) CAPCALL_0_2_GET_NEIGHBOUR_MOTES();
		   else if (capcall == 3)CAPCALL_0_3_REPLICATE();
		
	
	   }
	   else if (package == 1)
	   {
	   }
	   else if (package == 2)
	   {
	   }
	   else if (package == 3)
	   {
	   }
	 


	   
   }

   void KILL()
   {
	   exit(0);
   }
   
      void nextAgent()
   {
      //TODO: do something where there is NO agent
      do
      {  
         actualAgentID = (actualAgentID + 1) % 4;
      }while (agentQueue[actualAgentID].cs_size == 0);
   }
   
      void loadActualAgent()
   {
      uint8_t i;
      actualAgent = agentQueue[actualAgentID];
      actualAgent.cs_size = agentQueue[actualAgentID].cs_size;
      for(i = 0;i<4;i++)
         actualAgent.registers[i] = agentQueue[actualAgentID].registers[i];
      for(i = 0;i<215;i++)
         actualAgent.mem[i] = agentQueue[actualAgentID].mem[i];

      actualAgent.flags.pc = agentQueue[actualAgentID].flags.pc;
      actualAgent.flags.ret_cmp = agentQueue[actualAgentID].flags.ret_cmp;
      actualAgent.flags.rest_div = agentQueue[actualAgentID].flags.rest_div;
      actualAgent.flags.overUnderDivZero = agentQueue[actualAgentID].flags.overUnderDivZero;
   }

   void saveActualAgent()
   {
      uint8_t i;
      agentQueue[actualAgentID] = actualAgent;
      agentQueue[actualAgentID].cs_size =actualAgent.cs_size;
      for(i = 0;i<4;i++)
         agentQueue[actualAgentID].registers[i] = actualAgent.registers[i];
      for(i = 0;i<215;i++)
         agentQueue[actualAgentID].mem[i] = actualAgent.mem[i];

      agentQueue[actualAgentID].flags.pc = actualAgent.flags.pc;
      agentQueue[actualAgentID].flags.ret_cmp = actualAgent.flags.ret_cmp;
      agentQueue[actualAgentID].flags.rest_div = actualAgent.flags.rest_div;
      agentQueue[actualAgentID].flags.overUnderDivZero = actualAgent.flags.overUnderDivZero;
   }
   
   
   
   void interpreter()
   { 
	   uint8_t cmd;
      
      
		loadActualAgent();
	   
	   cmd = (actualAgent.mem[actualAgent.flags.pc/2] >>(((actualAgent.flags.pc+1) %2)*4)) & 15;
	   	incPC();
      
	   
	  printf("cmd: %d  pc: %d\n",cmd,actualAgent.flags.pc);
	  uint8_t ax = actualAgent.registers[0];
	  uint8_t bx = actualAgent.registers[1];
	  uint8_t cx = actualAgent.registers[2];
	  uint8_t dx = actualAgent.registers[3];
	  printf("r0: %d, r1: %d, r2: %d, r3: %d\n",ax,bx,cx,dx);

      //reg callsize: 2 bit; address callsize: 4 bit
      if (cmd == 0) XOR();//XOR reg,reg; 
      else if (cmd == 1) AND();//AND reg,reg
      else if (cmd == 2) OR(); //OR reg,reg
      else if (cmd == 3) CMP(); //CMP
      else if (cmd == 4) JNZ(); //JNZ
      else if (cmd == 5) ADD(); //ADD
      else if (cmd == 6) SUB(); //SUB
      else if (cmd == 7) DIV(); //DIV
      else if (cmd == 8) MUL(); //MUL
      else if (cmd == 9) MOV(); //MOV
      else if (cmd == 10) LOAD(); //LOAD
      else if (cmd == 11) STORE(); //STORE
      else if (cmd == 12) CAPCALL(); //CAPCALL
	  else if (cmd == 15) KILL();

	 saveActualAgent();
	  nextAgent();

   }

int main()
{
	int dummy;
	
	initAgent();
	
	while(true)
	{
		interpreter();
		std::cout << "press any key to continue" << std::endl;
		dummy = getchar();
		
		//std::cout << "getch()" << std::endl;
	}
	
	
	return 0;
}
