/*! \file chiroptera.c
 *  \brief Chiroptera main C file.
 */

#include "../config.h"
#include "chiroptera.h"

// argp parameter parser initialization
const char *argp_program_version = PACKAGE_STRING;
const char *argp_program_bug_address = PACKAGE_BUGREPORT;
static char doc[] = "chiroptera -- a zigbee localization daemon";
static char args_doc[] = "";
static struct argp_option options[] = {
    {"tty",         't',    "SERIAL",   0,  "Path to serial listener interface. (default: /dev/ttyS1)"},
    {"priority",    'p',    "PRIORITY", 0,  "Set scheduling priority. (default: not set)"},
    {"sleep",       's',    "SLEEP",    0,  "Set rt-loop sleep. (default: 300msec)"},
    {"lock-heap",   'l',    0,          0,  "Enable heap locking. (default: not set)"},
    {"nodes",       'n',    "NODES",    0,  "Number of nodes (default: 3)"},
    {"debug",       'd',    0,          0,  "Enable debuging to stdout."},
    { 0 }
};

static struct argp argp = { options, parse_opt, args_doc, doc };
pthread_mutex_t process_mutex;
arguments args;

int main (int argc, char *argv[])
{
    int fd;                 // serial file descriptor
    struct __measurement m; // measurement container
    struct timespec t;      // time argument for sleep
    struct sched_param param; // scheduler container
    pthread_t process_thread;
    thread_param tp;
    struct __position pos;

    // init arguments (to default values)  and parse them
    init_args (&args);
    argp_parse (&argp, argc, argv, 0, 0, &args);
   
    if (args.debug) printf("Starting initialization\n");

    pthread_mutex_init (&process_mutex, NULL);

    // memory intialization and other NON RT stuff
    m.max_len = args.nodes;
    // alloc beacons and init them to 0, since id=0 indicates free slot
    m.beacons = (struct __beacon*) calloc(m.max_len,sizeof(struct __beacon));

    init_serial (args.serial,&fd);

    // enable higher scheduling priortiy
    // NEEDS: SYS_NICE capability
    if (args.sched_prio > 0)
      {
        param.sched_priority = args.sched_prio;
        if(sched_setscheduler(0, SCHED_FIFO, &param) == -1) 
          {
            perror("sched_setscheduler failed");
            exit(-1);
          }
      }

    // lock acquired memory on heap
    // NEEDS: CAP_IPC_LOCK
    if (args.lock_heap)
      {
        if(mlockall(MCL_CURRENT|MCL_FUTURE) == -1) 
          {
            perror("mlockall failed");
            exit(-1);
          }
      }

    tp.fd = fd;
    tp.measurement = &m;
    tp.pos = &pos;

    clock_gettime (CLOCK_MONOTONIC, &t);
    t.tv_sec++;
    if (args.debug) printf("Entering real-time loop\n");
    while (1)
      { // RT loop
        clock_nanosleep (CLOCK_MONOTONIC, TIMER_ABSTIME, &t, NULL);
        if( pthread_create (&process_thread, NULL, process_data, &tp) != 0)
          {
            perror(NULL);
          }
        t.tv_nsec += args.sleep;
        tsnorm (&t);
      }

    // clean up
    close_serial (&fd);
    pthread_mutex_destroy (&process_mutex);

    return 0;
}

static inline void 
tsnorm (struct timespec *ts)
{
    while (ts->tv_nsec >= NSEC_PER_SEC)
      {
        ts->tv_nsec -= NSEC_PER_SEC;
        ts->tv_sec++;
      }
}

/**
 * IMPORTANT: PROCESSING MUST BE FASTER THAN INTERVALL!
 *  othwerwise we would create a queue of jobs and
 *  be not rt any more
 */
void*
process_data (void *ptr)
{
    char buffer[255];   // buffer to store serial data
    char buffer2[30];
    int bc;             // byte count
    thread_param *tp;

    tp = ptr;
    if ( pthread_mutex_trylock (&process_mutex) != 0)
      {
        if (args.debug) printf("Unable to lock mutex. Skipping to prevent queueing!\n");
        return;
      }
    
    while( (bc = read(tp->fd,buffer,255)) > 0)
      {
        buffer[bc] = '\0';
        parse_data (buffer, tp->measurement);
      }

    if (gettimeofday (&(tp->measurement->timestamp), NULL) < 0)
      {
        perror ("gettimeofday failed");
        exit (-1);
      }

    // DEBUGING COSTS RESOURCES!
    if (args.debug)
      {
        printf("Measurement summary\n");
        printf("-------------------\n");
        int j;
        int k=0;
        for (j=0;j<tp->measurement->max_len;j++)
          {
            if(tp->measurement->beacons[j].id != 0)
              {
                printf("id: %d;RSSI: %d;LQI: %d\n",
                    tp->measurement->beacons[j].id, 
                    tp->measurement->beacons[j].avg_rssi, 
                    tp->measurement->beacons[j].lqi);
                k++;
              }
          }
        printf("Number of nodes: %d\n",k);
        time_t timestamp = tp->measurement->timestamp.tv_sec;
        strftime(buffer2,30,"%d.%m.%Y  %T",localtime(&timestamp));
        printf("Time: %s.%03ld\n", buffer2,tp->measurement->timestamp.tv_usec/1000);
        printf("\n");
      }

    // TODO CALCULATE
    // OUTPUT ON CONSOLE

    memset (tp->measurement->beacons,0,sizeof(struct __beacon)*tp->measurement->max_len);
    pthread_mutex_unlock (&process_mutex);
}

static void
init_args (arguments *args)
{
    args->nodes = DEFAULT_NODES;
    args->serial = DEFAULT_SERIAL; 
    args->sched_prio = 0;
    args->lock_heap = 0;
    args->sleep = 300000000;
    args->debug = 0;
}

static void
parse_data (char *data_str, struct __measurement *m)
{
    char *pch;
    unsigned short cnt;
    int tmp_lqi=0;
    int tmp_rssi=0;
    int tmp_avg_rssi=0;
    unsigned short tmp_id=0;

    // check for line length
    // costs speed, but is needed to dismiss wrong packets
    if( strlen(data_str) != 30) 
      {
        if (args.debug) printf("Invalid data length. Skipping.\n");
        return;
      }


    pch = strtok(data_str,";");
    while (pch != NULL)
      {
        sscanf(pch,"LQI:%8d;",&tmp_lqi);
        sscanf(pch,"RSSI:%d(%d);",&tmp_avg_rssi,&tmp_rssi);
        sscanf(pch,"ID:%2hd",&tmp_id);
        pch = strtok (NULL,";");
      }
   
    if(tmp_id!=0)
      {
        cnt=0;
        while (cnt < m->max_len)
          {
            if (m->beacons[cnt].id == 0 || m->beacons[cnt].id == tmp_id)
              {
                m->beacons[cnt].id = tmp_id;
                m->beacons[cnt].lqi = tmp_lqi;
                m->beacons[cnt].avg_rssi = tmp_avg_rssi;
                m->beacons[cnt].rssi = tmp_rssi;
                break;
              }
            cnt++;
          }
      }
}

static void
close_serial (int *fd)
{
    if (close (*fd) < 0)
      {
        perror (NULL);
        exit (-1);
      }
}

static void
init_serial (char *serial, int *fd)
{
    struct termios tio;
    if( (*fd = open (serial,O_RDONLY | O_NOCTTY | O_NONBLOCK)) < 0)
      { // unable to open serial, exit
        perror (serial);
        exit (-1);
      }

    tio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD | CSTOPB;  // baud, 8 databits, local conn, enable recv 
    tio.c_iflag = IGNPAR | ICRNL;                   // ignore bits with parity errors, map CR to NL 
    tio.c_oflag = 0;                                // no raw mode 
    tio.c_lflag = ICANON;                           // canonical processing
    tio.c_cc[VMIN] = 0;                           // block read until x chars read 
    tio.c_cc[VTIME] = 0;                                
    tcflush (*fd, TCIFLUSH);                        // flush 
    tcsetattr (*fd, TCSANOW, &tio);
}

static error_t
parse_opt (int key, char *arg, struct argp_state *state)
{
    arguments *args = state->input;
    switch (key)
      {
        case 't':
            args->serial = arg;
            break;
        case 'n':
            args->nodes = atoi(arg);
            break;
        case 'p':
            args->sched_prio = atoi(arg);
            break;
        case 'l':
            args->lock_heap = 1;
            break;
        case 's':
            args->sleep = atol(arg);
            break;
        case 'd':
            args->debug = 1;
            break;
        default:
            return ARGP_ERR_UNKNOWN;
      }
    return 0;
}

