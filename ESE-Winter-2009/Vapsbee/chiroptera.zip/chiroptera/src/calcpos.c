#include "calcpos.h"

void 
calcpos(struct __position *pos,struct __measurement *m, struct __playground *floor)
{
    double x;
    double y;
    double zx;
    double zy;
    double zv;
    double zu;
    double dista;
    double distb;
    double distc;

    printf("Calcpos: for %d measurements",m->max_len);
    dista=m->beacons[0].rssi;
    distb=m->beacons[1].rssi;
    distc=m->beacons[2].rssi;	

    if(args.debug)
	  {
	    printf("\ndista %f:",dista);
	    printf("\ndistb %f:",distb);	
	    printf("\ndistc %f:",distc);
	  }

    // calc zx -helper
    zx=dista-distb+sqrt(floor->beaconspos[0].x)+sqrt(floor->beaconspos[1].x)-sqrt(floor->beaconspos[0].y)-sqrt(floor->beaconspos[1].y);
    // calc zy -helper
    zy=distb-distc-sqrt(floor->beaconspos[1].x)+sqrt(floor->beaconspos[2].x)-sqrt(floor->beaconspos[1].y)+sqrt(floor->beaconspos[2].y);
    // calc zv helper
    zv=(2*floor->beaconspos[0].y-2*floor->beaconspos[1].y)*(-2*floor->beaconspos[1].x+2*floor->beaconspos[2].x);
    // calc zu helper
    zu=(-2*floor->beaconspos[0].x+2*floor->beaconspos[1].x)*(-2*floor->beaconspos[1].y+2*floor->beaconspos[2].y);

    if(args.debug)
	  {
        printf("\nZX %f:",zx);
        printf("\nZY %f:",zy);
        printf("\nZV %f:",zv);	
        printf("\nZU %f:",zu);	
	  }
	
	if((zu+zv)==0)
	  {
	    perror("division by 0; failed");
        exit(-1);
 	  }

    y=-zx+zy*(-2*floor->beaconspos[0].x+2*floor->beaconspos[1].x);
    x=(zx-y*(2*floor->beaconspos[0].y-2*floor->beaconspos[1].y))/(-2*floor->beaconspos[0].x+floor->beaconspos[1].x);

    pos->rel_x=x;
    pos->rel_y=y;
    printf("x= %f, y= %f\n",pos->rel_x,pos->rel_y);
}

void 
setfloor(struct __playground *floor)
{
    int cnt;
    int i;
    cnt=0;

    floor->beaconspos[cnt].id=cnt;
    floor->beaconspos[cnt].x=0.1;
    floor->beaconspos[cnt].y=1.1;
    cnt++;
    floor->beaconspos[cnt].id=cnt;
    floor->beaconspos[cnt].x=0.1;
    floor->beaconspos[cnt].y=0.1;
    cnt++;
    floor->beaconspos[cnt].id=cnt;
    floor->beaconspos[cnt].x=1.1;
    floor->beaconspos[cnt].y=0.1;
    cnt++;
    if(args.debug)
      {
        for(i=0;i<cnt;i++)
          {
            printf("\nPlant %d:",floor->beaconspos[i].id);
            printf("\nX %f:",floor->beaconspos[i].x);
            printf("\nY %f:",floor->beaconspos[i].y);	
          }
      }
}

