#include <math.h>
#include "chiroptera.h"

/*! \struct __beaconpos
 *  \brief Struct holding beacon position data
  */
typedef struct __beaconpos {
    unsigned short id;
	double x;
	double y;
} beaconpos; 

/*! \struct __playground
 *  \brief Struct playground holding position data
  */
typedef struct __playground {
    unsigned short max_len;
	struct __beaconpos  *beaconspos;
} playground; 

void setfloor(struct __playground*);

void calcpos(struct __position*,struct __measurement *,struct __playground *);
