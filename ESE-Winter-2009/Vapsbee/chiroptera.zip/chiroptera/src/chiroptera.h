/* \file chiroptera.h
 * \brief Chiroptera main h file.
 */
#ifndef __CHIROPTERA_H__
#define __CHIROPTERA_H__

// "standard" includes
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/signal.h>
#include <sys/mman.h>
#include <string.h>
#include <time.h>
#include <sched.h>
#include <pthread.h>

// custom includes
#include <argp.h>

#define NSEC_PER_SEC    (1000000000)

#define BAUDRATE B38400
#define DEFAULT_SERIAL "/dev/ttyS1"

#define DEFAULT_NODES 3

/*! \struct __arguments
 *  \brief Struct holding the program arguments.
 *
 *  \typedef arguments 
 *  \brief Typedef for __arguments.
 */
typedef struct __arguments {
    char *serial;   /*!< Serial interface the should be used to fetch data. */
    unsigned short nodes; /*!< Number of nodes space should be allocated for. */
    unsigned short sched_prio;
    unsigned short lock_heap;
    unsigned long sleep;
    unsigned short debug;
} arguments;


typedef struct __thread_param {
    int fd;
    struct __measurement *measurement;
    struct __position *pos;
} thread_param;

/*! \struct __beacon
 *  \brief Struct holding beacon data.
 */
typedef struct __beacon {
    unsigned short id;
    int lqi;
    int avg_rssi;
    int rssi;
} beacon;

/*! \struct __measurement
 *  \brief Struct holding the measurement information.
 */
typedef struct __measurement {
    unsigned short max_len;
    struct timeval timestamp;
    struct __beacon  *beacons; /*!< Beacon information. */
} measurement;

typedef struct __position {
    double rel_x;
    double rel_y;
} position;

/*! \fn static error_t parse_opt (int key, char *arg, struct argp_state *state)
 *  \brief Function parsing program args into the arguments struct.
 *
 *  \param[in] key The option key to parse.
 *  \param[in] arg The argument.
 *  \param[in,out] state The state holding the current arguments object.
 *  \return The error, if one occured. (Currently unused.)
 */
static error_t parse_opt (int,char*,struct argp_state*); 

/*! \fn static void init_serial (char *serial, int *fd)
 *  \brief Function opening and configuring the serial interface.
 *
 *  \param[in] serial The serial device node.
 *  \param[out] fd File descriptor.
 */
static void init_serial (char*,int*);

/*! \fn static void close_serial (int *fd)
 *  \brief Function gently closing the serial interface. 
 *  
 *  \param[in] fd File descriptor.
 */
static void close_serial (int*);

static void init_signal_handler (struct sigaction*, int*);

void signal_handler_io (int);

static void parse_data (char*, struct __measurement*);

static void debug_data (struct __measurement*);

static inline void tsnorm (struct timespec*);

void *process_data(void*);

static void init_args(arguments*);

extern arguments args;

#endif
