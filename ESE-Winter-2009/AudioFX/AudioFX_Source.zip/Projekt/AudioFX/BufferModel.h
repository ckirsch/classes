/*
 *  BufferModel.h
 *  Project: AudioFX
 *
 *  Created by Christian Ebner, Daniel Suerth
 *
 */
#ifndef _BUFM_
#define _BUFM_ 1

#include <queue.h>
#include "include/al.h"

class BufferModel
{
public:
	BufferModel();
	void destroyBuffers();
	ALuint getNextFullBuffer();
	ALuint getFreeBuffer();
	int freeBuffersAvailable();
	int fullBuffersAvailable();


};

#endif
