/*
 *  Main.h
 *  Project: AudioFX
 *
 *  Created by Christian Ebner, Daniel Suerth
 *
 */




#ifndef _MAIN_
#define _MAIN_ 1

void initDevices(void);
void destroyDevices(void);
void capture(void);
void play(void);
void wait(int);

#endif
