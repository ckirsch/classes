/*
 *  Main.cpp
 *  Project: AudioFX
 *
 *  Created by Christian Ebner, Daniel Suerth
 *
 *  Main part of the AudioFX project. Manages the OpenAL commands,
 *  capturing and playing audio signals and offers a basic
 *  command line interface for changing the pitch value.
 *
 *  The current version is only valid for a Windows operating system,
 *  since a windows thread is created in here.
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "include/al.h"
#include "include/alc.h"

#include "BufferModel.h"
#include "Main.h"

// A fixed constant, which determines the maximum audio
// signals in a single buffer element.
#define QUEUEBUFFERSIZE 5000


// OpenAL structures:
ALCdevice* pCaptureDevice;
ALCdevice* outDevice;
ALuint 	   SourceID = 0;
BufferModel* buffers;

// audio effect information
float pitch = 1.0f;

// internal program information if
// the program should terminate
bool stop = false;

// init OpenAL structures and open standard device
void initDevices()
{
	ALint lFormat = AL_FORMAT_MONO16;
	ALint lFrequency = 44100;
	ALCcontext* contextOut;

	// creating playing device and context
	outDevice = alcOpenDevice(NULL);

	if (outDevice != NULL) {
		contextOut=alcCreateContext(outDevice,NULL); // create context
		if (contextOut != NULL) {
			alcMakeContextCurrent(contextOut); // set active context
		}
		else {
			printf("Failed to generate output device \n");
			fflush(stdout);
			return;
		}

	}
	else {
		printf("Failed to generate output device \n");
		fflush(stdout);
		return;
	}

	// reset error information before usage
	alGetError();

	// create source and buffers
	alGenSources(1, &SourceID);
	buffers = new BufferModel();

	if (alGetError() != AL_NO_ERROR)
	{
		printf("Failed to generate Source and / or Buffers\n");
		fflush(stdout);
		return;
	}

	// create capturing device
	pCaptureDevice = alcCaptureOpenDevice(NULL, lFrequency, lFormat, QUEUEBUFFERSIZE);
	if (!pCaptureDevice)
	{
		printf("Failed to generate capturing device \n");
		fflush(stdout);
		return;
	}
}

// free all used devices
void destroyDevices()
{
	alcCloseDevice(outDevice);
	alcCaptureCloseDevice(pCaptureDevice);

	alSourceStop(SourceID);
	alDeleteSources(1, &SourceID);

	buffers->destroyBuffers();
}


void capture()
{
	ALint             lBlockAlignment;
	ALchar            Buffer[QUEUEBUFFERSIZE];

	ALint lFormat = AL_FORMAT_MONO16;
	ALint lFrequency = 44100;
	ALint lSamplesAvailable;
	int counter = 0;
	lBlockAlignment = 2;

	alcGetIntegerv(pCaptureDevice, ALC_CAPTURE_SAMPLES, 1, &lSamplesAvailable);

	if ((lSamplesAvailable > (QUEUEBUFFERSIZE / lBlockAlignment)) && (buffers->freeBuffersAvailable() > 0 ))
	{
		// there might be enough audio signals to fill multiple buffers
		// this is checked and the amount of needed free buffers is expressed
		// by the 'counter' variable
		counter = (lSamplesAvailable / QUEUEBUFFERSIZE) +1;
		while (counter--)
		{
			alcCaptureSamples(pCaptureDevice, Buffer, QUEUEBUFFERSIZE / lBlockAlignment);
			alBufferData(buffers->getFreeBuffer(), lFormat, Buffer, QUEUEBUFFERSIZE, lFrequency);
		}
	}
}

// enqueues new buffers, dequeue already played buffers
// restarts audio source if necessary
void play()
{
	ALint playingState, processedBuffers;
	ALuint TempBufferID;
	ALuint id;

	alGetSourcei(SourceID, AL_SOURCE_STATE,&playingState);
	if ((playingState != AL_PLAYING) && (buffers->fullBuffersAvailable() > 0))
	{
		alSourcef(SourceID,AL_PITCH, pitch);
		alSourcePlay(SourceID);
	}

	// enqueue all existing buffers of the source:
	while (buffers->fullBuffersAvailable() > 0)
	{
		id = buffers->getNextFullBuffer();
		alSourceQueueBuffers(SourceID, 1, &id);
	}

	// dequeue all processed buffers from the source:
	alGetSourcei(SourceID, AL_BUFFERS_PROCESSED, &processedBuffers);
	while (processedBuffers)
	{
		alSourceUnqueueBuffers(SourceID, 1, &TempBufferID);
		processedBuffers--;
	}
}

// offers a basic command line interface for setting the pitch value
// or terminating the program.
DWORD getKeyboardInput (LPVOID lpdwThreadParam )
{
	printf("Enter a number greater than 1.0 (1.0 = no pitching, 2.5 = MickeyMouse voice) and press <enter>:\n");
	printf("Enter 0 and press <enter> for quitting\n");
	fflush(stdout);
	while(true)
	{
		scanf("%f", &pitch);
		if (pitch == 0)
		{
			stop = true;
			break;
		}
	}
	return 0;
}

// ===================================================================
// Main
// ===================================================================
int main(int argc, char *argv[])
{
	printf("Welcome to the AudioFX project\n");
	fflush(stdout);

	// Windows Threading part
	DWORD dwThreadId;
	int i;
	if(CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)&getKeyboardInput,(LPVOID) &i, 0, &dwThreadId) == NULL)
	{
		printf("thread error");
		fflush(stdout);
	}

	// start OpenAL
	initDevices();

	// start recording
	alcCaptureStart(pCaptureDevice);

	while(1)
	{
		capture();
		play();
		if (stop)
		{
			break;
		}
	}

	destroyDevices();

    return 0;
}

