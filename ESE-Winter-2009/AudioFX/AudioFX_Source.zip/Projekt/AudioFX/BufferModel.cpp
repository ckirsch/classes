/*
 *  BufferModel.cpp
 *  Project: AudioFX
 *
 *  Created by Christian Ebner, Daniel Suerth
 *
 *	The class BufferModel abstracts the access to
 *	the buffers of a source.
 *
 */

#include "BufferModel.h"
#include <stdio.h>

// maximal number of available buffers
#define NUMBOFBUFFERS 10

ALuint ID[NUMBOFBUFFERS];
int position;
queue<ALuint> fifo_BufferID;

BufferModel::BufferModel()
{
	// initialize buffers
	for (int i = 0; i < NUMBOFBUFFERS; i++)
	{
		alGenBuffers(1, &ID[i]);
	}
	position = 0;
}

// destroy all buffers
void BufferModel::destroyBuffers()
{
	for (int i = 0; i < NUMBOFBUFFERS; i++)
	{
		alDeleteBuffers(1, &ID[i]);
	}
}

// get the next free available buffer. The number is
// returned for external use and saved in the queue
ALuint BufferModel::getFreeBuffer()
{
	ALuint id = ID[position];

	position++;

	if (position == NUMBOFBUFFERS)
	{
		position = 0;
	}

	fifo_BufferID.push(id);
	return id;
}

// returns the amount of available buffers
int BufferModel::freeBuffersAvailable()
{
	return NUMBOFBUFFERS - fifo_BufferID.size();
}

// returns the amount of already filled buffers
int BufferModel::fullBuffersAvailable()
{
	return fifo_BufferID.size();
}

// returns the id of the next full buffer and deletes
// the buffer from the internal queue of the buffer model
ALuint BufferModel::getNextFullBuffer()
{
	ALuint id = 0;
	if (!fifo_BufferID.empty())
	{
		id = fifo_BufferID.front();
		fifo_BufferID.pop();
	}

	return id;
}
