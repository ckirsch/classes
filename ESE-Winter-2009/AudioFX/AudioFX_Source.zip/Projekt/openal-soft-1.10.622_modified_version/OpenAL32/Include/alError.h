#ifndef _AL_ERROR_H_
#define _AL_ERROR_H_

#include "AL/al.h"

#ifdef __cplusplus
extern "C" {
#endif

ALvoid alSetError(ALenum errorCode);

#ifdef __cplusplus
}
#endif

#endif
