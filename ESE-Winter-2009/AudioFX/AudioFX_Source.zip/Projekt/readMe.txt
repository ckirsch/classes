
- Folder AudioFX: 
	our project
- Folder openal-soft-1.10.622_modified_version:
	modified source code, will only compile under Linux
	only for scheduling concept, not used for windows program
	modified files: /include/AL/al.h, /Alc/alcThread.c

The AudioFX version is compiled for windows.

Installation:
- OpenAL32.dll has to be installed on the pc.
	-> http://connect.creativelabs.com/openal/Downloads/Forms/AllItems.aspx
	-> Download oalinst (OpenAL Installer for Windows)
	-> Install the tool. OpenAL32.dll will be installed in your Windows/System32 folder
	
Usage
- Run our tool (Main.exe) in command line