/*
 * remalloc.c
 *
 *  Created on: 02.02.2011
 *      Author: Stephanie Stroka
 *      		(stephanie.stroka@sbg.ac.at)
 */

#include "regmalloc.h"

static page_header_t* init_page(region_header_t* region);

/**
 * Allocate memory into a region.
 * The region consists out of multiple pages.
 */
void* regmalloc(size_t size, void* _region) {
	region_header_t* region = (region_header_t*) _region;
	page_header_t* page = region->lastPage;
	if(page == NULL) {
#ifdef SCM_PRINTMEM
	inc_used_mem(REGMALLOC_PAGE_SIZE);
	printf("[new_region_page (%u)]\n", REGMALLOC_PAGE_SIZE);
#endif
		page = init_page(region);
		region->firstPage = page;
	} else if((size + page->size) > REGMALLOC_MAX_PAGESIZE) {
#ifdef SCM_PRINTMEM
	inc_used_mem(REGMALLOC_PAGE_SIZE);
	printf("Page is full: %u bytes allocated\n Creating new page...", page->size);
	printf("[new_region_page (%u)]\n", REGMALLOC_PAGE_SIZE);
#endif
		// allocate new page
		page = init_page(region);
	}
	void* ptr = &page->memory[page->size];
	page->size += size;
	return ptr;
}

void regfree(void* _region) {
#ifdef SCM_PRINTMEM
	printf("FREE region: %x \n", _region);
#endif
	if(_region == NULL) {
		// region does not exist
		// nothing to free
		return;
	}
	region_header_t* region = (region_header_t*) _region;
	page_header_t* firstPage = region->firstPage;
	if(firstPage == NULL) {
		//free(region);
		// no pages -> return
		return;
	}
	while(firstPage != region->lastPage) {
#ifdef SCM_PRINTMEM
		inc_freed_mem(REGMALLOC_PAGE_SIZE);
#endif
		page_header_t* next = firstPage->nextPage;
		__real_free(firstPage);
		firstPage = next;
	}
#ifdef SCM_PRINTMEM
		inc_freed_mem(REGMALLOC_PAGE_SIZE);
#endif
	__real_free(firstPage);
	region->firstPage = NULL;
	region->lastPage = NULL;
//	free(_region);
}

void* init_region(size_t offset) {
	region_header_t* new_region = (region_header_t*) __real_malloc(offset + sizeof(region_header_t));
	return (void*) new_region;
}

static page_header_t* init_page(region_header_t* region) {
	page_header_t* prevLastPage = region->lastPage;
	page_header_t* new_page = (page_header_t*) __real_malloc(sizeof(page_header_t));
	if(prevLastPage != NULL) {
		prevLastPage->nextPage = new_page;
	}
	region->lastPage = new_page;
	new_page->size = 0;
	memset(new_page->memory, 0, REGMALLOC_MAX_PAGESIZE);
	return new_page;
}


