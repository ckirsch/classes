#include <stdlib.h>
#include <stdio.h>
#include "stm.h"

#define LOOPRUNS 30
#define MEMSIZE1 512
#define MEMSIZE2 512

void *pointer2 = NULL;

pthread_key_t clock1 = -1;
pthread_key_t clock2 = -1;

static long not_needed_mem;
static long needed_mem;
static long start_time = 0;

static void inc_not_needed_mem(long inc) {
    not_needed_mem += inc;
}

static void inc_needed_mem(long inc) {
    needed_mem += inc;
}

static void print_memory_consumption() {

    struct timeval t;
    gettimeofday(&t, NULL);

    long usec = t.tv_sec * 1000000 + t.tv_usec;

    if (start_time == 0) {
        start_time = usec;
    }

	FILE* f;
	f = fopen("/mnt/data/EmbeddedSoftwareEngineering/report/images/gnuplot/neededmem.dat", "a");
	fprintf(f, "%lu\t%ld\n", usec - start_time, needed_mem - not_needed_mem);
	fclose(f);
}

void use_some_memory() {

	//this pointer is only used within this scope
	printf("|-------------- clock1-malloc --------------|\n");

	int i=0;
	for(i=0; i<LOOPRUNS; i++) {
		scm_malloc_clock(MEMSIZE1, &clock1);
		inc_needed_mem(MEMSIZE1);
		print_memory_consumption();
	}
	printf("|-------------------------------------------|\n");
	//let pointer1 expire after this round
	//scm_refresh(pointer1, 0);
	
//	if (pointer2 != NULL) {
		//memory at pointer2 from previous round
		//.. do something with pointer2
//	}
	
	//refresh pointer2 to be valid in the next round
	//scm_refresh(pointer2, 1);
}

int main(int argc, char** argv) {
	
	int i, j;
	
	init_clock(&clock1);
	init_clock(&clock2);

	for (i = 0; i < 10; i++) {
		//...
		use_some_memory();
		//create new memory for pointer2
		if(i % 2 == 0) {
			printf("|-------------- clock2-malloc --------------|\n");
//			pointer2 = scm_malloc_clock(20, &clock2);
			for(j=0; j<LOOPRUNS; j++) {
				scm_malloc_clock(MEMSIZE2, &clock2);
				inc_needed_mem(MEMSIZE2);
				print_memory_consumption();
			}
			printf("|-------------------------------------------|\n");
		}
		for(i=0; i<LOOPRUNS; i++) {
			inc_not_needed_mem(MEMSIZE1);
			print_memory_consumption();
		}
		scm_tick_clock(&clock1);
		//...
		if(i % 2 == 0) {
			for(i=0; i<LOOPRUNS; i++) {
				inc_not_needed_mem(MEMSIZE2);
				print_memory_consumption();
			}
			scm_tick_clock(&clock2);
		}
	}
	
	printf("------------- deallocation: --------------\n");
	for(i=0; i<29; i++) {
		scm_tick_clock(&clock1);
		scm_tick_clock(&clock2);
	}
	printf("success\n");

	return 0;
}
