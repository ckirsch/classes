/*
 * regmalloc.h
 *
 *  Created on: 02.02.2011
 *      Author: sstroka
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "meter.h"

#ifndef REGMALLOC_H_
#define REGMALLOC_H_

#ifndef REGMALLOC_PAGE_SIZE
#define REGMALLOC_PAGE_SIZE 4096
#endif /* REGMALLOC_PAGE_SIZE */

#define REGMALLOC_MAX_PAGESIZE (REGMALLOC_PAGE_SIZE - sizeof(void*) - sizeof(size_t))

#define PAGE_HEADER(payload) ((void*)payload - sizeof(page_header_t))
#define PAGE_PAYLOAD(page) ((void*)page + sizeof(page_header_t))

typedef struct region_header region_header_t;
typedef struct page_header page_header_t;

struct page_header {
	page_header_t* nextPage;
	size_t size;
	char memory[REGMALLOC_MAX_PAGESIZE];
};

struct region_header {
	page_header_t* firstPage;
    page_header_t* lastPage;
};

/* region malloc, allocates memory into a given region */
extern void* regmalloc(size_t size, void* region);
/* region free, deallocates memory of a whole region in O(1) */
extern void regfree(void* region);

extern void* init_region(size_t offset);


#endif /* REGMALLOC_H_ */
