#include <stdlib.h>
#include <stdio.h>
#include "stm.h"
// the use of abstract addresses requires that we include scm-desc,
// to be able to dereference abstract addresses to physical addresses
// and to consider object headers
#include "scm-desc.h"
#if USE_STATS
#include <cf/cf.h>
#endif

#define DEREF(x) (PAYLOAD_OFFSET(*x))

void** aaddr2 = NULL;
//void *pointer2 = NULL;

void use_some_memory() {

	// allocate some memory
	void** aaddr1 = scm_malloc(10);
	// dereference abstract address
	void* pointer1 = DEREF(aaddr1);
	//this pointer is only used within this scope
	//let pointer1 expire after this round
	scm_refresh(aaddr1, 0);
	
	if (aaddr2 != NULL) {
		//memory at aaddr2 from previous round
		//.. do something with aaddr2
		int* p = (int*) DEREF(aaddr2);
		printf("pointer from last round has the content: %d\n", *p);
	}
	
	//create new memory for pointer2
	aaddr2 = scm_malloc(20);
	int* pointer2 = (int*) DEREF(aaddr2);
	*pointer2 = 3;
	//refresh pointer2 to be valid in the next round
	scm_refresh(aaddr2, 1);
}

static inline long get_utime() {
	struct timeval tv;
	long usecs;

	gettimeofday(&tv, NULL);

	usecs = tv.tv_usec + tv.tv_sec*1000000;

	return usecs;
}

int main(int argc, char** argv) {
	
	int i;
	file = fopen("output.txt", "w+");
	
	long starttime = get_utime();

	for (i = 0; i < 10; i++) {
		//...
		use_some_memory();
		scm_tick();
		//...
	}

	long endtime = get_utime();
#if USE_STATS
	sum_stats(endtime - starttime);
#endif
	fclose(file);
	printf("success\n");
	return 0;
}
