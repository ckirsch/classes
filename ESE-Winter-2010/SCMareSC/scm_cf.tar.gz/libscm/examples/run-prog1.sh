#!/bin/bash

export LD_LIBRARY_PATH=../dist && ./moreticks
