/*
 * nocompaction.c
 *
 *  Created on: Jan 21, 2011
 *      Author: stexx
 */
#include <stdlib.h>
#include <stdio.h>
#include "stm.h"
// the use of abstract addresses requires that we include scm-desc,
// to be able to dereference abstract addresses to physical addresses
// and to consider object headers
#include "scm-desc.h"
#if USE_STATS
#include <cf/cf.h>
#endif

// define number of long-, mid-,
//     and short-term memory allocations
#define NUM_LONG 13
#define NUM_MID 17
#define NUM_SHORT 19

// define size of long-, mid-,
//     and short-term memory allocations
#define SIZE_LONG 1024
#define SIZE_MID 512
#define SIZE_SHORT 512

static inline long get_utime() {
	struct timeval tv;
	long usecs;

	gettimeofday(&tv, NULL);

	usecs = tv.tv_usec + tv.tv_sec*1000000;

	return usecs;
}


/**
 * allocates some memory and returns a list that points to the abstract addresses used
 */
void*** allocateSomeMemory(int amount, int size) {
	int i = 0;
	void*** listOfMem = (void***) malloc(amount*sizeof(long**));
	for(i=0; i < amount; i++) {
		// aaddr is an abstract address that points to the physical memory
		void** aaddr = (void**) scm_malloc(size);
		// add the abstract address to the list of long term memory
		listOfMem[i] = aaddr;
	}
	return listOfMem;
}


int main(int argc, char** argv) {

	int i, j;
	int c;

	long starttime = get_utime();

	// allocate some long term memory
	void*** long_term_mem = allocateSomeMemory(NUM_LONG, SIZE_LONG);

	for (i = 0; i < 10; i++) {

		// allocate some mid term memory
		void*** mid_term_mem1 = allocateSomeMemory(NUM_MID, SIZE_MID);
		for(c=0; c < NUM_MID; c++) {
			void** aaddr = mid_term_mem1[c];
			scm_refresh(aaddr, 0);
		}
		free(mid_term_mem1);

		for(j = 0; j < 20; j++) {
			// allocate some short term memory
			void*** short_term_mem = allocateSomeMemory(NUM_SHORT, SIZE_SHORT);

			for(c=0; c < NUM_SHORT; c++) {
				void** aaddr = short_term_mem[c];
				scm_refresh(aaddr, 0);
			}
			free(short_term_mem);
		}

		// allocate some mid term memory
		void*** mid_term_mem2 = allocateSomeMemory(NUM_MID, SIZE_MID);
		for(c=0; c < NUM_MID; c++) {
			void** aaddr = mid_term_mem2[c];
			scm_refresh(aaddr, 0);
		}
		free(mid_term_mem2);

		for(j = 0; j < 20; j++) {
			// allocate some short term memory
			void*** short_term_mem = allocateSomeMemory(NUM_SHORT, SIZE_SHORT);

			for(c=0; c < NUM_SHORT; c++) {
				void** aaddr = short_term_mem[c];
				scm_refresh(aaddr, 0);
			}
			free(short_term_mem);
		}

		for(c=0; c < NUM_LONG; c++) {
			void** aaddr = long_term_mem[c];
			scm_refresh(aaddr, 1);
		}

		scm_tick();
	}

	free(long_term_mem);

	// memory with refresh(0) expires here
	scm_tick();

	// print statistics...
	long endtime = get_utime();
#if USE_STATS
	sum_stats(endtime - starttime);
#endif
	printf("success\n");
	return 0;
}
