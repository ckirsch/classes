import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.util.Hashtable;
import java.util.Vector;
import rcxdirect.*;



public class react
{
	static int globalTaskCounter = 0;
	static int globalEventCounter = 0;
	static int logicalTime = 0;   // a logic clock
	static int maxTime = 1000000;  // the value where the clock resets to 0
	
	static Vector eCodeFileContent;  //  content of the e-code file
	static Vector sCodeFileContent;  //  content of the s-code file
	
	static Vector taskList = new Vector();

	static EMachine emachine; 
	static SMachine smachine;
	
	static String sCodeFile;
	
	//// an increasing int, so that every scode-parser thread can have its own id
	static int sCodeParserID = 0;
	
	//// release port
	static Vector releasePort = new Vector();
	
	//// completion port 
	static Vector completionPort = new Vector();
	
	static Vehicle elvis = new Vehicle();
	
	static Vector triggerQueue = new Vector();
	static Hashtable eventQueue = new Hashtable();
	
	static Vector sensorList = new Vector();
	
	static Motor motor;
	static Sensor sensor;

	public static void main(String[] args) 
	{
		
		//// reads content from e-code-file and starts the e-machine
		String eCodeFile = "e-code3";
		
		emachine = new EMachine();
		emachine.loadCodeFile(eCodeFile);
		emachine.parseJumpPoints();
		emachine.parseCode();
		
		sCodeFile = "s-code3";

		//// starts s-machine and scodeParser
		smachine = new SMachine(sCodeFile);
		smachine.start();
		
		if (triggerQueue != null)
		{
			while (triggerQueue.isEmpty() == false)
			{
				jumpToTimeEvent();
				react.checkPorts();
			}
			
		}
		
	} // main

	//// increases the logical clock and resets it to 0 
	//// if the maxTime-value is reached
	public void increaseLogicalTime(int time)
	{
		if ((logicalTime + time) > maxTime)
		{
			logicalTime = time - (maxTime - logicalTime);
		}
		else
		{
			logicalTime = logicalTime + time;
		}
	}
	
	
	//// returns Task if the Task was released
	//// else it returns null
	static synchronized Task getTaskByName(String taskname)
	{
		if ((react.taskList == null) || (react.taskList.isEmpty() == true))
		{
			return null;
		}
		
		int sizeTaskList = react.taskList.size();
		for (int i=0; i<sizeTaskList; i++)
		{
			Task task;
			task = (Task)react.taskList.elementAt(i);
			
			if (task.name.compareTo(taskname) == 0)
			{
				return task;
			}
			else
			{
				continue;
			}
		}
		return null;
	}
	
	////returns Task if the Task was released
	//// else it returns null
	static synchronized Task getTaskByID(String ID)
	{
		int sizeTaskList = react.taskList.size();
		for (int i=0; i<sizeTaskList; i++)
		{
			Task task;
			task = (Task)react.taskList.elementAt(i);

			if (task.ID.compareTo(ID) == 0)
			{
				return task;
			}
			else
			{
				continue;
			}
		}
		return null;
	}
	
	
	/*
	//// checks if a particular instant is already over related to the logicalTime
	//// returns -1 if time is in the past
	//// returns 0 if time is now
	///  returns 1 if time is in the future
	public int checkTime(int time)
	{
		if (time > maxTime)
		{
			time = time - maxTime;
		}
		
		if (time > logicalTime)
		{
			return 1;
		}
		else if (time == logicalTime)
		{
			return 0;
		}
		else
		{
			float tmp = maxTime/4;
			int secDifference = (int)tmp;
			if ((time+secDifference) < logicalTime)
			{
				return 1;
			}
		}
		
	}
	*/
	
	//// runs through trigger-queue and searches for all the timetriggers
	//// is looks for the shortest time to wait for a trigger and sets the logicalClock to this time
	//// returns (-1) if there's no timestamp available and 0 if the clock was recalibrated
	public synchronized static int jumpToTimeEvent()
	{		
		if ((triggerQueue == null) || (triggerQueue.isEmpty() == true))
		{
			return (-1);
		}
		
		
		//// parse emachine triggerQueue
		int currentTime = react.logicalTime;
		int smallestOffset = -1;
		
		Trigger trigger;
		trigger = (Trigger)triggerQueue.elementAt(0);
		smallestOffset = ((trigger.releaseTime) - currentTime);
		
		for (int i=0; i<triggerQueue.size(); i++)
		{
			trigger = (Trigger)triggerQueue.elementAt(i);
			
			///// if trigger is a positionTrigger
			if (trigger.releaseTime == (-1))
			{
				continue;
			}
			
			int tmp = ((trigger.releaseTime) - currentTime);
			
			if (tmp<smallestOffset)
			{
				smallestOffset = tmp;
			}	
		}
		
		if (smallestOffset > (-1))
		{
			System.out.println("time:" + react.logicalTime + " - " + "offset(e):" + smallestOffset);
			react.logicalTime = react.logicalTime + smallestOffset;
			return 0;
		}
		else
		{
			return (-1);
		}
		
	} // jumpToTimeEvent
	
	
	
	//// reads filecontent from a file specified on the console
	public static Vector getFileContent(String filename)
	{
		Vector content = new Vector();
		
		StringBuffer s = new StringBuffer();
		char c;
		Reader in = new InputStreamReader(System.in);

		
		try
		{
			RandomAccessFile file = new RandomAccessFile(filename, "r");
			while (file.getFilePointer() < file.length())
			{
				content.addElement(file.readLine());
			}
		}
		catch(FileNotFoundException nofile)
		{
			System.out.println("File " + filename + " not found");
		}
		catch(IOException io)
		{
			System.out.println("Error while reading file " + filename);
		}
		
		return content;
	}
	
	/////// active a specific trigger
	public static synchronized void activateTrigger(String triggername)
	{
		if ((triggerQueue == null) || (triggerQueue.isEmpty() == true))
		{
			new Error("No Triggers defined");
			return;
		}
		
		int sizeTriggerQueue = triggerQueue.size();
		for (int i=0; i<sizeTriggerQueue; i++)
		{
			Trigger trigger = (Trigger)triggerQueue.elementAt(i);
			if (trigger.name.compareTo(triggername) == 0)
			{
				trigger.active = true;
				//return;
			}
		}
		
	} // activateTrigger
	
	//// runs through trigger-queue and set all triggers "active" which
	//// should fire now
	public static synchronized void updateTriggers()
	{
		if ((triggerQueue == null) || (triggerQueue.isEmpty() == true))
		{
			new Error("No Triggers defined");
			return;
		}
		
		int sizeTriggerQueue = triggerQueue.size();
		for (int i=0; i<sizeTriggerQueue; i++)
		{
			Trigger trigger = (Trigger)triggerQueue.elementAt(i);
			if(trigger.type.compareTo("TimeTrigger") == 0)
			{
				int releaseTime = trigger.releaseTime;

				if (react.logicalTime < releaseTime)
				{
					continue;
				}
				else if (react.logicalTime == releaseTime)
				{
					trigger.active = true;
				}
				else
				{
					new ErrorMessage("Time-safety violation for trigger " + trigger.name);
					trigger.active = true;
				}
			
			}
			//// the triggers from e-code/s-code are defined here statically
			else if(trigger.type.compareTo("PositionTrigger") == 0)
			{
				String triggername = trigger.name; 
				if (triggername.compareTo("position_1_reached") == 0)
				{
					
					if ((elvis.currentPosition == elvis.position1) && (elvis.position1 > 0))
					{
						trigger.active = true;
					}
					else
					{
						trigger.active = false;
					}
					continue;
				}
				else if (triggername.compareTo("position_2_reached") == 0)
				{
					if (elvis.currentPosition <= elvis.position2)
					{
						trigger.active = true;
					}
					else
					{
						trigger.active = false;
					}
					continue;
				}
				else if (triggername.compareTo("position_3_reached") == 0)
				{
					if (elvis.currentPosition <= elvis.position3)
					{
						trigger.active = true;
					}
					else
					{
						trigger.active = false;
					}
					continue;
				}
			}
			else
			{
				new ErrorMessage("Invalid Triggertype");
			}
		}
	} /// updateTriggers
	
	
	//// checks the triggerQueue and calls the commands if necessary
	//// returns 1 if code was executed
	//// returns 0 if nothing happend
	public static int runActiveTriggers()
	{
		Vector activeEvents = new Vector();
		
		if ((react.triggerQueue == null) || react.triggerQueue.isEmpty() == true)
		{
			System.out.println("Triggers in Queue: 0");
			return 0;
		}
		
		for (int i=0; i<react.triggerQueue.size(); i++)
		{
			Trigger trigger = (Trigger)react.triggerQueue.elementAt(i);
			if (trigger.active == false)
			{
				//System.out.println("inactive Trigger: " + trigger.name);
				continue;
			}
			else
			{
				String type = trigger.type;
				String eventID = trigger.eventID;
				
				Event event = (Event)eventQueue.get(eventID);
				if (event.type.compareTo("JumpToCodelineEvent") == 0)
				{
					activeEvents.add(0,event);
				}
				else
				{
					activeEvents.addElement(event);
				}
								
				//System.out.println("REMOVING TRIGGER: " + trigger.name + " . " + event.ID);
				react.triggerQueue.removeElementAt(i);
				if (i > 0) {i--;}
				
				//System.out.println("Trigger: " + trigger.name + ":" + event.taskID);
			
			}
		}
		
		
		if ((activeEvents == null) || (activeEvents.isEmpty() == true))
		{
			return 0;
		}
		
		
		int sizeActiveEvents = activeEvents.size();
		for (int i=0; i<sizeActiveEvents; i++)
		{
			Event activeEvent = (Event)activeEvents.elementAt(i);
			System.out.println("RUN EVENT: " + activeEvent.ID);
			activeEvent.execute();
		}
		
		for (int i = 0; i<react.triggerQueue.size(); i++)
		{
			Trigger t1 = (Trigger)triggerQueue.elementAt(i);
		}
		
		return 1;
		

	}  // public static void checkTriggerQueue()


	//// checks if tasks where finished by the s-machine
	//// remove task from completionPort
	public static synchronized void checkCompletionPort()
	{
		if ((react.completionPort == null) || (react.completionPort.isEmpty() == true))
		{
			return;
		}
		
		//System.out.println("size: " + react.completionPort.size());
		for (int i=0; i<react.completionPort.size(); i++)
		{
			Task task = (Task)react.completionPort.elementAt(i);
			System.out.println(i);
			String taskname = task.name;
			String taskID = task.ID;
			String tasktype = task.type;
			
			react.completionPort.removeElementAt(i);
			if(i>0)
			{
				i--;
			}
			
			System.out.println("time:" + react.logicalTime + " - " + taskname + " finished computation.");
			
		}	
	} //  checkCompletionPort()
	
	public static void checkPorts()
	{
		react.checkCompletionPort();
		react.updateTriggers();
		react.runActiveTriggers();
	}   // checkPorts()
	
}  // class react



class Vehicle
{
	int steeringAngle;
	int slotLength;
	int currentPosition;
	int position1, position2, position3;
	int time_to_position2, time_to_position3;
	
	
	public Vehicle()
	{
		System.out.println("Initializing car.");
		Port.setName("usb");
		react.motor.C.setPower(1);
		System.out.println("Battery power: " +
				Battery.getVoltageMilliVolt());
	}
		
	public static void delay(int t) {
		try {
			Thread.sleep(t);
			//// logicalTime moves t ms on
			react.logicalTime = react.logicalTime + t;
		} catch (InterruptedException ie) {
		}
	}
	
	public void move_forward()
	{
		System.out.println("moving car forwards");
		
		//react.motor.C.setPower(1);
		react.motor.C.forward();
	}
	public void move_backward()
	{
		System.out.println("moving car backwards");
		
		react.motor.C.setPower(7);
		react.motor.C.backward();

	}
	public void stop()
	{
		System.out.println("stopping car");
		react.motor.C.stop();
	}
	
	//// steer left until a certain light-level is reached
	public void steer_left()
	{
		System.out.println("steering left");
		
		int time = react.elvis.steeringAngle;
		int i = time / 10;
		if (time < 19) {
			i = 2;
		}
		int sleep_time = time / 200;
		int light = react.sensor.S2.readValue();
		

		while (i > 1) {
			i--;
			light = react.sensor.S2.readValue();
			if (light < 29) {
				react.motor.A.stop();
				return;
			}
			react.motor.A.setPower(1);
			react.motor.A.backward();
			delay(sleep_time);
			react.motor.A.stop();
		}
		react.motor.A.stop();		

	}
	////steer right until a certain light-level is reached
	public void steer_right()
	{
		System.out.println("steering right");
		
		int time=react.elvis.steeringAngle;
		
		int i = time / 10;
		if (time < 19) {
			i = 2;
		}
		int sleep_time = time / 200;
		int light = react.sensor.S2.readValue();

		while (i > 1) {
			i--;
			light = react.sensor.S2.readValue();
			if (light > 54) {
				react.motor.A.stop();
				return;
			}
			react.motor.A.setPower(1);
			react.motor.A.forward();
			
			delay(sleep_time);
			react.motor.A.stop();
		}
		react.motor.A.stop();
		
	}
	//// centering gear
	public void center_gear()
	{
		System.out.println("centering gear");
		int light = react.sensor.S2.readValue();
		/*
		 * vom Hellen ins Dunkel auf der Drehscheibe d.h das Auto f�hrt nach
		 * rechts (Motor.A.forward)
		 */
		if (light < 40) {
			while (light < 40) {
				react.motor.A.stop();
				light = react.sensor.S2.readValue();
				react.motor.A.forward();
			}
			react.motor.A.stop();
		}
		/*
		 * vom Dunkel -> Hellen auf der Drehscheibe d.h das Auto f�hrt nach
		 * links
		 */
		else if (light > 41) {
			while (light > 41) {
				react.motor.A.stop();
				light = react.sensor.S2.readValue();
				react.motor.A.backward();

			}
			react.motor.A.stop();

			//kleine Korrektur wegen ungenauigkeit des react.sensors
			center_gear();
		}
	}
	//// runs until size of parking slot is found out
	public void check_slot()
	{
		System.out.println("checking environment");
		int light = react.sensor.S3.readValue();
		System.out.println("sensor c1: " + light);
		long first_point = 0;
		long second_point = 0;
		//start of parking place
		int count = 0;
		
		//// check sensors until beginning of parking-slot is reached
		while (count == 0) {
			light = react.sensor.S3.readValue();
			
			if ((light < 45) && (light > 0)) {
				// 1. point
				count = 1;
				first_point = System.currentTimeMillis();
				System.out.println("Beginning of parking-slot reached: " + light);
			}
		}
		
		
		// check sensors until end of parking place is reached
		while (count == 1) {
			light = react.sensor.S3.readValue();
			System.out.println("sensor c2: " + light);
			
			//// end of parking slot is reached
			if (light > 46) 
			{
				
				second_point = System.currentTimeMillis();
				//int duration = (int)(1.6 *((second_point - first_point) / 1000));
				int slotLength = (int)(second_point - first_point);
				System.out.println("Zeit ben�tigt: "+ slotLength  + " ms.");
				react.elvis.slotLength = slotLength;
				//// in ms
				react.logicalTime = react.logicalTime + slotLength;
				react.elvis.position1 = slotLength;
				react.elvis.currentPosition = slotLength;
				
				count = 2;
				
				//// activates trigger position_1_reached
				react.activateTrigger("position_1_reached");
				
			
				react.runActiveTriggers();
			}
		}
	}
	
	//// calculates position2 and position3 from position1
	public void calculate_positions()
	{
		
		System.out.println("calculate_positions.");
		
		if (this.position1 != this.currentPosition)
		{
			new ErrorMessage("Car is not in the correct position");
			//System.exit(1);
		}

		int slotLengthcm = (int)((slotLength/1000) * 2.9);
		if(slotLengthcm == 0)
		{
			slotLengthcm = 43;
		}
		else if ((slotLengthcm > 0) && (slotLengthcm < 43))
		{
			new ErrorMessage("Parking slot to small");
			System.exit(1);
		}
		else if (slotLengthcm > 78){
			slotLength = 78;
		}
		
		
		System.out.println("Slotlengthcm"+ slotLengthcm + " slotLength(bei mir cm)"+slotLength);
		this.steeringAngle = ((4000/slotLengthcm) + (slotLengthcm/5));
		System.out.print("steeringAngle: "+ this.steeringAngle);
		
		time_to_position2 = (int)((this.position1-40)/5);
		time_to_position3 = (int)(time_to_position2+((this.position1-40)/10));

		position2 = position1 - time_to_position2;
		position3 = position2 - time_to_position3;
		System.out.println(" - 1: " + position1 + " 2: " + position2 + " 3: " + position3);
		
	}
	
}

//// an Event is bound to a trigger.
//// it stores the kind of work it has to do (terminate a task, parse a codeline)
//// execution of an event calls task-  or e-/smachine-functions
class Event
{
	public String type;
	int address;
	String taskID;
	//// scodeparser thread
	SCodeParser parser;
	public String ID;
	
	///// jumps to given codeline in e-code
	public Event(int codelineNumber)
	{
		this.type = "JumpToECodelineEvent";
		react.globalEventCounter++;
		this.ID = this.type + react.globalEventCounter;
		this.address = codelineNumber;
		
		react.eventQueue.put(ID,this);
	}
	
	//// jumps to given codeline in s-code
	//// s-code parser is the sleeping parser, that waits for notification
	public Event(SCodeParser parser)
	{
		this.type = "NotifyThreadEvent";
		react.globalEventCounter++;
		this.ID = this.type + react.globalEventCounter;
		this.parser = parser;
		
		react.eventQueue.put(ID,this);
	}
	
	///// terminates given task
	public Event(String taskID)
	{
		this.type = "TerminateTaskEvent";
		react.globalEventCounter++;
		this.ID = this.type + react.globalEventCounter;
		this.taskID = taskID;
		
		react.eventQueue.put(ID,this);
	}
	
	public void execute()
	{
		if(this.type.compareTo("TerminateTaskEvent") == 0)
		{
			//// terminating task
			System.out.println("terminating task: " + this.taskID);
			
			Task task = react.getTaskByID(this.taskID);
			if (task == null)
			{
				new ErrorMessage("TASK IS NULL: " + this.taskID );
			}

			task.stop();
			//// removing task from releasePort
			if ((react.releasePort == null) || (react.releasePort.isEmpty() == true))
			{
				new ErrorMessage("Task running but not in releasePort!");
				System.out.println("taskid: " + task.ID);
				return;
			}
			int sizeReleasePort = react.releasePort.size();
			for (int i=0; i<sizeReleasePort; i++)
			{
				Task releasePortTask = (Task)react.releasePort.elementAt(i);
				if (task.ID.compareTo(releasePortTask.ID) == 0)
				{
					react.releasePort.removeElementAt(i);
					break;
				}
			}
			//// writing task into completion port
			react.globalEventCounter--;
			react.completionPort.addElement(task);
			
			
		}
		else if(this.type.compareTo("JumpToECodelineEvent") == 0)
		{
			System.out.println("FUTURETRIGGER: " + this.address);
			react.emachine.parseCode(this.address);
			react.globalEventCounter--;
		}
		else if(this.type.compareTo("NotifyThreadEvent") == 0)
		{
			System.out.println("IDLETRIGGER: " + this.address);
			this.parser.notify();
			react.globalEventCounter--;
		}
		else
		{
			new ErrorMessage("Invalid EventType!");
		}
	}
}

class Task
{
	public String ID;
	public String name;
	long startTime = 0;
	long endTime = 0;
	int executionTime = 0;
	
	public boolean running = false; // true if task is currently running
	
	//// for later implementations...
	public String type;
	
	public Task(String taskname)
	{
		if ((react.taskList != null) && (react.taskList.isEmpty() == false))
		{
			for (int i=0; i< react.taskList.size(); i++)
			{
				Task tmp = (Task)react.taskList.elementAt(i);
				if(tmp.name.compareTo(taskname) == 0)
				{
					System.out.println("Task with name " +taskname+ " already exists." );
					return;
				}
			}
		}
		react.globalTaskCounter++;
		this.ID = taskname + react.globalTaskCounter;
		this.name = taskname;
	}

	public void run()
	{
		//// marks the task as running
		this.running = true;
		
		
		if(name.compareTo("move_forward") == 0)
		{
			react.elvis.move_forward();
			startTime = System.currentTimeMillis();
			while (this.running == true)
			{
				react.updateTriggers();
				react.runActiveTriggers();
			}
		
		}
		else if(name.compareTo("move_backward") == 0)
		{
			react.elvis.move_backward();
			long startTime = System.currentTimeMillis();
			long endTime = 0;
			int exTime;
			//System.out.println("pos: " + react.elvis.currentPosition);
			//System.exit(0);
			
			while (this.running == true)
			{
				endTime = System.currentTimeMillis();
				exTime = (int)(endTime - startTime);
				startTime = System.currentTimeMillis();
				react.elvis.currentPosition = react.elvis.currentPosition - exTime;
				react.logicalTime = react.logicalTime + exTime;
				//System.out.println("currentPos: " + react.elvis.currentPosition);
				
				//react.updateTriggers();
				//react.runActiveTriggers();
				
				
			}
		}
		else if(name.compareTo("stop") == 0)
		{
			react.elvis.stop();
		}
		else if(name.compareTo("steer_left") == 0)
		{
			react.elvis.steer_left();
			
		}
		else if(name.compareTo("steer_right") == 0)
		{
			react.elvis.steer_right();
			
		}
		else if(name.compareTo("center_gear") == 0)
		{
			react.elvis.center_gear();
			
		}
		else if(name.compareTo("check_slot") == 0)
		{
			react.elvis.check_slot();
			
			while (this.running == true)
			{}
			
		}
		else if(name.compareTo("calculate_positions") == 0)
		{
			react.elvis.calculate_positions();
		}
		else
		{
			new ErrorMessage("Invalid Taskname");
			this.running = false;
		}
	}
	
	public void stop()
	{
		//// marks this task as stopped
		this.running = false;
		
		if(name.compareTo("move_forward") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.delay(1000);
			react.elvis.stop();
			endTime = System.currentTimeMillis();
			
			react.elvis.currentPosition = react.elvis.currentPosition + executionTime;
			react.logicalTime = react.logicalTime + executionTime;
		}
		else if(name.compareTo("move_backward") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.stop();
		}
		else if(name.compareTo("stop") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.stop();
		}
		else if(name.compareTo("steer_left") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.stop();
		}
		else if(name.compareTo("steer_right") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.stop();
		}
		else if(name.compareTo("center_gear") == 0)
		{
			System.out.println("Taskname: " + this.name);
			react.elvis.stop();
		}
		else if(name.compareTo("check_slot") == 0)
		{
			System.out.println("Taskname: " + this.name);
			System.out.println("Stopping to scan environment");
		}
		else
		{
			new ErrorMessage("Invalid Taskname");
		}
		
	}
	
} // class task



//// no functionality because no initialization of sensors needed
//// rcxdirect does initialization
class OpticalPositionSensor
{

	public OpticalPositionSensor()
	{
		react.sensorList.addElement(this);
	}
	
	public int checkPort()
	{
		System.out.println("checking optical port");

		return 0;
	}
	
}


////active = trigger fired
class Trigger
{
	public boolean active; 
	public String type;
	public String eventID; // id of the event to call
	public String name;
	
	////for TimeTriggers
	public int releaseTime;
	
	//// TimeTrigger
	public Trigger(int releaseTime, String eventID)
	{
		this.type = "TimeTrigger";
		this.eventID = eventID;
		this.releaseTime = releaseTime;
		this.active = false;
		
		react.triggerQueue.addElement(this);
	}
	
	//// PositionTrigger
	public Trigger(String triggername, String eventID)
	{
		this.type = "PositionTrigger";
		this.name = triggername;
		this.releaseTime = (-1);
		this.eventID = eventID;
		this.active = false;
		
		react.triggerQueue.addElement(this);
	}
	
}




class SCodeParser extends Thread
{
	public int startAddress = 0;
	int id;
	

	public void run()
	{
		//// generates unique id for thread
		react.sCodeParserID++;
		id = react.sCodeParserID;
		
		parseCode(startAddress);
	}
	
	
	
	////sets the lineNumber where s-code execution should start
	void setStartAddress(int startAddress)
	{
		this.startAddress = startAddress;
	}
	

	////starts e-code-execution at line 0
	public void parseCode()
	{
		parseCode(0);
	}
	
	////runs the instructions from File
	public synchronized void parseCode(int startAddress)
	{

		System.out.println(react.smachine);
		
		if (react.smachine == null)
		{
			System.out.println("huahahaha0");
			System.exit(1);
		}
		
		if ((react.smachine.instructions == null) || 
				(react.smachine.instructions.isEmpty() == true))
		{
			new ErrorMessage("No S-Code-File loaded");
			System.out.println("Stopping program execution");
			//System.exit(-1);
		}
		if (startAddress > react.smachine.instructions.size())
		{
			new ErrorMessage("Invalid s-code address");
			return;
		}
		
		int sizeInstructions = react.smachine.instructions.size();
		for (int i=startAddress; i<sizeInstructions; i++)
		{
					
			String currentInstruction = react.smachine.instructions.elementAt(i).toString();
			currentInstruction.toLowerCase();
			
			int firstStart=0;
			int firstStop=0;
			int secondStart=0;
			int secondStop=0;
			
			currentInstruction = currentInstruction.trim();
			char characters[] = currentInstruction.toCharArray();
			
			//System.out.println(currentInstruction);
			
			System.out.print("time:" + react.logicalTime + " - S-Code - " + this.getName() + ": ");
			
			//// CALL - calls a driver
			if (currentInstruction.matches("^call(.+)$"))
			{
				//System.out.println("CALL");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String driver = currentInstruction.substring(firstStart, firstStop);
				
				//// call the method
				CALL(driver);
			} 
			//// COMMENT: comment lines start with a # 
			else if(currentInstruction.matches("^#.*$"))
			{
				//System.out.println("COMMENT");
				continue;
			}
			//// empty line
			else if(currentInstruction.compareTo("") == 0)
			{
				System.out.println("empty line");
				continue;
			}
			//// DISPATCH - gives task taskname some cpu-time
			else if(currentInstruction.matches("^dispatch(.+,.+)$"))
			{
				//System.out.println("DISPATCH");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ',')
					{
						firstStop = j;
						secondStart = j+1;
					}
					if (characters[j] == ')')
					{
						secondStop = j;
					}
				}
				String taskname = currentInstruction.substring(firstStart, firstStop);
				String triggername = currentInstruction.substring(secondStart, secondStop);

				//// call the method
				DISPATCH(taskname, triggername);
			}
			//// DISPATCH - gives task taskname some cpu-time
			else if(currentInstruction.matches("^dispatch(.+)$"))
			{
				//System.out.println("DISPATCH");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String taskname = currentInstruction.substring(firstStart, firstStop);

				//// call the method
				DISPATCH(taskname);
			}
			
			//// IDLE - idles the thread-execution
			else if(currentInstruction.matches("^idle(.+)$"))
			{
				//System.out.println("IDLE");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String strTimeout = currentInstruction.substring(firstStart, firstStop);
				
				int timeout = Integer.parseInt(strTimeout);
				
				IDLE(timeout);
			}
			
			//// FORK - forks the thread-execution
			else if(currentInstruction.matches("^fork(.+)$"))
			{
				//System.out.println("FORK");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String strAddress = currentInstruction.substring(firstStart, firstStop);

				FORK(strAddress);
			}
			//// JUMP-POINT
			else if(currentInstruction.matches("^.+:$"))
			{
				System.out.println(currentInstruction);
				continue;			
			}
			//// RETURN - quits s-code interpretation.
			else if(currentInstruction.matches("^return$"))
			{
				System.out.println("return");
				System.out.println(this.getName() + " finished execution");
				//this.stop();
				return;
			}
			//// Syntax-Error
			else
			{
				new ErrorMessage("S-Code Syntax Error at line " + (i+1));
			}
			
		}  // for (int i=startAddress; i<instructions.size(); i++)
	} // void runCode(int startAddress)

/*
	////checks if SMachine is idle
	//// returns true if idle and false if not
	//// returns 0 if nothing happend
	public synchronized boolean isIdle()
	{
		if ((react.triggerQueue == null) || (react.triggerQueue.isEmpty() == true))
		{
			return false;
		}
		
		for (int i=0; i<react.triggerQueue.size(); i++)
		{
			IdleTrigger trigger = (IdleTrigger)react.triggerQueue.elementAt(i);
			
			//// checks if idle-entry is for this current thread
			if (trigger.parserID != id)
			{
				continue;
			}
			
			int timeout = trigger.releaseTime;
			if (timeout == react.logicalTime)
			{
				react.triggerQueue.removeElementAt(i);
				if (i>0){i--;}
				return false;
			}
			else if (timeout < react.logicalTime)
			{
				new ErrorMessage("S-code time-safety violation (idle)");
				react.triggerQueue.removeElementAt(i);
				if (i>0){i--;}
				return false;
			}
			else
			{
				return true;
			}
			
		}  // for (int i=0; i<smachine.TriggerQueue.size(); i++)
		
		return false;
		
	}  // public static void isIdle()
*/
	
/*	
	void IDLE(int idleTime)
	{
		System.out.println("idle(" + idleTime + ")");
	
		if ((idleTime <= 0))
		{
			System.out.println("There's no point in defining an idle-time = 0");
			return;
		}
		
		IdleTrigger idleTrigger = new IdleTrigger(id, idleTime);
		react.triggerQueue.addElement(idleTrigger);
		
		try
		{
			this.wait();
		}
		catch(InterruptedException interrupted)
		{
			System.out.println("time:" + react.logicalTime + " - " + "Thread " + id + " finished idle-state.");
			
			////	check if there's another e-code-instruction to run (future)
			react.emachine.checkPorts();
			return;
		}
	
		//System.out.println("time:" + react.logicalTime + " - " + "Thread " + id + " finished idle-state.");
		
		////	check if there's another e-code-instruction to run (future)
		//react.emachine.checkPorts();
		
		//return;
		
	}

 */
	
	boolean taskReleased(Task task)
	{
		if ((react.releasePort == null) || (react.releasePort.isEmpty() == true))
		{
			return false;
		}
		else if(task == null)
		{
			return false;
		}
		
		String taskID = task.ID;
		
		int sizeReleasePort = react.releasePort.size();
		
		for (int i=0; i<sizeReleasePort; i++)
		{
			Task tmp = (Task)react.releasePort.elementAt(i);
			System.out.println("released tasks: " + tmp.ID);
			if(tmp.ID.compareTo(taskID) == 0)
			{
				return true;
			}
			
		}
		
		return false;
	}
	
	void CALL(String drivername)
	{
		if (drivername.compareTo("optical_position_sensor") == 0)
		{
			OpticalPositionSensor positionSensor = new OpticalPositionSensor();
			if (positionSensor == null)
			{
				new ErrorMessage("Driver not initialized");
				return;
			}
		}
		
		System.out.println("initialize_driver(" + drivername + ")");
	}
	
	//// halts the thread until it gets notified by an event
	synchronized void IDLE(int timeToWait)
	{
			
		///// idle for elvis needs real-time and no logical-time
		///// idle is just to handle rcxdirect delays and no for os-causes
		///// no we just implemented a while-loop here
		
		long startTime = System.currentTimeMillis();
		//// wait for some ms
		while (System.currentTimeMillis() < (startTime + timeToWait))
		{ }
		
		/*
		Event idleEvent = new Event(this);
		Trigger idleTrigger = new Trigger(timeToWait,idleEvent.ID);
		
		react.jumpToTimeEvent();
		while (react.jumpToTimeEvent() == 0)
		{
			try
			{
				wait();
			}
			catch(InterruptedException e) {}
		}			
		*/
	}
	
	//// dispatches a task until a trigger is fired
	synchronized void DISPATCH(String taskname, String triggername)
	{
		Task task = react.getTaskByName(taskname);
		boolean taskIsReleased = taskReleased(task);
		
		
		System.out.println("dispatch(" + taskname + "," + triggername + ")");
		
		if (taskIsReleased == true)
		{
			
			Event terminateTaskEvent = new Event(task.ID);
			Trigger terminateTaskTrigger = new Trigger(triggername, terminateTaskEvent.ID);
			
			for (int i=0; i<react.triggerQueue.size();i++)
			{
				Trigger t1 = (Trigger)react.triggerQueue.elementAt(i);
				Event ev = (Event)react.eventQueue.get(t1.eventID);
				System.out.println("Trigger_!!!: " + t1.name + " - " + ev.taskID);
			}
			task.run();
			
			//react.releasePort.removeElement(task);
			react.completionPort.addElement(task);
			System.out.println("time:" + react.logicalTime + " - " + taskname + " was executed");
			
			//react.checkPorts();
			System.out.println("continuing at s-code");
		}
		else
		{
			new ErrorMessage("task " + taskname + " was not released");
			if (react.releasePort.isEmpty() == true)
			{
				System.out.println("no tasks released at all");
				return;
			}
			for (int i=0; i<react.releasePort.size(); i++)
			{
				Task t1 = (Task)react.releasePort.elementAt(i);
				System.out.println("all released task: " + t1.ID);
			}
		}
	}
	
	//// dispatches a task until it terminates
	synchronized void DISPATCH(String taskname)
	{
		Task task = react.getTaskByName(taskname);
		boolean taskIsReleased = taskReleased(task);
		
		System.out.println("dispatch(" + taskname + ")");
		
		if (taskIsReleased == true)
		{
			task.run();
			
			react.releasePort.removeElement(task);
			react.completionPort.addElement(task);
			System.out.println("time:" + react.logicalTime + " - " + taskname + " was executed");
			
			react.checkPorts();
		}
		else
		{
			new ErrorMessage("task " + taskname + " was not released");
		}
	}
	
	//// branches code-execution: branch 1 is continuing current execution
	//// branch 2 starts code-execution on address
	void FORK(String address)
	{
		int startAddress = getLineNumber(address);
		
		System.out.println("fork(" + startAddress + ")");
		
		if (startAddress != (-1))
		{
			react.smachine.startNewParser(startAddress);
		}
		else
		{
			new ErrorMessage("S-Code: fork() failed - Jumppoint not found");
		}
				
	}
	
	
	//// returns linenumber of jumppoint "address"
	//// if jumppoint doesn't exist: return (-1)
	synchronized int getLineNumber(String address)
	{
		address = address.trim();
		
		if ((react.smachine.jumpPoints == null) || (react.smachine.jumpPoints.containsKey(address) == false))
		{
			new ErrorMessage("JumpPoint " + address + " not found");
			return (-1);
		}
		else
		{
			Integer integerLineNumber = (Integer)react.smachine.jumpPoints.get(address);
			if (integerLineNumber == null)
			{
				new ErrorMessage("Internal Error - JumpPoint(JUMP)");
			}
			
			int lineNumber = integerLineNumber.intValue();
			return lineNumber;
		}
	}
	
	
}

class SMachine 
{
	Vector instructions;
	public Hashtable jumpPoints = new Hashtable();

	public SMachine(String filename)
	{
		loadCodeFile(filename);
	}

	public void start()
	{
		parseJumpPoints();
		startNewParser(0);
	}
	
	public void startNewParser(int startAddress)
	{
		SCodeParser parser = new SCodeParser();
		parser.setStartAddress(startAddress);
		parser.start();
		System.out.println("Thread-Name " + parser.getName() + " started.");
	}
	
	//// loads code-file into instructions
	public void loadCodeFile(String filename)
	{
		instructions = react.getFileContent(filename);
	}
	
	//// writes the jumppoints from codefile into jumpPoints
	public void parseJumpPoints()
	{
		for (int i=0; i<instructions.size(); i++)
		{
			String currentInstruction = instructions.elementAt(i).toString();
			currentInstruction.toLowerCase();
			
			int firstStart=0;
			int firstStop=0;
			
			currentInstruction = currentInstruction.trim();
			char characters[] = currentInstruction.toCharArray();
			
			if(currentInstruction.matches("^.+:$"))
			{
				for (int j=0; j<characters.length; j++)
				{
					firstStart = 0;
					if (characters[j] == ':')
					{
						firstStop = j;
					}
					
				}
				
				String jumpPoint = currentInstruction.substring(firstStart, firstStop);
				System.out.println("jumppoint " + jumpPoint + " at line " + i);
				
				Integer currentLineNumber;
				currentLineNumber = new Integer(i);

				if ((jumpPoints == null) || (jumpPoints.containsKey(jumpPoint) == false))
				{
					jumpPoints.put(jumpPoint, currentLineNumber);
				}
			
			}  // if(currentInstruction.matches("^.+:$"))
			
		} // for (int i=0; i<instructions.size(); i++)
	}  // public void parseJumpPoints()
	

} // class SMachine


class EMachine // extends Thread
{
	Vector instructions;
	public Hashtable jumpPoints = new Hashtable();
	
	public void loadCodeFile(String filename)
	{
		instructions = react.getFileContent(filename);
	}
	
	void INITIALIZE(String taskname)
	{
		Task t = new Task(taskname);
		if (t == null)
		{
			new ErrorMessage("Task not initialized");
			return;
		}

		System.out.println("initialize_task(" + taskname + ")");
		react.taskList.addElement(t);
	}
	
	void CALL(String drivername)
	{
		if (drivername.compareTo("optical_position_sensor") == 0)
		{
			OpticalPositionSensor positionSensor = new OpticalPositionSensor();
			if (positionSensor == null)
			{
				new ErrorMessage("Driver not initialized");
				return;
			}
		}
		
		System.out.println("initialize_driver(" + drivername + ")");
	}
	
	void RELEASE(String taskname)
	{
		
		if ((react.taskList == null) || (react.taskList.isEmpty()))
		{
			new ErrorMessage("There are 0 tasks available...");
			return;
		}
		
		//// parse taskList for task with taskname
		for (int i=0; i<react.taskList.size(); i++)
		{
			Task t = (Task)react.taskList.elementAt(i);
			
			//// if task found -> add it to readyqueue
			if (t.name.compareTo(taskname) == 0)
			{
				react.releasePort.addElement(t);
				System.out.println("release(" + taskname + ")" + " taskid: " + t.ID);
				return;
			}
		}
		new ErrorMessage("Task " + taskname + " not found");
	}
	
	//// address is line-number in e-code-file
	//// time in milliseconds
	void FUTURE(String address, int time)
	{
		int codeline = getLineNumber(address);
		Event jumpToCodeline = new Event(codeline);
		Trigger futureTrigger = new Trigger(time, jumpToCodeline.ID);

		System.out.println("future(" + time + "," + address + ")");	
	}
	
	void FUTURE(String triggername, String address)
	{
		int codeline = getLineNumber(address);
		Event jumpToCodeline = new Event(codeline);
		Trigger futureTrigger = new Trigger(triggername, jumpToCodeline.ID);
		
		System.out.println("future(" + triggername + "," + address + ")");
	}
	//// if trigger <triggername> is true then continue at address
	//// else continue interpreting e-code at next line
	void IF(String triggername, String address)
	{
		if ((react.triggerQueue == null) || (react.triggerQueue.isEmpty() == true))
		{
			new ErrorMessage("Trigger " + triggername + " not defined.");
			return;
		}
		
		int sizeTriggerQueue = react.triggerQueue.size();
		for (int i=0; i<sizeTriggerQueue; i++)
		{
			Trigger trigger = (Trigger)react.triggerQueue.elementAt(i);
			if ((trigger.name == triggername) && (trigger.active == true))
			{
				int codelineNumber = getLineNumber(address);
				parseCode(codelineNumber);
				return;
			}
		}
		
	}
	
	//// jump to e-code at line address
	void JUMP(String address)
	{
		int codelineNumber = getLineNumber(address);
		parseCode(codelineNumber);
	}
	
	//// returns linenumber of jumppoint "address"
	//// if jumppoint doesn't exist: return (-1)
	int getLineNumber(String address)
	{
		address = address.trim();
		
		if ((jumpPoints == null) || (jumpPoints.containsKey(address) == false))
		{
			new ErrorMessage("JumpPoint " + address + " not found");
			return (-1);
		}
		else
		{
			Integer integerLineNumber = (Integer)jumpPoints.get(address);
			if (integerLineNumber == null)
			{
				new ErrorMessage("Internal Error - JumpPoint(JUMP)");
			}
			
			int lineNumber = integerLineNumber.intValue();
			return lineNumber;
		}
	}
	
	
	public void parseJumpPoints()
	{
		for (int i=0; i<instructions.size(); i++)
		{
			String currentInstruction = instructions.elementAt(i).toString();
			currentInstruction.toLowerCase();
			
			int firstStart=0;
			int firstStop=0;
			
			currentInstruction = currentInstruction.trim();
			char characters[] = currentInstruction.toCharArray();
			
			if(currentInstruction.matches("^.+:$"))
			{
				for (int j=0; j<characters.length; j++)
				{
					firstStart = 0;
					if (characters[j] == ':')
					{
						firstStop = j;
					}
					
				}
				
				String jumpPoint = currentInstruction.substring(firstStart, firstStop);
				System.out.println("jumppoint " + jumpPoint + " at line " + i);
				
				Integer currentLineNumber;
				currentLineNumber = new Integer(i);

				if ((jumpPoints == null) || (jumpPoints.containsKey(jumpPoint) == false))
				{
					jumpPoints.put(jumpPoint, currentLineNumber);
				}
			
			}  // if(currentInstruction.matches("^.+:$"))
			
		} // for (int i=0; i<instructions.size(); i++)
	}  // public void parseJumpPoints()
	
	
	//// runs E-Code beginning from line 0 
	public void parseCode()
	{
		parseCode(0);
	}

	
	//// runs the instructions from File from startAddress
	public void parseCode(int startAddress)
	{
		System.out.println("-------------------PARSING ECODE");
		if (startAddress > instructions.size())
		{
			new ErrorMessage("Invalid e-code address");
			return;
		}
		for (int i=startAddress; i<instructions.size(); i++)
		{
			
			String currentInstruction = instructions.elementAt(i).toString();
			currentInstruction.toLowerCase();
			
			int firstStart=0;
			int firstStop=0;
			int secondStart=0;
			int secondStop=0;
			
			currentInstruction = currentInstruction.trim();
			char characters[] = currentInstruction.toCharArray();
			
			//System.out.println(currentInstruction);
			System.out.print("time:" + react.logicalTime + " - E-Code: ");
			
			//// FUTURE
			if (currentInstruction.matches("^future(.+,.+)$"))
			{
				//System.out.println("FUTURE");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ',')
					{
						firstStop = j;
						secondStart = j+1;
					}
					if (characters[j] == ')')
					{
						secondStop = j;
					}
				}
				
				String strTriggername = currentInstruction.substring(firstStart, firstStop);
				String strAddress = currentInstruction.substring(secondStart, secondStop);
				
				
				//// call the method
				FUTURE(strTriggername, strAddress);
				
	
			}
			//// empty line
			else if(currentInstruction.compareTo("") == 0)
			{
				System.out.println("empty line");
				continue;
			}
			//// JUMP-POINT
			else if(currentInstruction.matches("^.+:$"))
			{
				System.out.println(currentInstruction);
				continue;			
			}
			//// COMMENT: comment lines start with a # 
			else if(currentInstruction.matches("^#.*$"))
			{
				//System.out.println("COMMENT");
				continue;
			}
			//// INITIALIZE - creates a new task with taskname
			else if(currentInstruction.matches("^initialize(.+)$"))
			{
				//System.out.println("INITIALIZE_TASK");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String taskname = currentInstruction.substring(firstStart, firstStop);

				INITIALIZE(taskname);
			}
			//// call - calls a driver
			else if(currentInstruction.matches("^call(.+)$"))
			{
				//System.out.println("call");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String drivername = currentInstruction.substring(firstStart, firstStop);

				CALL(drivername);
			}
			//// RELEASE - puts task taskname in ready-queue
			else if(currentInstruction.matches("^release(.+)$"))
			{
				//System.out.println("RELEASE");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String taskname = currentInstruction.substring(firstStart, firstStop);

				RELEASE(taskname);
			}
			//// IF
			else if(currentInstruction.matches("^if(.+,.+)$"))
			{
				//System.out.println("IF");
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ',')
					{
						firstStop = j;
						secondStart = j+1;
					}
					if (characters[j] == ')')
					{
						secondStop = j;
					}
				}
				String triggername = currentInstruction.substring(firstStart, firstStop);
				String address = currentInstruction.substring(secondStart, secondStop);

				//// call the method
				IF(triggername, address);
				
			}
			//// JUMP
			else if(currentInstruction.matches("^jump(.+)$"))
			{
				for (int j=0; j<characters.length; j++)
				{
					if (characters[j] == '(')
					{
						firstStart = j+1;
					}
					if (characters[j] == ')')
					{
						firstStop = j;
					}
				}
				String strAddress = currentInstruction.substring(firstStart, firstStop);
				
				JUMP(strAddress);

			}
			//// RETURN - quits e-code interpretation.
			else if(currentInstruction.matches("^return$"))
			{
				//Thread.currentThread().stop();
				System.out.println("return");
				return;
			}
			//// Syntax-Error
			else
			{
				new ErrorMessage("E-Code Syntax Error at line " + (i+1));
			}
			
		} // for (int i=0; i<instructions.size(); i++)
	} // void callMethods 	
	
	



} //class EcodeInterpreter	

class ErrorMessage
{
	public ErrorMessage(String msg)
	{
		System.out.println("An Error has occured: " + msg);
	}

}

	
//  // class react

