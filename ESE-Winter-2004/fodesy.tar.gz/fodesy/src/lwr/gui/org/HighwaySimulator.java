/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lwr.gui.org;
/**
 * @author root
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
//import net.tinyos.message.*;
//import net.tinyos.werna.*;
import lrw.msg.org.*;

public class HighwaySimulator extends JFrame implements Runnable{

	//private JPanel simField;

	private JPanel contrField;

	private JMenuBar menu = new JMenuBar();

	private WindowClosingAdapter adp = new WindowClosingAdapter(true);

	public JPanel cp;
    public SimField simField;
	private Image img, imgCar;
	private CarComponent car = new CarComponent("Car");
	private int xCoord = 560, yCoord = 160;
	private int width=70,height=20;
	private JTextField id,id2,id3,id4;
	private JTextField hum, hum2,hum3, hum4;
	private JTextField temp, temp2, temp3, temp4;
	private ArrayList output = new ArrayList();
	Controller controller;
	
	public HighwaySimulator(Controller controller) {
		super("HighwaySimulator 1.0");
		this.controller = controller;
		cp = (JPanel) this.getContentPane();
		cp.setLayout(null);
		this.setLocation(10, 10);
		this.setSize(1000, 600);
		this.menu.add(createMenu());
		this.setJMenuBar(menu);
		this.addWindowListener(adp);
		simField = new SimField();		
		cp.add(simField);
		this.createOutputFields();
		this.setMotes();				
		controller.setSim(this);
		this.startHighwayAnim();
		
	}

	/**
	 * controller is needed to control the dataflow between the model (MessageFormater) and
	 * the gui
	 * @param controller
	 */
	public void setController(Controller controller){
		this.controller = controller;
	}
	
	/**
	 * creates all the JTextFields to show data of each mote on the simulator
	 * temperature, humidity, moteID, parent
	 */
	private void createOutputFields(){		
		int objField = 5;
		int xCoord = 100, yCoord = 60;
		int width = 50, height = 20;
		for(int i=0; i<objField; i++){
			JTextField outField[] = new JTextField[5];
			for(int j=0; j<outField.length; j++){
				outField[j] = new JTextField();
				outField[j].setEditable(false);
				outField[j].setBounds(xCoord, yCoord, width, height);
				cp.add(outField[j]);
				yCoord += 30;
			}
			xCoord += 205;
			yCoord = 60;
			output.add(outField);
		}
	}

	/**
	 * creates the menu and menuitems, will be added to the menubar
	 * @return
	 */
	private JMenu createMenu() {
		JMenu men = new JMenu("Options");
		JMenuItem init = new JMenuItem("Init Mote");
		init.addActionListener(controller);
		men.add(init);
		return men;
	}
	
	/**
	 * starts the animation
	 *
	 */
	public void startHighwayAnim(){
		Thread t = new Thread(this);
		t.start();
	}
    
	/**
	 * invokes the repaint thread
	 * important for the simulation
	 */
	int slp = 40;
	/**
	 * run method is always invoked by the thread.start() function
	 * repaints the simulator picture every 40ms when no fog is on 
	 * the highway, if there is one repaint will be called every 70ms
	 * so that it looks like that the cars are driving slowlier
	 */
	public void run(){
		while(true){
			repaint();
			try{
				Thread.sleep(slp);
			}catch(InterruptedException e){
				System.out.println(e.toString());
			}
		}
	}
	
	/**
	 * inits all the labels on the screen
	 * each mote (we have five) are listed on the screen with
	 * their data (temp,humidity, parentID, fog/no fog)
	 */
	private void setMotes(){
		JLabel motes[] = new JLabel[5];
		JLabel motesID[] = new JLabel[5];
		JLabel motesHum[] = new JLabel[5];
		JLabel motesTmp[] = new JLabel[5];
		JLabel motesFog[] = new JLabel[5];
		int x=5,y=50;
		int xID = 5, yID = 60;
		int xHum = 5, yHum = 90;
		int xTmp = 5, yTmp = 120;
		int xFog = 5, yFog = 150;
		for(int i=0; i<motes.length; i++){
			motes[i] = new JLabel("Mote "+(i+1));
			motes[i].setBounds(x,y,width,height);
			motesID[i] = new JLabel("ID: ");
			motesID[i].setBounds(xID,yID,width,height);
			motesHum[i] = new JLabel("Humidity: ");
			motesHum[i].setBounds(xHum,yHum,width,height);
			motesTmp[i] = new JLabel("Temperature: ");
			motesTmp[i].setBounds(xTmp,yTmp,width,height);
			motesFog[i] = new JLabel("Fog: ");
			motesFog[i].setBounds(xFog,yFog,width, height);
			x += 210;
			xID += 210;
			xHum += 210;
			xTmp += 210;
			xFog += 210;
			cp.add(motes[i]);
			cp.add(motesID[i]);
			cp.add(motesHum[i]);
			cp.add(motesTmp[i]);
			cp.add(motesFog[i]);
		}		
	}
	
	/**
	 * prints data of each mote on the simulator
	 * when fog is detected then the background of the field
	 * will change from green to red
	 * @param data
	 */
	public void addData(String[] data){
		int dat = Integer.parseInt(data[0]);
		System.out.println("Mote ID: "+dat);
		if(dat <= 5 ){
		JTextField[] fields = (JTextField[])output.get(dat - 1);
		System.out.println("Fieldlength:  "+fields.length);
		
		setRegisteredMote(dat);
		for(int i=0; i<fields.length; i++){
			fields[i].setText(data[i]);
			if(data[i].equals("true")){
				slp = 70;
				fields[i].setBackground(Color.RED);
			}
			else if(data[i].equals("false")){
				fields[i].setBackground(Color.GREEN);
				slp = 40;
			}
		}
		}
	}
	
	/**
	 * each mote the got the init message will be shown on the
	 * highway simulator
	 * @param moteID
	 */
	public void setRegisteredMote(int moteID){
		simField.setMote(moteID);
	}
	
	/**
	 * if the mote dies, it disappear on the screen/simulator 
	 */
	public void unsetRegisteredMote(int moteID){
		simField.unsetMote(moteID);
	}
}