/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lwr.gui.org;

/**
 * @author root
 * the functions of this class is to shut down the application
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
import java.awt.*;
import java.awt.event.*;

public class WindowClosingAdapter extends WindowAdapter {
	
	private boolean exitSystem;
	
	public WindowClosingAdapter(boolean exitSystem){
		this.exitSystem = exitSystem;
	}
	
	public WindowClosingAdapter(){
		this(false);
	}
	
	public void windowClosing(WindowEvent e){
		e.getWindow().setVisible(false);
		e.getWindow().dispose();
		if(exitSystem)
			System.exit(0);
	}

}
