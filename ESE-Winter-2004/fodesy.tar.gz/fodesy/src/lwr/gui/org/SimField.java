/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lwr.gui.org;

/**
 * @author root
 * SimulatorPanel is responsible for animation
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class SimField extends JPanel {

	private Image imgHighway, imgCar, imgCar2, imgCar3, imgCar4;

	private Image mote_1, mote_2, mote_3, mote_4, mote_5;

	private MediaTracker mt;

	private int xCoord = 990, yCoord = 160, xCoord2 = 990, yCoord2 = 230;

	private int xCoord3 = 600, yCoord3 = 160;

	private int xCoord4 = 2, yCoord4 = 330;

	private int blink = 0;

	boolean mote1 = false, mote2 = false, mote3 = false, mote4 = false, mote5 = false;
	boolean isHighwSet = false;
	//boolean mote1 = true, mote2 = true, mote3 = true, mote4 = true;
	public SimField() {
		this.setLayout(null);
		this.setBounds(3, 100, 1000, 500);
		this.setDoubleBuffered(true);
		imgHighway = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "highway.bmp");
		imgCar = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "ck.png");
		imgCar2 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "schiff.png");
		imgCar3 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "car2.png");

		imgCar4 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "fast_car.png");

		mote_1 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "moteWerna.gif");
		mote_2 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "moteWerna.gif");

		mote_3 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "moteWerna.gif");

		mote_4 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "moteWerna.gif");
		
		mote_5 = this.getToolkit().getImage(
				"/opt/eclipse/workspace/mote2/pictures/" + "moteWerna.gif");

		MediaTracker mt = new MediaTracker(this);

		mt.addImage(imgHighway, 0);
		mt.addImage(imgCar, 1);
		mt.addImage(imgCar2, 2);
		mt.addImage(imgCar3, 3);
		mt.addImage(imgCar4, 4);
		mt.addImage(mote_1, 5);
		mt.addImage(mote_2, 6);
		mt.addImage(mote_3, 7);
		mt.addImage(mote_4, 8);
		mt.addImage(mote_5, 8);
		
		try {
			mt.waitForAll();
		} catch (InterruptedException e) {
			//
		}
	}

	public void paint(Graphics g) {
		
			g.drawImage(imgHighway, 0, 150, 1000, 300, this);

		
		if (xCoord <= 0)
			xCoord = 990;
		else if (xCoord2 <= 0)
			xCoord2 = 990;
		else if (xCoord3 <= 0)
			xCoord3 = 990;
		else if (xCoord4 >= 990)
			xCoord4 = 2;

		g.drawImage(imgCar, xCoord, yCoord, 50, 30, this);
		g.drawImage(imgCar2, xCoord2, yCoord2, 50, 30, this);
		g.drawImage(imgCar3, xCoord3, yCoord3, 50, 30, this);
		g.drawImage(imgCar4, xCoord4, yCoord4, 50, 30, this);
		if (blink < 4) {
			if (mote1)
				g.drawImage(mote_1, 20, 290, 30, 20, this);
			if (mote2)
				g.drawImage(mote_2, 280, 290, 30, 20, this);
			if (mote3)
				g.drawImage(mote_3, 520, 290, 30, 20, this);
			if (mote4)
				g.drawImage(mote_4, 760, 290, 30, 20, this);
			if (mote4)
				g.drawImage(mote_4, 900, 290, 30, 20, this);
			blink++;
		} else if (blink >= 4 && blink <= 8) {
			if (mote1)
				g.drawImage(mote_1, 20, 290, 30, 20, this);
			if (mote2)
				g.drawImage(mote_2, 280, 290, 30, 20, this);
			if (mote3)
				g.drawImage(mote_3, 520, 290, 30, 20, this);
			if (mote4)
				g.drawImage(mote_4, 760, 290, 30, 20, this);
			if (mote5)
				g.drawImage(mote_4, 900, 290, 30, 20, this);
			blink++;
		} else
			blink = 0;
		xCoord2 -= 6;
		xCoord3 -= 4;
		xCoord -= 4;
		xCoord4 += 5;
	}

	/**
	 * when a mote is initialized than it will 
	 * also appear on the screen
	 * @param mote
	 */
	public void setMote(int mote) {
		switch (mote) {
		case 1:
			mote1 = true;
			break;
		case 2:
			mote2 = true;
			break;
		case 3:
			mote3 = true;
			break;
		case 4:
			mote4 = true;
			break;
		case 5:
			mote5 = true;
		break;
	}
	}

	public void unsetMote(int mote) {
		switch (mote) {
		case 1:
			mote1 = false;
			break;
		case 2:
			mote2 = false;
			break;
		case 3:
			mote3 = false;
			break;
		case 4:
			mote4 = false;
			break;
		case 5:
			mote5 = true;
			break;
		}
	}

	public void startCar() {
		while (true) {
			repaint();
			try {
				Thread.sleep(40);
			} catch (InterruptedException e) {
				System.out.println(e.toString());
			}
		}
	}
}