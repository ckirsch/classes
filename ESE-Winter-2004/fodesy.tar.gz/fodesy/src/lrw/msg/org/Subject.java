/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lrw.msg.org;

/**
 * @author root
 * Subject Interface must be used by each Object that will invoke update method
 * of an observer, in out case MessageFormater is a subject and Controller is 
 * the observer object
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Subject {
	public void attach(Observer observer);
	public void fireUpdate();
	public String[] getMoteData();
}
