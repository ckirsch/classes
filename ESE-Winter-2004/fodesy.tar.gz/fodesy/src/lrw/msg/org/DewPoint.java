package lrw.msg.org;

public class DewPoint {

	/**
	 * isFog calculates wether there is fog or not
	 * 
	 * @param short
	 *            dataArray data out of FodesyMsg
	 */
	double dewPoint;

	//public boolean isFog(short dataArray[]) {
	public boolean isFog(double tmp, double humid) {
		boolean fog = false;
		double temp, dewPoint, svp, vp, v;
		double a, b; //Parameters
		//double relHum = this.getRelativeHum(dataArray);
		//temp = this.getTemperature(dataArray);
		double relHum = humid;
		temp = tmp;
		if (temp >= 0.0) {
			a = 7.5;
			b = 237.3;
		} else {
			a = 7.6;
			b = 240.7;
		}
		svp = 6.1078 * Math.pow(10, ((7.5 * temp) / (237.3 + temp))); //saturation
		// vapor
		// pressure
		// over
		// water
		vp = relHum / 100 * svp; //vapor pressure
		v = Math.log(vp / 6.1078) / Math.log(10);
		dewPoint = 237.3 * v / (7.5 - v); //Dewpoint
		this.dewPoint = dewPoint; //used for method getDewPoint
		if (Math.floor(temp) <= Math.floor(dewPoint))
			fog = true;
		return fog;
	}

	/**
	 * getTemperature returns the current temperature in ??C
	 * 
	 * @param dataArray
	 */
	public double getTemperature(short dataArray[]) {
		double d1 = -39.60, d2 = 0.009, temp;
		int tmpRaw;
		tmpRaw = dataArray[1] << 8 | dataArray[0];
		temp = d1 + d2 * (double) tmpRaw;
		return temp;
	}

	/**
	 * getRelativeHum return the relative humidity in %
	 * 
	 * @param dataArray
	 */
	public double getRelativeHum(short dataArray[]) {
		double linHum, relHum;
		int humRaw;
		double temp = this.getTemperature(dataArray);
		humRaw = dataArray[3] << 8 | dataArray[2];
		linHum = -4 + 0.0405 * humRaw + -2.8e-6 * humRaw; //linear relative
		// Humidity not
		// accurate enough
		relHum = (temp - 25) * (0.01 + 0.0001 * humRaw) + linHum; //relative
		// Humidity
		return relHum;
	}

	/**
	 * getDewPoint returns the dewpoint
	 *  
	 */
	public double getDewPoint() {
		return this.dewPoint;
	}

}