/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lrw.msg.org;

/**
 * @author root
 * 
 * The controller interacts between the gui and the MessageFormater. It will
 * receive new messages that will then be visualized on the screen by
 * the GUI object
 */
import lwr.gui.org.*;
import java.awt.event.*;

public class Controller implements Observer, ActionListener{
	
	HighwaySimulator sim;
	MessageFormater msgFormater;
	public Controller(MessageFormater msgFormater){
		this.msgFormater = msgFormater;
		msgFormater.attach(this);
	}
	
	
	/**
	 * will be invoked by the subject -> MessageFormater
	 */
	public void update(Subject subject){
		String[] moteData =subject.getMoteData();
		sim.addData(moteData);
	}
	
	/**
	 * opens the gui
	 * @param sim
	 */
	public void setSim(HighwaySimulator sim){
		this.sim = sim;
		this.initGui();
	}
	
	private void initGui(){
		sim.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent event){		
		if(event.getActionCommand().equals("Init Mote")){
			System.out.println("action Init");
			msgFormater.createInitMsg();
		}
	}
}
