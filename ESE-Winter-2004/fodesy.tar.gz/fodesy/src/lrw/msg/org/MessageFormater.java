/*
 * Created on Jan 21, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lrw.msg.org;

/**
 * @author root MessageFormater will receive messages from one mote including
 *         all the data from all nodes in the datafield from TOS_Msg struct.
 *         After receiving, MessageFormater will process the data into a
 *         readable format which can then be displayed the screen
 *  
 */
import net.tinyos.message.*;
import net.tinyos.werna.*;
import lwr.gui.org.*;
import java.util.ArrayList;
import java.lang.Math.*;

public class MessageFormater implements MessageListener, Subject {

	// private FodesyMsg myMsg = new FodesyMsg();
	private FodesyMsg myMsg = new FodesyMsg();

	private MoteIF mote = new MoteIF((net.tinyos.util.Messenger) null);

	private Observer[] observers = new Observer[3];

	private int observerCnt = 0;

	private int msgCounter1 = 0, msgCounter2 = 0, msgCounter3 = 0,
			msgCounter4 = 0;

	private ArrayList[] msgs = new ArrayList[5];

	private String[] moteData;

	private DewPoint dP = new DewPoint();

	FodesyMsg fod = new FodesyMsg();

	public MessageFormater() {
		mote.registerListener(myMsg, this);
		fod.set_initMsg((short) 1);
		fod.set_sourceMoteID((short) 0);

		msgs[0] = new ArrayList();
		msgs[1] = new ArrayList();
		msgs[2] = new ArrayList();
		msgs[3] = new ArrayList();
		msgs[4] = new ArrayList();
	}

	/**
	 * each observer object that wants to register himself by a subject has to
	 * call the attach function, otherwise the subject will not be able to
	 * inform it when that state in our when it receives an new message
	 * 
	 * @param observer
	 */
	public void attach(Observer observer) {
		System.out.println("new Observer attached");
		if (observerCnt < observers.length)
			observers[observerCnt++] = observer;
	}

	/**
	 * informs the observer object on receiving new messages from the motes
	 */
	public void fireUpdate() {
		System.out.println("in fireUpdate function");
		for (int i = 0; i < observerCnt; i++) {
			observers[i].update(this);
		}
	}

	/**
	 * notifies MessageFormater when a new message has been received
	 * (non-Javadoc)
	 * 
	 * @see net.tinyos.message.MessageListener#messageReceived(int,
	 *      net.tinyos.message.Message)
	 */
	public void messageReceived(int dstaddr, Message msg) {
		myMsg = (FodesyMsg) msg;
		System.out.println("in messageReceived function");
		System.out.println("MessageType " + myMsg.get_initMsg());
		this.setMoteMsgs(myMsg);
	}

	/***************************************************************************
	 * After 20 messages it calcs the average temp und humidity and also if
	 * there occures fog somewhere on the highway
	 */
	private void setMoteMsgs(FodesyMsg moteMsg) {
		System.out.println("in setMoteMsgs function");
		double temp = 0.0;
		double humidRel = 0.0;
		int j = 0;

		String[] moteData = new String[5];
		humidRel = dP.getRelativeHum(moteMsg.get_data());
		temp = dP.getTemperature(moteMsg.get_data());
		boolean isFog = dP.isFog(temp, humidRel);

		moteData[0] = String.valueOf(moteMsg.get_originaddr());
		moteData[1] = String.valueOf(humidRel);
		moteData[2] = String.valueOf(temp);
		moteData[3] = String.valueOf(isFog);
		moteData[4] = String.valueOf(moteMsg.get_sourceMoteID());
		this.setMoteData(moteData);
		this.fireUpdate();
	}

	/**
	 * sends a message to the mote connected to the pc
	 * 
	 * @param message
	 */
	public void sendMsg(FodesyMsg message) {
		System.out.println("in sendMsg function");
		try {
			mote.send(1, (Message) message);
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}

	/**
	 * creates the init message that is used to initialize the mote network
	 */
	public void createInitMsg() {
		System.out.println("in createIntiMsg function");
		FodesyMsg initMsg = new FodesyMsg();
		initMsg.set_initMsg((short) (1));
		initMsg.set_sourceMoteID((short) 0);
		initMsg.setElement_data(0, (short) 0);
		initMsg.setElement_data(0, (short) 0);
		this.sendMsg(initMsg);
	}

	/**
	 * sets the data that will be displayed afterwards by the gui into moteData
	 * array
	 *  
	 */
	public void setMoteData(String[] data) {
		this.moteData = data;
	}

	/**
	 * will be called by the controller on update and sends the data array to
	 * the gui
	 */
	public String[] getMoteData() {
		return this.moteData;
	}

	public MoteIF getMote() {
		return this.mote;
	}

	public FodesyMsg getFodesyMsg() {
		return this.myMsg;
	}

	/**
	 * FodesyMsg structure, each structure is saved in in the arrayList msgs[].
	 * 
	 * @author root
	 * 
	 * TODO To change the template for this generated type comment go to Window -
	 * Preferences - Java - Code Style - Code Templates
	 */
	class MoteMsg {
		short sourceMoteID;

		short originaddr;

		short initMsg;

		short[] data;

		/*
		 * getter and setter methods of the FodesyMsg
		 */

		public void setSourceID(short sourceID) {
			this.sourceMoteID = sourceID;
		}

		public void setOriginaddr(short originaddr) {
			this.originaddr = originaddr;
		}

		public void setInitMsg(short initMsg) {
			this.initMsg = initMsg;
		}

		public void setData(short[] data) {
			this.data = data;
		}

		public short getSourceID() {
			return this.sourceMoteID;
		}

		public short getOriginaddr() {
			return this.originaddr;
		}

		public short getInitMsg() {
			return this.initMsg;
		}

		public short[] getData() {
			return this.data;
		}
	}
}