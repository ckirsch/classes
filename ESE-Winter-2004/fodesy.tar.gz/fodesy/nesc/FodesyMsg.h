/** Fodesy Msg type definition (42)
 *  use free, at own risk, imagine the gpl text here
 *  Dittrich Rudi, rdittirch
 *  Findeisen Lutz, lfindeis
 *  Gitschthaler Werner, wgitscht @ cosy.sbg.ac.at
**/
enum {
  BUFFER_SIZE = 9
};

struct FodesyMsg
{
    uint8_t sourceMoteID;
	uint8_t originaddr;
	uint8_t hopcount;
	uint8_t initMsg; // 0 data, 1 do_init,2 info after init pass to parent !!
    uint8_t data[BUFFER_SIZE];
};

enum {
  AM_FODESYMSG = 42
};
