/* File: tasks.h (c) Harald Roeck jan 2005
 *
 * Definition and implementation of a small task framework.
 * A task is a function which runs in a separate thread
 * over and over again until it is stopped or finished,
 * however it stops always at the end of a run.
 *
 */

#ifndef _TASKS_H_
#define _TASKS_H_

#include <semaphore.h>
#include <unistd.h>

#ifndef MAX_TASKS
#define MAX_TASKS 10
#endif

/* type for pointer to task function */
typedef void (*func) ();
/* task datastructure */
typedef struct _task
{
  tid_t id;                     /* thread id */
  sem_t start;                  /* start signal */
  sem_t stop;                   /* stop signal */
  sem_t finish;                 /* finish signal */
  sem_t started;                /* started flag */
  sem_t stopped;                /* stopped flag */
  sem_t finished;               /* finishd flag */
  func start_func;              /* task function */
} task_t;

/* static allocation of all tasks */
static task_t tasks[MAX_TASKS];
/* initiated tasks in the system */
static int task_count = 0;

/* returns a pointer to a new task */
/* tasks are never freed */
task_t *new_task();

/* returns the task for a thread id */
task_t *find_task(tid_t id);

/* initialice the task */
void init_task(task_t * task, func start_func);

/* run task unitl stop task is called */
void run_task(task_t * task);

/* stop a running task */
void stop_task(task_t * task);

/* kill a task */
void finish_task(task_t * task);

/* check if a task is finished */
int task_finished(task_t * task);

/* get current task */
task_t *task_current();

/* task try_wait */
int task_signal(task_t * task);

/* wait until task stops */
void wait_task_stop(task_t * task);

/**********************************************************************
 * implementation
 **********************************************************************/

/* check if task received a signal */
int task_signal(task_t * task)
{
  if (task->start || task->stop || task->finish)
    return 1;

  return 0;
}

/* returns the task to the current thread 
 * or NULL if no task for this thread is registered
 */
task_t *task_current()
{
  extern tdata_t *ctid;
  return find_task((tid_t) ctid);
}

/* returns a pointer to a empty task */
task_t *new_task()
{
  if (task_count >= MAX_TASKS)
    return NULL;

  return &tasks[task_count++];
}

task_t *find_task(tid_t id)
{
  int i = 0;
  for (i = 0; i < task_count; ++i)
    if (tasks[i].id == id)
      return &tasks[i];

  return NULL;
}

/* helper function: this is the 
 * brickOS thread for a task
 */
static int _start_thread()
{
  task_t *task = task_current();
  do
  {
    sem_init(&task->started, 0, 0);
    sem_wait(&task->start);
    sem_post(&task->started);
    while (sem_trywait(&task->stop) == -1 && !shutdown_requested())
    {
      task->start_func();
    }
    sem_post(&task->stopped);
  }
  while (sem_trywait(&task->finish) == -1 && !shutdown_requested());
  sem_post(&task->finished);
  exit(0);
}

void init_task(task_t * task, func start_func)
{
  /* set the task function */
  task->start_func = start_func;
  /* initiate semaphores */
  sem_init(&task->finished, 0, 0);
  sem_init(&task->finish, 0, 0);
  sem_init(&task->start, 0, 0);
  sem_init(&task->stop, 0, 0);
  sem_init(&task->stopped, 0, 0);

  /* start the thread */
  task->id = execi(_start_thread, 0, NULL, PRIO_NORMAL, DEFAULT_STACK_SIZE);
}

/* give a task the signal to run */
void run_task(task_t * task)
{
  sem_init(&task->stopped, 0, 0);
  sem_init(&task->stop, 0, 0);
  sem_post(&task->start);
}

/* give task signal to stop */
void stop_task(task_t * task)
{
  sem_post(&task->stop);
}

/* wait until the task stops */
void wait_task_stop(task_t * task)
{
  sem_wait(&task->stopped);
}

/* check if a task is finished */
int task_finished(task_t * task)
{
  int sval;
  sem_getvalue(&task->finished, &sval);
  return sval > 0;
}

/* signal a task to finish */
void finish_task(task_t * task)
{
  if (!task_finished(task))
  {
    sem_post(&task->finish);
    stop_task(task);
    run_task(task);
  }
}

typedef struct _task *task;

#endif
