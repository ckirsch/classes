/* File: james.c (c) Harald Roeck dec 2004/jan 2005
 *
 * Implementation for Butler James: a lego robot which
 * brings a plant to the light and observers the light 
 * source
 *
 */

#include <config.h>
#if defined(CONF_DSENSOR) && defined(CONF_DMOTOR)

#include <conio.h>
#include <unistd.h>

#include <dsensor.h>
#include <dmotor.h>
#include <semaphore.h>

#include <sys/lcd.h>
#include <tm.h>

#define MAX_TASKS 4
#include "tasks.h"

/* sensor ports */
#define CANDLESENS     SENSOR_1 /* port for candle sensor */
#define LINESENS       SENSOR_2 /* port for line sensor */
#define TOUCHSENS      TOUCH_3  /* port for the touch sensors */

/* constants for the arm to grab the plant */
#define GRAB_SPEED  (MAX_SPEED/2)
#define OPEN fwd
#define CLOSE rev
/* speed constants */
#define NORMAL_SPEED (2*MAX_SPEED/3)
#define TURN_SPEED   (MAX_SPEED/4)

/* threshold values for the line and light sensors */
#define DARK_THRESH     0x2a
#define BRIGHT_THRESH   0x30
#define CANDLE_THRESH   0x4a

/* some usefull macros */
#define set_speed(speed) \
{ \
	motor_a_speed(speed); \
	motor_c_speed(speed); \
}

#define straight(dir) \
{ \
	motor_a_dir(dir); \
	motor_c_dir(dir); \
}

#define turn_right() \
{ \
		motor_a_dir(rev); \
		motor_c_dir(fwd); \
}

#define turn_left() \
{ \
		motor_a_dir(fwd); \
		motor_c_dir(rev); \
}

/******************************************
 * global tasks
 ******************************************/
task fline, oplant, fcandle;

/******************************************/

/******************************************
 *          control grabbing 
 ******************************************/
wakeup_t touched(wakeup_t data)
{
  if ((data != 0) && task_signal(oplant))
    return -1;

  return TOUCHSENS;
}

wakeup_t not_touched(wakeup_t data)
{
  if (data != 0 && task_signal(oplant))
    return -1;
  return !TOUCHSENS;
}

void grab_close()
{
  motor_b_dir(CLOSE);
  motor_b_speed(GRAB_SPEED);
}

void grab_open()
{
  motor_b_dir(OPEN);
  motor_b_speed(GRAB_SPEED / 4);

  msleep(100);
  wait_event(touched, 0);
  motor_b_speed(GRAB_SPEED / 16);
  wait_event(touched, 0);
  motor_b_dir(brake);
  msleep(500);
  motor_b_speed(0);
}

/************************************************************************/

/***************************************
 * control: following the 
 * black line
 ***************************************/

/* check for black underground */
wakeup_t dark_found(wakeup_t data)
{
  if (data != 0 && task_signal(fline))
    return -1;

#if DEBUG == 1
  unsigned short val = LIGHT(LINESENS);
  cputw(val);
  return val < DARK_THRESH;
#else
  return LIGHT(LINESENS) < DARK_THRESH;
#endif
}

/* check for bright underground */
wakeup_t bright_found(wakeup_t data)
{
  if (task_signal(fline))
    return -1;

#if DEBUG == 1
  unsigned short val = LIGHT(LINESENS);
  cputw(val);
  return val > BRIGHT_THRESH;
#else
  return LIGHT(LINESENS) > BRIGHT_THRESH;
#endif
}

/* task for following a black line */
void fline_task()
{
  cputs("fllw");
  set_speed(NORMAL_SPEED);
  straight(fwd);
  ds_active(&LINESENS);

  if (wait_event(bright_found, 1) != -1)
  {
    cputs("lst");

    set_speed(TURN_SPEED);
    turn_right();

    wait_event(dark_found, 1);
  }

  straight(off);
  set_speed(0);
  ds_passive(&LINESENS);
}

/************************************************************************/

/* task which checks the touch sensors
 * stops the task follow line 
 */
void obs_plant()
{
  wait_event(touched, 1);
  stop_task(fline);
  stop_task(task_current());
}

/************************************************************************/

/* check for light/candle */
wakeup_t candle_found(wakeup_t data)
{
  if (data != 0 && task_signal(fcandle))
    return -1;
#if DEBUG == 2
  unsigned short val = LIGHT(CANDLESENS);
  cputw(val);
  return val > CANDLE_THRESH;
#else
  return LIGHT(CANDLESENS) > CANDLE_THRESH;
#endif
}

/* task which checks for a light source
 * stops the task follow line
 */
void find_candle()
{
  wait_event(candle_found, 1);
  stop_task(fline);
  stop_task(task_current());
}

/* turns james until the candle 
 * is found
 */
void turn_to_light()
{
  set_speed(TURN_SPEED / 2);
  turn_right();
  wait_event(candle_found, 0);

  set_speed(0);
  straight(off);
}

/************************************************************************/

/* observe the light and block
 * until the light goes away
 * checks light source every second 
 */
void observe_light()
{
  while (!shutdown_requested())
  {
    if (LIGHT(CANDLESENS) < CANDLE_THRESH - 0x02)
      break;

    sleep(1);
  }
}

/************************************************************************
 *                              Main
 ************************************************************************/
int main(int argc, char *argv[])
{

  /* alloc and initiate all tasks */
  fcandle = new_task();
  init_task(fcandle, find_candle);

  fline = new_task();
  init_task(fline, fline_task);

  oplant = new_task();
  init_task(oplant, obs_plant);

  while (!shutdown_requested())
  {
    set_speed(TURN_SPEED);
    turn_left();

    ds_active(&LINESENS);
    wait_event(dark_found, 0);
    ds_passive(&LINESENS);
    set_speed(0);
    straight(off);

    /* activate line sensor */
    /* start the task for following the line
     * and the task which checks the touch sensors
     */
    run_task(fline);
    run_task(oplant);

    /* found plant when james stops the 
     * task follow line
     */
    wait_task_stop(fline);
    /* stop checking for the plant */
    //stop_task(oplant);

    /* stop  */
    set_speed(0);
    straight(off);

    /* grab the plant */
    grab_close();

    msleep(1000);

    /* start the task which looks for the candle 
     * and the task for following the line
     */
    run_task(fcandle);
    run_task(fline);

    /* found light source when follow line stops */
    wait_task_stop(fline);
    /* stop */
    set_speed(0);
    straight(off);
    msleep(500);

    /* leave plant */
    grab_open();

    /* push back for a bit */
    straight(rev);
    set_speed(NORMAL_SPEED);
    msleep(800);
    set_speed(0);
    straight(off);

    /* deactivate line sensor */
    ds_passive(&LINESENS);
    /* turn james to the light source */
    turn_to_light();

    /* observe light source */
    observe_light();
  }

  /* finish the tasks */
  finish_task(fline);
  finish_task(oplant);
  finish_task(fcandle);

  return 0;
}

#else
#warning james.c requires CONF_DMOTOR and CONF_DSENSOR
#warning rover demo will do nothing
int main(int argc, char *argv[])
{
  return 0;
}
#endif // CONF_DSENSOR, CONF_DMOTOR
